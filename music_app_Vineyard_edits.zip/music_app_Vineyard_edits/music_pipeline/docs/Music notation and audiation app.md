# Music notation and audiation app — project overview

This document is a living reference for a CLI + Qt6 GUI application that imports music notation from multiple formats (Lilypond, MusicXML, humdrum, MuseData, ABC, and MIDI), transforms it, and exports to LilyPond/MusicXML/MIDI, bundling results for Anki and a (separate, future) custom WebKit practice app.

## Pipeline shape

import  →  (shared in-memory representation)  →  transform (optional, chainable)
        →  export (one or more of: LilyPond+rendered images, MusicXML, MIDI[+mp3])
        →  bundle (Anki package and/or WebKit-app asset manifest)

Both a CLI and a Qt6 GUI sit on top of this as thin front ends. Neither front end contains musical logic — they only collect a job specification (input file(s), which transforms to apply and in what order, which export targets, which bundling target) and hand it to one shared run_job(spec) entry point in the core library. This is what keeps CLI and GUI options in lockstep without duplicating logic.

## Canonical representation

The canonical in-memory representation of parsed
music, from any import source, is a `music21.stream.Score`. We do not define a
custom intermediate data model: music21 carries everything it represents
reliably (pitches, durations, ties, beams, lyrics, key/time/clef, barlines,
repeats, metadata). But music21 is a foundation here, not a lossless carrier,
and the pipeline extends it in three deliberate, documented ways:

1. **Patches and pre/post-processing around music21.** Importers patch known
   library bugs (e.g. the stage-1 MuseData part-name crash, applied
   idempotently by the importer that needs it), transform input text before
   music21 sees it (Humdrum `!!!filter:` records), repair the parsed Score
   afterward (pure-Python satb2gs), or delegate format work to an external
   tool whose output is then imported as MusicXML (MIDI via MuseScore).
   Format-specific parsing that music21 lacks entirely (LilyPond) is done by
   our own reader, which still produces a Score.
2. **A verbatim-XML side channel for content music21 cannot round-trip.**
   Genuine cross-staff notation (one instrument, several staves, notes
   crossing between them) is corrupted by music21's reader/writer even
   with no modification in between. Importers therefore attach
   `score._manual_multistaff_parts` (positions of the affected Parts plus
   hand-built or preserved raw MusicXML), and the MusicXML export splices
   that XML into the file music21 writes. For those parts, the Score's Part
   objects are placeholders; the raw XML is the source of truth.
3. **Disclosed fidelity limits.** Where an importer detects something it
   cannot preserve (multi-staff MuseData, `*staff` changes in **kern,
   LilyPond cross-staff measures that could not be transcribed), it emits a
   specific warning class rather than silently degrading. Warnings are part
   of the import contract, not incidental output.

**Transforms take a Score and return a Score**, and must preserve or
deliberately rebuild any side-channel attributes (see 2). Exporters that can
work from music21 objects alone (MIDI) ignore the side channel; exporters
that must reproduce staff structure (MusicXML, LilyPond) consume it.

[NB: We will revisit the decision not to define our own model if the side channel
grows beyond cross-staff notation.]

Rationale:

- Existing importers (MuseData→MusicXML, Humdrum→MusicXML) and the MusicXML→LilyPond slash-chart exporter already operate on music21 objects directly — reusing the object model avoids two extra translation layers (into a custom IR on import, back out of it on export).
- music21 already models pitch, duration, chords, key/time signature, lyrics, articulations, part structure, etc. adequately for this project's needs.
- MusicXML export and (basic) MIDI export come essentially free via Score.write('musicxml') / Score.write('midi').
- Among other known (and likely unknown) gaps, LilyPond export is an important music21 weakness: itss built-in LilyPond support is old/incomplete, especially for anything stylistically particular (e.g. jazz slash notation). The existing hand-built MusicXML→LilyPond text emitter (from the "slash-chart" script) is the seed of a general LilyPond exporter — it needs generalizing to walk an arbitrary Score rather than being wired to the slash-chart use case specifically.

## Proposed module layout

``````importers/     format -> music21.Score   (musedata, humdrum, musicxml passthrough, future formats)
transforms/    Score -> Score            (transpose, slash-chart reduction, rhythm-strip, etc.)
exporters/
  musicxml.py    Score -> .musicxml        (thin wrapper on music21's writer)
  midi.py        Score -> .mid             (music21 writer, or custom for click tracks / multi-track needs)
  lilypond.py    Score -> .ly -> lilypond binary -> .svg/.png/.pdf
  audio.py       .mid -> .mp3              (timidity/fluidsynth + ffmpeg)
bundlers/
  anki.py        assemble note/media package
  webapp.py      assemble manifest + assets for the custom WebKit app
core/
  pipeline.py    orchestrates import -> transform -> export -> bundle given a job spec
cli.py           argparse/click front end calling core.pipeline
gui/             PySide6 or PyQt6 front end calling the same core.pipeline functions
``````

## Progress to date and additional source materials

(Identify by content, not by filename, though filenames current as of this revision)

- The script import_pipeline.py and all its support modules are built out fairly completely. It successfully imports and processess all of the input formats named above, with some limitations. Further testing may reveal limitations or failures not yet known.
- musicxml_to_lilypond_charts_and_midi.py is a preliminary, mineable script for converting to Lilypond with some of the transforms this app requires. It transposes chord symbols to concert pitch, outputs a LilyPond jazz-slash-notation chord chart, a plain-text chord list, and a MIDI preview (chord progression + metronome click track). Notable internals: KIND_TO_JAZZ (chord-kind → text lookup), jazz_chord_symbol() (assembly/ordering), format_pitch() (accidental spelling), format_modification() (alteration wording), and a separate chord_symbol_for_playback() so MIDI playback is unaffected by any display-text customization.
- File names in the working folder are the user's own organizational choice and are not meaningful identifiers for correlating content across chats — role and content are what matter.

## Work-level metadata (added to the import stage)

Every importer can attach a format-neutral metadata dict to the Score as `score._app_metadata` (schema and helpers: `core/score_metadata.py`; `run_job()` returns it as `JobResult.metadata` and stamps `date_processed`). It is deliberately separate from music21's own `Metadata`. Fields: work/movement titles and numbers, composers/lyricists/arrangers/poets/translators, rights, source, relations, encoders/software, four dates (`date_composed`, `date_arranged`, `date_engraved`, `date_processed`), page `credits`, free-text `comments`, and a `miscellaneous` catch-all so nothing in the source is dropped. There is no stored `title`: use `display_title()` ("Work: Movement").

Readers so far: MusicXML (`importers/musicxml_metadata.py`, reads raw XML; Dorico placeholder credits flagged), Humdrum (`humdrum_metadata.py`, reference records + `!!` comments; **date/**Zeit strings normalized per the Humdrum Reference Manual -- `^` between-range, `|` either-or, `~ ? < >` -- with originals kept in `origin['raw_dates']`; only the per-component `x`/`z` markers are left raw), LilyPond (`lilypond_metadata.py`, `\\header` blocks + leading comments, read from source text). ABC (`abc_metadata.py`: T/C/S/Z/N/H/B/D/F/G/O/R/I fields, `+:` continuations, accent escapes, file header vs tune header, `%` comments; no dates -- ABC has no date field). Still to do: MuseData. `cli.py --show-metadata` prints the dict; `--metadata-json FILE` saves it.

When writing MusicXML, `run_job()` copies title/composer/lyricist/arranger/translator/rights into music21's own metadata (only where music21 has nothing) and suppresses music21's "Music21 Fragment"/"Music21" placeholders, so a score with no title or composer exports none. Poets aren't exported yet (music21 has no slot).

Transforms that build a new Score must call `copy_metadata(old, new)`.

## Tuplet beaming (general repair)

music21 beams by meter position and knows nothing about tuplet groups, so any importer that leaves notes unbeamed (ABC, LilyPond, ...) produced beams that cut across tuplets, plus broken secondary beams in quintuplets and larger groups. `importers/notation_repair.py` fixes this centrally: `run_job()` calls `fix_tuplet_beaming()` for every format. Rules: (1) beams authored in the source (MusicXML, Humdrum L/J markers) are never overridden -- each importer declares `BEAMS_FROM_SOURCE = False` if its beams are only music21-generated (ABC, LilyPond); (2) only measures that are actually wrong are repaired, so correct stock beaming (e.g. a plain eighth joining a following sixteenth triplet) is left alone. The LilyPond cross-staff emitter (`multi_staff_emitter.py`) writes its own MusicXML and uses the same logic via `compute_beam_states()`.

## Humdrum `satb2gs` filter

Embedded `!!!filter: satb2gs` uses a compiled humlib tool ONLY if one already exists (`--satb2gs-bin`, `$SATB2GS_BIN`, PATH, or the cache); otherwise the built-in Python merger (exactly 4 SATB voices) with one short note. Nothing is ever cloned or compiled during an import. `python cli.py --build-satb2gs` builds the full tool on request (maintained repo craigsapp/humlib; `make library`, then `make satb2gsx`). That build path is written but NOT yet verified end to end.

## One file -> many scores; snippets

`core/import_pipeline.py`: `run_job()` is still one file -> one score. `run_job_all()` returns one `JobResult` per resulting score. An importer opts in with `import_scores()` (ABC: every tune, each through the per-tune pipeline on its own; LilyPond: every `\\score`, each with its own `\\header` metadata); `import_score()` still returns the first only, with a warning. Output naming for several results: `<stem>_<NN>_<title-slug>.musicxml`. CLI: `--first-only`, `--no-snippets`.

Snippets (`core/snippets.py`, format-independent): text markers `SS: title` (start), `SR: rhythm name`, `SD: source`, `SE:` (end at this measure); a snippet also ends at any measure with a non-plain right barline, or at the end of the piece. SR/SD before an SS apply to the next snippet. Markers live in the first part that has any. MusicXML: `<words>` text. LilyPond: text annotations, e.g. `c''4^"SS: Warm-up"` or `^\\markup "SS: ..."` -- NOT `%` comments (LilyPond's music dump drops comments, and a comment has no musical position). An extracted snippet is a deep copy of the whole Score (all parts, lyrics, dynamics, ...) cut to the measures, with clef/key/time re-inserted, spanners and ties that crossed the cut removed/trimmed, measures renumbered from 1, markers stripped, and metadata derived from the parent (snippet title -> movement_title, SD -> source, a `snippet` entry with index/count/title/rhythm_name/source/measure range). Not supported: cross-staff LilyPond scores (returned whole). Cost: one deep copy of the score per snippet (~0.25 s each at 200 measures).

## Lyrics

Lyrics live on the notes, in music21's own model (`note.lyrics`: one Lyric per verse, with number and syllabic single/begin/middle/end), so they survive MusicXML export and snippet cutting with no side channel. `core/lyrics.py` reads them back out: `verse_keys()`, `verse_text()`, `to_lyricmode()` (LilyPond `\\lyricmode` text, for the eventual exporter), `all_verses()`; `cli.py --show-lyrics` prints every verse per part. ALL verses are kept (the experimental script read only verse 1).

Import status by format: MusicXML -- native, multi-verse (verified round trip). LilyPond -- done: `\\addlyrics` and `\\lyricsto`, several blocks per voice = verses in source order, aligned by LilyPond's own melisma rules (rests, tied continuations and slurred notes take no syllable; `_` skips a note; a chord takes one); `__` extenders are dropped; manual-beam melismas are missed (beams aren't captured). Humdrum -- music21 attaches `**text` spines only with a `*staff` tandem, keeps only the LAST of several spines (one verse) and gets syllable positions wrong for trailing-hyphen text; not yet handled by us. ABC -- done (`abc_lyrics.py`): `w:` lines aligned per the ABC standard (`-`, lone `-` = one more note, `_` hold, `*` skip, `~` join, `|` next bar, `\\-` literal; several `w:` lines = verses; tied notes are separate notes, unlike LilyPond; not rests or grace notes), matched to the Part's notes BY WRITTEN DURATION so notes music21 split at a measure boundary get one syllable; a voice that can't be matched exactly is skipped with a warning. Not supported: inline `[V:]` voice changes mid-line, `w:` text spanning several music lines. Also fixed: music21 parses `+:` continuation lines as music (phantom notes) -- the ABC importer now joins them onto their field first. MuseData -- stage 2 handled natively by music21 (verses split by `|`, untested here); stage 1 (the Bach cantata files) returns no lyrics; needs a sample vocal stage-1 file. MIDI -- depends on MuseScore; unverified.

## Open questions (revisit as the build proceeds)

- Full transform catalog beyond slash-chart reduction and rhythm-only stripping (transposition, register simplification, part extraction, ornament stripping?) — affects how general the Score -> Score interface needs to be, e.g. whether any transform must add parts/voices rather than only modify existing ones.
- Anki bundling: note-type and media-naming conventions — design from scratch or is there an existing convention to match?
- WebKit-app bundling: does the app expect an existing manifest format, or is that being designed as part of this project too?
Qt6 binding choice: PySide6 (LGPL) vs PyQt6 (GPL/commercial).

## Working conventions

- Clarify ambiguities before implementing; don't proceed on silent assumptions.
- Explain root causes, not just workarounds.
- Verify behavior against real data rather than assumed correctness.
- Prefer plain objects over arrays of pairs for key-value data in JS contexts.
- Iterative, module-by-module work; consolidation passes come after functional completeness, not before.
