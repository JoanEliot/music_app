% Transcribed for practice use.
%{ Second leading comment,
   spanning lines %}
\version "2.24.0"
\language "english"

myTitle = "Never used"

\header {
  title = \markup { Sonata in \italic "G" \bold minor }
  subtitle = "Op. 1, No. 2"
  composer = "Arcangelo Corelli"
  arranger = \myTitle
  opus = "Op. 1"
  copyright = "Public domain \"as is\""
  date = "1681"
  source = "Roma, 1681"
  mutopiacomposer = "CorelliA"
  tagline = ##f
  % a comment inside the header
}

\book {
  \header { instrument = "Violin"  dedication = "For Anna" }
  \score {
    \header { piece = \markup { \fontsize #2 "Adagio" } composer = "Corelli, A." }
    \new Staff { \relative c' { c4 d e f | g1 \bar "|." } }
    \layout { }
  }
  \score {
    \header { piece = "Second score piece (must be ignored)" }
    \new Staff { c'1 }
  }
}
