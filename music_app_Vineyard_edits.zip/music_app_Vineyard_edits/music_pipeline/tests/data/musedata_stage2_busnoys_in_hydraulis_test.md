@muse2psv1==jc90FW1w2250l2770m100
@muse2psv1==T^In hydraulis^
@muse2psv1==C^Antoine Busnoys^
@muse2psv1==s^[(.)(.)(.)(.)]^
@muse2psv1==C^Antoine Busnoys^i2I150v90,90,90,120c122z18l2700t130
Header Record 1: optional copyright notice
Header Record 2: optional file identification
TIMESTAMP: SEP/19/2026 [md5sum:0d0a:818b4b4f91cd8098b6b356555e079998]
12/06/2015 Will Watson 07/11/12
WK#:1 MV#:1
Header Record 6: source
In hydraulis
Haec Okeghem
Superius
Header Record 10
Group memberships: score
score: part 1 of 4
$  K:0   Q:2   T:11/0   C:4
P C0:x0
D4    16      1 B                          In
E4     8      1 w                          hy-
measure 2
F4     8      1 w                          drau-
G4    12      1 w.                         _
F4     4      1 h                          _
measure 3
F4     8      1 w                          _
E4     4      1 h                          _
F4     8      1 w                          _
D4     4      1 h                          _
measure 4
C4     6      1 h.                         _
D4     2      1 q                          _
E4     4      1 h                          _
D4     8      1 w                          _
C4     2      1 q                          _
B3     2      1 q                          _
measure 5
A3     4      1 h                          _
C4     8      1 w                          _
D4     4      1 h                          _
E4     4      1 h                          _
G4     4      1 h                          _
measure 6
F4     4      1 h                          _
E4     6      1 h.                         _
D4     2      1 q                          _
D4     8      1 w                          _
C#4    4      1 h               ^+         _
measure 7
D4    24      1 B.                         lis
measure 8
rest  24      1
measure 9
rest  24      1
measure 10
rest  24      1
measure 11
rest  24      1
measure 12
rest  24      1
measure 13
rest  24      1
measure 14
rest  24      1
measure 15
rest   8      1 w
rest   8      1 w
D4     8      1 w                          me-
measure 16
C4     4      1 h                          _
E4     8      1 w                          _
F4     4      1 h                          _
G4     8      1 w                          _
measure 17
F4     4      1 h                          los
A4     8      1 w                          phon-
G4     4      1 h                          gi-
A4     4      1 h                          ta-
F4     4      1 h                          _
measure 18
E4     4      1 h                          _
A4     8      1 w                          _
F4     4      1 h                          _
G4     4      1 h                          _
E4     4      1 h                          _
measure 19
F4    12      1 w.                         _
G4     4      1 h                          _
A4     8      1 w                          _
measure 20
D4     8      1 w                          tes
rest   8      1 w
rest   8      1 w
measure 21
E4    24      1 B.                         Mal-
measure 22
F4    12      1 w.                         _
D4     4      1 h                          _
D4     8-     1 w              -           le-
measure 23
D4     8      1 w                          _
D4    12      1 w.                         o-
E4     4      1 h                          _
measure 24
F4     4      1 h                          _
G4     8      1 w                          _
F4     8      1 w                          _
E4     4      1 h                          _
measure 25
F4    16      1 B                          rum
rest   8      1 w
measure 26
F4     8      1 w                          per-
A4    12      1 w.                         _
G4     4      1 h                          _
measure 27
E4     8      1 w                          cus-
D4    12      1 w.                         _
C4     4      1 h                          _
measure 28
C4     8      1 w                          sa
rest   8      1 w
D4     8      1 w                          ae-
measure 29
E4     4      1 h                          _
E4     8      1 w                          quo-
D4     4      1 h                          _
C4     6      1 h.                         _
B3     2      1 q                          _
measure 30
A3     4      1 h                          _
D4     6      1 h.                         _
E4     2      1 q                          _
F4     4      1 h                          _
G4     8      1 w                          ra
measure 31
F4    16      1 B                          Per_
A4     8-     1 w              -           _
measure 32
A4     8      1 w                          _
B4    16      1 B                          _
measure 33
C5    12      1 w.                         pon-
B4     4      1 h                          _
G4     8      1 w                          _
measure 34
F4    12      1 w.                         de-
D4     4      1 h                          _
D4     8      1 w                          rum
measure 35
rest   4      1 h
D4     4      1 h                          in_
F4     6      1 h.                         _
G4     2      1 q                          _
A4     4      1 h                          _
D4     4-     1 h              -           ae-
measure 36
D4     4      1 h                          _
A3     8      1 w                          _
D4     4      1 h                          _
C#4    4      1 h               ^+         _
B3     4      1 h                          _
measure 37
D4    12      1 w.                         qua-
F4     6      1 h.                         _
G4     2      1 q                          _
A4     4      1 h                          _
measure 38
Bf4   12      1 w.              ^+         _
A4     4      1 h                          _
F4     6      1 h.                         _
G4     2      1 q                          _
measure 39
E4     4      1 h                          _
A4     8      1 w                          _
G4     2      1 q                          li-
F4     2      1 q                          _
E4     8      1 w                          ta-
measure 40
D4     8      1 w                          tes
rest   8      1 w
rest   8      1 w
measure 41
D4     8      1 w                          Ad-
F4     8      1 w                          _
Bf4    8      1 w                          _
measure 42
A4     4      1 h                          in-
A4     8      1 w                          ve-
F4     4      1 h                          _
G4     8      1 w                          _
measure 43
A4    16      1 B                          nit,
rest   8      1 w
measure 44
A4    16      1 B                          mu-
F4     8      1 w                          _
measure 45
G4     6      1 h.                         _
F4     2      1 q                          _
E4     2      1 q                          _
D4     2      1 q                          _
D4     8      1 w                          _
C#4    4      1 h               ^+         _
measure 46
D4     8      1 w                          sae
F4     8      1 w                          qui-
E4     4      1 h                          _
D4     4      1 h                          _
measure 47
D4     8      1 w                          di-
C4     8      1 w                          _
D4     4      1 h                          _
C4     4      1 h                          _
measure 48
D4    16      1 B                          ta-
B3     6      1 h.                         _
A3     2      1 q                          _
measure 49
A3     8      1 w                          tes.
rest   8      1 w
rest   8      1 w
measure 50
rest  24      1
measure 51
rest   8      1 w
rest   8      1 w
C4     8      1 w                          E-
measure 52
B3    12      1 w.                         pi-
D4     6      1 h.                         tri-
C4     2      1 q                          _
A3     4      1 h                          _
measure 53
Bf3   12      1 w.              ^+         _
G3     6      1 h.                         _
A3     2      1 q                          _
Bf3    4      1 h               ^+         _
measure 54
C4     4      1 h                          _
A3     4      1 h                          _
Bf3    4      1 h               ^+         _
D4     6      1 h.                         _
C4     2      1 q                          _
A3     4      1 h                          _
measure 55
Bf3    4      1 h               ^+         tum
G3     4      1 h                          ac
F3     4      1 h                          he-
G3     2      1 q                          mi-
Bf3    4      1 h               ^+         o-
C4     2      1 q                          _
A3     4      1 h                          li-
measure 56
G3     4      1 h                          am,
rest   4      1 h
F4     4      1 h                          he-
G4     2      1 q                          mi-
Bf4    4      1 h               ^+         o-
C5     2      1 q                          _
A4     4      1 h                          li-
measure 57
G4     6      1 h.                         am,
E4     2      1 q                          ac
F4     4      1 h                          he-
G4     2      1 q                          mi-
E4     4      1 h                          o-
C4     2      1 q                          _
D4     4      1 h                          li-
measure 58
C4     6      1 h.                         am,
A3     2      1 q                          ac
B3     4      1 h                          he-
C4     2      1 q                          mi-
E4     4      1 h                          o-
F4     2      1 q                          _
D4     4      1 h                          li-
measure 59
C4     8      1 w                          am,
B3     4      1 h                          E-
G3     4      1 h                          pog-
A3     8      1 w                          do-
measure 60
G3     4      1 h                          i
B3     4      1 h                          et
A3     4      1 h                          du-
D4     6      1 h.                         plum
C#4    2      1 q               ^+         per-
C#4    2      1 q               ^+         du-
B3     2      1 q                          _
measure 61
D4     8      1 w                          cunt
rest   8      1 w
msilent
rest   8      1 w
measure 62
irst   8      1
P  C1:p1
msilent
rest  16      1 B
measure 63
A4    12      1 w.                         Nam
F4     4-     1 w                          tes-
msilent
F4     4      1 h                          _
P  C1:p1
G4     4      1 h                          _
measure 64
A4     8-     1 w.                         sa-
msilent
A4     4      1 h                          _
P  C1:p1
D4     8      1 w                          ron_
E4     4      1 h                          _
measure 65
F4    16      1 B                          _
msilent
E4     8      1 w                          pen-
measure 66
C4     8      1 w                          _
msilent
D4    12      1 w.                         _
C4     4      1 h                          _
measure 67
C4    16      1 B                          te
msilent
F4     8      1 w                          con-
measure 68
A4     8      1 w                          _
msilent
G4     4      1 h                          _
G4     8      1 w                          cor-
E4     4      1 h                          _
measure 69
F4     8      1 w                          _
G4     8      1 w                          _
msilent
A4     8      1 w                          di-
measure 70
G4     8      1 w                          am
msilent
rest   8      1 w
G4     8      1 w                          Nec
measure 71
F4     4      1 h                          non_
D4     6      1 h.                         _
C4     2      1 q                          _
A3     4      1 h                          _
msilent
Bf3    4      1 h               ^+         _
G3     4-     1 h              -           _
measure 72
G3     4      1 h                          _
D4     4-     1 h.                         phton-
msilent
D4     2      1 q                          _
P  C1:p1
C4     2      1 q                          _
Bf3    4      1 h               ^+         _
A3     8      1 w                          gum
measure 73
G3     4      1 h                          et_
Bf3    6      1 h.              ^+         _
C4     2      1 q                          _
D4     4-     1 w                          _
msilent
D4     4      1 h                          _
P  C1:p1
G4     4-     1 h              -           pa-
measure 74
G4     2      1 q                          _
A4     2      1 q                          _
Bf4    4      1 h               ^+         _
msilent
C5     2      1 q                          _
Bf4    2      1 q               ^+         _
A4     2      1 q                          _
G4     2      1 q                          _
F#4    6      1 h.              ^+         _
E4     2      1 q                          _
measure 75
G4     8      1 w                          son
rest   8      1 w
msilent
rest   8      1 w
measure 76
A4     8      1 w                          ad-
msilent
F4     4      1 h                          _
G4     8      1 w                          du-
E4     4      1 h                          _
measure 77
D4     8      1 w                          cunt,
rest   8      1 w
msilent
rest   8      1 w
measure 78
E4     8      1 w                          ad-
msilent
C4     4      1 h                          _
D4     8      1 w                          du-
B3     4      1 h                          _
measure 79
A3     8      1 w                          cunt
rest   4      1 h
A4     4-     1 h.                         Mo-
msilent
A4     2      1 q                          _
P  C1:p1
G4     2      1 q                          _
F4     2      1 q                          _
E4     2      1 q                          _
measure 80
F4     4      1 h                          no-
E4     4      1 h.                         cor-
msilent
E4     2      1 q                          _
D4     2      1 q                          _
D4     6      1 h.                         _
B3     2      1 q                          _
C#4    4      1 h               ^+         _
measure 81
D4     4      1 h                          di
D4     6      1 h.                         dum_
C4     2      1 q                          _
B3     2      1 q                          _
A3     2      1 q                          _
msilent
A3     4      1 h                          _
A3     4-     1 h              -           ge-
measure 82
A3     2      1 q                          _
G3     2      1 q                          _
G3     2      1 q                          _
F3     2      1 q                          _
msilent
A3     4      1 h                          nus
C4     6      1 h.                         con-
D4     2      1 q                          _
E4     4      1 h                          _
measure 83
F4    12      1 w.                         du-
D4     4      1 h                          _
D4     8      1 L                          cunt._
msilent 84
D4    24      1 B.                         _
P  C1:p1
mdouble 85
P C0:x0
Pa C1:]
$   K:-1   T:61/0   C:4   D:Haec Okeghem
rest  16      1
measure 86
rest  16      1
measure 87
rest  16      1
measure 88
G4    16      1 B                          Haec
measure 89
Bf4    8      1 w                          O-
A4     8-     1 w              -           _
measure 90
A4     4      1 h                          _
G4     4      1 h                          _
F4     8      1 w                          cke-
measure 91
E4    16      1 B                          ghem,
measure 92
D4     8      1 w                          O-
F4     8      1 w                          _
measure 93
E4     8      1 w                          _
A4     8-     1 w              -           _
measure 94
A4     8      1 w                          _
G4     8      1 w                          _
measure 95
F4     8      1 w                          cke-
D4     8      1 w                          _
measure 96
C4    16      1 B                          ghem
measure 97
rest  16      1
measure 98
D4    16      1 B                          qui
measure 99
E4    16      1 B                          cunc-
measure 100
D4     8      1 w                          _
F4     8-     1 w              -           tis_
measure 101
F4     4      1 h                          _
E4     4      1 h                          _
D4     8-     1 w              -           prae-
measure 102
D4     8      1 w                          _
C#4    8      1 w               ^+         ci-
measure 103
D4    12      1 w.                         nis
A4     4-     1 h              -           Gal-
measure 104
A4     4      1 h                          _
G4     2      1 q                          li-
A4     2      1 q                          _
Bf4    4      1 h                          a-
A4     4-     1 h              -           _
measure 105
A4     2      1 q                          _
G4     2      1 q                          _
F4     4      1 h                          _
E4     6      1 h.                         _
D4     2      1 q                          _
measure 106
D4     8      1 w                          _
F4     8      1 w                          _
measure 107
E4     8      1 w                          _
D4     4      1 h                          _
C4     4      1 h                          _
measure 108
A3     4      1 h                          _
D4     8      1 w                          _
C#4    4      1 h               ^+         _
measure 109
D4    16      1 B                          rum
measure 110
rest  16      1
measure 111
F4     8      1 w                          in
G4     4      1 h                          re-
A4     4-     1 h              -           _
measure 112
A4     4      1 h                          _
D4     4      1 h                          _
E4     4      1 h                          _
F4     4      1 h                          _
measure 113
D4     8      1 w                          gis
rest   8      1 w
measure 114
G4     8      1 w                          au-
F4     4      1 h                          _
D4     4      1 h                          _
measure 115
E4     8      1 w                          _
D4     4      1 h                          _
G4     4-     1 h              -           _
measure 116
G4     4      1 h                          _
A4     4      1 h                          _
Bf4    8      1 w                          _
measure 117
C5     6      1 h.                         _
Bf4    2      1 q                          _
G4     8      1 w                          la
measure 118
rest   4      1 h
F4     4      1 h                          Prac-
G4     4      1 h                          ti-
E4     4      1 h                          _
measure 119
F4     4      1 h                          _
D4     4      1 h                          cu-
C4     8      1 w                          lum
measure 120
D4     8      1 w                          tu-
E4     8      1 w                          _
measure 121
D4     8      1 w                          ae
C4     6      1 h.                         pro-
D4     2      1 q                          _
measure 122
E4     4      1 h                          pa-
A3     4      1 h                          _
B3     4      1 h               ^+         _
C4     4      1 h                          _
measure 123
A3     4      1 h                          _
A4     8      1 w                          _
G4     4      1 h                          _
measure 124
A4     4      1 h                          _
C5     4      1 h                          _
B4     4      1 h               ^+         _
A4     4-     1 h              -           _
measure 125
A4     4      1 h                          _
G4     4      1 h                          _
A4     4      1 h                          _
F4     4-     1 h              -           _
measure 126
F4     2      1 q                          _
E4     2      1 q                          _
D4     4      1 h                          _
C4     4      1 h                          _
D4     4      1 h                          _
measure 127
F4     4      1 h                          _
E4     8      1 w                          _
D4     4-     1 h              -           _
measure 128
D4     4      1 h                          _
C4     4      1 h                          _
D4     4      1 h                          _
B3     4      1 h               ^+         gi-
measure 129
A3     8      1 w                          nis,
rest   4      1 h
D4     4      1 h                          pro-
measure 130
E4     4      1 h                          _
G4     4      1 h                          _
F4     4      1 h                          pa-
E4     2      1 q                          _
D4     2      1 q                          _
measure 131
C4     4      1 h                          _
A3     4      1 h                          _
B3     4      1 h               ^+         _
D4     4-     1 h              -           _
measure 132
D4     4      1 h                          _
C4     4      1 h                          _
D4     4      1 h                          _
F4     4      1 h                          _
measure 133
E4     4      1 h                          _
A4     6      1 h.                         _
G4     2      1 q                          _
E4     4      1 h                          _
measure 134
F4     4      1 h                          _
D4     4      1 h                          _
E4     4      1 h                          _
G4     4      1 h                          _
measure 135
F4     4      1 h                          _
D4     8      1 w                          _
C#4    4      1 h               ^+         gi-
measure 136
D4    16      1 B                          nis
measure 137
rest  16      1
measure 138
rest  16      1
measure 139
rest  16      1
measure 140
rest  16      1
measure 141
rest  16      1
measure 142
rest  16      1
measure 143
rest  16      1
measure 144
rest  16      1
measure 145
Bf4   12      1 w.                         Quon-
A4     4-     1 h              -           _
measure 146
A4     8      1 w                          _
G4     4      1 h                          dam
D4     4      1 h                          per
measure 147
G4     8      1 w                          a-
F4     8      1 w                          _
measure 148
G4    12      1 w.                         _
A4     4-     1 h              -           _
measure 149
A4     8      1 w                          _
G4     6      1 h.                         _
F4     2      1 q                          _
measure 150
E4     4      1 h                          _
D4     4      1 h                          _
F4     8      1 w                          _
measure 151
G4     4      1 h                          _
E4     6      1 h.                         _
D4     2      1 q                          _
F4     4-     1 h              -           _
measure 152
F4     2      1 q                          _
G4     2      1 q                          _
F4     2      1 q                          _
E4     1      1 e        [                 _
D4     1      1 e        ]                 _
C#4    6      1 h.              ^+         tri-
B3     2      1 q               ^+         _
measure 153
D4    16-     1 B              -           a_
measure 154
D4    16      1 B                          -
measure 155
rest  16      1
measure 156
D4    16      1 B                          Bur-
measure 157
D4    16-     1 B              -           gun-
measure 158
D4     8      1 w                          _
E4     8      1 w                          di-
measure 159
F4     8      1 w                          ae_
D4     8      1 w                          _
measure 160
E4     8      1 w                          du-
C4     8      1 w                          _
measure 161
D4     8      1 w                          cis_
Bf3    8      1 w                          _
measure 162
C4     8      1 w                          in_
A3     4      1 h                          _
D4     4-     1 h              -           pa-
measure 163
D4     2      1 q                          _
E4     2      1 q                          _
F4     2      1 q                          _
G4     2      1 q                          _
A4     4      1 h                          _
D4     4      1 h                          _
measure 164
E4     4      1 h                          _
C#4    8      1 w               ^+         _
B3     4      1 h               ^+         tri-
measure 165
D4     8      1 w                          a_
F4     8-     1 w              -           -
measure 166
F4     4      1 h                          -
G4     4      1 h                          -
A4     8-     1 w              -           -
measure 167
A4     4      1 h                          -
G4     4      1 h                          -
E4     8      1 w                          -
measure 168
rest   4      1 h
F4     8      1 w                          Bur-
D4     4      1 h                          gun-
measure 169
G4     4      1 h                          di-
F4     4      1 h                          _
Bf4    4      1 h                          _
A4     4-     1 h              -           _
measure 170
A4     2      1 q                          _
G4     2      1 q                          _
G4     8      1 w                          _
F#4    4      1 h               ^+         _
measure 171
G4     4      1 h                          ae
D4     6      1 h.                         du-
E4     2      1 q                          _
F4     4-     1 h              -           _
measure 172
F4     2      1 q                          _
G4     2      1 q                          _
A4     4      1 h                          _
Bf4    4      1 h                          _
A4     2      1 q                          _
G4     2      1 q                          _
measure 173
A4     2      1 q                          _
G4     2      1 q                          _
F#4    2      1 q               ^+         _
E4     2      1 q                          _
F#4    6      1 h.              ^+         _
E4     2      1 q                          _
measure 174
G4     8      1 w                          _
A4     8      1 w                          _
measure 175
Bf4   12      1 w.                         _
A4     4-     1 h              -           _
measure 176
A4     4      1 h                          _
F4     4      1 h                          _
G4     8      1 w                          _
measure 177
A4    16-     1 B              -           cis_
measure 178
A4    16      1 B                          _
measure 179
rest  16      1
measure 180
F4    16      1 B                          in
measure 181
E4     8      1 w                          pa-
D4     8-     1 w              -           _
measure 182
D4     8      1 w                          _
C#4    8      1 w               ^+         _
measure 183
D4    12      1 w.                         _
F4     4-     1 h              -           _
measure 184
F4     2      1 q                          _
G4     2      1 q                          _
A4     4      1 h                          _
D4     4      1 h                          _
F4     4-     1 h              -           _
measure 185
F4     4      1 h                          _
E4     2      1 q                          _
D4     2      1 q                          _
E4     2      1 q                          _
D4     2      1 q                          _
C4     2      1 q                          _
B3     2      1 q               ^+         _
measure 186
A3     8      1 w                          _
D4     8-     1 w              -           _
measure 187
D4     4      1 h                          _
C4     4      1 h                          _
F4     8-     1 w              -           _
measure 188
F4     4      1 h                          _
E4     4      1 h                          _
E4     4      1 h                          tri-
D4     4      1 h                          _
measure 189
F4    16      1 B                          a
measure 190
rest  16      1
measure 191
Bf4   16      1 B                          Per_
measure 192
A4     8      1 w                          _
A4     8-     1 w              -           me_
measure 193
A4     8      1 w                          _
G4     8      1 w                          Bus-
measure 194
A4    12      1 w.                         noys_
G4     2      1 q                          _
F4     2      1 q                          _
measure 195
E4    16      1 B                          _
measure 196
rest   8      1 w
F4     8      1 w                          il-
measure 197
G4    16      1 B                          lu-
measure 198
F4     8      1 w                          _
D4     8-     1 w              -           _
measure 199
D4     4      1 h                          _
C4     4      1 h                          _
Bf3    8      1 w                          _
measure 200
A3    16      1 B                          stris
measure 201
rest   8      1 w
D4     8      1 w                          co-
measure 202
C4     8      1 w                          mi-
F4     8      1 w                          _
measure 203
E4     8      1 w                          _
A4     8-     1 w              -           tis_
measure 204
A4     8      1 w                          _
D4     8      1 w                          de
measure 205
G4     8      1 w                          Cha-
E4     8      1 w                          ro-
measure 206
F4    12      1 w.                         lois_
E4     4      1 h                          _
measure 207
D4     8      1 w                          _
C4     8-     1 w              -           _
measure 208
C4     8      1 w                          _
D4     8      1 w                          in-
measure 209
F4     8      1 w                          _
E4     8      1 w                          di-
measure 210
G4     8      1 w                          _
F4     8      1 w                          gnum_
measure 211
A4     8      1 w                          _
G4     8      1 w                          mu-
measure 212
E4     8      1 w                          _
F4     8-     1 w              -           _
measure 213
F4     8      1 w                          _
G4     8-     1 w              -           _
measure 214
G4     8      1 w                          _
C4     8      1 w                          si-
measure 215
D4    16      1 B                          cum,
measure 216
E4    16-     1 B              -           mu-
measure 217
E4    16      1 B                          _
measure 218
A3    16-     1 B              -           _
measure 219
A3    16      1 B                          _
measure 220
B3    16-     1 B              -^+         _
measure 221
B3    16      1 B                          _
measure 222
C4    16-     1 B              -           si-
measure 223
C4    16      1 B                          _
measure 224
D4    16      1 B                          cum
measure 225
rest  16      1
measure 226
rest  16      1
measure 227
F4    16      1 B                          Sa-
measure 228
E4     8      1 w                          lu-
C4     8      1 w                          _
measure 229
D4    16      1 B                          te-
measure 230
E4    16      1 B                          ris
measure 231
rest   8      1 w
F4     8      1 w                          tu-
measure 232
E4     8      1 w                          is
G4     8      1 w                          pro
measure 233
F4    12      1 w.                         me-
E4     2      1 q                          _
D4     2      1 q                          _
measure 234
C#4   12      1 w.              ^+         ri-
B3     4      1 h               ^+         _
measure 235
$   T:106/0
D4    24      1 B.                         tis
measure 236
rest  24      1
measure 237
F4    16      1 B                          Tam-
A4     8      1 w                          _
measure 238
A4    12      1 w.                         quam_
G4     4      1 h                          _
E4     8      1 w                          _
measure 239
F4    16      1 B                          sum-
E4     8      1 w                          _
measure 240
C4     8      1 w                          _
D4    16      1 B                          _
measure 241
C4    16      1 B                          mum_
A3     8      1 w                          _
measure 242
D4    16      1 B                          che-
C#4    8      1 w               ^+         _
measure 243
D4     8      1 w                          phas
A4    12      1 w.                         tro-
G4     4      1 h                          _
measure 244
F4     8      1 w                          _
E4    12      1 w.                         _
D4     4      1 h                          _
measure 245
D4    24      1 B.                         pi-
measure 246
G4    16      1 B                          _
F#4    8      1 w               ^+         di-
measure 247
G4    24      1 B.                         um,
measure 248
rest  24      1
measure 249
F4    24      1 B.                         Va-
measure 250
D4     8      1 w                          _
E4    16      1 B                          _
measure 251
F4    16      1 B                          le_
D4     8      1 w                          _
measure 252
D4    16      1 B                          ve-
C#4    8      1 w               ^+         _
measure 253
D4     8      1 w                          rum
F4    12      1 w.                         in-
E4     4      1 h                          _
measure 254
A4    12      1 w.                         star_
G4     4      1 h                          _
G4     4      1 h                          _
F4     4      1 h                          _
measure 255
A4    24      1 B.                         _
measure 256
rest  24      1
measure 257
A4    16      1 B                          Or-
F4     8-     1 w              -           phe-
measure 258
F4     4      1 h                          _
G4     4      1 h                          _
A4    16      1 B                          i-
measure 259
D4    24      1 L                          cum.
mheavy2
@@START: HUMDRUMREFERENCE
@@TOP
@!!!COM: Busnoys, Antoine
@!!!CDT: ~1430///-1492/11/06
@!!!OTL: In hydraulis
@!!!AGN: Motet
@!!!SCT: Bus2007
@!!!SCA: Bus2007
@!!!jrpid: Bus2007
@!!!voices: 4
@@POSITION:1008
@!!!OMD: Haec Okeghem
@@BOTTOM
@!!!RDF**kern: l=long note in original notation
@!!!RDF**kern: i=editorial accidental
@!!!ENC: Will Watson 07/11/12
@!!!END: 2015/12/06/ (text added)
@!!!EED: Jesse Rodin
@!!!EEV: 2015/12/07/
@!!!ONB: Translated from MusicXML and edited on 2015/12/10/ by Craig Sapp
@@EXTRA
@!!!VTS: 2764331912
@!!!VTS-data: 2493210809
@@END: HUMDRUMREFERENCE
@START:	FOOTER
@FOOT1: 	
@FOOT2: 	Motet
@FOOT3: 	In hydraulis
@FOOT1R:	page %P
@FOOT2R:	7 Dec 2015
@FOOT3R:	Bus2007
@LOGO: JRP
@END:	FOOTER
/END
/eof
Header Record 1: optional copyright notice
Header Record 2: optional file identification
TIMESTAMP: SEP/19/2026 [md5sum:0d0a:544aa45319fccf8eccd09ee028bc68b8]
12/06/2015 Will Watson 07/11/12
WK#:1 MV#:1
Header Record 6: source
In hydraulis
Haec Okeghem
Altus
Header Record 10
Group memberships: score
score: part 2 of 4
$  K:-1   Q:2   T:11/0   C:34
P C0:x0
D4    16      1 B                          In
C4     8      1 w                          hy-
measure 2
D4     8      1 w                          drau-
E4    12      1 w.                         _
D4     4      1 h                          _
measure 3
D4     8      1 w                          _
C4     4      1 h                          _
A3     4      1 h                          _
Bf3    8      1 w                          _
measure 4
A3     4      1 h                          _
A3     8      1 w                          _
F3     4      1 h                          _
G3     8      1 w                          _
measure 5
F3     6      1 h.                         _
G3     2      1 q                          _
A3     4      1 h                          _
G3     8      1 w                          _
F3     2      1 q                          _
E3     2      1 q                          _
measure 6
D3     4      1 h                          _
C3     4      1 h                          _
D3     4      1 h                          _
F3     4      1 h                          _
E3     8      1 w                          _
measure 7
D3    16      1 B                          lis
rest   8      1 w
measure 8
A3    12      1 w.                         quon-
Bf3    4      1 h                          _
C4     6      1 h.                         dam_
Bf3    2      1 q                          _
measure 9
D4    12      1 w.                         Py-
C4     4      1 h                          _
D4     6      1 h.                         tha-
F4     2      1 q                          _
measure 10
E4     6      1 h.                         go-
D4     2      1 q                          _
Bf3    2      1 q                          _
A3     2      1 q                          _
D4     6      1 h.                         _
C#4    2      1 q               ^+         _
C#4    2      1 q               ^+         _
B3     2      1 q               ^+         _
measure 11
D4     8      1 w                          ra
rest   4      1 h
D4     4      1 h                          Ad_
G4     4      1 h                          _
F4     4      1 h                          _
measure 12
E4     4      1 h                          _
D4     4      1 h                          _
C4     8      1 w                          _
F4     4      1 h                          _
E4     4      1 h                          _
measure 13
D4     4      1 h                          _
C4     4      1 h                          _
Bf3    8      1 w                          _
Ef4    4      1 h               ^+         _
D4     4      1 h                          _
measure 14
C4     4      1 h                          _
Bf3    4      1 h                          _
A3     8      1 w                          _
D4     4      1 h                          _
C4     4      1 h                          _
measure 15
Bf3    4      1 h                          _
A3     4      1 h                          _
G3     4      1 h                          mi-
A3     8      1 w                          ran-
G3     4      1 h                          _
measure 16
A3     4      1 h                          te
C4     8      1 w                          me-
D4     4      1 h                          _
E4     8      1 w                          _
measure 17
D4     4      1 h                          los
F4     8      1 w                          phon-
E4     4      1 h                          gi-
C4     4      1 h                          ta-
D4     4      1 h                          _
measure 18
E4     4      1 h                          _
F4     8      1 w                          _
D4     8      1 w                          _
C#4    4      1 h               ^+         _
measure 19
D4     8      1 w                          tes
rest   8      1 w
A3     8      1 w                          Mal-
measure 20
Bf3   12      1 w.                         _
A3     2      1 q                          _
G3     2      1 q                          _
F3     6      1 h.                         _
G3     2      1 q                          _
measure 21
A3    12      1 w.                         _
G3     4      1 h                          _
E3     8      1 w                          _
measure 22
D3     8      1 w                          _
A3     8      1 w                          _
F3     4      1 h                          _
Bf3    4-     1 h              -           le-
measure 23
Bf3    2      1 q                          _
A3     2      1 q                          _
G3     4      1 h                          _
F3     4      1 h                          _
G3     6      1 h.                         o-
F3     2      1 q                          _
E3     4      1 h                          _
measure 24
D3     4      1 h                          _
Bf3    8      1 w                          _
A3     4      1 h                          _
G3     8      1 w                          _
measure 25
F3    12      1 w.                         rum_
G3     4      1 h                          _
A3     8      1 w                          _
measure 26
D3    24      1 B.                         _
measure 27
rest   8      1 w
rest   8      1 w
D3     8      1 w                          per
measure 28
E3     8      1 w                          cus-
F3    12      1 w.                         _
E3     4      1 h                          _
measure 29
E3     8      1 w                          sa
C3     4      1 h                          ae-
D3     4      1 h                          _
E3     8      1 w                          _
measure 30
F3     8      1 w                          quo-
D3     8      1 w                          _
E3     8      1 w                          _
measure 31
D3    24      1 B.                         ra
measure 32
rest  24      1
measure 33
rest   8      1 w
rest   8      1 w
G3     8      1 w                          Per
measure 34
A3     8      1 w                          pon-
Bf3    8      1 w                          _
A3     8      1 w                          de-
measure 35
G3     4      1 h                          rum_
F3     4      1 h                          _
D3     8      1 w                          _
rest   4      1 h
F3     4      1 h                          in_
measure 36
G3     4      1 h                          _
A3     4      1 h                          _
D3     8      1 w                          ae-
E3     8      1 w                          _
measure 37
D3    16      1 B                          qua-
F3     8      1 w                          _
measure 38
G3     8      1 w                          _
D3    16      1 B                          _
measure 39
A3     8      1 w                          _
F3     4      1 h                          li-
G3     4      1 h                          _
A3     8      1 w                          ta-
measure 40
D3     8      1 w                          tes
rest   8      1 w
A3     8      1 w                          Ad-
measure 41
G3     4      1 h                          _
Bf3    6      1 h.                         _
A3     2      1 q                          _
F3     4      1 h                          _
G3     6      1 h.                         in-
F3     2      1 q                          _
measure 42
D3     4      1 h                          _
D4     6      1 h.                         ve-
C4     2      1 q                          _
A3     4      1 h                          _
Bf3    6      1 h.                         _
A3     2      1 q                          _
measure 43
A3     8      1 w                          _
F3     4      1 h                          _
D3     4      1 h                          _
E3     8      1 w                          _
measure 44
D3     8      1 w                          nit
rest   8      1 w
rest   8      1 w
measure 45
rest  24      1
measure 46
F3     8      1 w                          mu-
D3     8      1 w                          sae
C3     8      1 w                          qui-
measure 47
D3     8      1 w                          di-
E3    12      1 w.                         _
D3     4      1 h                          _
measure 48
D3     8      1 w                          ta-
F3     8      1 w                          _
G3     8      1 w                          _
measure 49
A3    24      1 B.                         tes.
measure 50
Bf3   12      1 w.                         E-
C4     4      1 h                          _
D4     8      1 w                          pi-
measure 51
G3    12      1 w.                         tri-
F3     2      1 q                          _
E3     2      1 q                          _
F3     6      1 h.                         _
E3     2      1 q                          _
measure 52
G3     4      1 h                          _
D4     6      1 h.                         _
C4     2      1 q                          _
C4     4      1 h                          _
A3     8      1 w                          _
measure 53
G3     8      1 w                          tum
rest   8      1 w
G3     8      1 w                          ac
measure 54
A3     8      1 w                          he-
G3     4      1 h                          mi-
G3     8      1 w                          o-
F#3    4      1 h               ^+         li-
measure 55
G3     8      1 w                          am
rest   8      1 w
rest   8      1 w
measure 56
rest  24      1
measure 57
rest  24      1
measure 58
rest  24      1
measure 59
rest  24      1
measure 60
rest   8      1 w
rest   8      1 w
G3     8      1 w                          E-
measure 61
A3     8      1 w                          pog-
D4     8-     1 w.                         do-
msilent
D4     4      1 h                          _
P  C1:p1
C4     4      1 h                          _
measure 62
F4     8-     1 w                          i_
msilent
F4     4      1 h                          -
P  C1:p1
E4     4      1 h                          et
E4     4      1 h                          du-
D4     4      1 h                          _
measure 63
F4    12      1 w.                         plum_
D4     4-     1 w.                         _
msilent
D4     8      1 w                          _
P  C1:p1
measure 64
A3     8-     1 w.                         per-
msilent
A3     4      1 h                          _
P  C1:p1
Bf3    8      1 w                          du-
A3     4      1 h                          _
measure 65
F3    16      1 B                          cunt
msilent
rest   8      1 w
measure 66
rest   8      1 w
msilent
D3    16      1 B                          Nam
measure 67
E3     6      1 h.                         tes-
F3     2      1 q                          _
G3     4      1 h                          sa-
A3     4-     1 w                          ron_
msilent
A3     4      1 h                          _
P  C1:p1
D4     4-     1 h              -           pen-
measure 68
D4     2      1 q                          _
E4     2      1 q                          _
F4     4      1 h                          _
msilent
G4     2      1 q                          _
F4     2      1 q                          _
E4     2      1 q                          _
D4     2      1 q                          _
C#4    6      1 h.              ^+         _
B3     2      1 q               ^+         _
measure 69
D4     8      1 w                          te
Bf3    4      1 h                          con-
G3     4-     1 w                          _
msilent
G3     4      1 h                          _
F3     4      1 h                          _
measure 70
G3     4      1 h                          cor-
Bf3    4      1 h                          _
msilent
A3     4      1 h                          _
G3     2      1 q                          _
F3     2      1 q                          _
E3     6      1 h.                         di-
D3     2      1 q                          _
measure 71
D3     8      1 w                          am
rest   4      1 h
F3     4      1 h                          Nec_
msilent
G3     6      1 h.                         _
A3     2      1 q                          _
measure 72
Bf3    4      1 h                          non_
A3     2      1 q                          _
G3     2      1 q                          _
msilent
F3     4      1 h                          _
G3     8      1 w                          phton-
F#3    4      1 h               ^+         _
measure 73
G3    16      1 B                          gum
msilent
rest   8      1 w
measure 74
rest   8      1 B.
msilent
irst  16      1
P  C1:p1
measure 75
Bf3   12      1 w.                         et_
A3     4      1 h                          _
msilent
F3     8      1 w                          _
measure 76
rest   4      1 h
A3     4-     1 w                          pa-
msilent
A3     4      1 h                          _
P  C1:p1
G3     4      1 h                          _
E3     8      1 w                          _
measure 77
F3    12      1 w.                         son_
E3     4      1 h                          _
msilent
C3     8      1 w                          _
measure 78
rest   4      1 h
E3     4-     1 w                          ad-
msilent
E3     4      1 h                          _
P  C1:p1
D3     4      1 h                          du-
B2     8      1 w               +          cunt
measure 79
rest   4      1 h
D3     8      1 w                          Mo-
F3     4-     1 h.                         _
msilent
F3     2      1 q                          _
P  C1:p1
E3     2      1 q                          _
D3     4-     1 h              -           _
measure 80
D3     4      1 h                          _
C3     4      1 h                          no-
msilent
D3     8      1 w                          cor-
E3     8      1 w                          _
measure 81
D3    16      1 B                          di
msilent
F3     8      1 w                          dum
measure 82
D3     8      1 w                          ge-
msilent
E3    16      1 B                          nus
measure 83
D3     4      1 h                          con-
D4     6      1 h.                         du-
C4     2      1 q                          _
Bf3    2      1 q                          _
A3     2      1 q                          _
Bf3    6      1 h.                         _
A3     2      1 q                          _
measure 84
A3    24      1 L                          cunt.
mdouble 85
P C0:x0
Pa C1:]
$   K:-1   T:61/0   C:34   D:Haec Okeghem
rest  16      1
measure 86
rest  16      1
measure 87
rest  16      1
measure 88
rest  16      1
measure 89
rest  16      1
measure 90
rest  16      1
measure 91
G3    16      1 B                          Haec
measure 92
Bf3    8      1 w                          O-
A3     8-     1 w              -           _
measure 93
A3     4      1 h                          _
G3     4      1 h                          _
F3     8      1 w                          cke-
measure 94
E3    16      1 B                          ghem,
measure 95
D3     8      1 w                          O-
F3     8      1 w                          _
measure 96
E3     8      1 w                          _
A3     8-     1 w              -           _
measure 97
A3     8      1 w                          _
G3     8      1 w                          _
measure 98
F3     8      1 w                          cke-
D3     8      1 w                          _
measure 99
C3    16      1 B                          ghem
measure 100
rest  16      1
measure 101
D3    16      1 B                          qui
measure 102
E3    16      1 B                          cunc-
measure 103
D3     8      1 w                          _
F3     8-     1 w              -           tis_
measure 104
F3     4      1 h                          _
E3     4      1 h                          _
D3     8-     1 w              -           prae-
measure 105
D3     8      1 w                          _
C#3    8      1 w               ^+         ci-
measure 106
D3    12      1 w.                         nis
A3     4-     1 h              -           Gal-
measure 107
A3     4      1 h                          _
G3     2      1 q                          li-
A3     2      1 q                          _
Bf3    4      1 h                          a-
A3     4-     1 h              -           _
measure 108
A3     2      1 q                          _
G3     2      1 q                          _
F3     4      1 h                          _
E3     6      1 h.                         _
D3     2      1 q                          _
measure 109
D3     8      1 w                          rum
rest   8      1 w
measure 110
F3     8      1 w                          in
G3     4      1 h                          re-
A3     4-     1 h              -           _
measure 111
A3     4      1 h                          _
D3     4      1 h                          _
E3     4      1 h                          _
F3     4      1 h                          _
measure 112
D3     8      1 w                          gis
rest   8      1 w
measure 113
G3     8      1 w                          au-
F3     4      1 h                          _
D3     4      1 h                          _
measure 114
E3     8      1 w                          _
D3     4      1 h                          _
G3     4-     1 h              -           _
measure 115
G3     4      1 h                          _
A3     4      1 h                          _
Bf3    8      1 w                          _
measure 116
C4     6      1 h.                         _
Bf3    2      1 q                          _
G3     8      1 w                          la
measure 117
rest   4      1 h
F3     4      1 h                          Prac-
G3     4      1 h                          ti-
E3     4      1 h                          _
measure 118
F3     4      1 h                          _
D3     4      1 h                          cu-
C3     8      1 w                          lum_
measure 119
D3     8      1 w                          _
E3     8      1 w                          tu-
measure 120
D3     4      1 h                          ae
D4     8      1 w                          pro-
C4     4      1 h                          _
measure 121
D4     4      1 h                          pa-
F4     4      1 h                          _
E4     4      1 h                          _
A3     4-     1 h              -           _
measure 122
A3     2      1 q                          _
G3     2      1 q                          _
F3     4      1 h                          _
E3     4      1 h                          _
E4     4-     1 h              -           _
measure 123
E4     2      1 q                          _
D4     2      1 q                          _
C4     4      1 h                          gi-
B3     8      1 w               +          nis,
measure 124
rest   4      1 h
E4     8      1 w                          prac-
C4     4      1 h                          _
measure 125
D4     4      1 h                          _
E4     4      1 h                          _
A3     8      1 w                          _
measure 126
F3     4      1 h                          _
G3     4      1 h                          _
A3     4      1 h                          _
D3     4-     1 h              -           _
measure 127
D3     4      1 h                          _
C3     4      1 h                          _
D3     4      1 h                          ti-
F3     4      1 h                          cu-
measure 128
E3     8      1 w                          lum
rest   4      1 h
G3     4      1 h                          pro-
measure 129
A3     4      1 h                          pa-
C4     4      1 h                          gi-
Bf3    8      1 w                          nis,
measure 130
rest   4      1 h
C4     4      1 h                          prac-
D4     4      1 h                          _
F4     4      1 h                          _
measure 131
E4     4      1 h                          ti-
C4     4      1 h                          _
D4     4      1 h                          _
F4     4      1 h                          _
measure 132
E4     8      1 w                          cu-
D4     8      1 w                          lum
measure 133
rest   4      1 h
D3     8      1 w                          pro-
C3     4      1 h                          _
measure 134
D3     4      1 h                          pa-
F3     4      1 h                          _
E3     4      1 h                          _
C3     4      1 h                          _
measure 135
D3     4      1 h                          _
F3     4      1 h                          _
E3     8      1 w                          gi-
measure 136
D3     8      1 w                          nis
rest   8      1 w
measure 137
A3     8      1 w                          Ar-
Bf3    6      1 h.                         _
C4     2      1 q                          _
measure 138
D4     4      1 h                          _
D4     6      1 h.                         ma_
C4     2      1 q                          _
A3     4      1 h                          _
measure 139
Bf3    4      1 h                          cer-
G3    12-     1 w.             -           _
measure 140
G3     4      1 h                          _
F#3    4      1 h               ^+         _
G3     8      1 w                          _
measure 141
Bf3    8      1 w                          _
A3     8      1 w                          nens
measure 142
rest   4      1 h
G3     6      1 h.                         quon-
F3     2      1 q                          _
D3     2      1 q                          _
E3     2      1 q                          _
measure 143
F3     4      1 h                          _
G3     2      1 q                          _
A3     2      1 q                          _
Bf3    8-     1 w              -           _
measure 144
Bf3    4      1 h                          _
A3    12      1 w.                         _
measure 145
G3     4      1 h                          dam
D3     4      1 h                          per
G3     8      1 w                          a-
measure 146
F3     8      1 w                          _
G3     8-     1 w              -           _
measure 147
G3     4      1 h                          _
A3    12      1 w.                         _
measure 148
G3     6      1 h.                         _
F3     2      1 q                          _
E3     4      1 h                          _
D3     4      1 h                          _
measure 149
F3     8      1 w                          _
G3     4      1 h                          _
C4     4-     1 h              -           _
measure 150
C4     4      1 h                          _
Bf3    4      1 h                          _
A3     8      1 w                          _
measure 151
G3    12      1 w.                         _
F3     4      1 h                          _
measure 152
D3     8      1 w                          tri-
E3     8      1 w                          a
measure 153
rest   8      1 w
D3     6      1 h.                         Bur-
E3     2      1 q                          _
measure 154
F3     4      1 h                          _
G3     6      1 h.                         gun-
A3     2      1 q                          _
Bf3    4      1 h                          _
measure 155
C4     2      1 q                          di-
Bf3    2      1 q                          _
A3     2      1 q                          _
G3     2      1 q                          _
F#3    6      1 h.              ^+         _
E3     2      1 q                          _
measure 156
G3     8      1 w                          ae_
Bf3    8-     1 w              -           _
measure 157
Bf3    4      1 h                          _
A3     4      1 h                          _
F3     8      1 w                          du-
measure 158
G3    12      1 w.                         _
F3     4      1 h                          _
measure 159
F3    16      1 B                          cis_
measure 160
E3     8      1 w                          _
E3     8-     1 w              -           in_
measure 161
E3     8      1 w                          _
D3     8      1 w                          _
measure 162
E3     8      1 w                          pa-
F3     8      1 w                          _
measure 163
D3    16      1 B                          _
measure 164
G3    16      1 B                          tri-
measure 165
A3    12      1 w.                         a,_
Bf3    4-     1 h              -           _
measure 166
Bf3    4      1 h                          _
A3     2      1 q                          _
G3     2      1 q                          _
F3     4      1 h                          _
D3     4      1 h                          _
measure 167
F3     4      1 h                          _
G3     4      1 h                          _
A3     8      1 w                          _
measure 168
D3     6      1 h.                         Bur-
E3     2      1 q                          _
F3     4      1 h                          _
G3     4-     1 h              -           gun-
measure 169
G3     2      1 q                          _
A3     2      1 q                          _
Bf3    6      1 h.                         _
C4     2      1 q                          _
D4     4-     1 h              -           _
measure 170
D4     2      1 q                          _
G3     2      1 q                          _
Bf3    4      1 h                          _
A3     8      1 w                          di-
measure 171
G3     8      1 w                          ae_
Bf3    8      1 w                          _
measure 172
A3     8      1 w                          _
G3     8      1 w                          _
measure 173
rest   8      1 w
C4     8      1 w                          du-
measure 174
Bf3    8      1 w                          _
A3     8      1 w                          _
measure 175
G3     4      1 h                          _
Bf3    6      1 h.                         _
C4     2      1 q                          _
D4     4-     1 h              -           _
measure 176
D4     2      1 q                          _
C4     2      1 q                          _
A3     4      1 h                          _
Bf3    4      1 h                          _
A3     2      1 q                          _
G3     2      1 q                          _
measure 177
F3     4      1 h                          _
A3     6      1 h.                         _
G3     2      1 q                          _
F3     2      1 q                          _
E3     2      1 q                          _
measure 178
D3     4      1 h                          cis
D4     6      1 h.                         in_
E4     2      1 q                          _
F4     4      1 h                          _
measure 179
E4     4      1 h                          pa-
C#4    8      1 w               ^+         _
B3     4      1 h               ^+         tri-
measure 180
D4     8      1 w                          a,_
A3     8-     1 w              -           _
measure 181
A3     4      1 h                          _
G3     4      1 h                          _
F3     8      1 w                          _
measure 182
E3    12      1 w.                         _
D3     4      1 h                          _
measure 183
D3     8      1 w                          du-
A3     8-     1 w              -           _
measure 184
A3     8      1 w                          _
F3     8      1 w                          _
measure 185
C4    16      1 B                          cis
measure 186
rest   8      1 w
F3     8-     1 w              -           in_
measure 187
F3     8      1 w                          _
A3     8      1 w                          pa-
measure 188
G3    16      1 B                          tri-
measure 189
F3    16-     1 B              -           a_
measure 190
F3    16      1 B                          -
measure 191
rest  16      1
measure 192
rest  16      1
measure 193
Bf3   16      1 B                          Per_
measure 194
A3     8      1 w                          _
A3     8-     1 w              -           me_
measure 195
A3     8      1 w                          _
G3     8      1 w                          Bus-
measure 196
A3    12      1 w.                         noys_
G3     2      1 q                          _
F3     2      1 q                          _
measure 197
E3    16      1 B                          _
measure 198
rest   8      1 w
F3     8      1 w                          il-
measure 199
G3    16      1 B                          lu-
measure 200
F3     8      1 w                          _
D3     8-     1 w              -           _
measure 201
D3     4      1 h                          _
C3     4      1 h                          _
Bf2    8      1 w                          _
measure 202
A2    16      1 B                          stris
measure 203
rest   8      1 w
D3     8      1 w                          co-
measure 204
C3     8      1 w                          mi-
F3     8      1 w                          _
measure 205
E3     8      1 w                          _
A3     8-     1 w              -           tis_
measure 206
A3     8      1 w                          _
D3     8      1 w                          de
measure 207
G3     8      1 w                          Cha-
E3     8      1 w                          ro-
measure 208
F3    12      1 w.                         lois_
E3     4      1 h                          _
measure 209
D3     8      1 w                          _
C3     8-     1 w              -           _
measure 210
C3     8      1 w                          _
D3     8      1 w                          in-
measure 211
F3     8      1 w                          _
E3     8      1 w                          di-
measure 212
G3     8      1 w                          _
F3     8      1 w                          gnum_
measure 213
A3     8      1 w                          _
G3     8      1 w                          mu-
measure 214
E3    16      1 B                          si-
measure 215
F3    16      1 B                          cum_
measure 216
E3    16      1 B                          _
measure 217
rest  16      1
measure 218
rest  16      1
measure 219
rest  16      1
measure 220
rest  16      1
measure 221
rest  16      1
measure 222
rest  16      1
measure 223
rest  16      1
measure 224
rest  16      1
measure 225
F3    16      1 B                          Sa-
measure 226
E3     8      1 w                          lu-
C3     8      1 w                          _
measure 227
D3    16      1 B                          te-
measure 228
E3    16      1 B                          ris
measure 229
rest   8      1 w
F3     8      1 w                          tu-
measure 230
E3     8      1 w                          is
G3     8      1 w                          pro
measure 231
F3    12      1 w.                         me-
E3     2      1 q                          _
D3     2      1 q                          _
measure 232
C#3   12      1 w.              ^+         _
B2     4      1 h               ^+         _
measure 233
D3    16      1 B                          _
measure 234
E3    16      1 B                          ri-
measure 235
$   T:106/0
D3    24      1 B.                         tis
measure 236
rest  24      1
measure 237
A3     8      1 w                          Tam-
Bf3    8      1 w                          _
A3     8      1 w                          _
measure 238
D4    16      1 B                          _
C#4    8      1 w               ^+         _
measure 239
D4    16      1 B                          quam
rest   8      1 w
measure 240
rest   8      1 w
D3    16      1 B                          sum-
measure 241
E3     8      1 w                          mum_
F3    12      1 w.                         _
D3     4      1 h                          _
measure 242
D3     8      1 w                          che-
E3    12      1 w.                         _
D3     4      1 h                          _
measure 243
D3    16      1 B                          phas
F3     8      1 w                          tro-
measure 244
D3     8      1 w                          _
A3    16      1 B                          _
measure 245
F3     8      1 w                          pi-
G3    16      1 B                          _
measure 246
Bf3    8      1 w                          _
A3    16      1 B                          di-
measure 247
G3    12      1 w.                         um,_
A3     4      1 h                          _
Bf3    8      1 w                          _
measure 248
A3    16      1 B                          _
G3     8      1 w                          _
measure 249
A3    24      1 B.                         Va-
measure 250
F3     8      1 w                          _
G3    16      1 B                          _
measure 251
F3     8      1 w                          le_
D3     8      1 w                          _
F3     8-     1 w              -           _
measure 252
F3     8      1 w                          _
E3    16      1 B                          ve-
measure 253
D3     8      1 w                          rum
D4    16      1 B                          in-
measure 254
C4     8      1 w                          star_
Bf3   16      1 B                          _
measure 255
A3    12      1 w.                         Or-
G3     4      1 h                          _
F3     8      1 w                          _
measure 256
D3     8      1 w                          phe-
E3    12      1 w.                         i-
D3     4      1 h                          _
measure 257
D3    24-     1 B.             -           cum._
measure 258
D3    24      1 B.                         _
measure 259
A3    24      1 L                          _
mheavy2
@@START: HUMDRUMREFERENCE
@@TOP
@!!!COM: Busnoys, Antoine
@!!!CDT: ~1430///-1492/11/06
@!!!OTL: In hydraulis
@!!!AGN: Motet
@!!!SCT: Bus2007
@!!!SCA: Bus2007
@!!!jrpid: Bus2007
@!!!voices: 4
@@POSITION:1008
@!!!OMD: Haec Okeghem
@@BOTTOM
@!!!RDF**kern: l=long note in original notation
@!!!RDF**kern: i=editorial accidental
@!!!ENC: Will Watson 07/11/12
@!!!END: 2015/12/06/ (text added)
@!!!EED: Jesse Rodin
@!!!EEV: 2015/12/07/
@!!!ONB: Translated from MusicXML and edited on 2015/12/10/ by Craig Sapp
@@EXTRA
@!!!VTS: 3001594179
@!!!VTS-data: 1891639553
@@END: HUMDRUMREFERENCE
@START:	FOOTER
@FOOT1: 	
@FOOT2: 	Motet
@FOOT3: 	In hydraulis
@FOOT1R:	page %P
@FOOT2R:	7 Dec 2015
@FOOT3R:	Bus2007
@LOGO: JRP
@END:	FOOTER
/END
/eof
Header Record 1: optional copyright notice
Header Record 2: optional file identification
TIMESTAMP: SEP/19/2026 [md5sum:0d0a:08c958592c93bf2afa16a3ac03cf6762]
12/06/2015 Will Watson 07/11/12
WK#:1 MV#:1
Header Record 6: source
In hydraulis
Haec Okeghem
Tenor
Header Record 10
Group memberships: score
score: part 3 of 4
$  K:0   Q:2   T:11/0   C:34
P C0:x0
*               D       Tenor motto notated exclusively in the pattern long-breve-long
P C17:Y-8
rest  24      1
measure 2
rest  24      1
measure 3
rest  24      1
measure 4
rest  24      1
measure 5
rest  24      1
measure 6
rest  24      1
measure 7
rest  24      1
measure 8
rest  24      1
measure 9
rest  24      1
measure 10
rest  24      1
measure 11
rest  24      1
measure 12
rest  24      1
measure 13
rest  24      1
measure 14
rest  24      1
measure 15
rest  24      1
measure 16
rest  24      1
measure 17
rest  24      1
measure 18
rest  24      1
measure 19
D3    24-     1 B.             -           Re_
measure 20
D3    24      1 B.                         _
measure 21
C3    24      1 B.                         ut
measure 22
D3    24-     1 B.             -           re,_
measure 23
D3    24      1 B.                         _
measure 24
rest  24      1
measure 25
A3    24-     1 B.             -           la_
measure 26
A3    24      1 B.                         _
measure 27
G3    24      1 B.                         sol
measure 28
A3    24-     1 B.             -           la,_
measure 29
A3    24      1 B.                         _
measure 30
rest  24      1
measure 31
D4    24-     1 B.             -           re_
measure 32
D4    24      1 B.                         _
measure 33
C4    24      1 B.                         ut
measure 34
D4    24-     1 B.             -           re._
measure 35
D4    24      1 B.                         _
measure 36
rest  24      1
measure 37
D4    24-     1 B.             -           Re_
measure 38
D4    24      1 B.                         _
measure 39
C4    24      1 B.                         ut
measure 40
D4    24-     1 B.             -           re,_
measure 41
D4    24      1 B.                         _
measure 42
rest  24      1
measure 43
A3    24-     1 B.             -           la_
measure 44
A3    24      1 B.                         _
measure 45
G3    24      1 B.                         sol
measure 46
A3    24-     1 B.             -           la,_
measure 47
A3    24      1 B.                         _
measure 48
rest  24      1
measure 49
D3    24-     1 B.             -           re_
measure 50
D3    24      1 B.                         _
measure 51
C3    24      1 B.                         ut
measure 52
D3    24-     1 B.             -           re._
measure 53
D3    24      1 B.                         _
measure 54
rest  24      1
measure 55
rest  24      1
measure 56
rest  24      1
measure 57
rest  24      1
measure 58
rest  24      1
measure 59
rest  24      1
measure 60
rest  24      1
measure 61
$   T:31/0
D3    16-     1 B              -           Re_
measure
D3     8-     1 B                          _
msilent 62
D3     8      1 w                          _
P  C1:p1
measure
C3    16      1 B                          ut
measure 63
D3    16-     1 B              -           re,_
measure
D3     8-     1 B                          _
msilent 64
D3     8      1 w                          _
P  C1:p1
measure
rest  16      1 B
measure 65
A3    16-     1 B              -           la_
measure
A3     8-     1 B                          _
msilent 66
A3     8      1 w                          _
P  C1:p1
measure
G3    16      1 B                          sol
measure 67
A3    16-     1 B              -           la,_
measure
A3     8-     1 B                          _
msilent 68
A3     8      1 w                          _
P  C1:p1
measure
rest  16      1 B
measure 69
D4    16-     1 B              -           re_
measure
D4     8-     1 B                          _
msilent 70
D4     8      1 w                          _
P  C1:p1
measure
C4    16      1 B                          ut
measure 71
D4    16-     1 B              -           re._
measure
D4     8-     1 B                          _
msilent 72
D4     8      1 w                          _
P  C1:p1
measure
rest  16      1 B
measure 73
D4    16-     1 B              -           Re_
measure
D4     8-     1 B                          _
msilent 74
D4     8      1 w                          _
P  C1:p1
measure
C4    16      1 B                          ut
measure 75
D4    16-     1 B              -           re,_
measure
D4     8-     1 B                          _
msilent 76
D4     8      1 w                          _
P  C1:p1
measure
rest  16      1 B
measure 77
A3    16-     1 B              -           la_
measure
A3     8-     1 B                          _
msilent 78
A3     8      1 w                          _
P  C1:p1
measure
G3    16      1 B                          sol
measure 79
A3    16-     1 B              -           la,_
measure
A3     8-     1 B                          _
msilent 80
A3     8      1 w                          _
P  C1:p1
measure
rest  16      1 B
measure 81
D3    16-     1 B              -           re_
measure
D3     8-     1 B                          _
msilent 82
D3     8      1 w                          _
P  C1:p1
measure
C3    16      1 B                          ut
measure 83
D3    24      1 L                          re._
msilent 84
D3    24      1 B.                         _
P  C1:p1
mdouble 85
P C0:x0
Pa C1:]
$   K:0   T:61/0   C:34   D:Haec Okeghem
rest  16      1
measure 86
rest  16      1
measure 87
rest  16      1
measure 88
rest  16      1
measure 89
rest  16      1
measure 90
rest  16      1
measure 91
rest  16      1
measure 92
rest  16      1
measure 93
rest  16      1
measure 94
rest  16      1
measure 95
rest  16      1
measure 96
rest  16      1
measure 97
rest  16      1
measure 98
rest  16      1
measure 99
rest  16      1
measure 100
rest  16      1
measure 101
rest  16      1
measure 102
rest  16      1
measure 103
rest  16      1
measure 104
rest  16      1
measure 105
rest  16      1
measure 106
rest  16      1
measure 107
rest  16      1
measure 108
rest  16      1
measure 109
rest  16      1
measure 110
rest  16      1
measure 111
rest  16      1
measure 112
rest  16      1
measure 113
rest  16      1
measure 114
rest  16      1
measure 115
rest  16      1
measure 116
rest  16      1
measure 117
rest  16      1
measure 118
rest  16      1
measure 119
rest  16      1
measure 120
rest  16      1
measure 121
rest  16      1
measure 122
rest  16      1
measure 123
rest  16      1
measure 124
rest  16      1
measure 125
rest  16      1
measure 126
rest  16      1
measure 127
rest  16      1
measure 128
rest  16      1
measure 129
rest  16      1
measure 130
rest  16      1
measure 131
rest  16      1
measure 132
rest  16      1
measure 133
rest  16      1
measure 134
rest  16      1
measure 135
rest  16      1
measure 136
rest  16      1
measure 137
rest  16      1
measure 138
rest  16      1
measure 139
rest  16      1
measure 140
rest  16      1
measure 141
rest  16      1
measure 142
rest  16      1
measure 143
rest  16      1
measure 144
rest  16      1
measure 145
rest  16      1
measure 146
rest  16      1
measure 147
rest  16      1
measure 148
rest  16      1
measure 149
rest  16      1
measure 150
rest  16      1
measure 151
rest  16      1
measure 152
rest  16      1
measure 153
D3    16-     1 B              -           Re_
measure 154
D3    16      1 B                          _
measure 155
C3    16      1 B                          ut
measure 156
D3    16-     1 B              -           re,_
measure 157
D3    16      1 B                          _
measure 158
rest  16      1
measure 159
A3    16-     1 B              -           la_
measure 160
A3    16      1 B                          _
measure 161
G3    16      1 B                          sol
measure 162
A3    16-     1 B              -           la,_
measure 163
A3    16      1 B                          _
measure 164
rest  16      1
measure 165
D4    16-     1 B              -           re_
measure 166
D4    16      1 B                          _
measure 167
C4    16      1 B                          ut
measure 168
D4    16-     1 B              -           re._
measure 169
D4    16      1 B                          _
measure 170
rest  16      1
measure 171
D4    16-     1 B              -           Re_
measure 172
D4    16      1 B                          _
measure 173
C4    16      1 B                          ut
measure 174
D4    16-     1 B              -           re,_
measure 175
D4    16      1 B                          _
measure 176
rest  16      1
measure 177
A3    16-     1 B              -           la_
measure 178
A3    16      1 B                          _
measure 179
G3    16      1 B                          sol
measure 180
A3    16-     1 B              -           la,_
measure 181
A3    16      1 B                          _
measure 182
rest  16      1
measure 183
D3    16-     1 B              -           re_
measure 184
D3    16      1 B                          _
measure 185
C3    16      1 B                          ut
measure 186
D3    16-     1 B              -           re._
measure 187
D3    16      1 B                          _
measure 188
rest  16      1
measure 189
rest  16      1
measure 190
rest  16      1
measure 191
rest  16      1
measure 192
rest  16      1
measure 193
rest  16      1
measure 194
rest  16      1
measure 195
rest  16      1
measure 196
rest  16      1
measure 197
rest  16      1
measure 198
rest  16      1
measure 199
rest  16      1
measure 200
rest  16      1
measure 201
rest  16      1
measure 202
rest  16      1
measure 203
rest  16      1
measure 204
rest  16      1
measure 205
rest  16      1
measure 206
rest  16      1
measure 207
rest  16      1
measure 208
rest  16      1
measure 209
rest  16      1
measure 210
rest  16      1
measure 211
rest  16      1
measure 212
rest  16      1
measure 213
rest  16      1
measure 214
rest  16      1
measure 215
rest  16      1
measure 216
rest  16      1
measure 217
rest  16      1
measure 218
rest  16      1
measure 219
rest  16      1
measure 220
rest  16      1
measure 221
rest  16      1
measure 222
rest  16      1
measure 223
rest  16      1
measure 224
rest  16      1
measure 225
rest  16      1
measure 226
rest  16      1
measure 227
rest  16      1
measure 228
rest  16      1
measure 229
rest  16      1
measure 230
rest  16      1
measure 231
rest  16      1
measure 232
rest  16      1
measure 233
rest  16      1
measure 234
rest  16      1
measure 235
$   T:106/0
*               D       Tenor: pervasive coloration (here to end)
P C17:Y-5
D3    24-     1 B.             -           Re_
measure 236
D3     8      1 w                          _
C3    16      1 B                          ut
measure 237
D3    24-     1 B.             -           re,_
measure 238
D3     8      1 w                          _
rest   8      1 w
rest   8      1 w
measure 239
A3    24-     1 B.             -           la_
measure 240
A3     8      1 w                          _
G3    16      1 B                          sol
measure 241
A3    24-     1 B.             -           la,_
measure 242
A3     8      1 w                          _
rest   8      1 w
rest   8      1 w
measure 243
D4    24-     1 B.             -           re_
measure 244
D4     8      1 w                          _
C4    16      1 B                          ut
measure 245
D4    24-     1 B.             -           re._
measure 246
D4     8      1 w                          _
rest   8      1 w
rest   8      1 w
measure 247
D4    24-     1 B.             -           Re_
measure 248
D4     8      1 w                          _
C4    16      1 B                          ut
measure 249
D4    24-     1 B.             -           re,_
measure 250
D4     8      1 w                          _
rest   8      1 w
rest   8      1 w
measure 251
A3    24-     1 B.             -           la_
measure 252
A3     8      1 w                          _
G3    16      1 B                          sol
measure 253
A3    24-     1 B.             -           la,_
measure 254
A3     8      1 w                          _
rest   8      1 w
rest   8      1 w
measure 255
D3    24-     1 B.             -           re_
measure 256
D3     8      1 w                          _
C#3   16      1 B               ^+         ut
measure 257
D3    24      1 L                          re._
msilent 258
D3    24-     1 B.                         _
P  C1:p1
msilent 259
D3    24      1 B.                         _
P  C1:p1
mheavy2
@@START: HUMDRUMREFERENCE
@@TOP
@!!!COM: Busnoys, Antoine
@!!!CDT: ~1430///-1492/11/06
@!!!OTL: In hydraulis
@!!!AGN: Motet
@!!!SCT: Bus2007
@!!!SCA: Bus2007
@!!!jrpid: Bus2007
@!!!voices: 4
@@POSITION:1008
@!!!OMD: Haec Okeghem
@@BOTTOM
@!!!RDF**kern: l=long note in original notation
@!!!RDF**kern: i=editorial accidental
@!!!ENC: Will Watson 07/11/12
@!!!END: 2015/12/06/ (text added)
@!!!EED: Jesse Rodin
@!!!EEV: 2015/12/07/
@!!!ONB: Translated from MusicXML and edited on 2015/12/10/ by Craig Sapp
@@EXTRA
@!!!VTS: 3001594179
@!!!VTS-data: 1891639553
@@END: HUMDRUMREFERENCE
@START:	FOOTER
@FOOT1: 	
@FOOT2: 	Motet
@FOOT3: 	In hydraulis
@FOOT1R:	page %P
@FOOT2R:	7 Dec 2015
@FOOT3R:	Bus2007
@LOGO: JRP
@END:	FOOTER
/END
/eof
Header Record 1: optional copyright notice
Header Record 2: optional file identification
TIMESTAMP: SEP/19/2026 [md5sum:0d0a:a4a697b73229d1a9e3cfaa132f092384]
12/06/2015 Will Watson 07/11/12
WK#:1 MV#:1
Header Record 6: source
In hydraulis
Haec Okeghem
Bassus
Header Record 10
Group memberships: score
score: part 4 of 4
$  K:-1   Q:2   T:11/0   C:22
P C0:x0
rest  24      1
measure 2
rest  24      1
measure 3
rest  24      1
measure 4
rest  24      1
measure 5
rest  24      1
measure 6
rest  24      1
measure 7
rest   8      1 w
rest   8      1 w
D3     8      1 w                          Quon-
measure 8
F3    12      1 w.                         dam_
G3     4      1 h                          _
A3     8      1 w                          _
measure 9
F3     4      1 h                          Py-
G3     8      1 w                          _
E3     4      1 h                          _
F3     4      1 h                          tha-
D3     4      1 h                          _
measure 10
C3     4      1 h                          go-
G3     6      1 h.                         _
D3     2      1 q                          _
F3     4      1 h                          _
E3     8      1 w                          _
measure 11
D3     4      1 h                          ra
G3     8      1 w                          Ad_
F3     4      1 h                          _
E3     4      1 h                          _
D3     4      1 h                          _
measure 12
C3     4      1 h                          _
F3     8      1 w                          _
E3     4      1 h                          _
D3     4      1 h                          _
C3     4      1 h                          _
measure 13
Bf2    4      1 h                          _
Ef3    8      1 w               ^+         _
D3     4      1 h                          _
C3     4      1 h                          _
Bf2    4      1 h                          _
measure 14
A2     4      1 h                          _
D3     8      1 w                          _
C3     4      1 h                          _
Bf2    4      1 h                          _
A2     4      1 h                          _
measure 15
G2     4      1 h                          _
C3     8      1 w                          _
A2     4      1 h                          mi-
Bf2    8      1 w                          ran-
measure 16
A2     8      1 w                          te
rest   8      1 w
C3     8      1 w                          me-
measure 17
D3    12      1 w.                         los_
E3     4      1 h                          _
F3     8      1 w                          _
measure 18
G3     4      1 h                          phon-
D3     4      1 h                          gi-
F3     8      1 w                          ta-
E3     8      1 w                          _
measure 19
D3    24      1 B.                         tes_
measure 20
Bf2   24      1 B.                         _
measure 21
A2    24      1 B.                         _
measure 22
rest   8      1 w
rest   8      1 w
Bf2    8      1 w                          Mal-
measure 23
Bf2   12      1 w.                         le-
G2     4      1 h                          o-
Bf2    4      1 h                          _
C3     4      1 h                          _
measure 24
D3     4      1 h                          _
Bf2    4      1 h                          _
Ef3    4      1 h               ^+         _
F3     4      1 h                          _
C3     8      1 w                          _
measure 25
D3    24-     1 B.             -           rum_
measure 26
D3     8      1 w                          _
F3    12      1 w.                         per-
E3     4      1 h                          _
measure 27
C3     8      1 w                          cus-
Bf2   12      1 w.                         _
A2     4      1 h                          _
measure 28
A2     8      1 w                          sa_
D3    12      1 w.                         _
C3     4      1 h                          _
measure 29
A2     8      1 w                          _
rest   8      1 w
A2     8      1 w                          ae-
measure 30
D3     4      1 h                          quo-
F3     8      1 w                          _
E3     2      1 q                          _
D3     2      1 q                          _
C#3    6      1 h.              ^+         _
B2     2      1 q               ^+         _
measure 31
D3    16      1 B                          ra_
F3     8      1 w                          _
measure 32
F3     8      1 w                          Per_
G3    16      1 B                          _
measure 33
A3    12      1 w.                         pon-
G3     4      1 h                          _
E3     8      1 w                          de-
measure 34
D3     8      1 w                          rum
rest   4      1 h
G3     8      1 w                          in-
F3     4      1 h                          _
measure 35
G3     4      1 h                          ae-
D3     8      1 w                          _
Bf2    4      1 h                          _
C3     4      1 h                          _
D3     4      1 h                          _
measure 36
G2     4      1 h                          qua-
D3     6      1 h.                         _
C3     2      1 q                          _
Bf2    4      1 h                          _
A2     8      1 w                          li-
measure 37
Bf2   12      1 w.                         ta-
D3    12      1 w.                         _
measure 38
G2     8      1 w                          tes
rest   8      1 w
rest   8      1 w
measure 39
rest   8      1 w
rest   8      1 w
A2     8      1 w                          Ad-
measure 40
Bf2   12      1 w.                         _
A2     2      1 q                          in-
G2     2      1 q                          _
F#2    6      1 h.              ^+         ve-
E2     2      1 q                          _
measure 41
G2     8      1 w                          nit,
rest   8      1 w
G2     8      1 w                          ad-
measure 42
D3     8      1 w                          in-
F3     8      1 w                          ve-
E3     8      1 w                          _
measure 43
F3     4      1 h                          _
D3    16      1 B                          _
C3     4      1 h                          _
measure 44
D3     4      1 h                          nit
F3     6      1 h.                         mu-
E3     2      1 q                          _
C3     4      1 h                          _
D3     8      1 w                          _
measure 45
G2     4      1 h                          _
C3     8      1 w                          _
D3     4      1 h                          _
E3     8      1 w                          _
measure 46
D3    16      1 B                          sae_
A2     8      1 w                          _
measure 47
rest   8      1 w
A2    16      1 B                          qui-
measure 48
Bf2    4      1 h                          di-
G2     4      1 h                          _
D3     8      1 w                          ta-
E3     8      1 w                          _
measure 49
F3    16      1 B                          tes.
Bf2    8-     1 w              -           E-
measure 50
Bf2    8      1 w                          _
G2     8      1 w                          pi-
Bf2    8      1 w                          _
measure 51
C3     8      1 w                          tri-
A2    12      1 w.                         _
G2     4      1 h                          _
measure 52
G2    16      1 B                          _
F2     8      1 w                          _
measure 53
G2    12      1 w.                         _
Bf2    8      1 w                          _
A2     2      1 q                          _
G2     2      1 q                          _
measure 54
F2     8      1 w                          tum
G2     8      1 w                          ac
A2     8      1 w                          he-
measure 55
G2     2      1 q                          mi-
Bf2    4      1 h                          o-
C3     2      1 q                          _
A2     4      1 h                          li-
G2     4      1 h                          am,
rest   4      1 h
F3     4      1 h                          he-
measure 56
G3     2      1 q                          mi-
Bf3    4      1 h                          o-
C4     2      1 q                          _
A3     4      1 h                          li-
G3     6      1 h.                         am,
E3     2      1 q                          ac
F3     4      1 h                          he-
measure 57
G3     2      1 q                          mi-
E3     4      1 h                          o-
C3     2      1 q                          _
D3     4      1 h                          li-
C3     6      1 h.                         am,
A2     2      1 q                          ac
Bf2    4      1 h                          he-
measure 58
C3     2      1 q                          mi-
E3     4      1 h                          o-
F3     2      1 q                          _
D3     4      1 h                          li-
C3     8      1 w                          am,
Bf2    4      1 h                          E-
measure 59
C3     4      1 h                          pog-
E3     4      1 h                          do-
D3     4      1 h                          i
G3     8      1 w                          et_
F#3    4      1 h               ^+         _
measure 60
G3     8      1 w                          du-
F3     4      1 h                          plum
D3     4      1 h                          per-
E3     8      1 w                          du-
measure 61
D3    16      1 B                          cunt_
msilent
F3     8-     1 w              -           _
measure 62
F3     8      1 w                          _
msilent
G3    16      1 B                          _
measure 63
F3    12      1 w.                         Nam
Bf3    4-     1 w                          tes-
msilent
Bf3    4      1 h                          _
P  C1:p1
A3     4      1 h                          _
measure 64
F3     8-     1 w.                         sa-
msilent
F3     4      1 h                          _
P  C1:p1
G3     8      1 w                          ron_
F3     4      1 h                          _
measure 65
D3    16      1 B                          _
msilent
C3     8-     1 w              -           pen-
measure 66
C3     8      1 w                          _
msilent
Bf2   16      1 B                          _
measure 67
A2    16      1 B                          te
msilent
D3     8      1 w                          con-
measure 68
F3     8      1 w                          _
msilent
E3    12      1 w.                         cor-
D3     4      1 h                          di-
measure 69
D3     8      1 w                          am
rest   8      1 w
msilent
rest   8      1 w
measure 70
rest   8      1 w
msilent
rest   8      1 w
C3     8      1 w                          Nec
measure 71
F3     8      1 w                          non_
D3     8      1 w                          _
msilent
Bf2    8      1 w                          _
measure 72
G2     6      1 h.                         phton-
A2     2      1 q                          _
msilent
Bf2    4      1 h                          _
G2     4      1 h                          _
D3     8      1 w                          _
measure 73
G2    16      1 B                          gum
msilent
G3     8-     1 w              -           et_
measure 74
G3     8      1 w                          _
msilent
A3    16      1 B                          pa-
measure 75
G3    12      1 w.                         son_
F3     4      1 h                          _
msilent
D3     8      1 w                          _
measure 76
F3     8-     1 w.                         ad-
msilent
F3     4      1 h                          _
P  C1:p1
E3     4      1 h                          _
C3     8      1 w                          _
measure 77
D3    12      1 w.                         du-
C3     4      1 h                          _
msilent
A2     8      1 w                          _
measure 78
C3     8-     1 w.                         cunt_
msilent
C3     4      1 h                          _
P  C1:p1
Bf2    4      1 h                          _
G2     8      1 w                          _
measure 79
D3     8      1 w                          Mo-
F3     8      1 w                          _
msilent
D3     8      1 w                          no-
measure 80
rest   4      1 h
A2     4      1 h                          cor-
msilent
Bf2    8      1 w                          di-
A2     8      1 w                          dum
measure 81
rest   4      1 h
Bf2    4      1 h                          ge-
G2     8      1 w                          _
msilent
F2     8      1 w                          nus
measure 82
Bf2    8      1 w                          con-
msilent
A2    16      1 B                          du-
measure 83
D3    24      1 L                          cunt._
msilent 84
D3    24      1 B.                         _
P  C1:p1
mdouble 85
P C0:x0
Pa C1:]
$   K:-1   T:61/0   C:22   D:Haec Okeghem
G3    16      1 B                          Haec
measure 86
Bf3    8      1 w                          O-
A3     8-     1 w              -           _
measure 87
A3     4      1 h                          _
G3     4      1 h                          _
F3     8      1 w                          cke-
measure 88
E3    16      1 B                          ghem,
measure 89
D3    16-     1 B              -           O-
measure 90
D3    16      1 B                          _
measure 91
C3    16      1 B                          cke-
measure 92
D3    16      1 B                          ghem
measure 93
rest  16      1
measure 94
rest  16      1
measure 95
rest  16      1
measure 96
rest  16      1
measure 97
rest  16      1
measure 98
rest  16      1
measure 99
rest  16      1
measure 100
rest  16      1
measure 101
rest  16      1
measure 102
rest  16      1
measure 103
rest  16      1
measure 104
rest  16      1
measure 105
rest  16      1
measure 106
rest  16      1
measure 107
rest  16      1
measure 108
rest  16      1
measure 109
rest  16      1
measure 110
rest  16      1
measure 111
rest  16      1
measure 112
rest  16      1
measure 113
rest  16      1
measure 114
rest  16      1
measure 115
rest  16      1
measure 116
rest  16      1
measure 117
rest  16      1
measure 118
rest  16      1
measure 119
rest  16      1
measure 120
rest  16      1
measure 121
rest  16      1
measure 122
rest  16      1
measure 123
rest  16      1
measure 124
rest  16      1
measure 125
rest  16      1
measure 126
rest  16      1
measure 127
rest  16      1
measure 128
rest  16      1
measure 129
rest  16      1
measure 130
rest  16      1
measure 131
rest  16      1
measure 132
rest  16      1
measure 133
rest  16      1
measure 134
rest  16      1
measure 135
rest   8      1 w
A2     8      1 w                          Ar-
measure 136
Bf2    6      1 h.                         _
C3     2      1 q                          _
D3     4      1 h                          _
D3     4-     1 h              -           ma_
measure 137
D3     2      1 q                          _
C3     2      1 q                          _
A2     4      1 h                          _
G2     4      1 h                          _
G3     4-     1 h              -           cer-
measure 138
G3    12      1 w.                         _
F3     4      1 h                          _
measure 139
G3     8      1 w                          _
Bf3    8      1 w                          _
measure 140
A3     8      1 w                          nens
rest   4      1 h
G3     4-     1 h              -           quon-
measure 141
G3     2      1 q                          _
F3     1      1 e        [                 _
E3     1      1 e        ]                 _
D3     2      1 q                          _
E3     2      1 q                          _
F3     4      1 h                          _
G3     2      1 q                          _
A3     2      1 q                          _
measure 142
Bf3   12      1 w.                         _
A3     4-     1 h              -           _
measure 143
A3     8      1 w                          _
G3     4      1 h                          _
D3     4      1 h                          _
measure 144
G3     8      1 w                          _
F3     8      1 w                          _
measure 145
G3     4      1 h                          _
G2     4      1 h                          _
Bf2    4      1 h                          _
C3     4      1 h                          _
measure 146
D3     8      1 w                          _
G2     8      1 w                          dam
measure 147
rest  16      1
measure 148
rest  16      1
measure 149
rest  16      1
measure 150
rest   8      1 w
D3     8      1 w                          per-
measure 151
E3     4      1 h                          a-
C3     8      1 w                          _
D3     4-     1 h              -           _
measure 152
D3     4      1 h                          _
Bf2    4      1 h                          tri-
A2     8      1 w                          a
measure 153
Bf2   12      1 w.                         Bur-
A2     2      1 q                          _
G2     2      1 q                          _
measure 154
F2     4      1 h                          _
Bf2    6      1 h.                         gun-
C3     2      1 q                          _
D3     4      1 h                          _
measure 155
Ef3    2      1 q               ^+         di-
D3     2      1 q                          _
C3     2      1 q                          _
Bf2    2      1 q                          _
A2     6      1 h.                         _
G2     2      1 q                          _
measure 156
G2    16      1 B                          ae
measure 157
Bf2   16-     1 B              -           du-
measure 158
Bf2    8      1 w                          _
C3     8      1 w                          _
measure 159
D3    16      1 B                          cis_
measure 160
C3     8      1 w                          _
A2     8      1 w                          _
measure 161
Bf2   16      1 B                          _
measure 162
A2     8      1 w                          in
D3     8-     1 w              -           pa-
measure 163
D3     8      1 w                          _
F3     8      1 w                          _
measure 164
E3    16      1 B                          tri-
measure 165
D3    16      1 B                          a
measure 166
rest  16      1
measure 167
rest   8      1 w
A2     8      1 w                          Bur-
measure 168
Bf2    6      1 h.                         _
C3     2      1 q                          _
D3     4      1 h                          _
G2     4-     1 h              -           gun-
measure 169
G2     4      1 h                          _
D3     4      1 h                          _
E3     4      1 h                          _
F3     4      1 h                          _
measure 170
G3     8      1 w                          _
D3     8      1 w                          di-
measure 171
G2     4      1 h                          ae
Bf2    6      1 h.                         du-
C3     2      1 q                          _
D3     4-     1 h              -           _
measure 172
D3     2      1 q                          _
E3     2      1 q                          _
F3     4      1 h                          _
G3     4      1 h                          _
A3     2      1 q                          _
Bf3    2      1 q                          _
measure 173
C4     2      1 q                          _
Bf3    2      1 q                          _
A3     2      1 q                          _
G3     2      1 q                          _
A3     8      1 w                          _
measure 174
G3     8      1 w                          cis
F3     8      1 w                          in
measure 175
G3    12      1 w.                         pa-
D3     4      1 h                          _
measure 176
F3     8      1 w                          _
E3     8      1 w                          _
measure 177
D3     8      1 w                          _
C3     8      1 w                          _
measure 178
D3    16      1 B                          _
measure 179
E3    16      1 B                          tri-
measure 180
D3    16      1 B                          a,
measure 181
C3     8      1 w                          pa-
D3     8      1 w                          _
measure 182
A2    16      1 B                          _
measure 183
A3    16      1 B                          _
measure 184
F3    16      1 B                          _
measure 185
G3    16      1 B                          tri-
measure 186
F3    16      1 B                          a,
measure 187
rest   8      1 w
F3     8      1 w                          pa-
measure 188
C3    16      1 B                          _
measure 189
D3     8      1 w                          _
Bf2    8-     1 w              -           _
measure 190
Bf2    4      1 h                          _
C3     4      1 h                          _
D3     8      1 w                          tri-
measure 191
G2    16      1 B                          a_
measure 192
F2    16      1 B                          -
measure 193
rest  16      1
measure 194
rest  16      1
measure 195
rest  16      1
measure 196
rest  16      1
measure 197
rest  16      1
measure 198
rest  16      1
measure 199
rest  16      1
measure 200
rest  16      1
measure 201
rest  16      1
measure 202
rest  16      1
measure 203
rest  16      1
measure 204
rest  16      1
measure 205
rest  16      1
measure 206
rest  16      1
measure 207
rest  16      1
measure 208
rest  16      1
measure 209
rest  16      1
measure 210
rest  16      1
measure 211
rest  16      1
measure 212
rest  16      1
measure 213
rest  16      1
measure 214
rest  16      1
measure 215
rest  16      1
measure 216
rest  16      1
measure 217
C3    16      1 B                          mu-
measure 218
D3     4      1 h                          _
F3     6      1 h.                         _
E3     2      1 q                          _
D3     4      1 h                          _
measure 219
C3     4      1 h                          _
D3     6      1 h.                         _
C3     2      1 q                          _
A2     4      1 h                          _
measure 220
G2     4      1 h                          _
G3     8      1 w                          _
F3     2      1 q                          _
E3     2      1 q                          _
measure 221
D3     4      1 h                          _
E3     6      1 h.                         _
F3     2      1 q                          _
G3     4      1 h                          _
measure 222
E3     4      1 h                          _
A3     6      1 h.                         _
G3     2      1 q                          _
F3     4-     1 h              -           _
measure 223
F3     4      1 h                          _
E3     2      1 q                          _
D3     2      1 q                          _
E3     6      1 h.                         si-
A2     2      1 q                          _
measure 224
D3    16      1 B                          cum
measure 225
A3    16      1 B                          Sa-
measure 226
G3     8      1 w                          lu-
E3     8      1 w                          _
measure 227
F3    12      1 w.                         te-
E3     2      1 q                          _
D3     2      1 q                          _
measure 228
C3    16      1 B                          ris
measure 229
rest  16      1
measure 230
rest  16      1
measure 231
rest  16      1
measure 232
rest  16      1
measure 233
rest  16      1
measure 234
rest  16      1
measure 235
$   T:106/0
F3    16      1 B                          Tam-
A3     8      1 w                          _
measure 236
A3    12      1 w.                         quam_
G3     4      1 h                          _
E3     8      1 w                          _
measure 237
D3    16      1 B                          sum-
F3     8-     1 w              -           _
measure 238
F3     8      1 w                          _
E3    16      1 B                          _
measure 239
D3    16      1 B                          _
C3     8      1 w                          _
measure 240
A2     8      1 w                          _
Bf2   16      1 B                          _
measure 241
A2    16      1 B                          mum
D3     8-     1 w              -           che-
measure 242
D3     8      1 w                          _
A2    16      1 B                          _
measure 243
D3    24      1 B.                         phas
measure 244
rest   8      1 w
rest   8      1 w
A2     8      1 w                          tro-
measure 245
Bf2   16      1 B                          pi-
G2     8-     1 w              -           _
measure 246
G2     8      1 w                          _
D3    16      1 B                          di-
measure 247
G2     8      1 w                          um,
G3    16      1 B                          Va-
measure 248
F3     8      1 w                          _
E3    16      1 B                          le
measure 249
D3    24-     1 B.             -           ve-
measure 250
D3     8      1 w                          _
C3    16      1 B                          _
measure 251
D3    24      1 B.                         rum
measure 252
rest  24      1
measure 253
F3    24-     1 B.             -           in-
measure 254
F3     8      1 w                          _
G3    16      1 B                          _
measure 255
F3     8      1 w                          star
D3    12      1 w.                         Or-
C3     4      1 h                          _
measure 256
Bf2    8      1 w                          _
A2    16      1 B                          phe-
measure 257
rest   8      1 w
rest   8      1 w
D3     8      1 w                          i-
measure 258
D3    24      1 L                          cum._
msilent 259
D3    24      1 B.                         _
P  C1:p1
mheavy2
@@START: HUMDRUMREFERENCE
@@TOP
@!!!COM: Busnoys, Antoine
@!!!CDT: ~1430///-1492/11/06
@!!!OTL: In hydraulis
@!!!AGN: Motet
@!!!SCT: Bus2007
@!!!SCA: Bus2007
@!!!jrpid: Bus2007
@!!!voices: 4
@@POSITION:1008
@!!!OMD: Haec Okeghem
@@BOTTOM
@!!!RDF**kern: l=long note in original notation
@!!!RDF**kern: i=editorial accidental
@!!!ENC: Will Watson 07/11/12
@!!!END: 2015/12/06/ (text added)
@!!!EED: Jesse Rodin
@!!!EEV: 2015/12/07/
@!!!ONB: Translated from MusicXML and edited on 2015/12/10/ by Craig Sapp
@@EXTRA
@!!!VTS: 482566879
@!!!VTS-data: 4246495016
@@END: HUMDRUMREFERENCE
@START:	FOOTER
@FOOT1: 	
@FOOT2: 	Motet
@FOOT3: 	In hydraulis
@FOOT1R:	page %P
@FOOT2R:	7 Dec 2015
@FOOT3R:	Bus2007
@LOGO: JRP
@END:	FOOTER
/END
/eof
//
