\version "2.24.0"
\header { title = "Sing-along drills" composer = "A. Teacher" }
\score {
  \new Staff = "s" {
    \time 4/4
    \new Voice = "v" {
      c''4^"SS: Verse A" d'' e'' f'' | g''4 f'' e'' d''^"SE:" |
      c''4^"SS: Verse B" e'' g'' e'' | c''1 |
    }
    \addlyrics { Do re mi fa sol fa mi re }
    \addlyrics { Un dos tres cua tro cin co seis }
  }
}
