\version "2.24.0"
\header { title = "Rhythm drill book" composer = "A. Teacher" }
\score {
  \new Staff {
    \time 4/4
    % --- snippet 1: measures 1-2, ends at SE
    c''4^"SR: quarters" ^"SD: Drill book p. 4" ^"SS: Warm-up" d'' e'' f'' |
    g''4 f'' e'' d''^"SE:" |
    % --- snippet 2: measure 3-4, ends at the double bar
    c''8^\markup { "SS: Eighths" } d'' e'' f'' g'' a'' b'' c''' |
    c'''4 r r2 \bar "||"
    % --- snippet 3: to the end, untitled
    c''4^"SS:" c'' c'' c'' |
    c''1 \bar "|."
  }
}
