\version "2.24.0"
\score { \new PianoStaff << \new Staff = "up" { \time 3/4 \partial 4 \tuplet 3/2 { c''8 d'' e'' } | \tuplet 3/2 { f''8 \change Staff = "down" g' a' } \change Staff = "up" b'4 c''4 | c''2 } \new Staff = "down" { \clef bass \time 3/4 \partial 4 r4 | R2. | c2 } >> }
