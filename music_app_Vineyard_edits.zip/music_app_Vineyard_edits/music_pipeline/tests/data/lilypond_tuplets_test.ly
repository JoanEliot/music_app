\version "2.24.0"
\score {
  \new Staff {
    \time 4/4
    \tuplet 2/3 { a'8 b' } \tuplet 3/2 { a'8 b' a' } \tuplet 4/3 { a'8 b' a' b' } |
    \tuplet 5/4 { a'16 b' a' b' a' } \tuplet 6/4 { a'16 b' a' b' a' b' } \tuplet 7/4 { a'16 b' a' b' a' b' a' } r4 |
    c''8 \tuplet 3/2 { d''16 e'' f'' } g''8 \tuplet 3/2 { a'4 b' c'' } |
  }
}
