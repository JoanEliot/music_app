\version "2.24.0"
global = { \time 3/4 \partial 4 }
\score { \new PianoStaff << \new Staff { \global g'4 | c''2 d''4 | e''2 f''4 | g''2 } \new Staff { \clef bass \global r4 | c2. | c2. | c2 } >> }
