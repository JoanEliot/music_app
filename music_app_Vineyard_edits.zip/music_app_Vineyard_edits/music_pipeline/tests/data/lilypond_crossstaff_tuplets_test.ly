\version "2.24.0"
\score {
  \new PianoStaff <<
    \new Staff = "up" { \clef treble \time 4/4
      \tuplet 3/2 { c''8 d'' e'' } \tuplet 3/2 { f''8 \change Staff = "down" g' a' } \change Staff = "up" \tuplet 3/2 { b'8 c'' d'' } \tuplet 3/2 { e''8 f'' g'' } |
      c''8. d''16 e''8 f''16 g'' a''8. b''16 c'''4 |
    }
    \new Staff = "down" { \clef bass \time 4/4 R1 | R1 | }
  >>
}
