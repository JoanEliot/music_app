\version "2.24.0"
\score {
  \new Staff <<
    \new Voice { \voiceOne \time 3/4
      \tuplet 3/2 { c''8 r e'' } \tuplet 3/2 { g''8 a''16 b'' } \tuplet 3/2 { c'''4 r8 } |
      \tuplet 3/2 { c''16 d'' e'' f'' g'' a'' } \tuplet 5/4 { b'16 c'' d'' e'' f'' } c''8 c'' |
    }
    \new Voice { \voiceTwo
      \tuplet 3/2 { c'8 d' e' } \tuplet 3/2 { f'8 g' a' } \tuplet 3/2 { b'8 c'' d'' } |
      c'4 \tuplet 3/2 { e'8 e' e' } \tuplet 3/2 { g'8 g' g' } |
    }
  >>
}
