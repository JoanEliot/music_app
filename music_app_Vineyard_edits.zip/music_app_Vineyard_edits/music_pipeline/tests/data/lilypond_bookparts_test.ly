\version "2.24.0"
\book { \bookpart { \score { \new Staff { c'4 d' } } } \bookpart { \score { \new Staff { e'4 f' } } } }
