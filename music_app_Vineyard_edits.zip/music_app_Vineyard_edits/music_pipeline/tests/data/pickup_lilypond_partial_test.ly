\version "2.24.0"
\score { \new Staff { \time 3/4 \partial 4 g'4 | c''2 d''4 | e''2 f''4 | g''2 \bar "|." } }
