#!/usr/bin/env python3
"""
tests/test_import_pipeline.py

Confirms core.import_pipeline.run_job() produces the same result the
three original standalone scripts did, on real files -- one per format:

  MuseData  tests/fixtures/musedata_quintet/   (5 real part-files, from
                                                 music21's own MuseData
                                                 test corpus -- a Mozart
                                                 Clarinet Quintet movement)
  Humdrum   tests/fixtures/palestrina_agnus.krn (5-voice Palestrina, from
                                                 music21's own corpus --
                                                 the same file the
                                                 humdrum_to_musicxml.py
                                                 docstring's "5-voice
                                                 Palestrina" spot-check
                                                 refers to)
  MusicXML  tests/fixtures/prayer_of_a_tired_child.musicxml (real,
                                                 uncompressed .musicxml
                                                 from music21's corpus)

For each format, this parses the fixture BOTH the old way (calling the
original script's own conversion function, copied unmodified into
tests/legacy/) and the new way (core.import_pipeline.run_job()), then
checks that they agree on: part count, total note count, and pitch
content. This is a behavioral regression check, not a unit test suite --
its only job is to catch the extraction having silently changed
something.

CAVEAT -- read before trusting the MuseData result too far
-------------------------------------------------------------
The bundled MuseData quintet used here parses as a *stage 2* file (it
has a '$'-prefixed attribute record, and its part names already resolve
via getPartName() -- see importers/musedata_importer.py's docstring).
That means this test exercises the *directory-of-parts* import path
correctly, but does NOT exercise the stage-1 id-crash bug the patch in
musedata_importer.apply_musedata_stage1_fix() exists to fix, since this
file never hits that code path in the first place (with the patch
active or not, it converts the same way -- see the
test_musedata_stage1_patch_is_harmless_here() check below, which
confirms exactly that: same result either way, not that the patch was
exercised). No genuine stage-1 file (of the kind that crashes without
the patch) was found bundled with music21 or in this session's uploads.
If you still have the original 496.musedata / 05.musedata files
mentioned as this project's test corpus, add them under
tests/fixtures/ and this script can be extended to check that
scenario specifically.

Run directly:
    python3 tests/test_import_pipeline.py
"""

import sys
from pathlib import Path

THIS_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = THIS_DIR.parent
FIXTURES = THIS_DIR / 'fixtures'

sys.path.insert(0, str(PACKAGE_ROOT))   # for `importers`, `core`
sys.path.insert(0, str(THIS_DIR / 'legacy'))  # for the original scripts

from core.import_pipeline import JobSpec, run_job  # noqa: E402


def score_signature(score):
    """A cheap, order-independent fingerprint of a Score's actual musical
    content: part count, total note count, and the sorted multiset of
    pitch names -- enough to catch the extraction having dropped or
    duplicated anything, without needing an exact object-identity match
    (which parsing the same file twice, old way vs. new way, wouldn't
    give us anyway)."""
    parts = list(score.parts)
    notes = list(score.recurse().notes)
    pitches = sorted(
        p.nameWithOctave
        for n in notes
        for p in (n.pitches if n.isChord else [n.pitch])
    )
    return {
        'n_parts': len(parts),
        'n_notes': len(notes),
        'n_pitches': len(pitches),
        'pitches': pitches,
    }


def assert_same_content(label, sig_old, sig_new):
    mismatches = []
    for key in ('n_parts', 'n_notes', 'n_pitches'):
        if sig_old[key] != sig_new[key]:
            mismatches.append(f"{key}: legacy={sig_old[key]} new={sig_new[key]}")
    if sig_old['pitches'] != sig_new['pitches']:
        mismatches.append("pitch content differs")
    if mismatches:
        raise AssertionError(f"[{label}] MISMATCH: " + "; ".join(mismatches))
    print(f"[{label}] OK  -- {sig_new['n_parts']} part(s), {sig_new['n_notes']} note(s)")


def test_musedata():
    from legacy import musedata_to_musicxml as legacy_musedata

    fixture_dir = FIXTURES / 'musedata_quintet'
    legacy_musedata.apply_musedata_stage1_fix()
    from music21 import converter
    legacy_score = converter.parse(str(fixture_dir), forceSource=True)

    result = run_job(JobSpec(input_path=str(fixture_dir),
                              output_path=str(THIS_DIR / '_out_musedata.musicxml')))
    assert result.format == 'musedata'
    assert_same_content('musedata', score_signature(legacy_score), score_signature(result.score))

    # Round-trip: the MusicXML we just wrote should itself parse back
    # into the same content.
    roundtrip = converter.parse(str(result.output_path), forceSource=True)
    assert_same_content('musedata (round-trip)', score_signature(legacy_score),
                         score_signature(roundtrip))

    # A file whose attributes ('$') record declares more than one staff
    # (S: field > 1) is MuseData's own documented convention for
    # grand-staff writing, required whenever notation crosses between
    # the two staves -- detected and warned about (no real multi-staff
    # MuseData file was available to verify actual output fidelity
    # against -- see MuseDataMultiStaffNotPreservedWarning). A normal,
    # single-staff file (like the fixture above) must NOT trigger it.
    import warnings
    from importers.musedata_importer import MuseDataMultiStaffNotPreservedWarning
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        run_job(JobSpec(input_path=str(fixture_dir),
                         output_path=str(THIS_DIR / '_out_musedata_normal.musicxml')))
    assert not any(issubclass(w.category, MuseDataMultiStaffNotPreservedWarning) for w in caught)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        run_job(JobSpec(input_path=str(FIXTURES / 'musedata_multistaff'),
                         output_path=str(THIS_DIR / '_out_musedata_multistaff.musicxml')))
    assert any(issubclass(w.category, MuseDataMultiStaffNotPreservedWarning) for w in caught), \
        [str(w.message) for w in caught]
    print("[musedata: S:2+ multi-staff declaration -- detected and warned, not silently assumed correct] OK")


def test_musedata_stage1_patch_is_harmless_here():
    """See the CAVEAT in the module docstring: this fixture doesn't
    trigger the stage-1 bug either way, so this only confirms applying
    the patch doesn't change the result for a file that didn't need it --
    it is NOT a test that the patch fixes the crash (nothing in this
    fixture set can exercise that without a genuine stage-1 file)."""
    import importlib
    from importers import musedata_importer

    fixture_dir = FIXTURES / 'musedata_quintet'
    from music21 import converter

    # Parse once via the patched path (import_score always applies it).
    patched_score = musedata_importer.import_score(fixture_dir)

    # And once via a fresh, unpatched parse, by reloading music21's
    # musedata.translate module to undo the monkeypatch just for this
    # comparison.
    from music21.musedata import translate as musedata_translate
    importlib.reload(musedata_translate)
    unpatched_score = converter.parse(str(fixture_dir), forceSource=True)
    musedata_importer.apply_musedata_stage1_fix()  # restore the patch

    assert_same_content('musedata (patched vs. unpatched, non-stage-1 fixture)',
                         score_signature(unpatched_score), score_signature(patched_score))


def test_humdrum():
    import warnings
    from legacy import humdrum_to_musicxml as legacy_humdrum

    fixture = FIXTURES / 'palestrina_agnus.krn'
    from music21 import converter
    with open(fixture, encoding='utf-8', errors='ignore') as f:
        text = f.read()
    import legacy.humdrum_filters as legacy_filters
    filter_notes = []
    needs_python_satb2gs = False
    if legacy_filters.extract_filter_commands(text):
        text, filter_notes, needs_python_satb2gs = legacy_filters.apply_embedded_filters(text)
    legacy_score = converter.parse(text, format='humdrum', forceSource=True)
    if needs_python_satb2gs:
        import legacy.satb2gs_python as legacy_satb
        legacy_score = legacy_satb.merge_satb_to_grand_staff(legacy_score)

    result = run_job(JobSpec(input_path=str(fixture),
                              output_path=str(THIS_DIR / '_out_humdrum.musicxml')))
    assert result.format == 'humdrum'
    assert_same_content('humdrum', score_signature(legacy_score), score_signature(result.score))

    roundtrip = converter.parse(str(result.output_path), forceSource=True)
    assert_same_content('humdrum (round-trip)', score_signature(legacy_score),
                         score_signature(roundtrip))

    # A **kern spine's own `*staff` tandem interpretation changing
    # value partway through is the documented (if rare) convention for
    # a single line notated across two staves -- music21's own
    # Humdrum importer doesn't act on this at all (a disclosed,
    # commented-out TODO in its source), so this is detected and
    # warned about rather than silently mis-transcribed. A normal
    # file (like the fixture above, with no `*staff` changes at all)
    # must NOT trigger this warning.
    from importers.humdrum_importer import HumdrumCrossStaffNotPreservedWarning
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        run_job(JobSpec(input_path=str(fixture),
                         output_path=str(THIS_DIR / '_out_humdrum_normal.musicxml')))
    assert not any(issubclass(w.category, HumdrumCrossStaffNotPreservedWarning) for w in caught)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        run_job(JobSpec(input_path=str(FIXTURES / 'humdrum_cross_staff_spine.krn'),
                         output_path=str(THIS_DIR / '_out_humdrum_cross_staff.musicxml')))
    assert any(issubclass(w.category, HumdrumCrossStaffNotPreservedWarning) for w in caught), \
        [str(w.message) for w in caught]
    print("[humdrum: mid-spine *staff change -- detected and warned, not silently mis-transcribed] OK")


def test_musicxml():
    fixture = FIXTURES / 'prayer_of_a_tired_child.musicxml'
    from music21 import converter
    legacy_score = converter.parse(str(fixture), forceSource=True)

    result = run_job(JobSpec(input_path=str(fixture),
                              output_path=str(THIS_DIR / '_out_musicxml.musicxml')))
    assert result.format == 'musicxml'
    assert_same_content('musicxml', score_signature(legacy_score), score_signature(result.score))

    roundtrip = converter.parse(str(result.output_path), forceSource=True)
    assert_same_content('musicxml (round-trip)', score_signature(legacy_score),
                         score_signature(roundtrip))

    # A MusicXML INPUT can already correctly encode genuine cross-staff
    # notation (a single instrument declaring >1 staff, with per-note
    # <staff> tags and one continuous beam/tuplet bracket crossing
    # between them) -- confirmed, independent of anything in this
    # pipeline, that plain music21 parse-then-write corrupts such a
    # file even with zero modification in between (phantom tuplet
    # ratios appear). Since the input's own encoding is already
    # correct, the fix preserves that part's original XML verbatim
    # rather than rebuilding it (contrast importers/lilypond_importer.
    # py, which has no already-correct source to fall back on).
    cross_fixture = FIXTURES / 'musicxml_cross_staff_reference.mxl'
    cross_result = run_job(JobSpec(input_path=str(cross_fixture),
                                    output_path=str(THIS_DIR / '_out_musicxml_cross_staff.musicxml')))
    cross_xml = cross_result.output_path.read_text()
    assert cross_xml.count('<part id=') == 1, "should stay one part, not the reader's split-into-two"
    import re
    ratios = set(re.findall(r'<actual-notes>(\d+)</actual-notes>\s*<normal-notes>(\d+)</normal-notes>',
                             cross_xml))
    assert ratios == {('6', '4')}, f"no phantom tuplet ratio should appear: {ratios}"
    print("[musicxml: input with genuine cross-staff notation -- preserved verbatim, not corrupted] OK")


def _assert_no_type_duration_mismatch(score, label):
    """A note/chord/rest whose duration is LINKED (the normal case --
    type/dots determine quarterLength, or vice versa) must have those
    two agree; music21 guarantees this itself, so a mismatch here would
    mean something bypassed normal Duration construction. Confirmed,
    against a real piece, that this specific failure mode -- a stale,
    wrong type left over from an earlier version of a fix -- made a
    layout engine misplace everything following a hidden, but still
    spacing-relevant, rest: correct duration, wrong type, real reported
    "shifted" appearance.

    A note/chord/rest with an UNLINKED duration is deliberately exempt:
    that's importers.lilypond_importer._pad_short_measures' own
    fallback for a padding rest whose exact quarterLength has no clean
    notated equivalent (typically one left by a cross-staff tuplet
    redirect, e.g. 2/3 or 7/3) -- there, type/dots are intentionally
    NOT expected to reconstruct the true quarterLength; what matters
    for that case is covered by the caller's own tuplet-ratio checks
    (no bogus tuplet should be attached) instead."""
    from music21 import duration as m21duration
    from fractions import Fraction
    for n in score.recurse().notesAndRests:
        if n.duration.isGrace or not n.duration.type or n.duration.type == 'zero':
            continue
        if not n.duration.linked:
            continue
        expected = m21duration.Duration(type=n.duration.type, dots=n.duration.dots)
        for t in n.duration.tuplets:
            expected = expected.augmentOrDiminish(Fraction(t.numberNotesNormal, t.numberNotesActual))
        assert abs(float(expected.quarterLength) - float(n.duration.quarterLength)) < 1e-6, \
            f"{label}: {n} type={n.duration.type} dots={n.duration.dots} " \
            f"implies ql={float(expected.quarterLength)} but actual ql={float(n.duration.quarterLength)}"


def test_lilypond():
    """No legacy script exists to compare against (this is a new
    importer, not an extraction) -- instead this checks the resolved
    Score's actual content directly against what each fixture should
    produce, since we know exactly what's in each by construction."""
    import warnings
    from music21 import converter

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        result = run_job(JobSpec(input_path=str(FIXTURES / 'lily_two_staff.ly'),
                                  output_path=str(THIS_DIR / '_out_lily_two_staff.musicxml')))
    assert result.format == 'lilypond'
    assert not caught, f"unexpected warning(s): {[str(w.message) for w in caught]}"
    sig = score_signature(result.score)
    assert sig['n_parts'] == 2, sig
    assert sig['n_notes'] == 5, sig  # treble: G,A,B,C (4); bass: 3 rests (not counted) + G (1)
    print(f"[lilypond: two-staff StaffGroup] OK  -- {sig['n_parts']} part(s), {sig['n_notes']} note(s)")

    roundtrip = converter.parse(str(result.output_path), forceSource=True)
    assert_same_content('lilypond (round-trip)', sig, score_signature(roundtrip))

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        result2 = run_job(JobSpec(input_path=str(FIXTURES / 'lily_ties_articulations_voices.ly'),
                                   output_path=str(THIS_DIR / '_out_lily_voices.musicxml')))
    assert not caught, f"unexpected warning(s): {[str(w.message) for w in caught]}"
    part = result2.score.parts[0]
    voices_by_measure = [list(m.getElementsByClass('Voice'))
                          for m in part.getElementsByClass('Measure')]
    assert [len(v) for v in voices_by_measure] == [2, 2], \
        f"expected 2 voices in each of 2 measures, got {[len(v) for v in voices_by_measure]}"
    # MusicXML voice numbers are conventionally 1-based; makeMeasures()
    # renumbers from 0 internally (confirmed empirically, and confirmed
    # to make MuseScore 3 fail to display the part's notes at all) --
    # _renumber_voices() must fix this back up to 1-based before export.
    voice_ids = sorted({v.id for measure in voices_by_measure for v in measure})
    assert voice_ids == ['1', '2'], voice_ids
    # music21's makeMeasures() renumbers Voice.id sequentially per
    # measure (confirmed empirically -- it does NOT preserve the lane
    # ids this importer assigned), so voices are matched here by
    # content/position instead of by id. .notes (not .notesAndRests)
    # since the shorter voice is now padded out to the full measure
    # length with a hidden rest (see _pad_short_measures) -- confirmed
    # necessary against a real piece for cross-staff passages, and
    # applied the same way here since an incomplete voice within a
    # measure is the same underlying situation.
    line_a = [n.pitch.nameWithOctave for m in voices_by_measure for n in m[0].notes]
    line_b = [n.pitch.nameWithOctave for m in voices_by_measure for n in m[1].notes]
    assert line_a == ['C4', 'C4', 'D4', 'E4', 'G4', 'A4'], line_a
    assert line_b == ['C4', 'B3'], line_b
    ties = [n.tie.type for m in voices_by_measure for n in m[0].notes if n.tie is not None]
    assert ties == ['start', 'stop'], f"tie start/stop not resolved correctly: {ties}"
    arts = [a.name for m in voices_by_measure for n in m[0].notes
            for a in getattr(n, 'articulations', [])]
    assert arts == ['staccato', 'accent'], f"articulations not resolved correctly: {arts}"
    print("[lilypond: full polyphony retained (both voices) + ties + articulations] OK")

    result_repeat = run_job(JobSpec(input_path=str(FIXTURES / 'lily_repeat_volta.ly'),
                                     output_path=str(THIS_DIR / '_out_lily_repeat.musicxml')))
    rpart = result_repeat.score.parts[0]
    measures = list(rpart.getElementsByClass('Measure'))
    from music21 import bar as m21bar
    assert isinstance(measures[0].leftBarline, m21bar.Repeat) and measures[0].leftBarline.direction == 'start'
    assert isinstance(measures[1].rightBarline, m21bar.Repeat) and measures[1].rightBarline.direction == 'end'
    brackets = list(rpart.recurse().getElementsByClass('RepeatBracket'))
    assert sorted(b.number for b in brackets) == ['1', '2'], [b.number for b in brackets]
    pitches_folded = [n.pitch.nameWithOctave for n in rpart.recurse().notes]
    assert pitches_folded == ['C4', 'D4', 'E4', 'F4', 'G4', 'A4'], pitches_folded  # each ending written once
    print("[lilypond: repeat volta PRESERVED (barlines + volta brackets, not unfolded)] OK")

    from transforms.unfold_repeats import unfold_repeats
    unfolded = unfold_repeats(result_repeat.score)
    pitches_unfolded = [n.pitch.nameWithOctave for n in unfolded.recurse().notes]
    assert pitches_unfolded == ['C4', 'D4', 'E4', 'F4', 'G4', 'C4', 'D4', 'E4', 'F4', 'A4'], pitches_unfolded
    assert not list(unfolded.recurse().getElementsByClass('RepeatBracket'))
    print(f"[transforms.unfold_repeats: expands to played-through form] OK  -- "
          f"{'-'.join(pitches_unfolded)}")

    result_trans = run_job(JobSpec(input_path=str(FIXTURES / 'lily_transposing_slur_dynamics.ly'),
                                    output_path=str(THIS_DIR / '_out_lily_trans.musicxml')))
    tpart = result_trans.score.parts[0]
    assert tpart.partName == 'Clarinet in Bb', tpart.partName
    inst = list(tpart.recurse().getElementsByClass('Instrument'))[0]
    assert str(inst.transposition) == '<music21.interval.Interval M-2>', inst.transposition
    from music21 import key as m21key
    written_sharps = tpart.recurse().getElementsByClass(m21key.KeySignature).first().sharps
    sounding_sharps = tpart.toSoundingPitch().recurse().getElementsByClass(m21key.KeySignature).first().sharps
    assert written_sharps == 2 and sounding_sharps == 0, (written_sharps, sounding_sharps)
    assert len(list(result_trans.score.recurse().getElementsByClass('Spanner'))) == 2  # slur + crescendo
    cresc = [s for s in result_trans.score.recurse().getElementsByClass('Spanner')
             if 'Crescendo' in type(s).__name__][0]
    cresc_notes = [n.pitch.nameWithOctave for n in cresc.getSpannedElements()]
    assert cresc_notes == ['F4', 'A4'], cresc_notes  # ends at the next dynamic mark (\f), not an explicit \!
    assert len(list(tpart.recurse().getElementsByClass('Dynamic'))) == 2  # the "p" and the "f"
    print("[lilypond: transposing instrument (Bb clarinet, written D maj / sounding C maj) "
          "+ slur + dynamic] OK")

    result3 = run_job(JobSpec(input_path=str(FIXTURES / 'lily_chords.ly'),
                               output_path=str(THIS_DIR / '_out_lily_chords.musicxml')))
    chords = [n for n in result3.score.parts[0].recurse().notes if n.isChord]
    assert len(chords) == 3 and len(chords[-1].pitches) == 4
    # This fixture states no \time and has no barchecks either; its
    # actual content is 5 quarter-notes' worth -- makeMeasures() would
    # otherwise silently assume 4/4 and split it, which real programs
    # (confirmed: MuseScore and Dorico) then resolve inconsistently.
    from music21 import meter as m21meter
    measures3 = list(result3.score.parts[0].getElementsByClass('Measure'))
    assert len(measures3) == 1, f"expected the whole fragment as one bar, got {len(measures3)}"
    ts3 = measures3[0].getElementsByClass(m21meter.TimeSignature).first()
    assert ts3 is not None and ts3.ratioString == '5/4', ts3
    print(f"[lilypond: chords + no-\\time inference -> {ts3.ratioString}] OK  -- {len(chords)} chord(s)")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        result4 = run_job(JobSpec(input_path=str(FIXTURES / 'lily_welcome_scale.ly'),
                                   output_path=str(THIS_DIR / '_out_lily_welcome.musicxml')))
    assert not caught, f"unexpected warning(s): {[str(w.message) for w in caught]}"
    notes = list(result4.score.parts[0].recurse().notes)
    scale = [n.pitch.nameWithOctave for n in notes]
    assert scale == ['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4', 'C5'], scale
    print("[lilypond: bare \\relative toplevel, no \\score block] OK  -- "
          f"{'-'.join(scale)}")

    result_tuplets = run_job(JobSpec(input_path=str(FIXTURES / 'lily_tuplets.ly'),
                                      output_path=str(THIS_DIR / '_out_lily_tuplets.musicxml')))
    tuplet_notes = list(result_tuplets.score.parts[0].recurse().notes)
    # `\tuplet` used to have NO handler at all -- an unhandled node's
    # music is silently skipped -- which dropped every tupleted note
    # entirely and shifted everything after it earlier by the tuplet's
    # full duration (confirmed against a real piece with two 16th-note
    # triplets and a run of sextuplets). 16 notes total: 2 plain
    # quarters + 3+3 triplet 16ths + 6 sextuplet 16ths + 2 more quarters.
    assert len(tuplet_notes) == 16, len(tuplet_notes)
    from fractions import Fraction
    triplet_qls = {n.duration.quarterLength for n in tuplet_notes[1:4]}
    assert triplet_qls == {Fraction(1, 6)}, triplet_qls  # 3-in-the-time-of-2 sixteenths
    sextuplet_qls = {n.duration.quarterLength for n in tuplet_notes[8:14]}
    assert sextuplet_qls == {Fraction(1, 6)}, sextuplet_qls  # 6-in-the-time-of-4 sixteenths
    print(f"[lilypond: tuplets (\\tuplet 3/2 and \\tuplet 6/4)] OK  -- {len(tuplet_notes)} note(s)")

    # Every C-clef in common use (soprano, mezzo-soprano, alto, tenor,
    # baritone -- both its C- and F-clef forms), verified directly
    # against real LilyPond output, not just derived from a formula:
    # ran each \clef command through this project's own _run_lilypond
    # and read the actual clefGlyph/clefPosition values out of the
    # dump (see _CLEF_TABLE's own comment for the confirmed pattern).
    result_clefs = run_job(JobSpec(input_path=str(FIXTURES / 'lily_c_clefs.ly'),
                                    output_path=str(THIS_DIR / '_out_lily_c_clefs.musicxml')))
    clef_classes = [type(c).__name__ for c in
                    result_clefs.score.parts[0].recurse().getElementsByClass('Clef')]
    assert clef_classes == ['SopranoClef', 'MezzoSopranoClef', 'CBaritoneClef',
                             'FBaritoneClef', 'TrebleClef'], clef_classes
    print("[lilypond: all common C-clefs (soprano/mezzo-soprano/baritone) + varbaritone] OK")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        result_cross = run_job(JobSpec(input_path=str(FIXTURES / 'lily_cross_staff_tuplet.ly'),
                                        output_path=str(THIS_DIR / '_out_lily_cross_staff.musicxml')))
    from importers.lilypond_importer import LilyCrossStaffManualFixWarning, LilyCrossStaffMergeFailedWarning
    # This fixture also carries a coexisting whole-measure rest voice
    # (`R2.`) alongside the tuplet -- the exact pitch/staff/beam/tuplet
    # sequence checked below would not match if _remove_rest_only_
    # voices() had not already cleanly removed it before the merge, so
    # that cleanup is implicitly verified here too, not just the merge
    # itself.
    # `\change Staff` mid-tuplet -- a single tuplet's own notes split
    # across two staves -- is the one case this importer's normal
    # per-staff-Part architecture can't correctly represent (MusicXML
    # has no way for one beam/tuplet bracket to span two <part>
    # elements). Rather than fall back to replacing the measure with a
    # rest, the whole staff group is merged into one custom-emitted
    # multi-staff part (see importers/multi_staff_emitter.py) whenever
    # this is detected -- confirmed here neither fallback warning fired,
    # and checked directly against the WRITTEN FILE below (not
    # result_cross.score, which still holds the normal, unmerged
    # per-part music21 objects -- the merge happens only in the
    # spliced-in XML text music21's own object model can't represent).
    assert not any(issubclass(w.category, (LilyCrossStaffManualFixWarning, LilyCrossStaffMergeFailedWarning))
                    for w in caught), [str(w.message) for w in caught]

    import re
    xml_text = result_cross.output_path.read_text()
    assert xml_text.count('<part ') == 1, "should be ONE merged part, not two separate ones"
    assert '<staves>2</staves>' in xml_text
    measure1 = re.search(r'<measure number="1">(.*?)</measure>', xml_text, re.S).group(1)
    notes = re.findall(r'<note>.*?</note>', measure1, re.S)

    def field(note_xml, tag):
        m = re.search(rf'<{tag}>([^<]*)</{tag}>', note_xml)
        return m.group(1) if m else None

    steps = [field(n, 'step') for n in notes if '<rest' not in n]
    staves = [field(n, 'staff') for n in notes]
    assert steps == ['C', 'D', 'E', 'F', 'G', 'A', 'B', 'C', 'C', 'D', 'E'], steps
    # The 6-note tuplet run starts on staff 1 and crosses to staff 2
    # partway through -- exactly the run this whole mechanism exists
    # for.
    assert staves[:6] == ['1', '1', '2', '2', '2', '2'], staves[:6]
    beam1_states = [re.search(r'<beam number="1">(\w+)</beam>', n) for n in notes[:6]]
    beam1_states = [m.group(1) if m else None for m in beam1_states]
    assert beam1_states == ['begin', 'continue', 'continue', 'continue', 'continue', 'end'], beam1_states
    tuplet_types = [re.search(r'<tuplet type="(\w+)"', n) for n in notes[:6]]
    tuplet_types = [m.group(1) if m else None for m in tuplet_types]
    assert tuplet_types == ['start', None, None, None, None, 'stop'], tuplet_types
    print("[lilypond: \\change Staff mid-tuplet -- correctly PRESERVED as one merged multi-staff part] OK")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        result_simple = run_job(JobSpec(input_path=str(FIXTURES / 'lily_simple_staff_change.ly'),
                                         output_path=str(THIS_DIR / '_out_lily_simple_staff_change.musicxml')))
    # A `\change Staff` between ordinary notes (no tuplet open at the
    # time) must NOT trigger LilyCrossStaffManualFixWarning -- confirmed
    # against a real piece that flagging every `\change Staff`
    # regardless blanked 11 measures that were already rendering
    # correctly, alongside the one that genuinely needed it. Only a
    # redirect that happens WHILE A TUPLET IS OPEN should ever raise it.
    assert not any(issubclass(w.category, LilyCrossStaffManualFixWarning) for w in caught), \
        [str(w.message) for w in caught]
    simple_treble, simple_bass = result_simple.score.parts
    treble_notes = [n.pitch.name for n in simple_treble.recurse().notes]
    assert treble_notes == ['C', 'D', 'E', 'C', 'D', 'E'], treble_notes  # native only; redirected F,E,D land on bass
    bass_notes = [n.pitch.name for n in simple_bass.recurse().notes]
    assert bass_notes == ['C', 'D', 'E', 'F', 'G', 'A', 'F', 'E', 'D', 'C', 'D', 'E'], bass_notes
    print("[lilypond: plain \\change Staff between notes (no tuplet open) -- NOT flagged] OK")


def test_abc():
    import warnings
    fixture = FIXTURES / 'abc_single_tune.abc'
    from music21 import converter
    legacy_score = converter.parse(str(fixture), forceSource=True)

    result = run_job(JobSpec(input_path=str(fixture),
                              output_path=str(THIS_DIR / '_out_abc.musicxml')))
    assert result.format == 'abc'
    assert_same_content('abc', score_signature(legacy_score), score_signature(result.score))

    roundtrip = converter.parse(str(result.output_path), forceSource=True)
    assert_same_content('abc (round-trip)', score_signature(legacy_score),
                         score_signature(roundtrip))
    print(f"[abc] OK  -- {'-'.join(n.pitch.nameWithOctave for n in result.score.recurse().notes)}")

    # A single .abc file very commonly bundles many tunes under separate
    # "X:" headers (confirmed against music21's own bundled corpus: one
    # real file held 200) -- music21 then returns an Opus, not a Score,
    # which this importer's import_score() contract ("return ONE Score")
    # can't pass through directly. The first tune is kept and an
    # ABCMultipleTunesWarning names how many others were skipped, rather
    # than either crashing or silently picking one with no indication
    # anything else was in the file.
    from importers.abc_importer import ABCMultipleTunesWarning
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        multi_result = run_job(JobSpec(input_path=str(FIXTURES / 'abc_multi_tune.abc'),
                                        output_path=str(THIS_DIR / '_out_abc_multi.musicxml')))
    assert any(issubclass(w.category, ABCMultipleTunesWarning) for w in caught), \
        [str(w.message) for w in caught]
    first_tune_pitches = [n.pitch.name for n in multi_result.score.recurse().notes]
    assert first_tune_pitches == ['C', 'D', 'E', 'F'], first_tune_pitches
    print("[abc: multi-tune file -- first tune kept, warning names the rest] OK")

    # ABC's `V:n clef=...` (per-voice clef) is standard, common syntax
    # (see the module's clef-support section) that music21's own ABC
    # importer does not read at all -- confirmed directly in its
    # source: the one place it looks for clef info only ever checks a
    # K: (key) field's text, is never consulted for V: fields, and even
    # then only recognizes the substrings 'bass' and '-8va'. A real
    # 4-voice SATB tune (soprano/alto: treble, tenor: tenor clef, bass:
    # bass clef) must come out with all four clefs correct, not the
    # treble-for-everything music21 produces on its own.
    satb_result = run_job(JobSpec(input_path=str(FIXTURES / 'abc_satb_clefs.abc'),
                                   output_path=str(THIS_DIR / '_out_abc_satb.musicxml')))
    from music21 import clef as m21clef
    actual_clefs = [type(p.recurse().getElementsByClass(m21clef.Clef).first()).__name__
                    for p in satb_result.score.parts]
    assert actual_clefs == ['TrebleClef', 'TrebleClef', 'TenorClef', 'BassClef'], actual_clefs

    # Every C-clef in common use, plus the standard aliases and +8/-8
    # octave suffix, must parse to the correct sign/line -- covering
    # ABC 2.1's own documented equivalence table (alto1=soprano,
    # alto2=mezzosoprano, alto4=tenor, bass3=baritone) and the named
    # aliases real ABC software (abc2midi, yaps, abcm2ps) also accepts.
    from importers.abc_importer import _parse_abc_clef
    expected = {
        'treble': ('G', 2), 'alto': ('C', 3), 'tenor': ('C', 4), 'bass': ('F', 4),
        'alto1': ('C', 1), 'alto2': ('C', 2), 'alto4': ('C', 4), 'bass3': ('F', 3),
        'soprano': ('C', 1), 'mezzosoprano': ('C', 2), 'baritone': ('F', 3),
    }
    for spec, (sign, line) in expected.items():
        c = _parse_abc_clef(spec)
        assert c is not None and c.sign == sign and c.line == line, (spec, c)
    assert _parse_abc_clef('treble-8').octaveChange == -1
    assert _parse_abc_clef('not-a-clef') is None
    print("[abc: all common C-clefs + aliases + octave suffixes parse correctly] OK")


def test_midi():
    import shutil
    if not any(shutil.which(name) for name in
               ('mscore3', 'mscore', 'musescore3', 'MuseScore3', 'mscore4', 'musescore4')):
        print("[midi] SKIPPED -- no MuseScore executable found on PATH")
        return

    fixture = FIXTURES / 'midi_scale.mid'
    result = run_job(JobSpec(input_path=str(fixture),
                              output_path=str(THIS_DIR / '_out_midi.musicxml')))
    assert result.format == 'midi'
    pitches = [n.pitch.nameWithOctave for n in result.score.recurse().notes]
    # This importer doesn't do its own MIDI->notation work at all (see
    # importers/midi_importer.py's docstring) -- it shells out to a real
    # MuseScore install and imports whatever MusicXML MuseScore itself
    # produces, so this just confirms that hand-off actually works
    # end to end, not any quantization/voicing logic of our own.
    assert pitches == ['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4', 'C5'], pitches
    print(f"[midi] OK  -- {'-'.join(pitches)}")


def test_format_autodetection():
    assert run_job(JobSpec(input_path=str(FIXTURES / 'musedata_quintet'),
                            output_path=str(THIS_DIR / '_out_autodetect_md.musicxml'))).format == 'musedata'
    assert run_job(JobSpec(input_path=str(FIXTURES / 'palestrina_agnus.krn'),
                            output_path=str(THIS_DIR / '_out_autodetect_krn.musicxml'))).format == 'humdrum'
    assert run_job(JobSpec(input_path=str(FIXTURES / 'prayer_of_a_tired_child.musicxml'),
                            output_path=str(THIS_DIR / '_out_autodetect_xml.musicxml'))).format == 'musicxml'
    assert run_job(JobSpec(input_path=str(FIXTURES / 'lily_chords.ly'),
                            output_path=str(THIS_DIR / '_out_autodetect_ly.musicxml'))).format == 'lilypond'
    assert run_job(JobSpec(input_path=str(FIXTURES / 'abc_single_tune.abc'),
                            output_path=str(THIS_DIR / '_out_autodetect_abc.musicxml'))).format == 'abc'
    import shutil
    if any(shutil.which(name) for name in
           ('mscore3', 'mscore', 'musescore3', 'MuseScore3', 'mscore4', 'musescore4')):
        assert run_job(JobSpec(input_path=str(FIXTURES / 'midi_scale.mid'),
                                output_path=str(THIS_DIR / '_out_autodetect_mid.musicxml'))).format == 'midi'
    print("[format autodetection] OK  -- all fixtures detected correctly")


if __name__ == '__main__':
    test_musedata()
    test_musedata_stage1_patch_is_harmless_here()
    test_humdrum()
    test_musicxml()
    test_lilypond()
    test_abc()
    test_midi()
    test_format_autodetection()
    print("\nAll checks passed.")
