\version "2.24.3"
\score {
  \new Staff {
    <c' e' g'>4 <d' f' a'>4 r4 <c' e' g' c''>2
  }
}
