\version "2.24.3"
\score {
  \new Staff {
    \key e \minor
    \time 4/4
    c'4~ c'8 d'8-. e'4-> |
    << { g'4 a' } \\ { c'4 b } >>
  }
}
