\version "2.24.3"
\score {
  \context PianoStaff <<
    \context Staff = "up" {
      \clef treble
      \time 3/4
      <<
        { \tuplet 6/4 { c'16 d' \change Staff = "down" e f g a } b'4 \change Staff = "up" c''4 }
        { R2. }
      >>
    }
    \context Staff = "down" {
      \clef bass
      c,4 d,4 e,4
    }
  >>
}
