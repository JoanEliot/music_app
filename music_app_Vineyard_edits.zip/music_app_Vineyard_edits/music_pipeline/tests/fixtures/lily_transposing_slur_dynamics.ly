\version "2.24.3"
\score {
  <<
    \new Staff \with { instrumentName = "Clarinet in Bb" } {
      \transposition bes
      \key d \major
      c'4( d' e')-\p f'4\<
      \repeat unfold 2 { g'8 }
      a'4\f
    }
  >>
}
