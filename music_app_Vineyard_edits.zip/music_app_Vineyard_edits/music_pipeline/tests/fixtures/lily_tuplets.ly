\version "2.24.3"
\score {
  \new Staff {
    \time 4/4
    c'4 \tuplet 3/2 { d'16 e' f' } \tuplet 3/2 { g'16 a' b' } c''4
    \tuplet 6/4 { c'16 d' e' f' g' a' } b'4 c''4
  }
}
