\version "2.24.3"
\score {
  \new StaffGroup <<
    \new Staff {
      \key g \major
      \time 3/4
      \clef treble
      g'4 a' b' | c''2. |
    }
    \new Staff {
      \clef bass
      r4 r r | g2. |
    }
  >>
}
