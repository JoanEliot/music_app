\version "2.24.3"
\score {
  \new Staff {
    \repeat volta 2 { c'4 d' e' f' }
    \alternative { { g'1 } { a'1 } }
  }
}
