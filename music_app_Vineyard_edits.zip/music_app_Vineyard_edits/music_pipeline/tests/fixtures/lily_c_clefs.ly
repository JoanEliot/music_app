\version "2.24.3"
\score {
  \new Staff {
    \clef soprano
    c'4
    \clef mezzosoprano
    c'4
    \clef baritone
    c'4
    \clef varbaritone
    c'4
    \clef treble
    c'4
  }
}
