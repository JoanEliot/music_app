\version "2.24.3"
\score {
  \context PianoStaff <<
    \context Staff = "up" {
      \clef treble
      \time 3/4
      c'4 d' e'
      \change Staff = "down" f e d
      \change Staff = "up" c' d' e'
    }
    \context Staff = "down" {
      \clef bass
      c4 d e | f g a | c4 d e
    }
  >>
}
