\version "2.24.0"
\score {
  \new Staff = "melody" {
    \time 4/4 \key g \major
    \new Voice = "tune" { g'4 a' b'( c'') d''2 r4 g'4 | g'1 }
    \addlyrics { Twin -- kle twin __ kle lit -- tle }
    \addlyrics { Ba -- by dar __ ling "sleep now" }
  }
}
