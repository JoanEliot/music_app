\version "2.24.0"
\header { title = "Pickup phrases" composer = "A. Teacher" }
\score {
  \new Staff = "s" {
    \time 4/4
    \new Voice = "v" {
      c''4 d'' e'' g''8( a''^"SS: Pickup one" | b''8 c''') d''4 e''8 f'' g''4^"SE:" |
      c''4 d'' e'' f''8^"SS: Pickup two" g'' | a''4 b'' c'''2 |
    }
    \addlyrics { one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen }
  }
}
