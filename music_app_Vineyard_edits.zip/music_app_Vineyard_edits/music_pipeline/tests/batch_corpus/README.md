# Batch demo corpus

A small mixed folder for trying batch processing:

    python cli.py tests/batch_corpus -r --output-dir out --report out/report.json
    python cli.py tests/batch_corpus -r --dry-run

Expected: 13 inputs ok, 1 failed (`broken_on_purpose.ly` is invalid LilyPond,
to show that one bad file doesn't stop the batch), this README and
`sub/notes.txt` passed over as not music, the `.hidden` folder skipped, and
`dup.abc` / `dup.ly` written as `dup-abc.musicxml` / `dup-lilypond.musicxml`
instead of overwriting each other. `tunes.abc`, `dup.abc`, `snippets.ly` and
`sub/marked.musicxml` each produce several output files. `musedata_work_in_parts/` holds the four single-part files of one MuseData work (Busnoys, "In hydraulis", stage 2 with lyrics): the scan turns the folder into ONE job named after the folder, unlike a single multi-part `.md` file, which is a job by itself.
