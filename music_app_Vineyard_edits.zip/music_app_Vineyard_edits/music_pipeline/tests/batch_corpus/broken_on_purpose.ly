\version "2.24.0"
\score { \new Staff { c\x27 d\x27 e\x27 | this is not valid lilypond ((( } }
