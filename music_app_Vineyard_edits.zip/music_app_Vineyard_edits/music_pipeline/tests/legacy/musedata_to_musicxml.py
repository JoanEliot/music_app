#!/usr/bin/env python3
"""
musedata_to_musicxml.py

Converts MuseData files (stage 1 or stage 2; .md / .musedata / .zip) to
MusicXML, using music21's own MuseData parser under the hood.

WHY THIS EXISTS
----------------
music21's built-in MuseData -> MusicXML pipeline is correct for parsing,
but has one real bug: for *stage 1* MuseData files, it crashes during
MusicXML export with:

    TypeError: cannot serialize <int> (type int)

Root cause (in music21/musedata/__init__.py and
music21/musedata/translate.py):
  - MuseDataPart.getPartName() unconditionally returns None when the
    file is stage 1 (stage 1 never carried a part-name field).
  - translate.musedataPartToStreamPart() does:
        p.id = museDataPart.getPartName()   # -> p.id = None
        p.partName = p.id
  - Music21Object.id, when set to None, falls back to returning Python's
    builtin id(self) -- a raw memory address (an int) -- from then on.
  - That int ends up as `partName`, and MusicXML's XML serializer can't
    write an int as element text, hence the crash.

This is NOT a bug in your files, and it is not specific to any one
file -- it fires on every stage 1 MuseData file. This script patches
just that one behavior (assigns a fallback "Part N" name instead of
letting None leak into a memory address) and otherwise relies entirely
on music21's existing, well-tested MuseData parsing (stage 1 and stage
2, ties, slurs, beams, dynamics, lyrics, figured bass, etc.).

USAGE
-----
    python3 musedata_to_musicxml.py input.musedata [output.musicxml]
    python3 musedata_to_musicxml.py input_dir/ [output.musicxml]
    python3 musedata_to_musicxml.py --movements parent_dir/ [output_dir/]

Single file:
    Converts that one file. Output defaults to the input path with a
    .musicxml extension.

Single directory (no flag):
    MuseData conventionally stores one physical file per
    instrument/part (e.g. a string quartet as 01, 02, 03, 04 -- often
    with no file extension at all -- in one folder, all belonging to
    the same work). This script follows music21's own convention: it
    feeds every part-file in the directory into a single MuseDataWork
    and writes ONE combined multi-part MusicXML score (all parts
    together), NOT one MusicXML file per part-file. Output defaults to
    <directory_name>.musicxml.

--movements parent_dir/ [output_dir/]:
    For corpora laid out as one subfolder per movement, each
    subfolder holding that movement's per-part files -- e.g.:
        cantata18/01/01, cantata18/01/02, ..., cantata18/01/08
        cantata18/02/01, cantata18/02/02, ...
        ...
    -- this walks every FIRST-LEVEL subfolder of parent_dir, and for
    each one combines all the files directly inside it into one
    multi-part score (same combining logic as the single-directory
    case above), written as <output_dir>/<subfolder_name>.musicxml.
    Subfolders nested deeper than one level are not descended into --
    each first-level subfolder is treated as exactly one movement/work.
    If output_dir is omitted, output files are written next to
    parent_dir, in a new folder named <parent_dir_name>_musicxml/.

NOTE ON music21's PARSE CACHE
------------------------------
music21 caches parsed results on disk (under its temp directory, e.g.
/tmp/music21/*.p.gz) keyed by file content hash, to speed up repeat
parsing. This script always parses with forceSource=True to bypass
that cache, since a stale cache entry can otherwise silently serve an
old (possibly broken) parse result even after this patch is applied.
"""

import sys
from pathlib import Path

from music21.musedata import translate as _musedataTranslate

_original_musedataPartToStreamPart = _musedataTranslate.musedataPartToStreamPart


def _make_patched_part_fn():
    counter = {"n": 0}

    def patched(museDataPart, inputM21=None):
        part_name = museDataPart.getPartName()

        if not part_name or not isinstance(part_name, str):
            counter["n"] += 1
            part_name = f"Part {counter['n']}"

        # Reuse music21's original, well-tested logic by temporarily
        # overriding getPartName() to return our fallback string
        # instead of None.
        orig_get_part_name = museDataPart.getPartName
        museDataPart.getPartName = lambda: part_name
        try:
            return _original_musedataPartToStreamPart(museDataPart, inputM21=inputM21)
        finally:
            museDataPart.getPartName = orig_get_part_name

    return patched


def apply_musedata_stage1_fix():
    """Monkeypatch music21 so stage-1 MuseData files export cleanly."""
    _musedataTranslate.musedataPartToStreamPart = _make_patched_part_fn()


def convert_one(input_path: Path, output_path: Path) -> None:
    """Convert a single MuseData file (.md/.musedata/.zip) to MusicXML."""
    from music21 import converter

    score = converter.parse(str(input_path), forceSource=True)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    score.write("musicxml", fp=str(output_path))
    print(f"OK  {input_path} -> {output_path}")


def convert_directory_as_one_work(input_dir: Path, output_path: Path) -> None:
    """Combine every MuseData part-file in a directory into ONE multi-part
    MusicXML score, matching music21's own convention for MuseData
    directories (one physical file per instrument, all one work)."""
    from music21 import converter

    score = converter.parse(str(input_dir), forceSource=True)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    score.write("musicxml", fp=str(output_path))
    part_names = ", ".join(p.partName for p in score.parts)
    print(f"OK  {input_dir}/ -> {output_path}  ({len(score.parts)} parts: {part_names})")


def convert_movements(parent_dir: Path, output_dir: Path) -> int:
    """Walk each first-level subfolder of parent_dir, treat all files
    directly inside each subfolder as one movement/work (one combined
    multi-part score), and write one MusicXML file per subfolder.

    Returns the number of subfolders that failed to convert.
    """
    subfolders = sorted(p for p in parent_dir.iterdir() if p.is_dir())
    if not subfolders:
        print(f"No subfolders found directly inside {parent_dir}")
        return 1

    failures = []
    for sub in subfolders:
        # skip empty subfolders or ones with no files at all
        if not any(f.is_file() for f in sub.iterdir()):
            print(f"SKIP {sub} (no files)")
            continue
        out_path = output_dir / f"{sub.name}.musicxml"
        try:
            convert_directory_as_one_work(sub, out_path)
        except Exception as e:
            failures.append((sub, e))
            print(f"FAIL {sub}: {e}")

    if failures:
        print(f"\n{len(failures)} of {len(subfolders)} movement(s)/subfolder(s) failed.")
    return len(failures)


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 1

    apply_musedata_stage1_fix()

    if argv[1] == "--movements":
        rest = argv[2:]
        if not rest:
            print(__doc__)
            return 1
        parent_dir = Path(rest[0])
        if not parent_dir.is_dir():
            print(f"{parent_dir} is not a directory")
            return 1
        output_dir = Path(rest[1]) if len(rest) > 1 else parent_dir.parent / f"{parent_dir.name}_musicxml"
        output_dir.mkdir(parents=True, exist_ok=True)
        n_failed = convert_movements(parent_dir, output_dir)
        return 1 if n_failed else 0

    in_path = Path(argv[1])

    if in_path.is_dir():
        out_path = Path(argv[2]) if len(argv) > 2 else in_path.with_suffix(".musicxml")
        convert_directory_as_one_work(in_path, out_path)
        return 0
    else:
        out_path = Path(argv[2]) if len(argv) > 2 else in_path.with_suffix(".musicxml")
        convert_one(in_path, out_path)
        return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
