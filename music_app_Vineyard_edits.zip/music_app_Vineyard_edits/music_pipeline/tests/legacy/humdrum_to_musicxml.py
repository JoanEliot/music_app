#!/usr/bin/env python3
"""
humdrum_to_musicxml.py

Converts Humdrum files (most commonly **kern, .krn) to MusicXML, using
music21's Humdrum parser under the hood.

STRUCTURAL DIFFERENCE FROM MuseData
------------------------------------
MuseData conventionally splits a multi-part work across several
FILES, one per instrument (see musedata_to_musicxml.py's directory-
combining logic and its --movements mode).

Humdrum/**kern does NOT work that way: a single Humdrum file already
holds every part for one movement, as parallel "spines" (tab-separated
columns) within that one file -- e.g. a 4-voice choral piece is one
file with 4 **kern spines, not 4 separate files. music21 turns each
spine into its own Part automatically. So there is no directory-
combining step needed here, unlike MuseData -- each Humdrum file
converts to one complete, already-multi-part score on its own.

For a whole multi-movement work (one Humdrum file per movement, all
sitting in one folder -- also a common layout), this script's
directory mode simply converts each file independently to its own
MusicXML file (it does NOT merge multiple files into one score, since
each file already IS one complete movement).

STATUS
------
Unlike MuseData, music21's Humdrum importer has no known systemic
export bug -- this script does not carry a patch/workaround the way
musedata_to_musicxml.py does. It has been spot-checked against real,
bundled multi-voice **kern files (5-voice Palestrina, 2-staff Chopin)
and both convert cleanly. That said, this has NOT been exhaustively
tested against every Humdrum feature (e.g. exotic spine manipulators,
multiple pieces concatenated in one file with *^/*v splits/joins,
unusual tandem interpretations) -- if you hit a conversion error on a
real file, send it over the same way we debugged the MuseData issue
and we'll trace it the same way rather than guessing.

EMBEDDED '!!!filter:' REFERENCE RECORDS
----------------------------------------
Some Humdrum files (particularly Craig Sapp's KernScores-style
encodings) carry '!!!filter:' reference records -- self-describing
instructions for the separate Humdrum Extras 'shed' toolkit, which
viewers like the Verovio Humdrum Viewer run automatically before
display. The most common one, 'satb2gs', merges a 4-voice open-score
SATB layout (one **kern spine per voice) onto a 2-staff grand-staff
layout, splitting a staff into two Humdrum sub-spines only where its
two voices are rhythmically independent at a given moment. music21's
own importer does not know about these records at all -- without this
script's help it always produces one Part per raw **kern spine and
only ever reads the primary '*clef' tandem, never the records' effect.

By default (see humdrum_filters.py), this script reads a file's own
'!!!filter:' records and applies the ones it recognizes -- 'satb2gs'
(by running the REAL compiled humlib tool, auto-building it from
github.com/humdrum-tools/humlib the first time it's needed, and
caching the binary for reuse) and simple 'shed -e s/PATTERN/REPL/FLAGS'
substitutions (applied ourselves, scoped to interpretation tokens only,
never to notes). Anything else (e.g. 'msearch', a search/highlight
tool that doesn't reshape the score) is left alone and reported.
Building satb2gs requires git, g++, and make on this machine, plus
network access to github.com the first time. Pass --no-filters to skip
all of this and parse the raw, un-transformed spine layout instead.

USAGE
-----
    python3 humdrum_to_musicxml.py input.krn [output.musicxml]
    python3 humdrum_to_musicxml.py input_dir/ [output_dir/]
    python3 humdrum_to_musicxml.py --no-filters input.krn [output.musicxml]

--no-filters:
    Skip applying any embedded '!!!filter:' records (see above) --
    parse the file exactly as literally encoded, spine by spine. Must
    come before the input path if used.

Single file:
    Converts that one file. Output defaults to the input path with a
    .musicxml extension.

Directory (no flag):
    Converts every Humdrum file found *recursively* under the
    directory, each one INDEPENDENTLY (no combining -- see above),
    preserving the relative subfolder structure in the output
    directory. A file counts as Humdrum if it has a .krn or .hum
    extension, or -- for extensionless files -- if one of its leading
    lines starts with '**' (a Humdrum exclusive interpretation, e.g.
    '**kern'; leading '!!!' reference/metadata comment lines before it
    are skipped over), the same kind of content-based detection used
    for extensionless MuseData part-files.

    If output_dir is omitted, it defaults to <dir_name>_musicxml/ next
    to the input directory.
"""

import sys
from pathlib import Path

HUMDRUM_EXTENSIONS = {".krn", ".hum"}


def looks_like_humdrum(path: Path) -> bool:
    if path.suffix.lower() in HUMDRUM_EXTENSIONS:
        return True
    # Extension missing or unrecognized: sniff content. Real Humdrum
    # files commonly start with one or more '!!!' global reference
    # comments before the '**' exclusive interpretation line (e.g.
    # '**kern') that actually starts the data, so scan a bounded
    # number of leading lines rather than just the first non-blank one.
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for _, line in zip(range(200), f):
                if line.strip().startswith("**"):
                    return True
    except OSError:
        return False
    return False


def convert_one(input_path: Path, output_path: Path, apply_filters: bool = True) -> None:
    """Convert a single Humdrum file to MusicXML.

    If apply_filters is True (the default), any embedded '!!!filter:'
    records in the file (e.g. 'satb2gs') are applied first -- see
    humdrum_filters.py and this script's module docstring. If a
    'satb2gs' filter is present but no compiled satb2gs binary is
    available or buildable, falls back automatically to the
    pure-Python SATB merger in satb2gs_python.py (4-voice SATB only).
    """
    from music21 import converter
    import humdrum_filters

    with open(input_path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()

    filter_notes = []
    needs_python_satb2gs = False
    if apply_filters and humdrum_filters.extract_filter_commands(text):
        text, filter_notes, needs_python_satb2gs = humdrum_filters.apply_embedded_filters(text)

    score = converter.parse(text, format="humdrum", forceSource=True)

    if needs_python_satb2gs:
        import satb2gs_python
        score = satb2gs_python.merge_satb_to_grand_staff(score)
        filter_notes.append("Applied pure-Python SATB-to-grand-staff merge")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    score.write("musicxml", fp=str(output_path))
    n_parts = len(score.parts)
    print(f"OK  {input_path} -> {output_path}  ({n_parts} part(s))")
    for note in filter_notes:
        print(f"     {note}")


def convert_directory_batch(input_dir: Path, output_dir: Path, apply_filters: bool = True) -> int:
    """Convert every Humdrum file found recursively under input_dir,
    each one independently, mirroring the output directory structure.

    Returns the number of files that failed to convert.
    """
    files = sorted(p for p in input_dir.rglob("*") if p.is_file() and looks_like_humdrum(p))
    if not files:
        print(f"No Humdrum (**kern) files found under {input_dir}")
        return 1

    failures = []
    for f in files:
        rel = f.relative_to(input_dir)
        out_path = (output_dir / rel).with_suffix(".musicxml")
        try:
            convert_one(f, out_path, apply_filters=apply_filters)
        except Exception as e:
            failures.append((f, e))
            print(f"FAIL {f}: {e}")

    if failures:
        print(f"\n{len(failures)} of {len(files)} file(s) failed.")
    return len(failures)


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 1

    apply_filters = True
    if argv[1] == "--no-filters":
        apply_filters = False
        argv = [argv[0]] + argv[2:]

    if len(argv) < 2:
        print(__doc__)
        return 1

    in_path = Path(argv[1])

    if in_path.is_dir():
        output_dir = Path(argv[2]) if len(argv) > 2 else in_path.parent / f"{in_path.name}_musicxml"
        output_dir.mkdir(parents=True, exist_ok=True)
        n_failed = convert_directory_batch(in_path, output_dir, apply_filters=apply_filters)
        return 1 if n_failed else 0
    else:
        out_path = Path(argv[2]) if len(argv) > 2 else in_path.with_suffix(".musicxml")
        convert_one(in_path, out_path, apply_filters=apply_filters)
        return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
