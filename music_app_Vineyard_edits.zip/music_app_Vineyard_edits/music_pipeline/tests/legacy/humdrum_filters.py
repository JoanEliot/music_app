"""
humdrum_filters.py

Some Humdrum files carry embedded '!!!filter:' global reference
records -- self-describing instructions for the separate Humdrum
Extras toolkit (humlib's 'shed' program and friends) telling a
humlib-aware viewer (e.g. the Verovio Humdrum Viewer) how to
transform the raw spine data before display. Two common ones:

    !!!filter: satb2gs
        Merge a 4-voice open-score SATB layout (one **kern spine per
        voice) onto a 2-staff piano/grand-staff layout (soprano+alto
        share a treble staff, tenor+bass share a bass staff), splitting
        a staff into two Humdrum sub-spines (*^ / *v) only where the
        two voices on it are rhythmically independent at that moment.

    !!!filter: shed -e s/PATTERN/REPLACEMENT/FLAGS
        A plain sed-style substitution applied to interpretation
        tokens (tokens starting with '*', e.g. clef/key/meter tandems)
        -- NOT to note data. Commonly used after satb2gs to fix up a
        clef that merging left as a historic clef (e.g. turning a
        soprano *clefC1 into a modern *clefG2).

music21's own Humdrum importer does not know about or execute these
filter records at all (verified: they don't even survive into parsed
metadata) -- it only ever sees the raw, pre-filter spine layout. This
module closes that specific gap by:

  1. Reading a file's own '!!!filter:' lines.
  2. For 'satb2gs': running the REAL compiled humlib 'satb2gs' tool
     (not a Python reimplementation) as a subprocess, auto-building it
     from source (github.com/humdrum-tools/humlib) the first time it's
     needed, and caching the binary for reuse.
  3. For a 'shed -e s/.../.../ ' substitution: applying that exact
     substitution ourselves, scoped to interpretation tokens only.
  4. Leaving any other filter (e.g. 'msearch ...', a search/highlight
     tool that doesn't reshape the score) untouched, with a note.

This is intentionally NOT a general 'shed' or 'humlib filter' clone --
only the two transform types above are supported. Anything else is
reported, not silently mishandled.
"""

import re
import shutil
import subprocess
from pathlib import Path

HUMLIB_REPO_URL = "https://github.com/humdrum-tools/humlib.git"
DEFAULT_BUILD_DIR = Path.home() / ".cache" / "musicxml_converters" / "humlib"


def extract_filter_commands(text: str) -> list:
    """Return the command strings from every '!!!filter:' reference
    record in the file, in the order they appear."""
    commands = []
    for line in text.splitlines():
        line = line.rstrip("\r")
        if line.startswith("!!!filter:"):
            commands.append(line[len("!!!filter:"):].strip())
    return commands


def find_satb2gs_binary(build_dir: Path = DEFAULT_BUILD_DIR):
    """Locate a usable satb2gs(x) binary: first on PATH, then in the
    cached build directory. Returns None if not found (does not build)."""
    for name in ("satb2gs", "satb2gsx"):
        found = shutil.which(name)
        if found:
            return Path(found)
    for name in ("satb2gs", "satb2gsx"):
        candidate = build_dir / "bin" / name
        if candidate.exists():
            return candidate
    return None


def build_satb2gs_binary(build_dir: Path = DEFAULT_BUILD_DIR) -> Path:
    """Clone and compile humlib's satb2gs tool from source, caching the
    result under build_dir. Requires git, g++, and make on this machine,
    plus network access to github.com. Raises RuntimeError with a clear
    message if any of that isn't available."""
    for tool in ("git", "g++", "make"):
        if shutil.which(tool) is None:
            raise RuntimeError(
                f"Cannot build the satb2gs tool: '{tool}' is not installed. "
                f"Install it, or place a prebuilt 'satb2gs' binary on your PATH."
            )

    if not build_dir.exists():
        build_dir.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            ["git", "clone", "--depth", "1", HUMLIB_REPO_URL, str(build_dir)],
            check=True,
        )

    # humlib's cli/ source file is named satb2gsx.cpp (with a trailing
    # 'x'), so the built program is called satb2gsx, not satb2gs.
    subprocess.run(["make", "satb2gsx"], cwd=str(build_dir), check=True)

    binary = build_dir / "bin" / "satb2gsx"
    if not binary.exists():
        raise RuntimeError(
            f"Build appeared to succeed but {binary} was not produced. "
            f"Check {build_dir} manually."
        )
    return binary


def ensure_satb2gs_binary(build_dir: Path = DEFAULT_BUILD_DIR) -> Path:
    """Find an existing satb2gs binary, or build one if none is found."""
    existing = find_satb2gs_binary(build_dir)
    if existing is not None:
        return existing
    return build_satb2gs_binary(build_dir)


def run_satb2gs(text: str, binary: Path) -> str:
    result = subprocess.run(
        [str(binary)], input=text, capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"satb2gs failed: {result.stderr.strip()}")
    return result.stdout


_SED_EXPR_RE = re.compile(r"^s(.)(.*?)\1(.*?)\1([a-zA-Z]*)$")
_SHED_DASH_E_RE = re.compile(r"^shed\s+-e\s+(.+)$")


def apply_shed_substitution(text: str, pattern: str, replacement: str, flag_str: str) -> str:
    """Apply a sed-style s/pattern/replacement/flags substitution,
    scoped to interpretation tokens (fields starting with '*') only --
    never to note/rest/barline data. This mirrors how the shed-based
    filters we've seen in real files are actually used (clef/key/meter
    tandem cleanup after a structural transform like satb2gs)."""
    re_flags = re.IGNORECASE if "i" in flag_str.lower() else 0
    compiled = re.compile(pattern, re_flags)

    out_lines = []
    for line in text.split("\n"):
        if not line or line[0] in "!=":
            out_lines.append(line)
            continue
        fields = line.split("\t")
        new_fields = [
            compiled.sub(replacement, f) if f.startswith("*") else f
            for f in fields
        ]
        out_lines.append("\t".join(new_fields))
    return "\n".join(out_lines)


def apply_embedded_filters(text: str, build_dir: Path = DEFAULT_BUILD_DIR):
    """Apply every recognized '!!!filter:' record found in text, in
    order. Returns (transformed_text, notes, needs_python_satb2gs):

      - transformed_text: the text after any text-level filters (shed
        substitutions, or a successful compiled-satb2gs run).
      - notes: human-readable strings about anything applied or skipped.
      - needs_python_satb2gs: True if a 'satb2gs' filter was requested
        but no compiled binary could be found or built. The caller
        should parse `transformed_text` with music21 as normal, then
        call satb2gs_python.merge_satb_to_grand_staff() on the
        resulting Score. In this case, any 'shed' clef-substitution
        filter is intentionally skipped (returned text is unchanged
        for it) since the Python merger assigns its own clefs.
    """
    notes = []
    needs_python_satb2gs = False

    for cmd in extract_filter_commands(text):
        if cmd == "satb2gs" or cmd.startswith("satb2gs "):
            try:
                satb2gs_binary = ensure_satb2gs_binary(build_dir)
                text = run_satb2gs(text, satb2gs_binary)
                notes.append("Applied embedded filter: satb2gs (compiled tool)")
            except Exception as e:
                needs_python_satb2gs = True
                notes.append(
                    f"Compiled satb2gs unavailable ({e}); "
                    f"will use the pure-Python SATB merger after parsing instead"
                )
            continue

        m = _SHED_DASH_E_RE.match(cmd)
        if m:
            if needs_python_satb2gs:
                notes.append(
                    f"Skipped shed filter {cmd!r}: superseded by the Python "
                    f"merger's own clef assignment"
                )
                continue
            sed_expr = m.group(1).strip()
            sm = _SED_EXPR_RE.match(sed_expr)
            if sm:
                _, pattern, replacement, flags = sm.groups()
                text = apply_shed_substitution(text, pattern, replacement, flags)
                notes.append(f"Applied embedded filter: shed -e {sed_expr}")
                continue
            notes.append(f"Skipped unsupported shed expression: {cmd!r}")
            continue

        notes.append(f"Skipped filter (not a layout transform, or unsupported): {cmd!r}")

    return text, notes, needs_python_satb2gs
