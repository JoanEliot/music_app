"""
importers/lilypond_importer.py

LilyPond -> music21.stream.Score.

WHY THIS DOESN'T PARSE LILYPOND TEXT
--------------------------------------
LilyPond's input syntax is expressive enough (custom Scheme, `\\relative`
pitch arithmetic, `\\include`, user-defined variables, tag filtering...)
that a hand-rolled text parser chases that syntax forever. python-ly's
own maintainers, after over a decade of work on exactly this, still
describe their LilyPond->MusicXML export as "not optimal" and "heavy
development" in their own docs.

Instead, this runs the REAL `lilypond` binary against the input, with a
small Scheme override (see _WRAPPER_TEMPLATE below) that intercepts
every top-level `\\score` right after LilyPond's own parser has fully
resolved it -- `\\relative` already turned into absolute pitches,
`\\include`s already merged in, variables already substituted, repeat
structure still intact as a structured repeat (see "REPEATS" below,
NOT yet unfolded -- that part LilyPond does not do for us) -- and
prints that resolved music expression as a plain, structured Scheme
s-expression (`display-scheme-music`, a stable, built-in LilyPond
debugging function -- see scm/lily/music-functions.scm) instead of
typesetting it. No PDF/PNG/MIDI is produced. This was verified against
real output from LilyPond 2.24.3 before any of the parsing code below
was written (see importers/lilypond_sexp.py's docstring).

The result (importers.lilypond_sexp.Reader) is then walked into a
Score by _build_score() below.

SECURITY NOTE: a `.ly` file can embed arbitrary Scheme, and running
`lilypond` on it executes that Scheme, same as opening it in real
LilyPond or Frescobaldi would. Only import `.ly` files you trust.

WHAT COUNTS AS "ALREADY RESOLVED" BEFORE WE EVER SEE THE TREE
------------------------------------------------------------------
Everything LilyPond's own parser/interpreter resolves ahead of the
point our override intercepts it: `\\relative` octave arithmetic (every
pitch we see is already absolute), `\\include`, `\\set`/user-defined
music variables (already substituted/expanded in place), and key-aware
enharmonic spelling of `\\transpose` blocks if used. What is NOT
resolved at this point: repeat structure (see REPEATS below) --
LilyPond's actual unfolding of a repeat into its played-through form
happens later, inside its internal playback iterator, which never runs
in our dump-only mode, so this importer does that unfolding itself
(see _visit_VoltaRepeatedMusic).

REPEATS
------------------------------------------------------------------
`\\repeat volta N { body } \\alternative { {end1} {end2} ... }` is
meant to be NOTATED as an actual repeat sign, and this importer keeps
it that way: body and each ending are recorded once each, in printed
order, and turned into real music21 bar.Repeat barlines and
spanner.RepeatBracket volta brackets once real Measures exist (see
_apply_repeat_structure()) -- so writing the result back out as
MusicXML reproduces the repeat signs and 1st/2nd-ending brackets, not
a flattened play-through. `\\repeat unfold N { body }`, in contrast, is
LilyPond's own way of saying "don't show a repeat sign at all, just
write the notes out N times" -- a genuinely different source-level
instruction from `\\repeat volta` -- so THAT one is unfolded directly
during the walk (see _visit_UnfoldedRepeatedMusic). Either way, a
Score that still has its repeat barlines intact is not what you want
to feed straight to a MIDI export (a repeat sign means nothing to a
MIDI file) -- for that, run the Score through
transforms/unfold_repeats.py first, which expands bar.Repeat/
RepeatBracket structure into its played-through form, independent of
which importer produced the Score.

`\\repeat percent` and `\\repeat tremolo` are NOT handled (different,
rarer node types) -- if either appears, a LilyUnhandledRepeatWarning is
raised rather than silently dropping that music. LilyPond's own
`unfold-repeats` Scheme function was tried first, empirically, before
settling on the above: calling it only relabels a VoltaRepeatedMusic
node's type; it does NOT flatten it, because the actual unfolding
LilyPond itself does is normally performed by a different code path
(the playback iterator) that a tree dump never invokes.

TRANSPOSING INSTRUMENTS
------------------------------------------------------------------
LilyPond notes are always written in the instrument's WRITTEN pitch;
`\\transposition PITCH` is purely an informational/MIDI-only marker
(see LilyPond's own docs) naming the pitch that sounds when the staff's
written middle C is played -- it does not itself transpose anything in
the notation, including `\\key`, which stays in the WRITTEN key exactly
as typed. This importer captures `\\transposition` as a real
music21 Instrument.transposition Interval (computed from that pitch
relative to C4, which is exactly what LilyPond's own convention
means) and sets Part.atSoundingPitch = False, so the Part's own
KeySignature and notes are correctly the WRITTEN ones, and calling
music21's own, already-correct Part.toSoundingPitch() gives the
concert/sounding version -- notes AND key signature -- on demand,
rather than this importer inventing a separate parallel "concert key"
field. `\\with { instrumentName = ... }` is captured too, onto both
Part.partName and the Instrument object.

CROSS-STAFF NOTATION (`\\change Staff`) -- A REAL LIMITATION
------------------------------------------------------------------
`\\change Staff = "id"` (see _visit_ContextChange) redirects a voice's
notes onto a named staff correctly in terms of pitch and timing --
confirmed extensively against a real piece, for the common case of a
plain note/chord/rest run switching staves between tuplets (padding,
voice cleanup, and tuplet-ratio display for the surrounding material
are all independently handled and verified elsewhere in this file).

The one case this importer genuinely can't get right is a SINGLE
tuplet's own notes being split across two staves (`\\tuplet N/M { ...
\\change Staff = "x" ... }`, the redirect landing INSIDE the braces):
this importer represents each staff as its own independent music21
Part, and MusicXML has no way for a single beam or tuplet bracket to
span two different `<part>` elements, so such a run comes out as two
separately-bracketed fragments rather than one continuous beamed
group, the way real engraving software (Dorico, MuseScore) produces
natively when it owns the whole grand staff as one part. Getting that
right would need a different architecture (one Part, multiple staves,
notes tagged per-staff -- confirmed music21 has real support for this
via stream.PartStaff, but not for keeping ONE voice's notes numbered
continuously across the join, which would need further work of its
own) -- out of scope for now.

Rather than silently emit a measure whose correctness depends on
exactly how a given program interprets that specific edge case, only a
measure where a `\\change Staff` occurs WHILE A TUPLET IS OPEN is
replaced, on every affected staff, with a single visible whole-measure
rest, plus a bold text warning on the top staff -- see
_flag_and_blank_cross_staff_measures() -- and a
LilyCrossStaffManualFixWarning naming the affected measure(s) so a
caller (see cli.py) can report exactly where to look. Fix those
measures by hand from the original LilyPond source. Flagging every
`\\change Staff` regardless of whether a tuplet was open was tried
first and confirmed, against that same real piece, to blank 11
measures that were already rendering correctly alongside the one that
genuinely wasn't -- scoping the check to "was a tuplet open" is what
actually distinguishes the one real problem case from the many
harmless ones.

WHAT'S HANDLED
------------------------------------------------------------------
  - Staff / StaffGroup / ChoirStaff / PianoStaff / GrandStaff nesting
    -> Parts (grouping brackets/braces themselves are not yet
    represented -- see "NOT YET HANDLED"), including a bare sequential
    `{ }` wrapper around the whole staff structure (confirmed necessary
    against a real multi-page piano piece -- see _find_staves()).
  - `\\change Staff = "id"` (cross-staff notation, e.g. a piano piece
    where a passage in one hand is written on the other hand's staff
    for beaming/voice-crossing reasons -- confirmed present, and
    initially mishandled, in that same real piece): the notes that
    follow are correctly placed on the NAMED staff instead of the one
    they were physically read from, until changed back or the staff
    ends (see _StaffWalker.lane_target and _visit_ContextChange).
    Requires the target staff to have a name (`\\context Staff = "id"`
    or `\\new Staff = "id"`) matching the `\\change`; an unrecognized
    id raises LilyUnknownStaffChangeWarning and leaves the notes on
    their current staff rather than losing them.
  - Full polyphony: every voice on every staff is retained (via
    music21 Voice objects when a staff has more than one -- see
    _visit_SimultaneousMusic and _assemble_part()), not just the
    first. Nesting (divisi within divisi) is supported to whatever
    depth actually occurs, each level naming its child lanes
    "parent.2", "parent.3", etc. A voice that turns out to contain
    nothing but rests in a given measure (commonly a `<< {real} {R2.}
    >>` construct, where the second voice has nothing to say at that
    instant) is removed from that measure and the remaining voices
    renumbered, rather than left cluttering the output (see
    _remove_rest_only_voices()) -- confirmed to also resolve a real
    music21-export interaction where such a voice, sitting alongside a
    tupleted one, caused a bogus tuplet ratio to appear on the OTHER
    voice's own plain notes.
  - Notes, rests, chords, ties, slurs.
  - Dynamics: point markings (p, f, mf, ...) and crescendo/diminuendo
    hairpins (as music21 spanners).
  - Key signatures (as accidental pattern -- see _key_signature_from()
    for why mode/tonic naming is deliberately not attempted), time
    signatures, clefs (treble/bass/alto/tenor/soprano/mezzo-soprano/
    baritone/percussion -- see _CLEF_TABLE) -- including
    the common shorthand of writing `\\time`/`\\key` on only one staff
    of a system and letting it apply to all of them (see
    _propagate_signatures()), and a piece that never states `\\time`
    at all but does use manual `|` barchecks (see
    _infer_missing_time_signature()).
  - Repeats: `\repeat volta` (with or without `\alternative` endings)
    is preserved as real repeat barlines/volta brackets (see REPEATS
    above); `\repeat unfold` is unfolded, matching what it means in
    the source.
  - Transposing instruments (see TRANSPOSING INSTRUMENTS above) and
    instrument/part names.

NOT YET HANDLED (deliberately out of scope for this pass)
------------------------------------------------------------------
  - Tuplets are readable (quarterLength comes straight from LilyPond's
    own resolved 'length, so the *timing* is correct) but music21's
    automatic notation of an unusual fractional quarterLength isn't
    guaranteed to look clean -- fine for reading/playback, not
    guaranteed for re-engraving.
  - Grace notes, `\\repeat percent`/`\\repeat tremolo`, StaffGroup/
    ChoirStaff bracket styling, octave-shifted or rare clef variants
    (treble_8, french, subbass, ... -- see _CLEF_TABLE, trivial to
    extend once a real file needs one -- every C-clef in common use,
    plus baritone in both its C- and F-clef forms, is already covered).
  - Articulations beyond the common few in _ARTICULATION_TABLE.
  - More than one `\\score` block per file: only the first is
    converted; a LilyMultipleScoresWarning is raised for the rest
    rather than silently dropping them.
"""

import subprocess
import warnings
from fractions import Fraction
from pathlib import Path

from core.snippets import parse_markers
from .lilypond_sexp import Reader, MusicNode, Pitch, Symbol


class LilyMultipleScoresWarning(UserWarning):
    """Raised when the input has more than one \\score block; only the
    first is converted."""


class LilyPartialWarning(UserWarning):
    """A `\\partial` that couldn't be honoured -- one that isn't at the very
    start of the music (a short bar in the middle of a piece). The music
    is imported without it, so bar lines after that point may not line up
    with the source."""


class LilyLyricsWarning(UserWarning):
    """Lyrics that couldn't be placed exactly as written: a lyric block
    naming a voice or staff that doesn't exist, or more (or fewer)
    syllables than the notes can carry. The lyrics that could be placed
    still were."""


class LilyMetadataWarning(UserWarning):
    """Raised when the file's \\header/comment text couldn't be read;
    the notes still import, with an empty metadata dict."""


class LilyUnrecognizedClefWarning(UserWarning):
    """Raised when a \\clef produces a glyph/position combination not in
    _CLEF_TABLE; the clef change is skipped rather than guessed at."""


class LilyUnhandledRepeatWarning(UserWarning):
    """Raised for a repeat type this importer doesn't know how to
    unfold (e.g. \\repeat percent or \\repeat tremolo) -- that music is
    skipped rather than silently guessed at."""


class LilyVoiceMisalignedWarning(UserWarning):
    """Raised when the voices in an explicit polyphonic passage
    (<< \\\\ >>, \\new Voice, etc.) don't all end up the same length --
    real, well-formed LilyPond input shouldn't trigger this."""


class LilyUnterminatedSpannerWarning(UserWarning):
    """Raised when a slur or crescendo/diminuendo hairpin is still open
    at the end of a staff (no closing note ever arrived) -- it's kept,
    ending on the last note it reached, rather than silently dropped."""


class LilyUnknownStaffChangeWarning(UserWarning):
    """Raised when `\\change Staff = "X"` names a staff id this importer
    never found among the piece's declared staves -- the notes that
    follow stay on whichever staff they were already on, rather than
    being silently lost."""


class LilyCrossStaffMergeFailedWarning(UserWarning):
    """Raised when building correctly-preserved cross-staff notation
    (see importers/multi_staff_emitter.py) raises an exception for any
    reason -- the importer falls back to the older, safer
    blank-and-flag behavior (see LilyCrossStaffManualFixWarning) for
    the affected measure(s) rather than let a bug in the new emitter
    silently produce wrong or lost music."""


class LilyCrossStaffManualFixWarning(UserWarning):
    """Raised for a measure where a `\\change Staff` occurs WHILE A
    TUPLET IS OPEN -- i.e. a single tuplet's own notes get split across
    two staves, not just an ordinary note/chord/rest run changing
    staves between tuplets (that common case is already handled
    correctly and does NOT raise this). This importer represents
    cross-staff writing as two independent Parts trading voices --
    which, after extensive real testing, cannot reliably reproduce a
    single continuous beam/tuplet bracket spanning the staff change the
    way a genuine single-voice, multi-staff Part would (a real,
    documented architectural limitation; see the module docstring's
    CROSS-STAFF NOTATION section). Rather than emit a measure whose
    correctness depends on exactly how a given program interprets that
    specific edge case, every voice in the affected measure(s), on
    every affected staff, is replaced with a single, VISIBLE
    whole-measure rest, and a bold text warning is attached to the top
    staff -- so the gap is obvious and can never be mistaken for a
    silently-wrong transcription. Fix the measure(s) by hand from the
    original LilyPond source. Each warning names the
    affected measure number(s) so a caller (see cli.py) can report
    exactly where to look.
    """


_WRAPPER_TEMPLATE = '''\\version "{version}"

%% An explicit `\\score {{...}}` block is dispatched through
%% toplevel-score-handler, which receives a real ly:score? object --
%% ly:score-music unwraps it back to the music expression itself.
#(define (_import_pipeline_score_handler score)
   (display-scheme-music (ly:score-music score)))
#(set! toplevel-score-handler _import_pipeline_score_handler)

%% A BARE top-level music expression (no `\\score{{}}` at all, e.g. a
%% file that's just `\\relative {{ c' d e }}`) is dispatched separately,
%% through toplevel-music-handler, and never reaches
%% toplevel-score-handler above (confirmed against
%% ly/declarations-init.ly and scm/lily/lily-library.scm: the default
%% toplevel-music-handler, collect-music-for-book, calls
%% collect-scores-for-book directly rather than consulting the
%% toplevel-score-handler variable) -- so it needs its own override.
%% Routing it through scorify-music (the same preprocessing LilyPond's
%% own default handler would apply) rather than dumping the raw music
%% directly matters: the raw music has no 'length annotations at all
%% (confirmed empirically -- those are only added during the
%% score-interpreting step scorify-music performs), which this
%% importer relies on throughout for timing.
#(define (_import_pipeline_music_handler music)
   (display-scheme-music (ly:score-music (scorify-music music))))
#(set! toplevel-music-handler _import_pipeline_music_handler)

%% Scores written INSIDE an explicit `\\book {{...}}` (or its `\\bookpart`s)
%% never reach toplevel-score-handler either (confirmed: without this a
%% file whose only \\score sits inside \\book produced no output at all
%% and import failed with "no score output"). They arrive instead in
%% the finished book object, handed to toplevel-book-handler, so dump
%% each book's scores -- and, recursively, those of its bookparts --
%% the same way. LilyPond hands back a book's scores AND its bookparts
%% in REVERSE source order (confirmed: three scores arrive as 3, 2, 1),
%% so both lists are reversed here -- otherwise "the first \\score" the
%% importer keeps would silently be the last one in the file.
#(define (_import_pipeline_dump_book book)
   (for-each (lambda (s) (display-scheme-music (ly:score-music s)))
             (reverse (ly:book-scores book)))
   (let ((parts (ly:book-book-parts book)))
     (if (pair? parts) (for-each _import_pipeline_dump_book (reverse parts)))))
#(set! toplevel-book-handler _import_pipeline_dump_book)

\\include "{included_path}"
'''


def _run_lilypond(input_path: Path, lilypond_bin: str, work_dir: Path) -> str:
    """Runs lilypond on a wrapper file that \\includes the real input
    and overrides toplevel-score-handler (see module docstring) so
    each \\score prints its resolved music tree instead of being
    typeset. Returns everything printed to stdout (one dump per
    \\score, back to back). -I work_dir/input's own directory is added
    to LilyPond's search path so any \\include *inside* the user's file
    still resolves relative to the real file, not our temp wrapper.
    """
    version = _detect_lilypond_version(lilypond_bin)
    wrapper_path = work_dir / '_wrapper.ly'
    wrapper_path.write_text(
        _WRAPPER_TEMPLATE.format(version=version, included_path=str(input_path.resolve()))
    )

    result = subprocess.run(
        [lilypond_bin, '-I', str(input_path.resolve().parent),
         '-dno-point-and-click', str(wrapper_path)],
        cwd=str(work_dir), capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"lilypond failed to process {input_path} (exit {result.returncode}):\n"
            f"{result.stderr}"
        )
    Path('lilypond_raw_dump.txt').write_text(result.stdout)
    return result.stdout


def _detect_lilypond_version(lilypond_bin: str) -> str:
    """The wrapper's own \\version needs to be <= the installed
    LilyPond's version or it refuses to run; asking the binary directly
    avoids hardcoding a version that might be newer than what's
    actually installed."""
    result = subprocess.run([lilypond_bin, '--version'], capture_output=True, text=True)
    first_line = result.stdout.splitlines()[0] if result.stdout else ''
    # e.g. "GNU LilyPond 2.24.3 (running Guile 2.2)"
    for token in first_line.split():
        if token[:1].isdigit():
            return token
    return '2.24.0'  # fallback; still likely to work for basic input


# ---------------------------------------------------------------------
# Tree walking: resolved music tree -> music21 Score
# ---------------------------------------------------------------------

_GROUPING_CONTEXTS = {'StaffGroup', 'ChoirStaff', 'GrandStaff', 'PianoStaff'}
_STAFF_CONTEXTS = {'Staff', 'RhythmicStaff', 'DrumStaff', 'TabStaff'}

_NOTENAME_TO_STEP = ['C', 'D', 'E', 'F', 'G', 'A', 'B']

# (clefGlyph, clefPosition) -> music21 clef class. Values confirmed
# empirically against real `\clef treble/bass/alto/tenor/percussion`
# output from LilyPond 2.24.3 -- see the importer's development notes.
# Extending this for treble_8/bass_8/french/soprano/baritone/etc. is
# straightforward once a real file needs one (those also involve a
# separate 'clefOctavation property for the _8 variants, not just
# glyph+position).
_CLEF_TABLE = {
    ('clefs.G', -2): 'TrebleClef',
    ('clefs.F', 2): 'BassClef',
    ('clefs.C', 0): 'AltoClef',
    ('clefs.C', 2): 'TenorClef',
    ('clefs.percussion', 0): 'PercussionClef',
    # The remaining C-clefs in common use, added alongside the two
    # above -- all five share one empirically-confirmed pattern
    # (clefPosition = 2 * (staff_line - 3), staff_line counted 1
    # (bottom) to 5 (top)), verified directly against real LilyPond
    # output (not just against documentation) for every position here:
    # ran `\clef soprano`, `\clef mezzosoprano`, `\clef baritone`, and
    # `\clef varbaritone` through this project's own _run_lilypond and
    # inspected the resulting clefGlyph/clefPosition PropertySet
    # values in the dump directly. `\clef baritone` in LilyPond is the
    # C-clef form (C5, top line) -- `varbaritone` is LilyPond's name
    # for the alternative F-clef form (F3), included here too since
    # confirming it was needed to validate the position formula held
    # across clef families, not just within the C-clef family.
    ('clefs.C', -4): 'SopranoClef',        # C1
    ('clefs.C', -2): 'MezzoSopranoClef',   # C2
    ('clefs.C', 4): 'CBaritoneClef',       # C5
    ('clefs.F', 0): 'FBaritoneClef',       # F3 ("\clef varbaritone" in LilyPond)
}

_LOG_TO_TYPE = {
    0: 'whole', 1: 'half', 2: 'quarter', 3: 'eighth',
    4: '16th', 5: '32nd', 6: '64th', 7: '128th', 8: '256th',
}


def _lily_duration_of(node):
    """The LilyPond (log/dots/scale) Duration for a NoteEvent/RestEvent
    directly, or -- since an EventChord carries no 'duration of its
    own -- its first NoteEvent child's, which is the same for every
    note in the chord. Used only when constructing a tuplet-aware
    music21 Duration (see _StaffWalker._apply_duration); outside a
    tuplet this importer trusts each node's own resolved 'length
    directly and never needs this."""
    d = node.get('duration')
    if d is not None:
        return d
    if node.type == 'EventChord':
        for el in node.get('elements') or []:
            if isinstance(el, MusicNode) and el.type == 'NoteEvent':
                dd = el.get('duration')
                if dd is not None:
                    return dd
    return None


_ARTICULATION_TABLE = {    'staccato': 'Staccato',
    'staccatissimo': 'Staccatissimo',
    'accent': 'Accent',
    'marcato': 'StrongAccent',
    'tenuto': 'Tenuto',
    'portato': 'Portato',
}

# These render via music21's separate `expressions` module (appended to
# `.expressions`, not `.articulations`) -- confirmed empirically that
# LilyPond's ArticulationEvent 'articulation-type carries these same
# values for ornaments/fermata, not a distinct node type of their own.
# 'prall' -> InvertedMordent matches the conventional LilyPond/MusicXML
# correspondence (MusicXML's own <inverted-mordent> is documented as
# representing the "pralltriller" LilyPond's \prall means); a bare
# \turn's 'direction property (seen in real output) affects placement
# only, not which class to use, so it's not consulted here.
_EXPRESSION_TABLE = {
    'turn': 'Turn',
    'trill': 'Trill',
    'mordent': 'Mordent',
    'prall': 'InvertedMordent',
    'fermata': 'Fermata',
}

def _is_slashed_grace(node):
    """True if this GraceMusic's own subtree carries LilyPond's
    \\slashedGrace marker: an OverrideProperty on the Flag grob setting
    stroke-style = 'grace' (wrapped in the usual SequentialMusic /
    ContextSpeccedMusic padding -- confirmed against real LilyPond
    2.24.3 output). A plain \\grace has no such override anywhere in
    its subtree, so this cleanly distinguishes the two."""
    if not isinstance(node, MusicNode):
        return False
    if node.type == 'OverrideProperty':
        return (node.get('symbol') == 'Flag'
                and 'stroke-style' in (node.get('grob-property-path') or [])
                and node.get('grob-value') == 'grace')
    for el in (node.get('elements') or []):
        if _is_slashed_grace(el):
            return True
    return _is_slashed_grace(node.get('element'))


def _collect_grace_events(node):
    """Recurses through a GraceMusic's own nested SequentialMusic
    wrappers (confirmed empirically: LilyPond wraps grace content in
    padding sequences even for a plain `\\grace` with no `\\afterGrace`
    involved) to find the actual NoteEvent/EventChord content, in
    order, ignoring everything else -- used by _visit_GraceMusic."""
    if not isinstance(node, MusicNode):
        return []
    if node.type in ('NoteEvent', 'EventChord'):
        return [node]
    found = []
    for el in (node.get('elements') or []):
        found.extend(_collect_grace_events(el))
    found.extend(_collect_grace_events(node.get('element')))
    return found


def _contains_notes(node):
    """True if `node`'s subtree has any actual sounding content
    (Note/Rest/Chord/Skip/whole-measure-rest) anywhere -- used both by
    _find_staves() to filter out a context wrapper that holds nothing
    but property-setting noise (confirmed to occur in real files:
    `\\context PianoStaff { \\set PianoStaff.midiInstrument = ... }`,
    generated by LilyPond around a bare \\set, has PianoStaff -- a
    grouping context -- as its type, so without this filter it would
    be treated as an empty extra staff), and by
    _StaffWalker._visit_SimultaneousMusic to decide which branches of
    a `<<...>>` are real, separate voices versus pure property-setting
    branches that should just fold into the current one. A branch that
    is ONLY a whole-measure rest (`R2.` etc.) still counts as real
    content here even though it has no individual notes -- confirmed
    necessary against a real piece where such a branch, if treated as
    noise and folded into the lane carrying the OTHER, real branch,
    produced a spurious rest overlapping that real branch's own notes
    instead of becoming its own (resting) voice."""
    if not isinstance(node, MusicNode):
        return False
    if node.type in ('NoteEvent', 'RestEvent', 'EventChord', 'SkipEvent', 'MultiMeasureRestMusic'):
        return True
    if _contains_notes(node.get('element')):
        return True
    return any(_contains_notes(el) for el in (node.get('elements') or []))


def _find_staves(node):
    """Descend through grouping contexts (StaffGroup/ChoirStaff/
    GrandStaff/PianoStaff), simultaneous siblings, AND a bare
    sequential wrapper (confirmed necessary against a real multi-page
    file whose \\score was `\\score { { \\context PianoStaff << ... >>
    } ... }` -- the outer `{ }` is a SequentialMusic with the
    PianoStaff as its only element, which this function used to have
    no case for at all, silently falling through to "treat the whole
    thing as one staff" and merging both hands into one Part) to find
    every actual staff -- each becomes one music21 Part. A plain `\\new
    Staff` or even a bare `\\score { music }` with no context at all
    both come back as a single-item list (an implicit staff). Any
    candidate with no real notes/rests/chords anywhere in it (see
    _contains_notes) is dropped, so a pure property-setting wrapper
    around a grouping context (confirmed to occur in the same real
    file: `\\context PianoStaff { \\set PianoStaff.midiInstrument = ...
    }`) doesn't turn into a spurious empty Part.
    """
    return [s for s in _find_staves_raw(node) if _contains_notes(s)]


def _find_staves_raw(node):
    if isinstance(node, MusicNode):
        if node.type == 'ContextSpeccedMusic':
            ctype = node.get('context-type')
            if ctype in _STAFF_CONTEXTS:
                return [node]
            if ctype in _GROUPING_CONTEXTS:
                return _find_staves_raw(node.get('element'))
            # Some other context (e.g. a lone \new Voice with no
            # enclosing Staff) -- still just one implicit staff.
            return [node]
        if node.type in ('SimultaneousMusic', 'SequentialMusic'):
            staves = []
            for el in node.get('elements') or []:
                staves.extend(_find_staves_raw(el))
            return staves
    return [node] if node is not None else []


def _pitch_to_m21(p: Pitch):
    from music21 import pitch as m21pitch
    step = _NOTENAME_TO_STEP[p.notename]
    octave = p.octave + 4  # LilyPond octave 0 == the octave starting at middle C
    semitone_alter = float(Fraction(p.alteration)) * 2
    return m21pitch.Pitch(step=step, octave=octave, accidental=(semitone_alter or None))


def _quarter_length(node: MusicNode) -> Fraction:
    """Every music node carries its own resolved 'length, in whole-note
    units (see importers/lilypond_sexp.py's ly:make-moment handling) --
    multiplying by 4 gives music21's quarterLength directly, already
    correct for dotted notes and tuplet-scaled durations alike, with no
    need to recompute it from the separate log/dots/scale duration
    properties ourselves."""
    return Fraction(node.get('length', 0)) * 4


def _quarter_length_of_duration(d) -> Fraction:
    """For the rare case where there's a bare Duration (log/dots/scale)
    to convert but no node's own 'length to just trust directly -- e.g.
    a MetronomeMark's "referent" note value (`\\tempo 4 = 108`'s "4"),
    which names a note VALUE, not a moment in the piece's timeline."""
    from .lilypond_sexp import Duration
    if not isinstance(d, Duration):
        return Fraction(1)  # quarter note, a reasonable fallback
    base = Fraction(4, 1) * Fraction(2, 1) ** (-d.log)
    dotted = base * (2 - Fraction(1, 2 ** d.dots))
    return dotted * Fraction(d.scale)


def _key_signature_from(node: MusicNode):
    """Builds a plain key.KeySignature (sharps count) from a
    KeyChangeEvent's 'pitch-alist -- the full 7-scale-degree accidental
    table LilyPond already resolved from `\\key TONIC MODE`. This
    deliberately does NOT try to reconstruct TONIC/MODE into a proper
    music21 Key: pitch-alist alone doesn't distinguish, say, G major
    from E natural minor (same accidentals), and guessing wrong would
    be worse than not claiming a mode at all. What actually renders on
    the staff -- the sharps/flats -- is what this captures. (For a
    transposing instrument this is the WRITTEN key, deliberately --
    see the module docstring's TRANSPOSING INSTRUMENTS section for how
    the concert/sounding key is derived instead, on demand, via
    Part.toSoundingPitch().)"""
    from music21 import key as m21key
    alist = node.get('pitch-alist') or []
    total = sum(Fraction(alt) for _, alt in alist)
    sharps = round(total * 2)
    return m21key.KeySignature(sharps)


def _flatten_text(value) -> str:
    """Visible text of a TextScriptEvent's 'text value: a plain string, or
    a \\markup expression (nested lists whose strings are the words)."""
    if value is None:
        return ''
    if isinstance(value, str) and not isinstance(value, Symbol):
        return value
    if isinstance(value, (list, tuple)):
        return ' '.join(t for t in (_flatten_text(v) for v in value) if t)
    return ''


class _ClefPending:
    """Accumulates the scattered PropertySet events (clefGlyph,
    clefPosition, plus others we don't need) that a single `\\clef`
    command expands into, and resolves them into one Clef object as
    soon as both pieces needed for the lookup have arrived (see
    _CLEF_TABLE). Confirmed empirically that clefGlyph/clefPosition
    always both appear per clef change, though not always adjacent or
    in the same order -- see the importer's development notes."""

    def __init__(self):
        self.glyph = None
        self.position = None

    def offer(self, symbol, value):
        if symbol == 'clefGlyph':
            self.glyph = value
        elif symbol == 'clefPosition':
            self.position = value

    def resolve(self):
        if self.glyph is not None and self.position is not None:
            key = (self.glyph, self.position)
            self.glyph = self.position = None
            return key
        return None


class _StaffWalker:
    """Walks one staff's resolved music tree into a set of "lanes" --
    one per voice actually present on the staff (almost always just
    one) -- each a flat, offset-based timeline. Lanes don't always end
    up in THIS staff's own final Part, though: `\\change Staff = "id"`
    (see _visit_ContextChange) can redirect a lane's subsequent events
    into a DIFFERENT staff's timeline mid-walk -- confirmed necessary
    against a real piano piece where the left hand's material is
    written on the right-hand staff for several bars. That's why every
    append goes through self._append() rather than a local list: it
    looks up which staff is CURRENTLY the target for this lane (usually
    this staff itself) and writes into `shared_events[target_key]`, a
    dict shared by every _StaffWalker for the whole piece (see
    _build_score()), keyed there by this walker's own home-staff-
    qualified lane name so a redirected lane can never collide with a
    same-numbered lane native to the staff it lands in.

    A lane is created only at the point a SimultaneousMusic (an
    explicit `<< ... >>`, however it was written -- \\new Voice,
    \\voiceOne/\\voiceTwo, or the `\\\\` shorthand) is encountered while
    exactly one lane is currently active for its enclosing music: the
    first branch keeps the current lane id, every other branch gets a
    fresh child id ("<parent>.2", "<parent>.3", ...), and once every
    branch has been walked, whatever plain (non-simultaneous) music
    follows in the SAME enclosing sequence continues in just the
    FIRST/base lane again -- exactly matching what `<< ... >>` means in
    real LilyPond notation (content after it reverts to the single
    voice that was active before it opened). A staff whose polyphony
    is nested (divisi within divisi) gets nested lane ids the same way,
    to whatever depth actually occurs.
    """

    def __init__(self, shared_events, home_staff_key):
        self.shared_events = shared_events  # staff_key -> {lane_name: [(offset, obj), ...]}
        self.home_staff_key = home_staff_key
        self.bar_ql = 4.0        # active bar length in quarter notes (LilyPond's default is 4/4)
        self.pickup_gap = None   # leading gap a `\\partial` opened (see _visit_PartialSet)
        self.voice_lane = {}   # \\new Voice = "id" -> the lane it was walked in (for lyrics)
        self.lane_offset = {'1': Fraction(0)}
        self.lane_target = {'1': home_staff_key}  # which staff this lane CURRENTLY writes to
        self.lane_tied_pitches = {'1': set()}
        self.lane_open_slur = {'1': None}
        self.lane_open_hairpin = {'1': None}  # (spanner, kind) or None
        self.spanners = []
        self.repeat_markers = []
        self.barcheck_offsets = []
        self._pending_clef = _ClefPending()
        self.instrument_name = None
        self.transposition_pitch = None
        self.cross_staff_events = []  # list of (offset, target_staff_key)
        self._active_tuplet_ratios = []  # stack of (numberNotesActual, numberNotesNormal)
        self._tuplet_collectors = []     # parallel stack of lists, for start/stop bracket marking
        self.lane_stem_dir = {} # for stem direction of course

    def _append(self, lane, offset, obj):
        # Tag every actual note/rest/chord with the LOGICAL voice it
        # belongs to (its lane, namespaced by the staff it originated
        # from) -- independent of target_key, i.e. independent of
        # which staff it's currently being WRITTEN to. This is what
        # lets a later merge step (see importers/multi_staff_emitter.py)
        # correctly beam/group a voice that was redirected mid-stream
        # via `\change Staff`: the notes before and after the redirect
        # share the same tag even though they land in different music21
        # Parts, which is exactly the information needed to reconstruct
        # one continuous logical voice for CORRECT cross-staff beaming
        # -- confirmed, by testing a real reference file, that beams
        # and tuplet brackets in MusicXML are per-note elements, not
        # tied to voice-NUMBER matching, so this tag is all that's
        # needed; no separate "same voice number" bookkeeping is
        # required for correct rendering.
        from music21 import note as m21note
        target_key = self.lane_target[lane]
        namespaced_lane = f'{self.home_staff_key}:{lane}'
        from music21 import note as m21note
        if isinstance(obj, m21note.GeneralNote):
            obj.editorial.lily_lane_id = namespaced_lane
            if target_key != self.home_staff_key:
                # This note is being written to a staff other than the one
                # it was read from -- i.e. it is actually crossing right
                # now. Tag it so the emitter can apply the cross-staff stem
                # convention to it, without extending that convention to
                # every other note in the same lane.
                obj.editorial.lily_redirected = True
        self.shared_events[target_key].setdefault(namespaced_lane, []).append((offset, obj))

    def close_unterminated_spanners(self):
        """Call once after walking this staff's whole tree: a slur or
        hairpin still open at the end (no closing note ever arrived) is
        kept, ending on the last note it reached, rather than silently
        dropped -- with a warning, since it usually means the source
        had one."""
        for open_slur in self.lane_open_slur.values():
            if open_slur is not None:
                warnings.warn(
                    "A slur was never closed before the end of the staff "
                    "-- kept, ending on the last note it reached.",
                    LilyUnterminatedSpannerWarning,
                )
                self.spanners.append(open_slur)
        for open_hairpin in self.lane_open_hairpin.values():
            if open_hairpin is not None:
                warnings.warn(
                    "A crescendo/diminuendo hairpin was never closed "
                    "before the end of the staff -- kept, ending on the "
                    "last note it reached.",
                    LilyUnterminatedSpannerWarning,
                )
                self.spanners.append(open_hairpin)

    # -- dispatch -------------------------------------------------


    # # --- debug probe --- (delete with the marked block in walk())
    # # Articulation-type of the note you tagged as a probe. Change to
    # # match whatever you put on the Eb -- common values: 'marcato',
    # # 'staccatissimo', 'accent', 'fermata'.
    # _DEBUG_TRIGGER = 'snappizzicato'
    # # --- end debug probe ---

    def walk(self, node, lane):
        if node is None:
            return
        if not isinstance(node, MusicNode):
            return

        # # --- debug probe --- (delete this whole block when done)
        # armed = getattr(self, '_debug_armed', False)
        # if node.type == 'NoteEvent':
        #     for a in (node.get('articulations') or []):
        #         if (isinstance(a, MusicNode)
        #                 and a.type == 'ArticulationEvent'
        #                 and str(a.get('articulation-type')) == self._DEBUG_TRIGGER):
        #             armed = True
        #             self._debug_armed = True
        #             off = float(self.lane_offset.get(lane, 0))
        #             print(f"=== DBG ARMED off={off} lane={lane} "
        #                   f"staff={self.home_staff_key} ===")
        #             break
        # if armed and node.type == 'BarCheck':
        #     print(f"=== DBG DISARMED (barcheck at "
        #           f"off={float(self.lane_offset.get(lane, 0))}) ===")
        #     self._debug_armed = False
        #     armed = False
        # if armed and node.type in (
        #         'BeamEvent', 'OverrideProperty', 'RevertProperty',
        #         'PropertySet', 'SlurEvent', 'TieEvent',
        #         'CrescendoEvent', 'DecrescendoEvent',
        #         'ContextChange', 'ContextSpeccedMusic',
        #         'TimeScaledMusic', 'ArticulationEvent'):
        #     off = float(self.lane_offset.get(lane, 0))
        #     print(f"DBG off={off} lane={lane} "
        #           f"{node.type} :: {dict(node.props)}")
        # # --- end debug probe ---

        handler = getattr(self, f'_visit_{node.type}', None)
        if handler is not None:
            handler(node, lane)
        elif 'Repeated' in node.type:
            warnings.warn(
                f"Unrecognized repeat construct ({node.type}, e.g. "
                f"\\repeat percent or \\repeat tremolo) -- its music was "
                f"skipped rather than guessed at.",
                LilyUnhandledRepeatWarning,
            )


    # def walk(self, node, lane):
    #     if node is None:
    #         return
    #     if not isinstance(node, MusicNode):
    #         return  # not a music node (e.g. a stray literal) -- ignore
    #     handler = getattr(self, f'_visit_{node.type}', None)
    #     if handler is not None:
    #         handler(node, lane)
    #     elif 'Repeated' in node.type:
    #         warnings.warn(
    #             f"Unrecognized repeat construct ({node.type}, e.g. "
    #             f"\\repeat percent or \\repeat tremolo) -- its music was "
    #             f"skipped rather than guessed at.",
    #             LilyUnhandledRepeatWarning,
    #         )


        # Anything else without a handler (grob property tweaks, layout
        # overrides, ApplyContext, etc.) is intentionally skipped --
        # see the module docstring's "WHAT'S HANDLED" list. It doesn't
        # advance the offset either, matching its own 'length of 0.

    # -- containers -------------------------------------------------
    def _visit_SequentialMusic(self, node, lane):
        for el in node.get('elements') or []:
            self.walk(el, lane)

    def _visit_SimultaneousMusic(self, node, lane):
        elements = node.get('elements') or []
        if len(elements) <= 1:
            if elements:
                self.walk(elements[0], lane)
            return

        # A SimultaneousMusic commonly mixes pure property-setting
        # branches (e.g. a shared `\Global` block holding just \key/
        # \time, or a \clef-scoping wrapper -- both confirmed present
        # in a real piece, sitting alongside the staff's actual voices
        # inside the SAME `<<...>>`) together with the real musical
        # voice(s). Only a branch with real notes/rests/chords in it
        # (see _contains_notes) is treated as its own polyphonic voice;
        # a property-only branch is walked straight into the CURRENT
        # lane instead, since giving it its own lane would create a
        # bogus, permanently-empty "voice" and made every real voice
        # look misaligned against it (confirmed: this was silently
        # producing extra near-empty voices and misalignment warnings
        # against that real piece before this filter existed).
        noise_branches = [el for el in elements if not _contains_notes(el)]
        real_branches = [el for el in elements if _contains_notes(el)]
        for el in noise_branches:
            self.walk(el, lane)

        if len(real_branches) <= 1:
            if real_branches:
                self.walk(real_branches[0], lane)
            return

        base_offset = self.lane_offset[lane]
        base_target = self.lane_target[lane]
        child_lanes = []
        for i, el in enumerate(real_branches):
            if i == 0:
                child_lane = lane  # first branch just continues this lane
            else:
                child_lane = f"{lane}.{i + 1}"
                self.lane_offset[child_lane] = base_offset
                self.lane_target[child_lane] = base_target
                self.lane_tied_pitches[child_lane] = set()
                self.lane_open_slur[child_lane] = None
                self.lane_open_hairpin[child_lane] = None
            child_lanes.append(child_lane)
            self.walk(el, child_lane)

        end_offsets = {self.lane_offset[cl] for cl in child_lanes}
        if len(end_offsets) > 1:
            warnings.warn(
                f"Voices in a polyphonic passage ended at different "
                f"offsets ({sorted(end_offsets)}) -- results in that "
                f"passage may be misaligned.",
                LilyVoiceMisalignedWarning,
            )
        # Content after this point in the enclosing sequence continues
        # in `lane` only (see class docstring) -- nothing further to do;
        # the other child lanes simply stop receiving new events, which
        # is exactly what "the divisi ended" means.

    def _visit_ContextSpeccedMusic(self, node, lane):
        # _find_staves() already decided which ContextSpeccedMusic nodes
        # start a new Part; by the time we're inside a _StaffWalker,
        # ANY further ContextSpeccedMusic (typically a \Staff wrapper
        # LilyPond generates just to scope a \clef change, or a \new
        # Voice around the staff's only voice) is just "keep going" --
        # see class/module docstring.
        if node.get('context-type') == 'Voice' and node.get('context-id') is not None:
            self.voice_lane[str(node.get('context-id'))] = lane
        if self.instrument_name is None:
            for op in node.get('property-operations') or []:
                if isinstance(op, list) and len(op) == 3 and op[0] == 'assign' \
                        and str(op[1]) == 'instrumentName':
                    self.instrument_name = op[2]
        self.walk(node.get('element'), lane)

    def _visit_ContextChange(self, node, lane):
        # `\change Staff = "id"` -- confirmed, against a real piano
        # piece, to appear inline in a voice's own SequentialMusic
        # exactly where the notation physically moves to another
        # staff. Redirects this lane's SUBSEQUENT events (not what's
        # already been recorded) to the named staff -- see class
        # docstring and self._append(). A `\change` to something other
        # than Staff (e.g. \change Dynamics) doesn't affect this
        # importer's per-staff Part model and is ignored.
        if node.get('change-to-type') not in _STAFF_CONTEXTS:
            return
        target_id = node.get('change-to-id')
        if target_id in self.shared_events:
            old_target = self.lane_target[lane]
            if target_id != old_target and self._active_tuplet_ratios:
                # Only a redirect that happens WHILE A TUPLET IS OPEN
                # actually needs flagging (see LilyCrossStaffManualFix
                # Warning) -- confirmed against a real piece that most
                # `\change Staff` uses are just a plain note/chord/rest
                # switching staves between tuplets, which this importer
                # already handles correctly (padding, voice cleanup,
                # tuplet-ratio display are all independently verified
                # elsewhere in this file); it's specifically a SINGLE
                # tuplet's own notes being split across two staves that
                # this importer's two-Part architecture can't correctly
                # give ONE continuous bracket for. Flagging every
                # `\change Staff` regardless was confirmed, against
                # that same real piece, to blank 11 measures that were
                # already rendering correctly alongside the one that
                # genuinely wasn't.
                #
                # Both the staff the notes are LEAVING (old_target --
                # home_staff_key on the first redirect, but possibly a
                # PREVIOUS target if this lane has already been
                # redirected once before) and the one they're LANDING
                # on need the measure at this offset flagged once real
                # Measures exist (see _flag_and_blank_cross_staff_
                # measures).
                self.cross_staff_events.append((self.lane_offset[lane], old_target,
                                                 f'{self.home_staff_key}:{lane}'))
                self.cross_staff_events.append((self.lane_offset[lane], target_id,
                                                 f'{self.home_staff_key}:{lane}'))
            self.lane_target[lane] = target_id
        else:
            warnings.warn(
                f"\\change Staff = {target_id!r} refers to a staff id "
                f"this importer didn't find declared anywhere in the "
                f"piece -- ignored; the notes that follow stayed on "
                f"their current staff.",
                LilyUnknownStaffChangeWarning,
            )

    def _visit_RelativeOctaveMusic(self, node, lane):
        # `\relative { ... }`'s wrapper node -- by the time we ever see
        # it, LilyPond's own parser has already converted every pitch
        # inside to an absolute one (that's the whole point of running
        # the real engine instead of parsing text -- see module
        # docstring), so this is purely a pass-through.
        self.walk(node.get('element'), lane)

    def _visit_TimeScaledMusic(self, node, lane):
        # `\tuplet N/M { ... }` / `\times N/M { ... }` -- confirmed
        # against a real dump that every note inside already carries
        # its own correctly tuplet-scaled 'length (e.g. a 16th-note
        # triplet's is 1/24 of a whole note, not 1/16), which is all
        # this importer needs for TIMING (see _quarter_length) -- but
        # DISPLAY needs more: without an explicit tuplet-bracket
        # ratio attached to each note, music21 has to guess a grouping
        # purely from the note's numeric quarterLength, and when a
        # `\change Staff` (see _visit_ContextChange) splits one
        # tuplet's notes across two different Parts, each Part's guess
        # is independently wrong/incomplete -- confirmed against a
        # real piece, where a 6-tuplet's 2-note and 4-note fragments
        # were BOTH mislabeled as fragments of a 3-tuplet by MuseScore.
        # LilyPond's own dump uses 'denominator for the tuplet's ACTUAL
        # note count and 'numerator for the NORMAL count it replaces --
        # reversed from the user-facing "\tuplet ACTUAL/NORMAL" syntax
        # (confirmed: \tuplet 3/2 dumps as 'denominator 3 'numerator 2,
        # and -- important, since 6/4 and 3/2 are the same TIMING ratio
        # but must NOT display the same bracket number -- confirmed
        # separately that \tuplet 6/4 dumps as its own 'denominator 6
        # 'numerator 4, not silently reduced).
        actual = node.get('denominator')
        normal = node.get('numerator')
        self._active_tuplet_ratios.append((actual, normal))
        collector = []
        self._tuplet_collectors.append(collector)
        self.walk(node.get('element'), lane)
        self._tuplet_collectors.pop()
        self._active_tuplet_ratios.pop()
        if collector:
            collector[0].duration.tuplets[-1].type = 'start'
            if len(collector) > 1:
                collector[-1].duration.tuplets[-1].type = 'stop'

    def _set_grace_duration(self, m21_obj, node):
        """Set m21_obj's duration TYPE from the LilyPond node's own
        written value (log/dots) BEFORE it is converted to a grace.
        Without this, music21's Note() default of 'quarter' survives
        .getGrace(), and a \\grace { d16 } comes out as a quarter-note
        grace -- wrong notation, and wrong beam counts in the emitter.
        A grace note's isGrace=True makes quarterLength report 0, so no
        real timeline length is involved; the <type> is what an engraver
        prints and what _beam_count() reads."""
        from music21 import duration as m21duration
        ly_dur = _lily_duration_of(node)
        if ly_dur is None:
            return
        m21_obj.duration = m21duration.Duration(
            type=_LOG_TO_TYPE.get(ly_dur.log, 'eighth'),
            dots=ly_dur.dots)

    def _apply_duration(self, m21_obj, node, ql):
        """Sets m21_obj's duration to `ql` quarter-lengths -- exactly
        like every other note/rest/chord in this importer -- unless a
        `\\tuplet`/`\\times` is currently open (see
        _visit_TimeScaledMusic), in which case the duration is instead
        built explicitly from the note's own written type/dots plus
        the active tuplet ratio(s), so the correct bracket/ratio
        DISPLAYS in the output rather than leaving music21 to guess one
        purely from the numeric quarterLength (confirmed empirically:
        setting .duration.quarterLength directly on a fraction like 1/6
        makes music21 infer its OWN, sometimes-reduced tuplet ratio for
        display, e.g. silently showing "3" for what should show "6";
        building the Duration from type+tuplets from the start avoids
        that entirely, and produces the identical quarterLength as a
        consequence). Registers the object with every currently open
        tuplet's collector either way, for start/stop bracket marking.
        """
        if not self._active_tuplet_ratios:
            m21_obj.duration.quarterLength = ql
            return
        from music21 import duration as m21duration
        ly_dur = _lily_duration_of(node)
        if ly_dur is None:
            m21_obj.duration.quarterLength = ql  # fallback; shouldn't occur in practice
        else:
            d = m21duration.Duration(type=_LOG_TO_TYPE.get(ly_dur.log, 'quarter'), dots=ly_dur.dots)
            d.tuplets = tuple(m21duration.Tuplet(numberNotesActual=a, numberNotesNormal=n)
                               for a, n in self._active_tuplet_ratios)
            m21_obj.duration = d
        for collector in self._tuplet_collectors:
            collector.append(m21_obj)

    def _visit_VoltaRepeatedMusic(self, node, lane):
        # `\repeat volta N { body } [\alternative { {end1} {end2} ...}]` is
        # meant to be NOTATED as an actual repeat sign -- unlike
        # `\repeat unfold` (see _visit_UnfoldedRepeatedMusic below),
        # which explicitly means "don't show a repeat sign, just write
        # the notes out". So body and each ending are each walked only
        # ONCE, in the order they're printed on the page (body, then
        # ending 1, then ending 2, ...) -- NOT repeated in the timeline
        # -- and a marker is recorded so _apply_repeat_structure() can
        # attach the real bar.Repeat barlines and spanner.RepeatBracket
        # volta brackets once real Measures exist (repeat barlines are
        # a property of a Measure in music21, so this has to wait until
        # after makeMeasures() -- see _build_score()). A caller that
        # wants the played-through form instead (e.g. for MIDI, where a
        # repeat sign means nothing) should run the Score through
        # transforms/unfold_repeats.py afterward -- see that module.
        main = node.get('element')
        repeat_count = node.get('repeat-count', 1)
        alternatives = node.get('elements') or []

        start_offset = self.lane_offset[lane]
        self.walk(main, lane)
        end_offset = self.lane_offset[lane]

        endings = []
        for alt in alternatives:
            if not isinstance(alt, MusicNode):
                continue
            numbers = alt.get('volta-numbers') or []
            alt_start = self.lane_offset[lane]
            self.walk(alt.get('element'), lane)
            alt_end = self.lane_offset[lane]
            endings.append((numbers, alt_start, alt_end))

        if repeat_count > 1:
            self.repeat_markers.append({
                'lane': lane, 'start': start_offset, 'end': end_offset,
                'repeat_count': repeat_count, 'endings': endings,
            })

    def _visit_UnfoldedRepeatedMusic(self, node, lane):
        # `\repeat unfold N { body }` literally means "no repeat sign --
        # just write body out N times" (this is LilyPond's own
        # source-level distinction from \repeat volta, not something
        # this importer is choosing to unfold on its own initiative --
        # see class/module docstring). volta-style endings under an
        # explicit \repeat unfold are vanishingly rare in practice, but
        # handled the obvious way (appended after every repetition they
        # list) for completeness.
        main = node.get('element')
        repeat_count = node.get('repeat-count', 1)
        alternatives = node.get('elements') or []
        alt_by_number = {}
        for alt in alternatives:
            if not isinstance(alt, MusicNode):
                continue
            el = alt.get('element')
            for n in (alt.get('volta-numbers') or []):
                alt_by_number[n] = el
        for i in range(1, repeat_count + 1):
            self.walk(main, lane)
            self.walk(alt_by_number.get(i), lane)

    # -- leaves -------------------------------------------------
    def _visit_KeyChangeEvent(self, node, lane):
        self._append(lane, self.lane_offset[lane], _key_signature_from(node))

    def _visit_TimeSignatureMusic(self, node, lane):
        from music21 import meter
        ts = meter.TimeSignature(f"{node.get('numerator')}/{node.get('denominator')}")
        self.bar_ql = float(ts.barDuration.quarterLength)
        self._append(lane, self.lane_offset[lane], ts)

    def _visit_PartialSet(self, node, lane):
        # `\\partial 4` -- an anacrusis: the first bar holds only the given
        # duration. Modelled by moving every lane's clock FORWARD by what's
        # missing from a full bar, so the measure grid falls where the
        # source's bar lines do and every offset-keeping consumer (bar
        # checks, repeats, spanners, cross-staff events) stays consistent;
        # _build_score() then turns that leading gap into a real pickup
        # measure (_convert_leading_gap_to_pickup). Only honoured at the
        # very start of the music; a `\\partial` later on (a short bar in
        # the middle of a piece) isn't, and says so.
        if any(off != 0 for off in self.lane_offset.values()) or self.pickup_gap is not None:
            warnings.warn(
                "A \\partial that isn't at the very start of the music was ignored; "
                "bar lines after that point may not match the source.",
                LilyPartialWarning)
            return
        partial_ql = float(_quarter_length_of_duration(node.get('duration')))
        gap = self.bar_ql - partial_ql
        if gap <= 1e-9:
            return
        self.pickup_gap = gap
        for lane_key in self.lane_offset:
            self.lane_offset[lane_key] += Fraction(gap).limit_denominator(1000)

    def _visit_OverrideProperty(self, node, lane):
        if node.get('symbol') != 'Stem':
            return
        prop = node.get('grob-property')
        path = node.get('grob-property-path')
        if prop != 'direction' and not (path and 'direction' in path):
            return
        val = node.get('grob-value')
        if val == 1:
            self.lane_stem_dir[lane] = 'up'
        elif val == -1:
            self.lane_stem_dir[lane] = 'down'

    def _visit_RevertProperty(self, node, lane):
        if node.get('symbol') != 'Stem':
            return
        prop = node.get('grob-property')
        path = node.get('grob-property-path')
        if prop != 'direction' and not (path and 'direction' in path):
            return
        self.lane_stem_dir.pop(lane, None)

    def _visit_PropertySet(self, node, lane):
        symbol = node.get('symbol')
        if symbol == 'instrumentTransposition' and self.transposition_pitch is None:
            value = node.get('value')
            if isinstance(value, Pitch):
                self.transposition_pitch = value
            return
        if symbol in ('clefGlyph', 'clefPosition'):
            self._pending_clef.offer(symbol, node.get('value'))
            key = self._pending_clef.resolve()
            if key is not None:
                self._insert_clef(key, lane)

    def _insert_clef(self, key, lane):
        from music21 import clef as m21clef
        class_name = _CLEF_TABLE.get(key)
        if class_name is None:
            warnings.warn(
                f"Unrecognized clef (glyph={key[0]!r}, position={key[1]!r}) "
                f"-- skipped. See lilypond_importer._CLEF_TABLE.",
                LilyUnrecognizedClefWarning,
            )
            return
        self._append(lane, self.lane_offset[lane], getattr(m21clef, class_name)())

    def _visit_BarCheck(self, node, lane):
        # Purely a source-level sanity check, not itself a signature --
        # but its POSITION tells us where the user thinks bars fall,
        # which matters when the piece never states \time at all (see
        # _infer_missing_time_signature): a real bar length derived
        # from the user's own `|` marks beats a silently-assumed 4/4.
        self.barcheck_offsets.append(self.lane_offset[lane])

    def _visit_NoteEvent(self, node, lane):
        from music21 import note
        n = note.Note(_pitch_to_m21(node.get('pitch')))
        ql = _quarter_length(node)
        self._apply_duration(n, node, ql)
        offset = self.lane_offset[lane]
        self._apply_events(n, node.get('articulations') or [], lane, offset)
        self._append(lane, offset, n)
        self.lane_offset[lane] += ql

    def _visit_RestEvent(self, node, lane):
        from music21 import note
        ql = _quarter_length(node)
        r = note.Rest()
        self._apply_duration(r, node, ql)
        self._append(lane, self.lane_offset[lane], r)
        self.lane_offset[lane] += ql

    _visit_SkipEvent = _visit_RestEvent  # `s4`/\skip -- treated as an ordinary rest (see module docstring)
    # `R1`/`R2.`/etc. (a whole-measure rest, distinct from a plain `r1`
    # -- confirmed against a real file that this produces a DIFFERENT
    # node type, MultiMeasureRestMusic, which this importer previously
    # had no handler for at all: silently skipped, contributing zero
    # duration, and every note after it in that staff landed a full
    # measure too early. Its own resolved 'length is trusted exactly
    # like every other node's, so this needs nothing beyond treating it
    # as an ordinary rest the same way.
    _visit_MultiMeasureRestMusic = _visit_RestEvent

    def _visit_TempoChangeEvent(self, node, lane):
        from music21 import tempo
        text = node.get('text')
        number = node.get('metronome-count')
        if number and number is not False:
            unit_ql = _quarter_length_of_duration(node.get('tempo-unit')) if node.get('tempo-unit') else 1.0
            mark = tempo.MetronomeMark(number=number, referent=unit_ql,
                                        text=(str(text) if text else None))
        elif text:
            mark = tempo.TempoText(str(text))
        else:
            return
        self._append(lane, self.lane_offset[lane], mark)

    def _visit_GraceMusic(self, node, lane):
        # `\grace {...}` -- LilyPond gives grace-note content its own
        # non-zero 'length (internal bookkeeping, e.g. for \afterGrace
        # timing), but grace notes conventionally do NOT consume time
        # from the main pulse: they're inserted at the SAME offset as
        # whatever follows them, without advancing the timeline.
        # Confirmed against a real `\grace { d16 } c4` dump: the grace
        # content sits inside two empty padding SequentialMusic
        # siblings (LilyPond's own bookkeeping, present even for a
        # plain \grace with no \afterGrace involved) -- this walks past
        # those (see _collect_grace_events) and converts each real
        # note/chord found to music21's own grace-note form
        # (Note/Chord.getGrace()) rather than an ordinary timed one.
        # Multiple grace notes in one group are all inserted at the
        # same offset, in encounter order -- their exact relative
        # sub-offset isn't tracked, a documented simplification.
        from music21 import note as m21note, chord as m21chord

        # def _walk(n, depth=0):
        #     if not isinstance(n, MusicNode):
        #         return
        #     # print('  ' * depth + f'{n.type} :: {dict(n.props)}')
        #     for v in n.props.values():
        #         if isinstance(v, MusicNode):
        #             _walk(v, depth + 1)
        #         elif isinstance(v, list):
        #             for el in v:
        #                 _walk(el, depth + 1)
        # print('=== GRACE MUSIC ===')
        # _walk(node)
        # print('=== END GRACE MUSIC ===')

        offset = self.lane_offset[lane]
        is_slash = _is_slashed_grace(node)
        for grace_node in _collect_grace_events(node.get('element')):
            if grace_node.type == 'NoteEvent':
                n = m21note.Note(_pitch_to_m21(grace_node.get('pitch')))
                self._set_grace_duration(n, grace_node)
                n = n.getGrace()
                if is_slash:
                    n.editorial.grace_slash = True
                self._append(lane, offset, n)
            elif grace_node.type == 'EventChord':
                note_events = [el for el in (grace_node.get('elements') or [])
                            if isinstance(el, MusicNode) and el.type == 'NoteEvent']
                if note_events:
                    pitches = [_pitch_to_m21(ev.get('pitch')) for ev in note_events]
                    c = m21chord.Chord(pitches)
                    self._set_grace_duration(c, grace_node)
                    c = c.getGrace()
                    if is_slash:
                        c.editorial.grace_slash = True
                    self._append(lane, offset, c)
        # self.lane_offset[lane] is deliberately left unchanged.

        # offset = self.lane_offset[lane]
        # for grace_node in _collect_grace_events(node.get('element')):
        #     if grace_node.type == 'NoteEvent':
        #         n = m21note.Note(_pitch_to_m21(grace_node.get('pitch')))
        #         self._set_grace_duration(n, grace_node)   # <-- before getGrace()
        #         n = n.getGrace()
        #         self._append(lane, offset, n)
        #     elif grace_node.type == 'EventChord':
        #         note_events = [el for el in (grace_node.get('elements') or [])
        #                        if isinstance(el, MusicNode) and el.type == 'NoteEvent']
        #         if note_events:
        #             pitches = [_pitch_to_m21(ev.get('pitch')) for ev in note_events]
        #             c = m21chord.Chord(pitches)
        #             self._set_grace_duration(c, grace_node)   # <-- before getGrace()
        #             c = c.getGrace()
        #             self._append(lane, offset, c)
        #     print('GRACE NODE:', grace_node.type, grace_node.props)
        # # self.lane_offset[lane] is deliberately left unchanged.

    def _visit_EventChord(self, node, lane):
        from music21 import chord as m21chord
        elements = node.get('elements') or []
        note_events = [el for el in elements
                       if isinstance(el, MusicNode) and el.type == 'NoteEvent']
        # A chord's own `-!`/`~`/slur/dynamic marking (as opposed to one
        # tied to a single pitch inside it) is attached as a SIBLING
        # entry in this SAME 'elements list, not nested under any one
        # NoteEvent's own 'articulations -- confirmed against a real
        # `<c e>4-!`, which showed the ArticulationEvent sitting right
        # alongside the two NoteEvents here. Filtering 'elements down to
        # NoteEvent only (as this used to do) silently discarded these
        # entirely.
        chord_level_events = [el for el in elements
                               if isinstance(el, MusicNode) and el.type != 'NoteEvent']
        if not note_events:
            return
        pitches = [_pitch_to_m21(ev.get('pitch')) for ev in note_events]
        c = m21chord.Chord(pitches)
        ql = _quarter_length(node)
        self._apply_duration(c, node, ql)
        offset = self.lane_offset[lane]
        # Tie/slur/articulation precision per-note-within-a-chord isn't
        # tracked separately (see module docstring) -- if ANY member
        # note carries one, it's applied to the whole chord.
        for ev in note_events:
            self._apply_events(c, ev.get('articulations') or [], lane, offset)
        if chord_level_events:
            self._apply_events(c, chord_level_events, lane, offset)
        self._append(lane, offset, c)
        self.lane_offset[lane] += ql

    # -- shared: ties, slurs, dynamics, articulations -------------------
    def _apply_events(self, m21_obj, events, lane, offset):
        from music21 import articulations as m21art, tie as m21tie
        from music21 import spanner as m21span, dynamics as m21dyn
        from music21 import expressions as m21expr

        pitches = m21_obj.pitches if getattr(m21_obj, 'isChord', False) else [m21_obj.pitch]
        pitch_keys = [p.nameWithOctave for p in pitches]
        starts_tie = False
        for event in events or []:
            if not isinstance(event, MusicNode):
                continue

            if event.type == 'TieEvent':
                starts_tie = True

            elif event.type == 'BeamEvent':
                direction = event.get('span-direction')
                if direction == -1:
                    m21_obj.editorial.lily_beam = 'start'
                elif direction == 1:
                    m21_obj.editorial.lily_beam = 'stop'

            elif event.type == 'ArticulationEvent':
                art_type = str(event.get('articulation-type'))
                art_name = _ARTICULATION_TABLE.get(art_type)
                expr_name = _EXPRESSION_TABLE.get(art_type)
                if art_name is not None:
                    m21_obj.articulations.append(getattr(m21art, art_name)())
                elif expr_name is not None:
                    m21_obj.expressions.append(getattr(m21expr, expr_name)())

            elif event.type == 'TextScriptEvent':
                # Only snippet markers (`c'4^"SS: title"`) are imported --
                # not text scripts in general -- as ordinary text
                # expressions, so the format-independent detector in
                # core/snippets.py sees them exactly as it sees MusicXML
                # <words>. See that module for the marker language. (A
                # `%` comment can't carry a marker: LilyPond's dump drops
                # comments, and a comment has no musical position anyway.)
                text = _flatten_text(event.get('text'))
                if text and parse_markers(text):
                    self._append(lane, offset, m21expr.TextExpression(text))

            elif event.type == 'SlurEvent':
                direction = event.get('span-direction')
                if direction == -1:  # start
                    sl = m21span.Slur()
                    sl.addSpannedElements(m21_obj)
                    self.lane_open_slur[lane] = sl
                elif direction == 1:  # stop
                    sl = self.lane_open_slur.get(lane)
                    if sl is not None:
                        sl.addSpannedElements(m21_obj)
                        self.spanners.append(sl)
                        self.lane_open_slur[lane] = None

            elif event.type == 'AbsoluteDynamicEvent':
                # A crescendo/diminuendo ending at the next dynamic mark
                # rather than an explicit `\!` is the more common way
                # hairpins are actually written -- and confirmed, by
                # inspecting a real dump, to leave NO stop marker in the
                # tree at all (purely a rendering-time convention where
                # the hairpin visually ends wherever the next dynamic
                # text appears) -- so an incoming dynamic mark closes
                # whatever hairpin is currently open in this lane, using
                # this note as its end point, exactly like an explicit
                # `\!` would.
                open_hairpin = self.lane_open_hairpin.get(lane)
                if open_hairpin is not None:
                    open_hairpin.addSpannedElements(m21_obj)
                    self.spanners.append(open_hairpin)
                    self.lane_open_hairpin[lane] = None
                self._append(lane, offset, m21dyn.Dynamic(str(event.get('text'))))

            elif event.type in ('CrescendoEvent', 'DecrescendoEvent'):
                direction = event.get('span-direction')
                if direction == -1:  # start
                    # A new hairpin starting while another is already
                    # open (no explicit `\!` and no dynamic mark between
                    # them -- rare, but possible, e.g. `\< ... \>`) closes
                    # the old one at this same note first, same reasoning
                    # as the AbsoluteDynamicEvent case above.
                    open_hairpin = self.lane_open_hairpin.get(lane)
                    if open_hairpin is not None:
                        open_hairpin.addSpannedElements(m21_obj)
                        self.spanners.append(open_hairpin)
                    hp = m21dyn.Crescendo() if event.type == 'CrescendoEvent' else m21dyn.Diminuendo()
                    hp.addSpannedElements(m21_obj)
                    self.lane_open_hairpin[lane] = hp
                elif direction == 1:  # explicit `\!` stop -- LilyPond confirmed to use
                    # CrescendoEvent for this regardless of whether a
                    # cresc. or a decresc. is being closed.
                    hp = self.lane_open_hairpin.get(lane)
                    if hp is not None:
                        hp.addSpannedElements(m21_obj)
                        self.spanners.append(hp)
                        self.lane_open_hairpin[lane] = None

        was_tied_into = any(k in self.lane_tied_pitches[lane] for k in pitch_keys)
        if was_tied_into and starts_tie:
            m21_obj.tie = m21tie.Tie('continue')
        elif was_tied_into:
            m21_obj.tie = m21tie.Tie('stop')
        elif starts_tie:
            m21_obj.tie = m21tie.Tie('start')

        if starts_tie:
            self.lane_tied_pitches[lane].update(pitch_keys)
        else:
            self.lane_tied_pitches[lane].difference_update(pitch_keys)


def _assemble_part(events_by_lane, instrument_name, transposition_pitch):
    """Turns one staff's accumulated lane events (see _StaffWalker;
    `events_by_lane` is `shared_events[staff_key]`, which may hold
    contributions from more than one _StaffWalker if `\\change Staff`
    redirected material into this staff -- see class docstring) into
    one Part. A staff that only ever had one lane comes out as a plain
    flat Part, ready for makeMeasures(); one with more gets one
    music21 Voice per lane, each still holding its content at absolute
    offsets (confirmed empirically that Part.makeMeasures() correctly
    relocalizes a Voice's absolute-offset content per measure,
    including across measure boundaries, so no manual offset
    translation is needed here)."""
    from music21 import stream, key as m21key, meter, clef as m21clef
    from music21 import instrument as m21instrument, interval, pitch as m21pitch

    part = stream.Part()

    if instrument_name or transposition_pitch is not None:
        inst = m21instrument.Instrument()
        if instrument_name:
            inst.instrumentName = instrument_name
            part.partName = instrument_name
        if transposition_pitch is not None:
            sounding = _pitch_to_m21(transposition_pitch)
            inst.transposition = interval.Interval(m21pitch.Pitch('C4'), sounding)
            part.atSoundingPitch = False
        part.insert(0, inst)

    lanes = sorted(events_by_lane)
    if not lanes:
        return part
    global_types = (m21key.KeySignature, meter.TimeSignature, m21clef.Clef)

    if len(lanes) == 1:
        for offset, obj in events_by_lane[lanes[0]]:
            part.insert(float(offset), obj)
    else:
        voices = {}
        for lane in lanes:
            v = stream.Voice()
            v.id = lane
            voices[lane] = v
        seen_global = set()
        for lane in lanes:
            for offset, obj in events_by_lane[lane]:
                if isinstance(obj, global_types):
                    dedup_key = (offset, type(obj))
                    if dedup_key in seen_global:
                        continue
                    seen_global.add(dedup_key)
                    part.insert(float(offset), obj)
                else:
                    voices[lane].insert(float(offset), obj)
        for lane in lanes:
            part.insert(0, voices[lane])

    return part


def _staff_key_for(staff_node, index):
    """A stable key identifying one staff for the lifetime of one
    _build_score() call: its own declared name (`\\context Staff =
    "id"`/`\\new Staff = "id"`) if it has one -- the only thing a
    `\\change Staff = "id"` could ever refer to -- else a synthetic,
    never-colliding key, since an unnamed staff can't be a \\change
    target anyway."""
    context_id = staff_node.get('context-id')
    return context_id if context_id is not None else f'__staff{index}__'


def _convert_leading_gap_to_pickup(measured_part, gap):
    """A `\\partial` left every note starting `gap` quarters into the first
    measure (see _StaffWalker._visit_PartialSet). Slide that content back
    to the start of the measure and record the anacrusis as
    paddingLeft, so the first measure IS the short pickup bar; then
    number the measures from 0 (music21 numbers from 1). The initial
    time/key/clef stay put at offset 0."""
    from music21 import meter, key as m21key, clef as m21clef, stream as m21stream
    globals_ = (meter.TimeSignature, m21key.KeySignature, m21clef.Clef)
    measures = list(measured_part.getElementsByClass(m21stream.Measure))
    if not measures:
        return
    first = measures[0]
    voices = list(first.getElementsByClass(m21stream.Voice))
    for container in (voices if voices else [first]):
        for el in list(container):
            if isinstance(el, globals_) and float(el.offset) < 1e-9:
                continue
            new_offset = float(el.offset) - gap
            if new_offset >= -1e-9:
                container.setElementOffset(el, max(new_offset, 0.0))
    if voices:                     # things placed directly on the measure
        for el in list(first):
            if el in voices or (isinstance(el, globals_) and float(el.offset) < 1e-9):
                continue
            if not isinstance(el, m21stream.Voice):
                new_offset = float(el.offset) - gap
                if new_offset >= -1e-9:
                    first.setElementOffset(el, max(new_offset, 0.0))
    first.paddingLeft = gap
    for m in measures:
        m.number = m.number - 1


def _pad_short_measures(part, last_measure_length=None):
    """A voice whose real content doesn't span a full measure -- most
    commonly because some of its beats were redirected to ANOTHER
    staff via `\\change Staff` (see _visit_ContextChange) -- needs an
    explicit (hidden) Rest filling whatever it's missing, or the
    written MusicXML measure doesn't match its own stated time
    signature; real notation software has been observed to handle that
    inconsistently, re-barring much of what follows.

    This checks for gaps directly from the actual elements' own
    offsets/durations -- BEFORE, BETWEEN, or AFTER them -- rather than
    trusting the container's own aggregate .duration/.highestTime:
    confirmed necessary against a real piece where a voice's redirected
    content started partway through the measure (a LEADING gap) with
    its last note landing exactly on the measure's own end -- making
    .duration/.highestTime report the full, correct-looking measure
    length despite 7/3 quarter-notes of real leading silence, so no
    shortfall was ever detected there and music21's own MusicXML
    writer was left to invent its own padding for that gap, uncontrolled
    by this importer -- which is exactly where a real piece was found
    to pick up a bogus, unrelated tuplet ratio on the padding it
    invented. Building the padding explicitly, ourselves, here (with a
    linked=False duration -- see the note below) avoids that entirely.
    """
    from music21 import meter, note, stream as m21stream
    current_ts_ql = 4.0  # default 4/4 if a measure appears before any TimeSignature
    all_measures = list(part.getElementsByClass(m21stream.Measure))
    for measure in all_measures:
        ts = measure.getElementsByClass(meter.TimeSignature).first()
        if ts is not None:
            current_ts_ql = ts.barDuration.quarterLength
        # How long this measure is MEANT to be: a pickup bar is the bar minus
        # its paddingLeft; a FINAL bar the music simply stops short of is
        # only as long as the music in it (any staff's -- see the caller),
        # not padded out with an invented rest. Everything else: a full bar.
        target = current_ts_ql - float(measure.paddingLeft or 0.0)
        if (measure is all_measures[-1] and last_measure_length is not None
                and last_measure_length < target - 1e-6):
            target = last_measure_length
        voices = list(measure.getElementsByClass(m21stream.Voice))
        containers = voices if voices else [measure]
        for container in containers:
            elements = sorted(container.notesAndRests, key=lambda e: e.offset)
            gaps = []
            cursor = 0.0
            for el in elements:
                if el.offset - cursor > 1e-6:
                    gaps.append((cursor, el.offset - cursor))
                cursor = max(cursor, el.offset + el.duration.quarterLength)
            if target - cursor > 1e-6:
                gaps.append((cursor, target - cursor))
            for gap_start, gap_length in gaps:
                # A plain, fully-linked Rest(quarterLength=...) is used
                # here even for a gap with no clean type+dots value on
                # its own (typically one left by a cross-staff tuplet
                # redirect, e.g. 2/3 or 7/3) -- confirmed the hard way
                # that this is actually the RIGHT choice, not a
                # regression risk: music21's own linked construction
                # picks a type+tuplet-ratio pair whose EFFECTIVE length
                # is mathematically exact (e.g. type "whole" scaled by
                # a 12/7 tuplet for a 7/3-quarter gap: 4 * 7/12 = 7/3,
                # correct), unlike an earlier version of this function
                # that forced linked=False to avoid that tuplet ratio --
                # which left a stale, WRONG type/duration pairing
                # instead (e.g. "quarter" for a gap really 2.33 quarters
                # long). That mismatch is the real problem: since this
                # rest, though hidden, is still marked
                # print-spacing="yes", a layout engine sizing the gap
                # from its <type> reserves the WRONG amount of space,
                # displacing every real note that follows -- confirmed
                # against a real piece as a reported, reproducible
                # "notes start too early" symptom. The tuplet ratio
                # this now carries doesn't reintroduce the OTHER,
                # earlier tuplet-display bug (a bogus ratio bleeding
                # onto a DIFFERENT, real, visible note): that one's
                # actual cause -- a coexisting whole-measure-rest voice
                # sitting alongside a tupleted one -- is what
                # _remove_rest_only_voices() (called before this
                # function) already eliminates, and this rest's own
                # tuplet tag, being on a print-object="no" element,
                # hasn't been observed to draw a visible bracket of its
                # own in real testing.
                r = note.Rest(quarterLength=gap_length)
                r.style.hideObjectOnPrint = True
                container.insert(gap_start, r)


def _remove_rest_only_voices(part):
    """Removes any Voice, in any Measure, whose content is entirely
    rests -- most commonly the whole-measure-rest voice that exists
    because a `<< {real music} {R2.} >>` construct called for a second
    voice in principle at that instant but has nothing to say there.
    Confirmed, incidentally, to also fix a real display bug: a
    multi-voice measure mixing a tupleted voice with an otherwise
    plain one was seen (via a real piece's actual written MusicXML) to
    make music21's own export machinery attach a bogus tuplet ratio to
    the PLAIN voice's own notes -- removing the extra, contentless
    voice removed that interaction entirely. Whichever voices remain
    are renumbered 1, 2, 3, ...; if only one remains in a measure, the
    Voice wrapper itself is removed and its content promoted straight
    into the Measure, matching what a measure with no polyphony at
    that point would look like natively."""
    from music21 import stream as m21stream
    for measure in part.getElementsByClass(m21stream.Measure):
        voices = list(measure.getElementsByClass(m21stream.Voice))
        if not voices:
            continue
        real_voices = [v for v in voices if list(v.notes)]
        for v in voices:
            if v not in real_voices:
                measure.remove(v)
        if len(real_voices) == 1:
            only = real_voices[0]
            for el in list(only):
                measure.insert(el.offset, el)
            measure.remove(only)
        else:
            for i, v in enumerate(real_voices):
                v.id = str(i + 1)


def _measure_containing(part, offset):
    """The measure covering `offset` in an already-measured Part (its
    own start <= offset < its own end), or, for an offset that lands
    exactly on the final barline, the last measure."""
    from music21 import stream as m21stream
    measures = list(part.getElementsByClass(m21stream.Measure))
    for m in measures:
        if m.offset <= offset < m.offset + m.duration.quarterLength + 1e-6:
            return m
    candidates = [m for m in measures if m.offset <= offset + 1e-6]
    return candidates[-1] if candidates else None


def _blank_measure(measure):
    """Replaces a measure's entire musical content -- any Voices and
    any direct notes/rests/chords -- with a single, VISIBLE
    whole-measure rest, keeping only its signature-carrying elements
    (clef/key/time/barlines). See LilyCrossStaffManualFixWarning."""
    from music21 import stream as m21stream, note
    target_ql = measure.duration.quarterLength or 4.0
    for v in list(measure.getElementsByClass(m21stream.Voice)):
        measure.remove(v)
    for n in list(measure.notesAndRests):
        measure.remove(n)
    measure.insert(0, note.Rest(quarterLength=target_ql))


def _mark_measure_needs_manual_fix(measure):
    """Attaches the bold, hard-to-miss text warning -- called only on
    the TOP staff's copy of a flagged measure (see
    _flag_and_blank_cross_staff_measures), so it appears once per
    system, not once per staff."""
    from music21 import expressions
    te = expressions.TextExpression('\u26a0 CROSS-STAFF NOTATION \u2014 FIX BY HAND \u26a0')
    te.style.fontWeight = 'bold'
    te.style.fontSize = 10
    measure.insert(0, te)


def _flag_and_blank_cross_staff_measures(measured_by_key, walkers_by_key, staff_keys):
    """See LilyCrossStaffManualFixWarning and the module docstring's
    CROSS-STAFF NOTATION section for why this exists. Finds every
    measure touched by a `\\change Staff` redirect (recorded during the
    walk -- see _StaffWalker.cross_staff_events), blanks it on every
    affected staff (see _blank_measure), attaches the visible warning
    text to the TOP staff's copy only (see _mark_measure_needs_manual_
    fix), and raises one LilyCrossStaffManualFixWarning naming every
    affected measure number, so a caller (see cli.py) can report
    exactly where to look."""
    affected = {}  # staff_key -> set of measure numbers
    for key in staff_keys:
        for offset, target_key, _lane_id in walkers_by_key[key].cross_staff_events:
            for affected_key in (key, target_key):
                part = measured_by_key.get(affected_key)
                if part is None:
                    continue
                m = _measure_containing(part, offset)
                if m is not None:
                    affected.setdefault(affected_key, set()).add(m.number)

    if not affected:
        return

    top_key = staff_keys[0]
    for key, measure_numbers in affected.items():
        part = measured_by_key[key]
        for m in part.getElementsByClass('Measure'):
            if m.number in measure_numbers:
                _blank_measure(m)
                if key == top_key:
                    _mark_measure_needs_manual_fix(m)

    all_measure_numbers = sorted({n for numbers in affected.values() for n in numbers})
    numbers_str = ', '.join(str(n) for n in all_measure_numbers)
    warnings.warn(
        f"Measure(s) {numbers_str}: cross-staff notation (\\change Staff) here "
        f"isn't reliably representable by this importer's per-staff-Part "
        f"architecture (see the module docstring's CROSS-STAFF NOTATION "
        f"section) -- replaced with a rest and flagged for manual fixing "
        f"from the original LilyPond source.",
        LilyCrossStaffManualFixWarning,
    )


# ---------------------------------------------------------------------------
# Lyrics
# ---------------------------------------------------------------------------
#
# LilyPond keeps lyrics apart from the notes they sing: an `\\addlyrics`
# block, or a `\\new Lyrics \\lyricsto "voice" {...}`, is a separate
# LyricCombineMusic node in the tree, tied to a Voice (by its \\new Voice
# = "id") or, for a bare `\\addlyrics`, to a Staff. Its LyricEvents are one
# syllable each: a hyphen or extender after a syllable arrives as an
# attached HyphenEvent/ExtenderEvent, an explicit `_` as a lyric whose
# text is a single space. Several such blocks on one voice are several
# VERSES, numbered in source order.
#
# The syllables are laid onto the voice's notes the way LilyPond itself
# does it: a rest takes none; a note tied FROM the previous note takes
# none; and a slur is a MELISMA -- the note that starts it takes the
# syllable, every later note through the one that ends it takes none.
# (LilyPond's default also treats a hand-written beam `[ ]` as a melisma;
# this importer doesn't capture manual beams, so that one case is
# missed.) A chord takes one syllable. Grace notes take none.
#
# The result is music21's own model: each note's `.lyrics` list holds one
# Lyric per verse (number = verse, syllabic = single/begin/middle/end),
# so it survives every later step -- MusicXML export, snippet cutting --
# with no side channel. A `__` extender has no music21 equivalent and is
# dropped (the melisma itself is still visible: those notes carry no
# syllable).

def _is_text_hyphen(event) -> bool:
    return any(isinstance(a, MusicNode) and a.type == 'HyphenEvent'
               for a in (event.get('articulations') or []))


def _collect_lyric_blocks(node, out):
    """Every LyricCombineMusic under `node`, in source order, as
    (associated-context id, [LyricEvent nodes], stanza label or None)."""
    if isinstance(node, MusicNode):
        if node.type == 'LyricCombineMusic':
            events, stanza = [], [None]

            def gather(n):
                if isinstance(n, MusicNode):
                    if n.type == 'LyricEvent':
                        events.append(n)
                    elif n.type == 'PropertySet' and str(n.get('symbol')) == 'stanza':
                        stanza[0] = str(n.get('value'))
                    for v in n.props.values():
                        if isinstance(v, (MusicNode, list)):
                            gather(v)
                elif isinstance(n, list):
                    for x in n:
                        gather(x)
            gather(node.get('element'))
            out.append((str(node.get('associated-context')), events, stanza[0]))
            return
        for v in node.props.values():
            if isinstance(v, (MusicNode, list)):
                _collect_lyric_blocks(v, out)
    elif isinstance(node, list):
        for x in node:
            _collect_lyric_blocks(x, out)


def _syllables_of(events):
    """[(text or None for an explicit skip, syllabic)] for a verse."""
    entries = []
    for ev in events:
        raw = ev.get('text')
        text = str(raw) if raw is not None else ''
        entries.append((text.strip() or None, _is_text_hyphen(ev)))
    result, continuing = [], False
    for text, hyphen in entries:
        if text is None:
            result.append((None, None))
            continue
        if continuing:
            syllabic = 'middle' if hyphen else 'end'
        else:
            syllabic = 'begin' if hyphen else 'single'
        result.append((text, syllabic))
        continuing = hyphen
    return result


def _lane_notes(shared_events, namespaced_lane):
    """One logical voice's notes/chords in time order (grace notes and
    rests left out), gathered from every staff it may have been written
    to (a `\\change Staff` moves a voice between them)."""
    from music21 import note as m21note
    items = []
    for lanes in shared_events.values():
        items.extend(lanes.get(namespaced_lane, []))
    items.sort(key=lambda pair: pair[0])
    return [obj for _offset, obj in items
            if isinstance(obj, (m21note.Note, m21note.Unpitched)) or getattr(obj, 'isChord', False)
            if not obj.duration.isGrace]


def _attach_lyrics(root_node, staff_nodes, staff_keys, walkers, shared_events):
    from music21 import note as m21note

    blocks = []
    _collect_lyric_blocks(root_node, blocks)
    if not blocks:
        return

    target_of = {}                      # associated-context id -> (staff_key, lane)
    for node, key, walker in zip(staff_nodes, staff_keys, walkers):
        if node.get('context-id') is not None:
            target_of[str(node.get('context-id'))] = (key, '1')
    for key, walker in zip(staff_keys, walkers):
        for voice_id, lane in walker.voice_lane.items():
            target_of[voice_id] = (key, lane)      # a named voice beats a staff id

    slurs = [sp for w in walkers for sp in w.spanners if type(sp).__name__ == 'Slur']
    verse_count = {}
    for assoc_id, events, _stanza in blocks:
        target = target_of.get(assoc_id)
        if target is None:
            warnings.warn(f"Lyrics tied to {assoc_id!r}, which isn't a staff or voice "
                          f"in this score -- skipped.", LilyLyricsWarning)
            continue
        key, lane = target
        notes = _lane_notes(shared_events, f'{key}:{lane}')
        verse = verse_count[target] = verse_count.get(target, 0) + 1

        position = {id(n): i for i, n in enumerate(notes)}
        melisma = set()
        for i, n in enumerate(notes):
            if n.tie is not None and n.tie.type in ('stop', 'continue'):
                melisma.add(id(n))
        for sl in slurs:
            spanned = [position[id(e)] for e in sl.getSpannedElements() if id(e) in position]
            if len(spanned) >= 2:
                for j in range(min(spanned) + 1, max(spanned) + 1):
                    melisma.add(id(notes[j]))
        slots = [n for n in notes if id(n) not in melisma]

        syllables = _syllables_of(events)
        for slot, (text, syllabic) in zip(slots, syllables):
            if text is None:
                continue
            slot.lyrics.append(m21note.Lyric(text=text, number=verse, syllabic=syllabic,
                                             applyRaw=True))
        if len(syllables) > len(slots):
            warnings.warn(f"Lyrics verse {verse} for {assoc_id!r} has {len(syllables)} "
                          f"syllables but only {len(slots)} notes to sing them; the last "
                          f"{len(syllables) - len(slots)} were dropped.", LilyLyricsWarning)
        elif len(syllables) < len(slots):
            warnings.warn(f"Lyrics verse {verse} for {assoc_id!r} has {len(syllables)} "
                          f"syllables for {len(slots)} notes; the remaining "
                          f"{len(slots) - len(syllables)} notes have no lyric.",
                          LilyLyricsWarning)


def _build_score(root_node):
    from music21 import stream
    from music21 import stream as m21stream_module
    import copy as copy_module

    staff_nodes = _find_staves(root_node)
    staff_keys = [_staff_key_for(n, i) for i, n in enumerate(staff_nodes)]
    shared_events = {key: {} for key in staff_keys}

    walkers = []
    for key, node in zip(staff_keys, staff_nodes):
        walker = _StaffWalker(shared_events, key)
        walker.walk(node, '1')
        walker.close_unterminated_spanners()
        walkers.append(walker)

    _attach_lyrics(root_node, staff_nodes, staff_keys, walkers, shared_events)

    parts = [_assemble_part(shared_events[key], w.instrument_name, w.transposition_pitch)
             for key, w in zip(staff_keys, walkers)]
    barcheck_lists = [w.barcheck_offsets for w in walkers]
    repeat_marker_lists = [w.repeat_markers for w in walkers]

    # Spanners must be inserted into their Part BEFORE makeMeasures()
    # runs, not after -- confirmed necessary the hard way: with
    # inPlace=False, makeMeasures() copies its Part's contents into a
    # new structure, and a spanner attached only afterward still
    # points at the pre-copy note objects, which promptly vanish from
    # the result (getSpannedElements() finds nothing there anymore).
    # Attaching it beforehand lets makeMeasures() carry the spanner and
    # its notes over together, consistently. Spanners are attached to
    # specific note/chord objects regardless of which staff's Part
    # those objects end up in, so they don't need per-staff
    # bookkeeping otherwise -- collected once from every walker and
    # placed by finding each one's actual containing (pre-measures)
    # Part.
    all_spanners = [sp for w in walkers for sp in w.spanners]
    for sp in all_spanners:
        spanned = sp.getSpannedElements()
        target_part = spanned[0].getContextByClass(stream.Part) if spanned else None
        if target_part is not None:
            target_part.insert(0, sp)

    inferred_ts = _infer_missing_time_signature(parts, barcheck_lists, repeat_marker_lists)
    if inferred_ts is not None:
        for part in parts:
            part.insert(0, copy_module.deepcopy(inferred_ts))

    _propagate_signatures(parts)
    score = stream.Score()
    measured_by_key = {}
    measured_list = []
    for key, part, repeat_markers in zip(staff_keys, parts, repeat_marker_lists):
        measured = _dedupe_signatures(part.makeMeasures(inPlace=False))
        _apply_repeat_structure(measured, repeat_markers)
        _renumber_voices(measured)
        _remove_rest_only_voices(measured)
        walker_for_key = walkers[staff_keys.index(key)]
        if walker_for_key.pickup_gap:
            _convert_leading_gap_to_pickup(measured, walker_for_key.pickup_gap)
        measured_by_key[key] = measured
        measured_list.append(measured)
    if len({bool(w.pickup_gap) for w in walkers}) > 1:
        warnings.warn(
            "Only some staves carry the \\partial (an anacrusis); the others start "
            "on a full bar, so their bar lines may not line up. In LilyPond a "
            "\\partial in ONE staff applies to the whole score's timing -- repeat "
            "it in each staff (or a shared `global` block) to import it faithfully.",
            LilyPartialWarning)

    # A `\change Staff` that happens WHILE A TUPLET IS OPEN means a
    # single tuplet's own notes are split across two staves -- the one
    # case this importer's normal per-staff-Part architecture can't
    # correctly represent (see importers/multi_staff_emitter.py's
    # module docstring for why: MusicXML has no way for a single beam
    # or tuplet bracket to span two <part> elements, confirmed by
    # round-tripping an independently hand-verified reference file
    # through plain music21 with zero modification and watching it
    # come out corrupted regardless). Rather than fall back to
    # replacing the affected measures with a rest (the previous,
    # disclosed-as-a-limitation behavior), the WHOLE staff group is
    # merged into one custom-emitted multi-staff part whenever this is
    # detected anywhere in it -- see _try_merge_cross_staff_group().
    # MusicXML's <staves> count is fixed for a part's entire duration,
    # so this can't be scoped to just the affected measure(s): once any
    # measure needs 2 staves, every measure of that instrument does.
    all_cross_staff_events = [ev for w in walkers for ev in w.cross_staff_events]
    if all_cross_staff_events:
        merge_result = _try_merge_cross_staff_group(
            staff_keys, measured_list, walkers, all_cross_staff_events)
        if merge_result is not None:
            score_part_xml, part_xml = merge_result
            score._manual_multistaff_parts = [{
                'original_part_indices': list(range(len(measured_list))),
                'score_part_xml': score_part_xml,
                'part_xml': part_xml,
            }]
            for measured in measured_list:
                score.insert(0, measured)
            return score
        # merge_result is None: _try_merge_cross_staff_group already
        # warned about why (an exception, logged as
        # LilyCrossStaffMergeFailedWarning) -- fall through to the
        # normal per-part pipeline, including the blank-and-flag
        # fallback below, rather than silently losing the safety net.

    # How long the FINAL bar really is: the longest any staff's last bar
    # runs. If that's short of a full bar the music simply stops short
    # (the bar that completes a pickup, say) and nothing is padded out.
    last_ends = []
    for measured in measured_list:
        ms_ = list(measured.getElementsByClass(m21stream_module.Measure))
        if ms_:
            containers = list(ms_[-1].getElementsByClass(m21stream_module.Voice)) or [ms_[-1]]
            ends = [float(el.offset + el.duration.quarterLength)
                    for c in containers for el in c.notesAndRests]
            last_ends.append(max(ends) if ends else 0.0)
    last_measure_length = max(last_ends) if last_ends else None
    for measured in measured_list:
        _pad_short_measures(measured, last_measure_length)
        score.insert(0, measured)

    _flag_and_blank_cross_staff_measures(measured_by_key, dict(zip(staff_keys, walkers)), staff_keys)

    return score


def _try_merge_cross_staff_group(staff_keys, measured_parts, walkers, cross_staff_events):
    """Attempts the real fix (see _build_score's own comment just above
    its call to this): merge every staff in this piece into one
    custom-emitted multi-staff part via importers.multi_staff_emitter,
    scoped to the common, real-world case this was built and tested
    against -- one instrument's whole grand staff, not a piece with
    multiple UNRELATED instruments each on their own staff (a
    `\\change Staff` can only ever target a staff that's part of the
    SAME instrument's own grouping in the first place, so merging every
    staff found in the piece is a safe, correct scope for that common
    case). Returns (score_part_xml, part_xml) on success, or None if
    the merge itself raised -- in which case a
    LilyCrossStaffMergeFailedWarning is raised here so the failure is
    visible, and the caller falls back to the previous, safer
    (blank-and-flag) behavior rather than letting an emitter bug
    silently corrupt or lose music.
    """
    from importers import multi_staff_emitter

    cross_staff_lane_ids = {lane_id for _offset, _target, lane_id in cross_staff_events}
    instrument_name = next((w.instrument_name for w in walkers if w.instrument_name), None)

    try:
        return multi_staff_emitter.merge_parts_to_xml(
            measured_parts, 'PLACEHOLDER_PART_ID', instrument_name,
            cross_staff_lane_ids=cross_staff_lane_ids,
        )
    except Exception as e:
        warnings.warn(
            f"Building correctly-preserved cross-staff notation failed "
            f"({type(e).__name__}: {e}) -- falling back to replacing the "
            f"affected measure(s) with a rest and a manual-fix warning "
            f"instead of risking silently wrong or lost music.",
            LilyCrossStaffMergeFailedWarning,
        )
        return None


def _measure_at_offset(measures, offset):
    for m in measures:
        if abs(m.offset - offset) < 1e-6:
            return m
    return None


def _measure_ending_at_offset(measures, offset):
    for m in measures:
        if m.offset < offset <= m.offset + m.duration.quarterLength + 1e-6:
            return m
    return None


def _measures_in_range(measures, start, end):
    return [m for m in measures if start - 1e-6 <= m.offset < end - 1e-6]


def _apply_repeat_structure(part, repeat_markers):
    """Turns the repeat_markers a _PartBuilder recorded (see
    _visit_VoltaRepeatedMusic) into real bar.Repeat barlines and
    spanner.RepeatBracket volta brackets on the now-measured Part.
    Primarily tested against the standard two-ending case; more than
    two endings are handled by the same general rule (every ending
    except the last gets a repeat-end barline of its own, matching how
    a repeat with N>2 endings is actually played) but with less
    real-file coverage."""
    from music21 import bar, spanner

    measures = list(part.getElementsByClass('Measure'))
    for marker in repeat_markers:
        start_measure = _measure_at_offset(measures, marker['start'])
        if start_measure is not None:
            start_measure.leftBarline = bar.Repeat(direction='start')

        endings = marker['endings']
        if not endings:
            end_measure = _measure_ending_at_offset(measures, marker['end'])
            if end_measure is not None:
                end_measure.rightBarline = bar.Repeat(direction='end', times=marker['repeat_count'])
            continue

        for i, (numbers, ending_start, ending_end) in enumerate(endings):
            ending_measures = _measures_in_range(measures, ending_start, ending_end)
            if not ending_measures:
                continue
            if i < len(endings) - 1:  # every ending but the last repeats back
                ending_measures[-1].rightBarline = bar.Repeat(direction='end')
            label = ','.join(str(n) for n in numbers) or str(i + 1)
            part.insert(0, spanner.RepeatBracket(ending_measures, number=label))


def _propagate_signatures(parts):
    """LilyPond scores very commonly state `\\time`/`\\key` on only ONE
    staff and let it apply to the whole system at engraving time --
    that's a property of the shared context hierarchy, not something
    duplicated into every staff's own parsed music. Since each Part
    here was built by walking only ITS OWN staff's tree in isolation
    (see _PartBuilder), a staff that never wrote its own `\\time`/`\\key`
    would otherwise end up with none at all, and Part.makeMeasures()
    would silently assume a default 4/4 -- confirmed by real testing
    to actually mis-measure such a staff (see this importer's
    development notes: a dotted-half note got split and tied across a
    phantom 4/4 barline). This copies every part's own time/key
    signature changes into every OTHER part at the same offset, unless
    that part already has its own at that exact offset.
    """
    from music21 import meter, key as m21key
    import copy as copy_module

    for cls in (meter.TimeSignature, m21key.KeySignature):
        by_offset = {}
        for part in parts:
            for el in part.recurse().getElementsByClass(cls):
                by_offset.setdefault(el.offset, el)  # first one seen wins
        for part in parts:
            existing_offsets = {el.offset for el in part.recurse().getElementsByClass(cls)}
            for offset, el in by_offset.items():
                if offset not in existing_offsets:
                    part.insert(offset, copy_module.deepcopy(el))


def _dedupe_signatures(measured_part):
    """makeMeasures() has been observed (empirically, on a Part
    containing Voice sub-streams -- i.e. any staff with retained
    polyphony) to insert a KeySignature/TimeSignature/Clef into a
    measure TWICE at the same offset, apparently while working out
    each Voice's own notational context. Harmless duplicates, but
    still duplicates -- this removes the extras, keeping the first."""
    from music21 import key as m21key, meter, clef as m21clef
    from music21 import stream as m21stream
    sig_types = (m21key.KeySignature, meter.TimeSignature, m21clef.Clef)
    for measure in measured_part.getElementsByClass(m21stream.Measure):
        seen = set()
        for el in list(measure.getElementsByClass(sig_types)):
            dedup_key = (el.offset, type(el), getattr(el, 'sharps', None),
                         getattr(el, 'ratioString', None), getattr(el, 'sign', None))
            if dedup_key in seen:
                measure.remove(el)
            else:
                seen.add(dedup_key)
    return measured_part


def _renumber_voices(part):
    """makeMeasures() renumbers every Voice.id to a 0-based integer,
    discarding whatever lane id _PartBuilder assigned (confirmed
    empirically). A 0-based first voice produces `<voice>0</voice>` in
    the written MusicXML, which is non-standard (MusicXML voice numbers
    are conventionally 1-based) and was confirmed, by real-world
    testing against this importer's own output, to make MuseScore 3
    fail to display the part's notes at all even though the file
    parses fine elsewhere (e.g. Dorico). This renumbers each measure's
    voices to 1, 2, 3, ... in their existing order."""
    from music21 import stream as m21stream
    for measure in part.getElementsByClass(m21stream.Measure):
        for i, voice in enumerate(measure.getElementsByClass(m21stream.Voice)):
            voice.id = str(i + 1)


def _infer_missing_time_signature(parts, barcheck_offsets_list, repeat_markers_list):
    """If the piece never states `\\time` anywhere (checked here, before
    _propagate_signatures runs, since that only copies EXISTING
    signatures between staves and has nothing to copy if none exist
    anywhere), makeMeasures() would otherwise silently assume 4/4 --
    and the MusicXML writer then serializes that guess as if it were
    real. Confirmed by real-world testing (a fragment with no \\time
    and 5 beats of actual content) that this produces a file different
    programs interpret inconsistently, each resolving the mismatch
    between the assumed 4 beats and the written 5 differently.

    Rather than accept that ambiguity, this derives the ACTUAL bar
    length from the piece's own structural boundaries -- barcheck ('|')
    marks if present, and, since a repeated section's body and each of
    its endings are themselves conventionally whole bars even with no
    `|` written at their edges, the start/end offsets
    _visit_VoltaRepeatedMusic already recorded for any repeat too --
    and asks music21's own meter.bestTimeSignature() (an existing,
    tested utility -- checked against real content before relying on
    it here) to name a signature that actually matches what's written.
    Only if a part has NONE of these boundaries at all is its entire
    content span used as a single implicit bar, on the same reasoning:
    presenting the whole thing as one bar of exactly the length it
    actually is is more honest than silently imposing an unstated 4/4
    grid partway through it (confirmed necessary by real-world testing:
    a repeat's own body/ending boundaries must be checked FIRST, since
    without them a piece that uses \\repeat volta but never writes an
    explicit `\\time` or `|` would otherwise be flattened into one
    single giant measure spanning the whole repeat structure, breaking
    _apply_repeat_structure's later measure lookups). Returns None
    (changing nothing) only if a part has no notes/rests at all to
    measure in the first place.
    """
    from music21 import meter, stream as m21stream
    import copy as copy_module

    if any(part.recurse().getElementsByClass(meter.TimeSignature) for part in parts):
        return None

    for part, barcheck_offsets, repeat_markers in zip(parts, barcheck_offsets_list, repeat_markers_list):
        notes_and_rests = list(part.notesAndRests)
        if not notes_and_rests:
            continue

        boundaries = set(barcheck_offsets)
        for marker in repeat_markers:
            boundaries.add(marker['start'])
            boundaries.add(marker['end'])
            for _numbers, ending_start, ending_end in marker['endings']:
                boundaries.add(ending_start)
                boundaries.add(ending_end)
        boundaries.discard(0)

        if boundaries:
            first_bar_end = min(boundaries)
        else:
            first_bar_end = max(el.offset + el.duration.quarterLength for el in notes_and_rests)

        probe = m21stream.Measure()
        for el in notes_and_rests:
            if el.offset < first_bar_end:
                probe.insert(el.offset, copy_module.deepcopy(el))
        if len(probe) == 0:
            continue
        return meter.bestTimeSignature(probe)
    return None


# ---------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------

# Beams on this importer's Score, if any, were generated by music21 (its
# ABC parser meter-beams barred input itself; the LilyPond importer sets
# none) -- NOT authored in the source. run_job() therefore lets
# importers/notation_repair.py repair tuplet beaming here even when
# beams are present. See that module's docstring, rule 1.
BEAMS_FROM_SOURCE = False


def _read_forms(input_path: Path, lilypond_bin: str):
    """(parsed score forms, source text) for a .ly file, in source order."""
    import tempfile

    with tempfile.TemporaryDirectory(prefix='lilypond_import_') as tmp:
        stdout = _run_lilypond(input_path, lilypond_bin, Path(tmp))

    forms = Reader(stdout).read_all()
    if not forms:
        raise RuntimeError(
            f"lilypond produced no score output for {input_path} -- "
            f"the file may have no music in it, or compiled with warnings "
            f"that suppressed output. Its own messages:\n{stdout}"
        )
    return forms, input_path.read_text(encoding='utf-8', errors='ignore')


def _score_with_metadata(form, source_text, input_path, index):
    score = _build_score(form)

    # Work-level metadata (\\header fields, leading comments) is read
    # from the source text -- LilyPond's music dump doesn't carry it.
    # See importers/lilypond_metadata.py.
    from core.score_metadata import attach_metadata, new_metadata
    from .lilypond_metadata import extract_metadata
    try:
        attach_metadata(score, extract_metadata(source_text, input_path, score_index=index))
    except Exception as e:      # metadata must never block the notes
        warnings.warn(f"{input_path}: could not read metadata ({e}); "
                      f"continuing with none.", LilyMetadataWarning)
        attach_metadata(score, new_metadata('lilypond', input_path))
    return score


def import_scores(input_path, lilypond_bin: str = 'lilypond', **options):
    """EVERY \\score in a LilyPond file as its own Score, in source order
    (see import_score for what a single one contains)."""
    input_path = Path(input_path)
    forms, text = _read_forms(input_path, lilypond_bin)
    return [_score_with_metadata(f, text, input_path, i) for i, f in enumerate(forms)]


def import_score(input_path, lilypond_bin: str = 'lilypond', **options):
    """Parse a LilyPond (.ly) file into a music21 Score. See the module
    docstring for what's handled and what isn't. `lilypond_bin` lets a
    caller point at a specific LilyPond install (e.g. on Windows,
    a full path to lilypond.exe) instead of relying on PATH. If the file
    has several \\score blocks only the first is returned, with a warning;
    import_scores() returns them all.
    """
    input_path = Path(input_path)
    forms, text = _read_forms(input_path, lilypond_bin)
    if len(forms) > 1:
        warnings.warn(
            f"{input_path} has {len(forms)} \\score blocks; only the "
            f"first was imported.",
            LilyMultipleScoresWarning,
        )
    return _score_with_metadata(forms[0], text, input_path, 0)
