"""
core/export_pipeline.py

The export half of the pipeline in the architecture doc:

    import -> prepare (beam repair, short-measure marking, metadata)
           -> transforms (each Score -> Score; the splitter, Score -> [Score],
              comes last)  -> exporters (LilyPond now; MusicXML/MIDI later)

This module ADDS to the project and changes none of its existing files: it
uses core.import_pipeline's JobSpec and _resolve() exactly as they are, and
carries its own copies of the two short steps (`_import_pieces`,
`prepare_score`) that the MusicXML job runs, so it cannot disagree with, or
overwrite, whatever version of the import pipeline and importers you have.

There are no transforms yet, so `transforms=[]` is the identity case and what
is written is the score as imported.

COMMAND LINE (from the project root):

    python -m core.export_pipeline sonata.ly -o sonata_out.ly
    python -m core.export_pipeline sonata.musicxml -o out/sonata.ly --midi --render svg
    python -m core.export_pipeline sonata.ly            # writes sonata_export.ly

`-o` names the output FILE (a name ending in .ly) or, if it is an existing
folder or has no extension, the folder to write into. The output is never
allowed to overwrite the input file: with no -o, a .ly input gets
`<name>_export.ly`, and an explicit -o that points at the input is refused.
"""

import argparse
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from core.import_pipeline import JobSpec, _resolve
from exporters import lilypond as ly


@dataclass
class ExportSpec:
    """What to do with an imported Score and what to write.

    transforms: callables applied in order, each Score -> Score.
    output_path: a file name ending in .ly, or a folder (existing, or with no
        extension). Default: next to the input, named <input>.ly -- or
        <input>_export.ly when the input is itself a .ly file.
    midi: also have LilyPond write a MIDI file from the same .ly.
    render: LilyPond output formats to produce from the .ly, any of
        'png', 'svg', 'pdf' -- empty means write the .ly only.
    lilypond_bin: path to the lilypond executable.
    """
    transforms: list = field(default_factory=list)
    output_path: Optional[str] = None
    midi: bool = False
    render: tuple = ()
    lilypond_bin: str = 'lilypond'


@dataclass
class ExportResult:
    ly_path: Path
    score: object
    export_warnings: list
    lilypond_problems: list = field(default_factory=list)   # empty if not rendered


def _import_pieces(spec: JobSpec):
    """Same steps as the MusicXML job's import stage: resolve the format,
    import every score the file yields (unless spec.multi == 'first'), cut
    marked-up scores into snippets. Nothing is written."""
    from core.snippets import split_snippets

    input_path, format_name, importer = _resolve(spec)
    multi_import = getattr(importer, 'import_scores', None)
    if spec.multi == 'all' and multi_import is not None:
        scores = multi_import(input_path, **spec.importer_options)
    else:
        scores = [importer.import_score(input_path, **spec.importer_options)]
    pieces = []
    for sc in scores:
        cut = split_snippets(sc) if spec.split_snippets else None
        pieces.extend(cut if cut else [sc])
    return input_path, format_name, importer, pieces


def prepare_score(score, importer, format_name, input_path: Path):
    """The repairs the MusicXML job applies before writing (in the same order):
    tuplet beaming, short-measure marking, metadata settling. In place."""
    from core.score_metadata import get_metadata, stamp_processed
    from importers.notation_repair import fix_tuplet_beaming
    from core.measures import mark_short_measures

    fix_tuplet_beaming(score, beams_from_source=getattr(importer, 'BEAMS_FROM_SOURCE', True))
    mark_short_measures(score)
    metadata = get_metadata(score)
    metadata['origin']['format'] = metadata['origin'].get('format') or format_name
    metadata['origin']['path'] = metadata['origin'].get('path') or str(input_path)
    stamp_processed(metadata)
    return metadata


def apply_transforms(score, transforms):
    for t in transforms:
        score = t(score)
    return score


def _output_paths(input_path: Path, output_path, n_pieces: int):
    """One .ly path per piece; never the input file itself."""
    stem = input_path.stem
    if output_path:
        out = Path(output_path)
        if out.suffix.lower() == '.ly':
            folder, base = out.parent, out.stem
        else:                                   # a folder, existing or not
            folder, base = out, stem + ('_export' if input_path.suffix.lower() == '.ly' else '')
    else:
        folder = input_path.parent
        base = stem + ('_export' if input_path.suffix.lower() == '.ly' else '')
    paths = [folder / (f'{base}_{k:02d}.ly' if n_pieces > 1 else f'{base}.ly')
             for k in range(1, n_pieces + 1)]
    for p in paths:
        if p.resolve() == input_path.resolve():
            raise ValueError(f'{p} is the input file; refusing to overwrite it. '
                             f'Give -o a different name.')
    return paths


def run_export_job(job: JobSpec, export: ExportSpec) -> list:
    """Import `job`, prepare and transform each resulting Score, and write
    one .ly per Score (numbered when the file held several). Returns one
    ExportResult per Score."""
    input_path, format_name, importer, pieces = _import_pieces(job)
    paths = _output_paths(input_path, export.output_path, len(pieces))
    results = []
    for score, ly_path in zip(pieces, paths):
        prepare_score(score, importer, format_name, input_path)
        score = apply_transforms(score, export.transforms)
        ly_path.parent.mkdir(parents=True, exist_ok=True)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            ly.write_lilypond(score, ly_path, midi=export.midi)
        problems = []
        if export.render:
            _, err = ly.compile_lilypond(ly_path, ly_path.parent, formats=export.render,
                                         lilypond_bin=export.lilypond_bin)
            problems = ly.lilypond_problems(err)
        results.append(ExportResult(
            ly_path=ly_path, score=score,
            export_warnings=[str(w.message) for w in caught
                             if issubclass(w.category, ly.LilyExportWarning)],
            lilypond_problems=problems))
    return results


def main(argv=None):
    ap = argparse.ArgumentParser(
        description='Import a score (any format the importers read) and write it as LilyPond, as-is.')
    ap.add_argument('input')
    ap.add_argument('-o', '--output', default=None, metavar='FILE.ly|FOLDER',
                    help='output .ly file, or a folder to write into (never the input file)')
    ap.add_argument('--format', default=None)
    ap.add_argument('--midi', action='store_true', help='also write MIDI (via LilyPond)')
    ap.add_argument('--render', nargs='*', default=[], choices=['png', 'svg', 'pdf'])
    ap.add_argument('--lilypond-bin', default='lilypond')
    a = ap.parse_args(argv)
    job = JobSpec(input_path=a.input, format=a.format,
                  importer_options={'lilypond_bin': a.lilypond_bin})
    exp = ExportSpec(output_path=a.output, midi=a.midi, render=tuple(a.render),
                     lilypond_bin=a.lilypond_bin)
    try:
        results = run_export_job(job, exp)
    except ValueError as e:
        print('error:', e)
        return 2
    for r in results:
        print('wrote', r.ly_path)
        for w in r.export_warnings:
            print('  note:', w)
        for p in r.lilypond_problems:
            print('  LilyPond:', p)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
