"""
core/import_pipeline.py

The "import umbrella" described for this project: one JobSpec + run_job()
that picks the right format-specific importer for a given input, gets
back a single music21 Score, and writes it out as MusicXML. This is the
first slice of the full import -> transform -> export -> bundle pipeline
in the architecture doc, and it's meant to be the one entry point both
a future CLI and a future Qt6 GUI call -- neither front end should
import a format-specific module (importers.musedata_importer, etc.)
directly, so CLI and GUI options stay in lockstep instead of drifting.

Named import_pipeline.py rather than the more generic pipeline.py so
it's clear at a glance this covers the import stage only -- transform/
export/bundle stages, when they exist, are expected to get their own
similarly-scoped modules (transforms/, exporters/, bundlers/ per the
architecture doc) rather than all piling into one file.

ONE FILE -> MANY SCORES. A file can hold several scores: an ABC file with
many tunes, a LilyPond file with several \\score blocks, or one score
marked up with snippet markers (core/snippets.py). run_job_all() returns
one JobResult per resulting score; run_job() is the original
one-file-one-score entry point and keeps its behavior (first score only,
no snippet splitting). An importer opts in to the multi-score path by
providing import_scores(); one that doesn't is treated as a one-score
importer.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from importers import detect_format, get_importer
from core.score_metadata import (fill_music21_metadata, get_metadata,
                                 no_music21_placeholder_metadata, stamp_processed)
from importers.notation_repair import fix_tuplet_beaming
from core.measures import mark_short_measures


@dataclass
class JobSpec:
    """One import job.

    input_path: a single file, or -- MuseData only -- a directory of
        per-part files that together form one work (see
        importers.musedata_importer's docstring).
    format: one of 'musedata', 'humdrum', 'musicxml', 'lilypond',
        'abc', 'midi', or None (the
        default) to auto-detect from input_path via importers.detect_format().
        Set this explicitly whenever detection is ambiguous (e.g. an
        extensionless file) or you already know the format.
    output_path: where to write the resulting MusicXML. Defaults to
        input_path with a .musicxml suffix, matching what each standalone
        script did before (this also works sensibly for a directory
        input, e.g. "quartet/" -> "quartet.musicxml").
    importer_options: passed straight through as **kwargs to the chosen
        importer's import_score() -- e.g. {'apply_filters': False} for
        Humdrum's --no-filters equivalent. Unrecognized options are
        simply ignored by importers that don't take them, per each
        import_score()'s **options catch-all.
    """
    input_path: str
    format: Optional[str] = None
    output_path: Optional[str] = None
    importer_options: dict[str, Any] = field(default_factory=dict)
    # run_job_all() only:
    multi: str = 'all'            # 'all' scores in the file, or the 'first' only
    split_snippets: bool = True   # cut marked-up scores into snippets


@dataclass
class JobResult:
    """What run_job() hands back."""
    format: str
    score: Any  # music21.stream.Score
    output_path: Path
    metadata: dict = field(default_factory=dict)  # see core/score_metadata.py
    beams_repaired: int = 0   # measures re-beamed around tuplets (notation_repair)


def _slug(text, limit=40) -> str:
    import re
    slug = re.sub(r'[^a-z0-9]+', '-', (text or '').lower()).strip('-')
    return slug[:limit].strip('-')


def prepare_score(score, importer, format_name, input_path: Path):
    """Everything that must happen to a freshly imported Score before ANY
    exporter (MusicXML, LilyPond, MIDI) sees it. Modifies `score` in
    place; returns (metadata, beams_repaired). Split out of _finish_job
    so exporters other than MusicXML start from the same repaired,
    stamped Score instead of re-deciding these steps."""
    # music21 beams by meter position and knows nothing of tuplet
    # groups, so any importer that leaves notes unbeamed (ABC, LilyPond,
    # ...) is affected -- repaired here for all of them, and only where
    # the beams are ours to generate. See importers/notation_repair.py.
    beams_repaired = fix_tuplet_beaming(
        score, beams_from_source=getattr(importer, 'BEAMS_FROM_SOURCE', True))

    # A short measure (pickup, short final bar, ...) must be MARKED short,
    # or music21's writer pads it with an invented rest. See core/measures.py.
    mark_short_measures(score)

    # Work-level metadata: whatever the importer attached (or an empty
    # dict), stamped with today's date as the date THIS APP processed it.
    metadata = get_metadata(score)
    metadata['origin']['format'] = metadata['origin'].get('format') or format_name
    metadata['origin']['path'] = metadata['origin'].get('path') or str(input_path)
    stamp_processed(metadata)
    return metadata, beams_repaired


def _finish_job(score, importer, format_name, input_path: Path, output_path: Path) -> JobResult:
    """Everything after import, for one Score: prepare it (see
    prepare_score), write the MusicXML, splice any hand-built XML."""
    metadata, beams_repaired = prepare_score(score, importer, format_name, input_path)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    # Put our metadata into what music21 writes (only where music21 has
    # none of its own), and stop music21 inventing a "Music21 Fragment"
    # title and a "Music21" composer for scores that have neither.
    fill_music21_metadata(score, metadata)
    with no_music21_placeholder_metadata():
        score.write('musicxml', fp=str(output_path))

    # An importer that had to build part of a Score's content by a
    # means music21's own object model can't represent at all (so far:
    # a multi-staff single instrument with genuine cross-staff
    # notation -- see importers/multi_staff_emitter.py and
    # importers/lilypond_importer.py's _try_merge_cross_staff_group)
    # signals this by attaching `_manual_multistaff_parts` to the
    # returned Score, rather than the shared import_score() contract
    # changing per-importer. When present, splice that hand-built XML
    # into the file music21 just wrote, replacing whatever (necessarily
    # wrong, for this specific content) output music21 produced for
    # those parts.
    manual_parts = getattr(score, '_manual_multistaff_parts', None)
    if manual_parts:
        _splice_manual_parts(output_path, manual_parts)

    return JobResult(format=format_name, score=score, output_path=output_path,
                     metadata=metadata, beams_repaired=beams_repaired)


def _resolve(spec: JobSpec):
    input_path = Path(spec.input_path)
    if not input_path.exists():
        raise FileNotFoundError(f"Input not found: {input_path}")
    format_name = spec.format or detect_format(input_path)
    return input_path, format_name, get_importer(format_name)


def run_job(spec: JobSpec) -> JobResult:
    """Run one import job end to end: resolve the format, hand off to
    that format's importer for a Score, write the Score out as
    MusicXML, and report what happened. ONE score: if the file holds
    several, the importer's own first-only behavior applies (with its
    warning) and no snippet splitting is done -- see run_job_all() for
    the multi-score path.

    Raises FileNotFoundError if input_path doesn't exist, and whatever
    importers.detect_format()/get_importer() raise (ValueError) if the
    format can't be determined or isn't recognized.
    """
    input_path, format_name, importer = _resolve(spec)
    score = importer.import_score(input_path, **spec.importer_options)
    output_path = (Path(spec.output_path) if spec.output_path
                   else input_path.with_suffix('.musicxml'))
    return _finish_job(score, importer, format_name, input_path, output_path)


def _import_pieces(spec: JobSpec):
    """Import step shared by run_job_all() and the export pipeline:
    resolve the format, import every score the file yields (unless
    spec.multi == 'first'), and cut marked-up scores into snippets
    (unless spec.split_snippets is False). Returns
    (input_path, format_name, importer, [Score, ...]) -- nothing written,
    nothing repaired yet (see prepare_score)."""
    from core.snippets import split_snippets

    input_path, format_name, importer = _resolve(spec)
    multi_import = getattr(importer, 'import_scores', None)
    if spec.multi == 'all' and multi_import is not None:
        scores = multi_import(input_path, **spec.importer_options)
    else:
        scores = [importer.import_score(input_path, **spec.importer_options)]

    pieces = []
    for sc in scores:
        cut = split_snippets(sc) if spec.split_snippets else None
        pieces.extend(cut if cut else [sc])
    return input_path, format_name, importer, pieces


def run_job_all(spec: JobSpec) -> list:
    """Like run_job(), but for files that can yield several scores.
    Returns one JobResult per score, in file order:
      - every score the importer can find (all tunes of an ABC file, all
        \\score blocks of a LilyPond file) unless spec.multi == 'first';
      - each of those cut into snippets if it carries snippet markers,
        unless spec.split_snippets is False.
    With a single result, output_path is used exactly as run_job() uses
    it. With several, output_path names the base: its folder (or, if it
    has no file extension, the folder itself) and its stem are used, and
    each file is written as <stem>_<NN>_<title-slug>.musicxml, NN
    counting from 01 across ALL results."""
    input_path, format_name, importer, pieces = _import_pieces(spec)

    if len(pieces) == 1:
        out = (Path(spec.output_path) if spec.output_path
               else input_path.with_suffix('.musicxml'))
        return [_finish_job(pieces[0], importer, format_name, input_path, out)]

    if spec.output_path:
        given = Path(spec.output_path)
        folder, stem = (given.parent, given.stem) if given.suffix else (given, input_path.stem)
    else:
        folder, stem = input_path.parent, input_path.stem
    results = []
    for n, sc in enumerate(pieces, start=1):
        md = get_metadata(sc)
        title = ((md.get('snippet') or {}).get('title') or md.get('movement_title')
                 or md.get('work_title')
                 or (sc.metadata.title if sc.metadata is not None else None))
        name = f"{stem}_{n:02d}" + (f"_{_slug(title)}" if _slug(title) else '') + '.musicxml'
        results.append(_finish_job(sc, importer, format_name, input_path, folder / name))
    return results


def _splice_manual_parts(output_path: Path, manual_parts_info: list) -> None:
    """Replaces whatever music21 wrote for certain parts with hand-built
    XML instead (see run_job()'s own comment above the call to this).

    Each entry in `manual_parts_info` is
    {'original_part_indices': [i, j, ...], 'score_part_xml': '...',
    'part_xml': '...'}: `original_part_indices` are 0-based positions
    in Score.parts, in insertion order -- the only way to identify them
    reliably, since music21 assigns each <part> a content-hash id
    (confirmed empirically: setting a Part's own .id before writing
    does NOT influence the id music21 gives it in the file), not
    anything derived from insertion order or a name we control.
    Insertion order IS preserved between Score.parts and the written
    <part-list>, though, which is what this relies on: the first index
    in each group becomes the merged part (keeping music21's own
    already-assigned id, with score_part_xml/part_xml spliced in to
    replace its original content); every other index in the group is
    removed entirely (its <score-part> entry and its whole <part>
    block), since its content now lives in the merged part instead.
    `PLACEHOLDER_PART_ID` in `part_xml`/`score_part_xml` (see
    importers/multi_    emitter.py) is substituted with whatever id
    music21 actually assigned to that first index.
    """
    import xml.etree.ElementTree as ET

    tree = ET.parse(output_path)
    root = tree.getroot()
    part_list = root.find('part-list')
    score_parts = part_list.findall('score-part')
    parts = root.findall('part')

    for info in manual_parts_info:
        indices = info['original_part_indices']
        if not indices:
            continue
        host_index = indices[0]
        # host_index is a position in the IN-MEMORY score.parts the
        # importer built -- but the WRITTEN file doesn't always have
        # one <part> per entry there: music21's own writer, when it
        # sees several sibling PartStaff objects (confirmed: this is
        # exactly what its own reader splits a multi-staff MusicXML
        # part into on read), automatically rejoins them back into a
        # single <part> at write time -- so the file may already have
        # fewer <part> blocks than score.parts had entries. Guard
        # every lookup below against running past what's actually in
        # the file instead of assuming a fixed count either way.
        if host_index >= len(score_parts):
            continue
        real_id = score_parts[host_index].get('id')

        new_score_part = ET.fromstring(
            info['score_part_xml'].replace('PLACEHOLDER_PART_ID', real_id))
        part_list_children = list(part_list)
        part_list.remove(score_parts[host_index])
        part_list.insert(part_list_children.index(score_parts[host_index]), new_score_part)

        new_part = ET.fromstring(info['part_xml'].replace('PLACEHOLDER_PART_ID', real_id))
        score_children = list(root)
        root.remove(parts[host_index])
        root.insert(score_children.index(parts[host_index]), new_part)

        for extra_index in indices[1:]:
            if extra_index >= len(score_parts) or score_parts[extra_index] not in list(part_list):
                continue
            part_list.remove(score_parts[extra_index])
            root.remove(parts[extra_index])

    # ElementTree doesn't preserve the DOCTYPE declaration MusicXML
    # files conventionally carry -- re-add it, matching what music21's
    # own writer produces.
    body = ET.tostring(root, encoding='unicode')
    doctype = ('<?xml version="1.0" encoding="UTF-8"?>\n'
               '<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 4.0 Partwise//EN" '
               '"http://www.musicxml.org/dtds/partwise.dtd">\n')
    output_path.write_text(doctype + body, encoding='utf-8')
