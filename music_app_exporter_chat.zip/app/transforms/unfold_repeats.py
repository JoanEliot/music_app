"""
transforms/unfold_repeats.py

Score -> Score. Expands real repeat structure (bar.Repeat start/end
barlines, spanner.RepeatBracket volta brackets -- whatever an importer
left in place, not just LilyPond's) into its played-through form: the
repeated material actually duplicated in the timeline, with each
ending appearing only where it's actually played and no repeat
barlines left behind.

WHY THIS IS A SEPARATE STEP, NOT PART OF ANY IMPORTER
--------------------------------------------------------
A Score should keep its repeat signs by default -- that's what the
piece actually looks like, and it's what you want if you're re-
exporting to MusicXML/LilyPond for engraving. Unfolding only matters
for consumers that can't represent a repeat sign at all, and MIDI is
the standing example: a MIDI file has no notion of "go back to the
start" the way notated music does, so whatever plays it back needs the
material physically repeated in the file. Rather than have every
importer that might feed a MIDI export re-decide this, unfolding lives
here as its own explicit step: call it right before MIDI generation,
and leave every other consumer (MusicXML export, LilyPond re-export,
on-screen display) working from the still-folded Score.

This is not LilyPond-specific -- it operates on whatever bar.Repeat/
RepeatBracket structure is already in a music21 Score, regardless of
which importer produced it (MusicXML also carries real repeat
barlines, and music21's own scores from any source can have them too).

IMPLEMENTATION
------------------------------------------------------------------
This is a thin wrapper around music21's own, already-existing
Stream.expandRepeats() (backed by music21.repeat.Expander) -- verified
directly against real repeat-preserving importer output before relying
on it here, rather than hand-rolling the same logic. expandRepeats()
already understands nested repeats and multiple volta endings; this
wrapper's only job is applying it per-Part (a Score-level
expandRepeats() call does not currently expand each Part
independently) and returning a proper Score.
"""


def unfold_repeats(score):
    """Returns a new Score with every Part's repeat structure expanded
    into its played-through form. The input Score is not modified
    (music21's own expandRepeats() always deep-copies)."""
    from music21 import stream

    unfolded = stream.Score()
    for part in score.parts:
        unfolded.insert(0, part.expandRepeats())
    return unfolded
