"""
transforms package

Score -> Score functions, per the architecture doc's module layout.
Each transform here takes a music21 Score (or, where noted, is applied
per-Part) and returns a new one -- none of them are specific to any
one import format.
"""
