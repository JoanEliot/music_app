"""
importers package

Each format-specific importer module below exposes exactly one required
entry point:

    import_score(input_path, **options) -> music21.stream.Score

That's the whole contract -- take a path (a single file, or, for
MuseData only, a directory of per-part files that together form one
work -- see musedata_importer's docstring), return one parsed music21
Score. No writing to disk happens here; that's core.import_pipeline's
job. Keeping every importer to this one shape is what lets
core.import_pipeline.run_job() dispatch to any of them (present or
future) through the same two lines of code, and what let this file
extract the real per-format logic out of the three original standalone
scripts (musedata_to_musicxml.py, humdrum_to_musicxml.py, and plain
music21 parsing for MusicXML) without changing that logic.

Adding a new format later means adding one more module here with an
import_score() of this shape, and one more line in
IMPORTERS/_EXTENSION_TO_FORMAT below -- core.import_pipeline does not
need to change. midi_importer.py is a case of this worth noting
specifically: it's not really a MIDI parser in its own right, it
shells out to a real MuseScore install for the actual MIDI->notation
work (music21's own MIDI reader has no real quantization of its own),
then hands MuseScore's own MusicXML output to musicxml_importer.
import_score() -- i.e. one importer calling another, which the shared
import_score() shape makes straightforward.
"""

from pathlib import Path

from . import (musedata_importer, humdrum_importer, musicxml_importer, lilypond_importer,
               abc_importer, midi_importer)

IMPORTERS = {
    'musedata': musedata_importer,
    'humdrum': humdrum_importer,
    'musicxml': musicxml_importer,
    'lilypond': lilypond_importer,
    'abc': abc_importer,
    'midi': midi_importer,
}

# Extension -> format name. Covers the discrete-file case; a directory
# (which has no extension to look at) is handled separately in
# detect_format() below, per MuseData's own directory-of-parts convention.
_EXTENSION_TO_FORMAT = {
    '.krn': 'humdrum',
    '.hum': 'humdrum',
    '.musicxml': 'musicxml',
    '.xml': 'musicxml',
    '.mxl': 'musicxml',
    '.musedata': 'musedata',
    '.md': 'musedata',
    '.ly': 'lilypond',
    '.ily': 'lilypond',
    '.abc': 'abc',
    '.mid': 'midi',
    '.midi': 'midi',
}


def detect_format(input_path) -> str:
    """Guess an input's format so a caller doesn't have to state it
    explicitly (JobSpec.format can always override this). Order of
    checks:

      1. A directory is always 'musedata' -- MuseData is the only one
         of these three formats where a whole work is conventionally
         split across several files in one folder.
      2. A recognized extension (see _EXTENSION_TO_FORMAT).
      3. Extensionless file content-sniffing: Humdrum's leading '**'
         interpretation line is distinctive (see
         humdrum_importer.looks_like_humdrum); MuseData part-files are
         also conventionally extensionless but less distinctively
         shaped (see musedata_importer.looks_like_musedata) and are
         checked second so a Humdrum file never gets misdetected.

    Raises ValueError if nothing matches -- the caller should pass
    JobSpec.format explicitly in that case.
    """
    path = Path(input_path)

    if path.is_dir():
        return 'musedata'

    ext = path.suffix.lower()
    if ext in _EXTENSION_TO_FORMAT:
        return _EXTENSION_TO_FORMAT[ext]

    if humdrum_importer.looks_like_humdrum(path):
        return 'humdrum'
    if musedata_importer.looks_like_musedata(path):
        return 'musedata'

    raise ValueError(
        f"Can't determine the format of {path} -- pass format= explicitly "
        f"on the JobSpec, or give the file one of the recognized "
        f"extensions (.krn/.hum for Humdrum, .musicxml/.xml/.mxl for "
        f"MusicXML, .musedata/.md for MuseData, .ly/.ily for LilyPond, "
        f".abc for ABC, .mid/.midi for MIDI)."
    )


def scan_format(path):
    """Format of a file FOUND WHILE SCANNING A FOLDER, or None if it isn't
    music this app reads. Stricter than detect_format(), which trusts an
    extension because a person named the file: a folder scan meets README
    files, config XML, notes and so on, and must not treat them as music.
      - `.xml`: only if it is MusicXML (a score-partwise/score-timewise
        root in its first few KB); any other XML is ignored.
      - `.md`: only if the content looks like MuseData (the extension is
        also Markdown's, and a README.md is not a score).
      - other known extensions: as detect_format().
      - no extension: Humdrum, then MuseData, by content; else ignored.
    (`.mxl`, a zip, is accepted as MusicXML on its extension.)
    """
    path = Path(path)
    ext = path.suffix.lower()
    try:
        if ext == '.xml':
            head = path.read_text(encoding='utf-8', errors='ignore')[:4096]
            return 'musicxml' if ('<score-partwise' in head or '<score-timewise' in head) else None
        if ext == '.md':
            return 'musedata' if musedata_importer.looks_like_musedata(path) else None
        if ext in _EXTENSION_TO_FORMAT:
            return _EXTENSION_TO_FORMAT[ext]
        if ext == '':
            if humdrum_importer.looks_like_humdrum(path):
                return 'humdrum'
            if musedata_importer.looks_like_musedata(path):
                return 'musedata'
    except OSError:
        return None
    return None


def get_importer(format_name: str):
    """Look up an importer module by format name (as returned by
    detect_format(), or as set explicitly on a JobSpec)."""
    try:
        return IMPORTERS[format_name]
    except KeyError:
        raise ValueError(
            f"Unknown format {format_name!r}. Known formats: "
            f"{', '.join(sorted(IMPORTERS))}"
        )
