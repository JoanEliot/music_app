"""
satb2gs_python.py

A pure-Python fallback for humlib's 'satb2gs' tool, operating directly
on an already-parsed music21 Score (not on raw Humdrum spine text).

This exists because compiling the real satb2gs tool requires a C++
toolchain and, as discovered the hard way, this particular Ubuntu
mingw-w64 gcc-13 package has a genuine internal defect for Windows
cross-compilation (its C++ headers emit SJLJ exception-personality
calls that don't exist anywhere in its own shipped libgcc.a/libgcc_eh.a
-- confirmed directly with `nm`, not a link-flag issue). Rather than
depend on a working C++ toolchain at all, this module reimplements
just the specific transform we need directly against music21's data
model, which is more tractable and has no external build dependency.

WHAT THIS DOES
--------------
Given a Score with exactly 4 monophonic Parts in SATB order (soprano,
alto, tenor, bass -- the order music21's Humdrum importer naturally
produces spines in), merges them onto 2 staves:
    - soprano + alto -> one Part, treble clef, as Voice 1 / Voice 2
    - tenor + bass   -> one Part, bass clef,   as Voice 1 / Voice 2

Unlike the real satb2gs, this does NOT dynamically collapse to a
single voice where both voices of a staff move in identical rhythm
(that requires Humdrum's *^/*v spine-manipulation machinery, which
lives upstream of music21's parsed Stream and isn't reconstructable
from it directly). Instead it ALWAYS keeps 2 Voices per merged staff.
This is not a compromise so much as a different, equally standard
convention -- most published SATB grand-staff reductions (soprano
stems-up / alto stems-down on the treble staff, tenor stems-up / bass
stems-down on the bass staff) are engraved exactly this way throughout,
voices merging visually only when they happen to share noteheads.

WHAT THIS DOES NOT DO
----------------------
- Does not handle anything other than exactly 4 monophonic SATB parts.
  If the input doesn't look like that, satb2gs_python raises rather
  than guessing.
- Does not apply the file's own '!!!filter: shed ...' clef substitution
  -- humdrum_filters.py still does that afterward, exactly as it did
  for the compiled-binary path.
- Has been validated against exactly one real piece (Bach, Art of the
  Fugue, Contrapunctus 1) by diffing its output against the real
  compiled satb2gs tool's output note-for-note (see test notes below);
  it has not been fuzz-tested against arbitrary SATB files.
"""

import copy

from music21 import stream, clef as m21clef
from core.score_metadata import copy_metadata


def _clef_for_group(parts_in_group):
    """Pick the merged staff's clef: bass clef if the group's lowest
    part uses a clef whose default octave places it clearly in the
    bass range, otherwise treble. In practice for a standard SATB
    pairing this just means: soprano+alto -> treble, tenor+bass -> bass.
    """
    lowest_part = parts_in_group[-1]
    original_clefs = lowest_part.recurse().getElementsByClass('Clef')
    if original_clefs:
        orig = original_clefs[0]
        # BassClef, baritone clefs, etc. all read comfortably in bass
        # clef; anything else (soprano/alto/tenor C-clefs, treble) we
        # render in treble for the upper group by convention.
        if isinstance(orig, m21clef.BassClef) or isinstance(orig, m21clef.Bass8vbClef):
            return m21clef.BassClef()
    return m21clef.TrebleClef()


def merge_satb_to_grand_staff(score):
    """Take a Score with exactly 4 monophonic SATB Parts (soprano,
    alto, tenor, bass, in that order -- music21's natural Humdrum
    spine order) and return a new Score with those merged onto 2
    staves as described in the module docstring.

    Raises ValueError if the input doesn't have exactly 4 parts.
    """
    parts = list(score.parts)
    if len(parts) != 4:
        raise ValueError(
            f"satb2gs_python only handles exactly 4 SATB parts, got {len(parts)}. "
            f"Use the compiled satb2gs tool, or --no-filters, instead."
        )

    groups = [(parts[0], parts[1]), (parts[2], parts[3])]  # (S,A), (T,B)

    new_score = stream.Score()
    if score.metadata is not None:
        new_score.metadata = copy.deepcopy(score.metadata)
    copy_metadata(score, new_score)   # the pipeline's own work-level metadata

    for group_index, (top_part, bottom_part) in enumerate(groups):
        merged = stream.Part()
        merged.id = f"grandstaff_{group_index}"
        merged.partName = "Soprano / Alto" if group_index == 0 else "Tenor / Bass"

        top_measures = list(top_part.getElementsByClass('Measure'))
        bottom_measures = list(bottom_part.getElementsByClass('Measure'))
        if len(top_measures) != len(bottom_measures):
            raise ValueError(
                f"Voice pair {group_index} has mismatched measure counts "
                f"({len(top_measures)} vs {len(bottom_measures)}); refusing to guess alignment."
            )

        merged_clef = _clef_for_group([top_part, bottom_part])

        for m_index, (top_m, bottom_m) in enumerate(zip(top_measures, bottom_measures)):
            new_measure = stream.Measure(number=top_m.number)

            # Carry over measure-level signature elements (clef, key,
            # time signature, barline style) from the top part's
            # measure, except clef -- we set our own merged-staff clef,
            # only on the very first measure (subsequent clef changes
            # inside the piece, if any, are not handled by this
            # simplified merger).
            for el in top_m.getElementsByClass(('KeySignature', 'TimeSignature')):
                new_measure.insert(el.offset, copy.deepcopy(el))
            if m_index == 0:
                new_measure.insert(0, merged_clef)

            voice1 = stream.Voice()
            voice1.id = '1'
            for el in top_m.notesAndRests:
                voice1.insert(el.offset, copy.deepcopy(el))

            voice2 = stream.Voice()
            voice2.id = '2'
            for el in bottom_m.notesAndRests:
                voice2.insert(el.offset, copy.deepcopy(el))

            new_measure.insert(0, voice1)
            new_measure.insert(0, voice2)

            if top_m.rightBarline is not None:
                new_measure.rightBarline = copy.deepcopy(top_m.rightBarline)

            merged.append(new_measure)

        new_score.insert(0, merged)

    return new_score
