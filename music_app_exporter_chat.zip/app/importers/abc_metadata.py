"""
importers/abc_metadata.py

ABC -> the pipeline's format-neutral metadata dict (see
core/score_metadata.py). Reads the tune's information fields and
comments from the ABC text itself (music21 keeps only the title and
composer, as its own metadata).

WHAT COUNTS. The fields of the FILE HEADER (everything before the first
`X:` line, which applies to every tune in the file) and of the TUNE
HEADER (from `X:` through the first `K:`, which ends it). A field present
in the tune header replaces the file header's; otherwise the file
header's is used. Field values are cleaned the way the ABC standard
says: `+:` continuation lines are joined onto the field they continue, a
trailing `% comment` is dropped, `&amp;`-style entities and the
backslash accent escapes (\\'e, \\`a, \\^o, \\"u, \\~n, \\cC, \\vS, \\ss,
\\AE, \\uXXXX, ...) are turned into the characters they stand for.

MAPPING TO THE DICT
  T   first title -> work_title; second -> subtitle; any further T
      lines -> miscellaneous['T (additional)']
  X   reference number -> movement_number (the tune's number within its
      collection)
  C   composers (one per line)          S   source (first; extras in
                                            miscellaneous['S (additional)'])
  Z   transcriber -> encoders (type 'transcriber')
  B / D / F / G   book / discography / file URL / group -> relations
  N, H, r   notes, history, remarks -> comments (H prefixed "History: ")
  I:abc-copyright -> rights;  I:abc-creator -> software;
  %abc-2.1 (first line) and I:abc-version / abc-charset -> miscellaneous
  W   unaligned words after the tune (read from the tune body)
      -> miscellaneous['W']
  O, A, R, P, Q   origin, area, rhythm, parts, tempo -> miscellaneous
  comments   `%` comment lines in the file header and tune header
             (`%%` directives and the `%abc-x.y` identifier line excluded)
Not read: M, L, K, V, U, m, s and the aligned lyrics `w:` (the notes and
lyrics are handled elsewhere: see abc_lyrics.py). ABC defines no date
field, so date_composed / date_arranged / date_engraved stay empty.
"""

import html
import re
import unicodedata

from core.score_metadata import new_metadata

_FIELD_RE = re.compile(r'^([A-Za-z+]):[ \t]?(.*)$')
_COMMENT_VALUE_RE = re.compile(r'(?<!\\)%.*$')

_COMBINING = {'`': '\u0300', "'": '\u0301', '^': '\u0302', '~': '\u0303',
              '"': '\u0308', 'c': '\u0327', 'v': '\u030c', 'u': '\u0306',
              '=': '\u0304', '.': '\u0307'}
_LIGATURES = {'ss': '\u00df', 'AE': '\u00c6', 'ae': '\u00e6', 'OE': '\u0152',
              'oe': '\u0153', 'AA': '\u00c5', 'aa': '\u00e5', 'O': '\u00d8',
              'o': '\u00f8', 'DH': '\u00d0', 'dh': '\u00f0', 'TH': '\u00de',
              'th': '\u00fe'}
_ESCAPE_RE = re.compile(
    r"\\(?:u([0-9A-Fa-f]{4})|U([0-9A-Fa-f]{8})"
    r"|(ss|AE|ae|OE|oe|AA|aa|DH|dh|TH|th)"
    r"|([`'^~\"cvu=.])([A-Za-z])|([Oo]))")


def decode_text(value: str) -> str:
    """ABC text escapes and HTML entities -> plain Unicode."""
    value = html.unescape(value)

    def repl(m):
        if m.group(1):
            return chr(int(m.group(1), 16))
        if m.group(2):
            return chr(int(m.group(2), 16))
        if m.group(3):
            return _LIGATURES[m.group(3)]
        if m.group(4):
            return unicodedata.normalize('NFC', m.group(5) + _COMBINING[m.group(4)])
        return _LIGATURES[m.group(6)]
    return unicodedata.normalize('NFC', _ESCAPE_RE.sub(repl, value))


def _clean(value: str) -> str:
    return decode_text(_COMMENT_VALUE_RE.sub('', value)).strip()


def _read_block(lines):
    """({field: [values]}, [comments], version) for a run of header lines."""
    fields, comments, version = {}, [], None
    last_key = None
    for raw in lines:
        line = raw.rstrip('\r\n')
        stripped = line.strip()
        if stripped.startswith('%%'):
            last_key = None
            continue
        m_ver = re.match(r'^%abc-(\S+)', stripped)
        if m_ver:
            version = m_ver.group(1)
            continue
        if stripped.startswith('%'):
            c = decode_text(stripped.lstrip('%').strip())
            if c:
                comments.append(c)
            continue
        m = _FIELD_RE.match(line)
        if not m:
            continue
        key, value = m.group(1), m.group(2)
        if key == '+':
            if last_key and fields.get(last_key):
                fields[last_key][-1] = (fields[last_key][-1] + ' ' + _clean(value)).strip()
            continue
        last_key = key
        fields.setdefault(key, []).append(_clean(value))
    return fields, comments, version


def _split_header(text: str):
    """(file-header lines, tune-header lines, body lines) of one tune's text."""
    lines = text.splitlines()
    x_index = next((i for i, l in enumerate(lines) if l.startswith('X:')), None)
    if x_index is None:
        x_index, file_lines = 0, []
    else:
        file_lines = lines[:x_index]
    tune_lines, body_start = [], len(lines)
    for i, l in enumerate(lines[x_index:], start=x_index):
        tune_lines.append(l)
        if l.startswith('K:'):
            body_start = i + 1
            break
    return file_lines, tune_lines, lines[body_start:]


def extract_metadata(text: str, path=None) -> dict:
    md = new_metadata('abc', path)
    file_lines, tune_lines, body_lines = _split_header(text)
    f_fields, f_comments, f_version = _read_block(file_lines)
    t_fields, t_comments, t_version = _read_block(tune_lines)
    # `W:` (unaligned words) is written AFTER the music, in the body
    body_words = _read_block(body_lines)[0].get('W')
    if body_words:
        t_fields.setdefault('W', []).extend(body_words)

    def get(key):
        return [v for v in (t_fields.get(key) or f_fields.get(key) or []) if v]

    titles = get('T')
    if titles:
        md['work_title'] = titles[0]
    if len(titles) > 1:
        md['subtitle'] = titles[1]
    if len(titles) > 2:
        md['miscellaneous']['T (additional)'] = ' | '.join(titles[2:])

    x = get('X')
    md['movement_number'] = x[0] if x else None
    md['composers'] = get('C')

    sources = get('S')
    if sources:
        md['source'] = sources[0]
    if len(sources) > 1:
        md['miscellaneous']['S (additional)'] = ' | '.join(sources[1:])

    for name in get('Z'):
        md['encoders'].append({'type': 'transcriber', 'name': name})
    for key, rtype in (('B', 'book'), ('D', 'discography'), ('F', 'file'), ('G', 'group')):
        for value in get(key):
            md['relations'].append({'type': rtype, 'text': value})

    for value in get('N') + get('r'):
        md['comments'].append(value)
    for value in get('H'):
        md['comments'].append(f'History: {value}')

    for instr in get('I'):
        name, _, rest = instr.partition(' ')
        rest = rest.strip()
        if name == 'abc-copyright' and rest:
            md['rights'].append({'type': None, 'text': rest})
        elif name == 'abc-creator' and rest:
            md['software'].append(rest)
        elif name in ('abc-version', 'abc-charset') and rest:
            md['miscellaneous'][name] = rest

    for key in ('O', 'A', 'R', 'P', 'Q'):
        values = get(key)
        if values:
            md['miscellaneous'][key] = ' | '.join(values)
    words = get('W')
    if words:
        md['miscellaneous']['W'] = '\n'.join(words)
    version = t_version or f_version
    if version:
        md['miscellaneous'].setdefault('abc-version', version)

    for c in f_comments + t_comments:
        if c not in md['comments']:
            md['comments'].append(c)
    return md
