"""
importers/midi_importer.py

MIDI -> music21.stream.Score, via MuseScore rather than music21's own
MIDI reader.

WHY NOT MUSIC21'S OWN MIDI IMPORT
------------------------------------
music21 can read MIDI directly (music21.midi.translate), but it has no
real quantization or voice-separation heuristics of its own -- for
anything that wasn't already mechanically quantized (i.e. any actual
human performance), it tends to produce badly over-fragmented,
unreadable notation. MuseScore's importer does this well: real
quantization and voice-separation, the same as when you open a MIDI
file in the MuseScore GUI. Rather than duplicate that (a large,
separate undertaking -- quantization/voice-separation is a research
problem in its own right), this shells out to a real MuseScore install
to do the MIDI->notation work, producing an intermediate MusicXML
file, and then hands that straight to importers.musicxml_importer --
which already gives us the same import_score() contract as every
other format, and correctly gets us there without a second importer's
worth of logic.

(We also checked whether LilyPond's own bundled `midi2ly` would be a
simpler, single-toolchain alternative: LilyPond's own documentation is
explicit that `midi2ly` is not recommended for human-performed MIDI, on
exactly the same quantization grounds -- so it wouldn't do better than
music21's own reader here, and MuseScore remains the better choice.)

MuseScore CLI details verified directly against a real MuseScore 3
install before writing this: `mscore -o out.musicxml in.mid` on this
platform; the QT_QPA_PLATFORM=offscreen environment variable is only
needed for a headless (no display) machine like a CI/server box, but
setting it unconditionally is harmless on a normal desktop too, so
this always sets it rather than trying to detect whether a display is
present.
"""

import os
import subprocess
import tempfile
from pathlib import Path

# Tried in this order when `mscore_bin` isn't given explicitly --
# MuseScore's own executable name varies by version/platform/install
# method (a plain package manager install of MuseScore 3 on Linux is
# typically "mscore3", but "mscore" and "musescore3" both show up too,
# and MuseScore 4 renamed its own binary again). Pass mscore_bin
# explicitly (e.g. a full path on Windows, where it's not normally on
# PATH at all) rather than relying on this list when it doesn't find
# your install.
_CANDIDATE_BINARIES = ['mscore3', 'mscore', 'musescore3', 'MuseScore3', 'mscore4', 'musescore4']


def _find_musescore_binary():
    import shutil
    for name in _CANDIDATE_BINARIES:
        found = shutil.which(name)
        if found:
            return found
    return None


def _run_musescore(input_path: Path, musescore_bin: str, output_path: Path):
    env = dict(os.environ)
    env.setdefault('QT_QPA_PLATFORM', 'offscreen')
    result = subprocess.run(
        [musescore_bin, '-o', str(output_path), str(input_path)],
        capture_output=True, text=True, env=env,
    )
    if result.returncode != 0 or not output_path.exists():
        raise RuntimeError(
            f"MuseScore ({musescore_bin}) failed to convert {input_path} to MusicXML "
            f"(exit {result.returncode}):\n{result.stderr or result.stdout}"
        )


def import_score(input_path, musescore_bin: str = None, **options):
    """Parse a MIDI file into a music21 Score by shelling out to
    MuseScore for the actual MIDI->notation work (see module
    docstring), then importing the MusicXML MuseScore produces the
    same way any other MusicXML file is imported.

    `musescore_bin`: path to the MuseScore executable, if it's not one
    of the common names already on PATH (see _CANDIDATE_BINARIES) --
    e.g. on Windows, a full path like
    "C:\\Program Files\\MuseScore 3\\bin\\MuseScore3.exe".
    """
    from . import musicxml_importer

    input_path = Path(input_path)
    if not input_path.exists():
        raise FileNotFoundError(f"Input not found: {input_path}")

    resolved_bin = musescore_bin or _find_musescore_binary()
    if resolved_bin is None:
        raise RuntimeError(
            "Could not find a MuseScore executable on PATH (tried: "
            f"{', '.join(_CANDIDATE_BINARIES)}). Pass musescore_bin= "
            "explicitly with the full path to your MuseScore install."
        )

    with tempfile.TemporaryDirectory(prefix='midi_import_') as tmp:
        intermediate_path = Path(tmp) / (input_path.stem + '.musicxml')
        _run_musescore(input_path, resolved_bin, intermediate_path)
        # Read the intermediate file's content now, inside the
        # TemporaryDirectory's own lifetime -- musicxml_importer.
        # import_score() only needs the path, but the directory (and
        # the file in it) must still exist when it runs.
        return musicxml_importer.import_score(intermediate_path)
