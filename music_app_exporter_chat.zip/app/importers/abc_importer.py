"""
importers/abc_importer.py

ABC notation -> music21.stream.Score. Like musicxml_importer.py, there
is no project-specific parsing logic here for the common case:
music21's own ABC support (music21.abcFormat) is solid and well-
exercised -- its own bundled corpus ships 1,100+ real .abc files that
parse cleanly.

ONE THING THIS MODULE DOES HANDLE: a single .abc file very commonly
bundles MANY tunes (each with its own "X:" tune-number header) --
confirmed against a real bundled corpus file, which turned out to hold
200 separate tunes. music21's own parser reflects that faithfully: it
returns a Score directly only for a single-tune file, and an Opus (a
container of many Scores, one per tune) for a multi-tune one. Since
this pipeline's import_score() contract is "return ONE Score", a
multi-tune file's FIRST tune is returned, and an
ABCMultipleTunesWarning names how many others were in the file --
matching the same "keep the first, warn about the rest" precedent
already used for multiple `\\score` blocks in a single LilyPond file
(see importers/lilypond_importer.py) -- rather than silently picking
one tune out of many with no indication anything else was there.

A SECOND THING THIS MODULE WORKS AROUND: ABC's "inline field" syntax --
e.g. `[V:2]`, `[K:D]`, `[M:3/4]`, `[L:1/8]` -- lets a tune body change
voice/key/meter/etc. mid-line without starting a new text line (this is
standard ABC, not a rare extension; see the abc standard v2.1's
sections on voices and on the tune body). Confirmed directly in
music21's own source (music21/abcFormat/__init__.py's tokenize(), the
`if c == '[':` branch): its tokenizer does not recognize this syntax at
all -- ANY bracketed content encountered in the tune body is
unconditionally treated as the start of a chord, with no check for the
single-letter-plus-colon pattern that unambiguously marks a field
rather than a chord (a real chord's bracket contents are pitches --
letters A-G, accidentals, octave marks -- which never include a colon).
So a bare voice/key/meter switch like `[V:1]` crashes when music21
tries to give it a note duration, with an unhelpful "no active default
note length" error that has nothing to do with note lengths at all.
_split_inline_fields() rewrites each inline field onto its own line
(which music21's tokenizer parses correctly, the same way it already
handles header-area field lines) before handing the text to music21,
leaving genuine chords -- no colon after the opening letter -- alone.
"""

import re
from pathlib import Path

from music21 import clef as m21clef


# A single letter immediately followed by ':' inside brackets is
# unambiguous: no valid ABC chord (a bracketed run of pitches) can
# start that way, since chord contents are pitch letters (A-G),
# accidentals, octave marks, and duration digits -- never a colon.
_INLINE_FIELD_RE = re.compile(r'\[([A-Za-z]):([^\]]*)\]')


class ABCMetadataWarning(UserWarning):
    """A tune's header fields couldn't be read; the notes still import,
    with an empty metadata dict."""


class ABCMultipleTunesWarning(UserWarning):
    """Raised when an ABC file holds more than one tune (each with its
    own "X:" header); only the first is imported."""


def _split_inline_fields(text: str) -> str:
    """See the module docstring's second paragraph. Moves each inline
    field (`[V:1]`, `[K:D]`, `[M:3/4]`, etc.) found anywhere in the
    text onto its own line, exactly as if the encoder had written it
    that way to begin with -- a form music21's tokenizer already
    parses correctly."""
    return _INLINE_FIELD_RE.sub(lambda m: f'\n{m.group(1)}:{m.group(2)}\n', text)


_VOICE_FIELD_RE = re.compile(r'(?m)^V:(\S+)([^\r\n]*)$')


def _normalize_voice_references(text: str) -> str:
    """A fourth thing this module works around: ABC lets a tune declare
    each voice's attributes (name/clef/etc.) ONCE, then switch back to
    it later with a bare `V:n` reference carrying no attributes -- this
    is standard practice, and exactly what a bracketed inline voice
    switch like `[V:1]` normally is (see _split_inline_fields, whose
    output is exactly such a bare reference). Confirmed directly,
    reproduced with a minimal hand-built file with no bracket syntax
    involved at all: music21 does NOT recognize a later bare `V:n` as
    the same voice already declared -- it starts an entirely new,
    duplicate Part for it instead, so an SATB-style tune written with
    one full declaration per voice up front and bare references
    per-line ends up as twice as many Parts as voices, half of them
    empty and half misattributed. Confirmed as a real workaround
    (reproduced on the same minimal file): repeating the FULL
    declaration at every reference, rather than a bare id, makes
    music21 correctly treat every mention as the same voice. This
    finds each voice's fullest declaration and substitutes it in for
    every later bare reference to that same voice id, so the encoder
    doesn't have to repeat it by hand.

    On its own this ISN'T enough, though (see
    _remove_redundant_voice_declarations immediately below) -- it's the
    first of two steps this gap needs."""
    declarations = {}

    def record_and_normalize(m):
        voice_id, rest = m.group(1), m.group(2)
        if rest.strip():
            if voice_id not in declarations or len(rest) > len(declarations[voice_id]):
                declarations[voice_id] = rest
            return m.group(0)
        if voice_id in declarations:
            return f'V:{voice_id}{declarations[voice_id]}'
        return m.group(0)

    return _VOICE_FIELD_RE.sub(record_and_normalize, text)


def _remove_redundant_voice_declarations(text: str) -> str:
    """The second of the two steps _normalize_voice_references' own
    docstring refers to. A tune commonly lists every voice up front (a
    run of consecutive `V:n` lines, one per voice, before any music) as
    well as declaring each one again right where its own music starts
    -- both are completely standard. Confirmed directly (reproduced
    with a minimal hand-built file, no connection to any bracket
    syntax or the earlier normalization step): music21 starts a new,
    disconnected Part for every mention of `V:n` found anywhere in the
    tune, full stop -- so a voice mentioned in both places still ends
    up duplicated even once _normalize_voice_references has given both
    mentions identical, full attributes. This removes any `V:n` line
    that is immediately followed (skipping over blank lines and `%`
    comments) by ANOTHER `V:n` line rather than by actual music -- i.e.
    a pure listing entry that contributes nothing once
    _normalize_voice_references has already propagated its attributes
    forward to the real, music-bearing declaration for that voice.
    A voice legitimately revisited mid-tune for a later section is
    NOT affected: each of ITS mentions is followed by real music, not
    by another `V:n` line, so none of them match this pattern."""
    lines = text.split('\n')
    is_voice_line = [bool(_VOICE_FIELD_RE.match(line)) for line in lines]
    is_skippable = [not line.strip() or line.strip().startswith('%') for line in lines]

    keep = [True] * len(lines)
    for i, line in enumerate(lines):
        if not is_voice_line[i]:
            continue
        j = i + 1
        while j < len(lines) and is_skippable[j]:
            j += 1
        if j < len(lines) and is_voice_line[j]:
            keep[i] = False

    return '\n'.join(line for line, k in zip(lines, keep) if k)


def _ensure_default_note_length(text: str) -> str:
    """A third thing this module works around: if a tune supplies
    neither L: (default note length) nor M: (meter) anywhere, the ABC
    standard (v2.1) specifies an explicit fallback of 1/8. Confirmed in
    music21's own source (music21/abcFormat/__init__.py's
    tokenProcess()): it derives a default note length from M: only
    when L: is absent, but has no fallback at all for a tune that gives
    neither -- so the very first note crashes with an unhelpful "no
    active default note length" error that has nothing to do with the
    real cause. This fills in that one specific gap using the
    standard's own stated default, rather than leaving a spec-legal (if
    unusual -- most real-world ABC supplies L: and/or M: explicitly)
    file unparseable. Only acts when BOTH are missing; when M: alone is
    present, music21's own meter-based fallback already handles it
    correctly and is left alone."""
    has_l = re.search(r'(?m)^L:', text) is not None
    has_m = re.search(r'(?m)^M:', text) is not None
    if has_l or has_m:
        return text
    # The K: (key) field is always the LAST header field in the ABC
    # standard, so inserting right after the first one found is
    # guaranteed to land in the header rather than mid-tune.
    return re.sub(r'(?m)^(K:[^\r\n]*)', r'\1\nL:1/8', text, count=1)


# --- Clef support ---------------------------------------------------
#
# ABC 2.1's own Clefs section names exactly five core clef names --
# treble, alto, tenor, bass, perc (plus the pseudo-clef 'none') -- each
# optionally followed by a staff-line number (defaults: treble 2, alto
# 3, tenor 4, bass 4) and/or a +8/-8 octave suffix. The remaining
# common C-clef positions (soprano, mezzo-soprano) and the F-baritone
# clef are reached via those same core names with an explicit line
# number (alto1, alto2, bass3) -- confirmed against the standard's own
# published equivalence table (alto1=soprano, alto2=mezzosoprano,
# alto4=tenor, bass3=baritone) -- and several real ABC tools (abc2midi,
# yaps, abcm2ps) additionally accept the named aliases 'soprano',
# 'mezzo'/'mezzosoprano', and 'baritone' directly, which are supported
# here too since they're in genuine common use, not a rare extension.
#
# Confirmed directly against music21's own source (music21/abcFormat/
# __init__.py's ABCMetadata.getClefObject()) that none of this is
# read by music21's ABC importer at all: that method only ever runs
# against a K: (key) field's text, is never consulted for the
# standard, far more common V: (voice) field `clef=` attribute at
# all, and even then recognizes only the two substrings 'bass' and
# '-8va' -- missing treble, every C-clef, and the ABC-standard +8/-8
# suffix syntax entirely. _parse_abc_clef()/_apply_voice_clefs() below
# are this pipeline's own replacement for that gap.

_CLEF_CLASS_BY_SIGN_LINE = {
    ('G', 1): m21clef.FrenchViolinClef,
    ('G', 2): m21clef.TrebleClef,
    ('C', 1): m21clef.SopranoClef,
    ('C', 2): m21clef.MezzoSopranoClef,
    ('C', 3): m21clef.AltoClef,
    ('C', 4): m21clef.TenorClef,
    ('C', 5): m21clef.CBaritoneClef,
    ('F', 3): m21clef.FBaritoneClef,
    ('F', 4): m21clef.BassClef,
    ('F', 5): m21clef.SubBassClef,
}

_CLEF_BASE_SIGN_AND_DEFAULT_LINE = {
    'treble': ('G', 2),
    'alto': ('C', 3),
    'tenor': ('C', 4),
    'bass': ('F', 4),
}

_CLEF_ALIAS_SIGN_AND_LINE = {
    'soprano': ('C', 1),
    'mezzosoprano': ('C', 2),
    'mezzo-soprano': ('C', 2),
    'mezzo': ('C', 2),
    'baritone': ('F', 3),
}

_CLEF_SPEC_RE = re.compile(r'^([a-z-]+?)(\d)?([+-]8)?$')


def _parse_abc_clef(spec: str):
    """A music21 Clef object for an ABC clef specifier -- e.g.
    'treble', 'alto', 'tenor', 'bass', 'perc', 'none', 'alto1'
    (soprano), 'alto2' (mezzosoprano), 'alto4' (tenor -- an
    equivalent spelling, not a distinct clef), 'bass3' (baritone),
    'treble-8', 'bass+8' -- or None if `spec` isn't recognized as a
    clef name at all (see the section comment above for what's
    covered and why)."""
    spec = spec.strip().lower()
    if spec in ('perc', 'percussion'):
        return m21clef.PercussionClef()
    if spec == 'none':
        return m21clef.NoClef()
    if spec == 'tab':
        return m21clef.TabClef()

    m = _CLEF_SPEC_RE.match(spec)
    if not m:
        return None
    base_name, line_digit, octave_suffix = m.groups()

    if base_name in _CLEF_ALIAS_SIGN_AND_LINE:
        sign, default_line = _CLEF_ALIAS_SIGN_AND_LINE[base_name]
    elif base_name in _CLEF_BASE_SIGN_AND_DEFAULT_LINE:
        sign, default_line = _CLEF_BASE_SIGN_AND_DEFAULT_LINE[base_name]
    else:
        return None

    line = int(line_digit) if line_digit else default_line

    clef_class = _CLEF_CLASS_BY_SIGN_LINE.get((sign, line))
    if clef_class is not None:
        clef_obj = clef_class()
    else:
        # An uncommon sign/line combination the standard technically
        # permits (any line number is legal) but music21 has no
        # dedicated class for -- the generic sign-only clef class with
        # its line set directly covers it.
        generic_class = {'G': m21clef.GClef, 'C': m21clef.CClef, 'F': m21clef.FClef}[sign]
        clef_obj = generic_class()
        clef_obj.line = line

    if octave_suffix:
        clef_obj.octaveChange = 1 if octave_suffix == '+8' else -1

    return clef_obj


_VOICE_CLEF_ATTR_RE = re.compile(r'(?i)\bclef=(\S+)')
_KEY_FIELD_RE = re.compile(r'(?m)^K:([^\r\n]*)')


def _extract_voice_clefs(text: str) -> dict:
    """{voice_id: Clef} for every voice whose (already-normalized, one-
    declaration-per-voice -- see _normalize_voice_references and
    _remove_redundant_voice_declarations, which must run before this)
    `V:` line carries a `clef=` attribute music21 itself won't apply
    (see the section comment above _parse_abc_clef). A voice with no
    explicit clef is left out here entirely -- it keeps whatever
    music21 assigns on its own (ordinarily treble, ABC's own default)."""
    result = {}
    for m in _VOICE_FIELD_RE.finditer(text):
        voice_id, rest = m.group(1), m.group(2)
        clef_match = _VOICE_CLEF_ATTR_RE.search(rest)
        if not clef_match:
            continue
        clef_obj = _parse_abc_clef(clef_match.group(1))
        if clef_obj is not None:
            result[voice_id] = clef_obj
    return result


def _extract_key_field_clef(text: str):
    """A Clef from a `K:` (key) field's own optional `clef=` parameter
    (or a bare clef name following the key, e.g. 'K:Cm bass3') --
    ABC's other place a clef can be specified, used as a tune-wide
    fallback when a voice has none of its own. Returns the first one
    found, or None."""
    m = _KEY_FIELD_RE.search(text)
    if not m:
        return None
    clef_match = _VOICE_CLEF_ATTR_RE.search(m.group(1))
    if clef_match:
        return _parse_abc_clef(clef_match.group(1))
    # A bare clef name can also follow the key directly with no
    # 'clef=' keyword at all (e.g. 'K:Cm bass3') -- try each
    # whitespace-separated word in turn.
    for word in m.group(1).split():
        clef_obj = _parse_abc_clef(word)
        if clef_obj is not None:
            return clef_obj
    return None


def _apply_voice_clefs(score, voice_clefs: dict, fallback_clef, order: list) -> None:
    """Replaces whatever clef music21 assigned to each Part with the
    correct one extracted from the source text (see the section
    comment above _parse_abc_clef for why music21's own clef is not
    trustworthy here). `order` is the voice ids in the order they were
    first declared, which -- confirmed against a real multi-voice file
    -- matches the order music21 assembles its Parts in; matched by
    position rather than by name, since a Part built by music21's ABC
    importer does not otherwise carry its originating voice id.
    A part whose voice has no explicit clef falls back to
    `fallback_clef` (the tune's own K: field clef, if any) and is left
    alone entirely if there's no fallback either."""
    from music21 import stream as m21stream

    parts = list(score.parts) if hasattr(score, 'parts') else []
    if len(parts) != len(order):
        return  # mismatched count -- safer to leave music21's own clefs than guess wrong
    for part, voice_id in zip(parts, order):
        new_clef = voice_clefs.get(voice_id, fallback_clef)
        if new_clef is None:
            continue
        for old_clef in list(part.recurse().getElementsByClass(m21clef.Clef)):
            old_clef.activeSite.remove(old_clef)
        first_measure = part.recurse().getElementsByClass(m21stream.Measure).first()
        target = first_measure if first_measure is not None else part
        target.insert(0, new_clef)


def _voice_order(text: str) -> list:
    """Distinct voice ids in first-appearance order -- see
    _apply_voice_clefs, which matches this against score.parts by
    position."""
    seen = []
    for m in _VOICE_FIELD_RE.finditer(text):
        voice_id = m.group(1)
        if voice_id not in seen:
            seen.append(voice_id)
    return seen


# Beams on this importer's Score, if any, were generated by music21 (its
# ABC parser meter-beams barred input itself; the LilyPond importer sets
# none) -- NOT authored in the source. run_job() therefore lets
# importers/notation_repair.py repair tuplet beaming here even when
# beams are present. See that module's docstring, rule 1.
BEAMS_FROM_SOURCE = False


_CONTINUATION_RE = re.compile(r'^\+:[ \t]?(.*)$')


def _join_field_continuations(text: str) -> str:
    """Join each `+:` line onto the information field it continues (the
    ABC standard's way of splitting a long H:, N:, w:, ... field over
    several lines). music21 has no notion of `+:` and parses the
    continuation's TEXT AS MUSIC -- confirmed: "+: extra" produced two
    phantom notes in the score -- so this must happen before anything
    else sees the text. Comment lines between a field and its
    continuation are allowed and left in place."""
    out, last_field = [], None
    for line in text.split('\n'):
        m = _CONTINUATION_RE.match(line.rstrip('\r'))
        if m and last_field is not None:
            out[last_field] = out[last_field].rstrip('\r') + ' ' + m.group(1).strip()
            continue
        out.append(line)
        stripped = line.strip()
        if re.match(r'^[A-Za-z]:', stripped):
            last_field = len(out) - 1
        elif stripped and not stripped.startswith('%'):
            last_field = None
    return '\n'.join(out)


_TUNE_START_RE = re.compile(r'(?m)^(?=X:)')


def _split_tunes(text: str) -> list:
    """The file's tunes as separate ABC texts. Anything before the first
    `X:` line is a file header that applies to every tune, so it is
    prepended to each. A file with no `X:` line comes back whole."""
    pieces = _TUNE_START_RE.split(text)
    if len(pieces) <= 1:
        return [text]
    header = pieces[0] if pieces[0].strip() else ''
    return [header + p for p in pieces[1:] if p.strip()]


def _score_from_text(text: str, label, path=None) -> 'Score':
    """The full per-tune pipeline: this module's ABC workarounds, then
    music21's parser, then the voice-clef fix. `text` holds ONE tune
    (or a file music21 reads as one)."""
    import warnings
    from music21 import converter, stream
    from core.score_metadata import attach_metadata, new_metadata
    from .abc_lyrics import attach_lyrics
    from .abc_metadata import extract_metadata

    text = _join_field_continuations(text)
    tune_as_written = text          # metadata and lyrics read the tune as written
    text = _split_inline_fields(text)
    text = _normalize_voice_references(text)
    text = _remove_redundant_voice_declarations(text)
    voice_clefs = _extract_voice_clefs(text)
    fallback_clef = _extract_key_field_clef(text)
    order = _voice_order(text)
    text = _ensure_default_note_length(text)
    result = converter.parse(text, format='abc', forceSource=True)

    if isinstance(result, stream.Opus):
        tunes = list(result.scores)
        if not tunes:
            raise RuntimeError(f"{label} parsed as an empty ABC collection (no tunes found).")
        if len(tunes) > 1:
            warnings.warn(
                f"{label} contains {len(tunes)} tunes; only the first was imported.",
                ABCMultipleTunesWarning,
            )
        result = tunes[0]

    if voice_clefs or fallback_clef is not None:
        _apply_voice_clefs(result, voice_clefs, fallback_clef, order)

    # Work-level metadata (title, composer, source, notes, ...) from the
    # tune's own header fields -- see importers/abc_metadata.py. It must
    # never block the notes.
    try:
        attach_metadata(result, extract_metadata(tune_as_written, path or label))
    except Exception as e:
        warnings.warn(f"{label}: could not read metadata ({e}); continuing with none.",
                      ABCMetadataWarning)
        attach_metadata(result, new_metadata('abc', path or label))

    # Aligned lyrics (`w:` lines), which music21 recognises but discards
    # -- see importers/abc_lyrics.py.
    attach_lyrics(tune_as_written, result, order, prepare=_ensure_default_note_length)

    # (Tuplet beaming is repaired centrally in core.import_pipeline.run_job();
    # see importers/notation_repair.py.)
    return result


def import_scores(input_path, **options):
    """EVERY tune in an ABC file as its own Score, in file order. Each
    tune goes through the whole per-tune pipeline on its own, so one
    tune's voices, clefs and default note length can't leak into another.
    A single-tune file returns a one-element list."""
    text = Path(input_path).read_text(encoding='utf-8', errors='ignore')
    return [_score_from_text(t, f"{input_path} (tune {i})", input_path)
            for i, t in enumerate(_split_tunes(text), start=1)]


def import_score(input_path, **options):
    """Parse an ABC file into a music21 Score. `options` is accepted
    for interface consistency with the other importers but ABC
    currently takes none. A multi-tune file returns only its first tune,
    with a warning; import_scores() returns them all."""
    import warnings

    text = Path(input_path).read_text(encoding='utf-8', errors='ignore')
    tunes = _split_tunes(text)
    if len(tunes) > 1:
        warnings.warn(
            f"{input_path} contains {len(tunes)} tunes; only the first was imported.",
            ABCMultipleTunesWarning,
        )
    return _score_from_text(tunes[0], str(input_path), input_path)
