"""
importers/abc_lyrics.py

ABC aligned lyrics (`w:` lines) -> music21 note lyrics. music21's own ABC
reader recognises `w:` lines but never attaches them to notes, so this
module does it, following the ABC standard's alignment rules:

  - A `w:` line supplies syllables for the notes of the music line
    IMMEDIATELY BEFORE it; `+:` continuation lines belong to the same
    `w:` line. Several `w:` lines under one music line are several
    VERSES (numbered 1, 2, ... in order, per music line).
  - Syllables go on NOTES and CHORDS -- not rests, spacers or grace
    notes. A tied note counts as a separate note (unlike LilyPond).
  - Within a `w:` line: whitespace separates syllables; `-` ends a
    syllable and continues the word ("Twin-kle", or "syl- la- ble"); a
    LONE `-` ("gra- - - tum") carries the word over one more note;
    `_` holds the current syllable over one more note (no new text);
    `*` skips one note; `|` skips to the next bar line (a no-op if the
    syllables already ended exactly at one); `~` joins words into ONE
    syllable ("of~the~day" -> "of the day"); `\\-` is a literal hyphen.
  - A `W:` line is unaligned words after the tune: not lyrics here (it
    goes to metadata).

HOW NOTES ARE MATCHED. The whole tune is run through music21's own ABC
tokenizer ONCE, with an invisible `N:` (notes) field written before and after
every music line so each line's notes, bar lines and voice can be told
apart (and an inline `[V:2]` mid-line detected). Each note or chord token
is a "slot"; slots are matched to the voice's Part by WRITTEN DURATION
(tuplet ratios applied): a slot claims consecutive notes of the Part until
their durations add up to its own. That matters because music21 splits
any note that crosses a measure boundary into tied pieces -- notably in
tunes written without bar lines -- and only the first piece may carry the
syllable. The tune's voices map to parts in first-appearance order, as
elsewhere in the ABC importer. If a voice's slots can't be matched
exactly the lyrics for that voice are SKIPPED with a warning, rather than
risk laying them on the wrong notes. Lines with an inline voice change
are not supported and are skipped the same way. The resulting Lyric
objects (number = verse, syllabic = single/begin/middle/end) live on the
notes like every other format's.
"""

import re
import warnings

from music21 import abcFormat, chord, note

_FIELD_RE = re.compile(r'^([A-Za-z+]):')
_VOICE_LINE_RE = re.compile(r'^V:\s*(\S+)')
_INLINE_VOICE_RE = re.compile(r'\[V:')


class ABCLyricsWarning(UserWarning):
    """Aligned lyrics (`w:`) that couldn't be placed exactly as written:
    a voice whose note count doesn't match, more syllables than notes in
    a line, or an unsupported construct. Whatever could be placed safely
    still was."""


# ---------------------------------------------------------------------------
# parsing one w: line
# ---------------------------------------------------------------------------

def parse_lyric_line(raw: str) -> list:
    """Items in order: ('syl', text, hyphen_after), ('hold',), ('skip',),
    ('bar',)."""
    items, buf = [], []

    def flush(hyphen=False):
        if buf:
            items.append(['syl', ''.join(buf), hyphen])
            buf.clear()
        elif hyphen:
            # A LONE '-' (nothing before it since the last space or hyphen):
            # the word carries on over one more note, like `_` but drawn as
            # a hyphen -- "gra- - - - tum" spreads "gra" over four notes.
            # Confirmed on the bundled Josquin tune, whose first line has
            # exactly 23 notes: counting each lone hyphen as a note fits its
            # 23 syllable slots exactly; ignoring them leaves 20 and shifts
            # every later word onto the wrong note.
            if items and items[-1][0] == 'syl':
                items[-1][2] = True
            items.append(['hold'])

    i, n = 0, len(raw)
    while i < n:
        c = raw[i]
        if c == '\\' and i + 1 < n:
            buf.append(raw[i + 1])     # `\-` and any other escape: literal
            i += 2
            continue
        if c.isspace():
            flush()
        elif c == '-':
            flush(hyphen=True)
        elif c == '_':
            flush()
            items.append(['hold'])
        elif c == '*':
            flush()
            items.append(['skip'])
        elif c == '|':
            flush()
            items.append(['bar'])
        elif c == '~':
            buf.append(' ')
        else:
            buf.append(c)
        i += 1
    flush()
    return [tuple(it) for it in items]


def align_line(items, n_slots: int, bars: set):
    """({slot: (text, syllabic)}, overflow) for one verse of one music
    line with `n_slots` note slots; `bars` holds the slot indices at
    which a bar line falls."""
    pos, placed, overflow, continuing = 0, {}, 0, False
    for item in items:
        kind = item[0]
        if kind == 'bar':
            if pos not in bars:
                later = [b for b in bars if b > pos]
                pos = min(later) if later else n_slots
        elif kind in ('hold', 'skip'):
            pos += 1
        else:
            _, text, hyphen = item
            if continuing:
                syllabic = 'middle' if hyphen else 'end'
            else:
                syllabic = 'begin' if hyphen else 'single'
            if pos < n_slots:
                placed[pos] = (text, syllabic)
            else:
                overflow += 1
            pos += 1
            continuing = hyphen
    return placed, overflow


# ---------------------------------------------------------------------------
# reading a tune's music lines
# ---------------------------------------------------------------------------

_START = '@@LYRICS-LINE-START@@'
_END = '@@LYRICS-LINE-END@@'
_EPS = 1e-6


def _mark_music_lines(tune_text: str) -> str:
    """The tune's text with an invisible `r:` remark field written before
    and after every music line of the body (everything after the first
    `K:`). (`N:` because music21's tokenizer accepts it as a field; it does
    NOT recognise `r:`, and would parse an `r:` line as music.)"""
    lines = tune_text.split('\n')
    k_index = next((i for i, l in enumerate(lines) if l.startswith('K:')), None)
    if k_index is None:
        return tune_text
    out = lines[:k_index + 1]
    for raw in lines[k_index + 1:]:
        stripped = raw.strip()
        if stripped and not stripped.startswith('%') and not _FIELD_RE.match(stripped):
            out.extend([f'N:{_START}', raw.rstrip('\r'), f'N:{_END}'])
        else:
            out.append(raw)
    return '\n'.join(out)


def _slot_length(token) -> float:
    ql = float(token.quarterLength)
    tup = getattr(token, 'activeTuplet', None)
    if tup is not None:
        ql *= tup.numberNotesNormal / tup.numberNotesActual
    return ql


def _read_lines(tune_text: str, prepare=None):
    """([{'voice', 'slots': [quarterLength, ...], 'bars': {slot index},
    'verses': [raw w: text, ...]}] for every music line of the body, in
    order; unsupported lines; number of w: lines with no music line to
    attach to)."""
    marked = _mark_music_lines(tune_text)
    if marked == tune_text:
        return [], [], 0
    if prepare is not None:
        marked = prepare(marked)
    handler = abcFormat.ABCHandler()
    handler.process(marked)

    entries, problems, orphans = [], [], 0
    voice, cur, last, last_line_text = None, None, None, ''
    for t in handler.tokens:
        if isinstance(t, abcFormat.ABCMetadata):
            data = (t.data or '').strip()
            if t.tag == 'N' and data == _START:
                cur = {'voice': voice, 'slots': [], 'bars': set(), 'verses': []}
                entries.append(cur)
                last = None
            elif t.tag == 'N' and data == _END:
                last, cur = cur, None
            elif t.tag == 'V':
                new_voice = data.split()[0] if data else voice
                if cur is not None and new_voice != voice:
                    problems.append(f'V:{new_voice}')
                voice = new_voice
            elif t.tag == 'w':
                if last is None:
                    orphans += 1
                else:
                    last['verses'].append(data)
            continue
        if cur is None:
            continue
        if isinstance(t, abcFormat.ABCBar):
            cur['bars'].add(len(cur['slots']))
        elif isinstance(t, abcFormat.ABCNote):
            if not t.isRest and not getattr(t, 'inGrace', False):
                cur['slots'].append(_slot_length(t))
        elif isinstance(t, abcFormat.ABCChord):
            if not getattr(t, 'inGrace', False):
                cur['slots'].append(_slot_length(t))
    return entries, problems, orphans


def _sung_notes(part):
    return [n for n in part.recurse().notes
            if isinstance(n, (note.Note, chord.Chord)) and not n.duration.isGrace]


def _match_slots(slot_lengths, notes):
    """Index into `notes` of the first note of each slot, or None if the
    slots can't be matched to the notes exactly (see module docstring)."""
    positions, idx = [], 0
    for length in slot_lengths:
        start, acc = idx, 0.0
        while idx < len(notes) and acc < length - _EPS:
            acc += float(notes[idx].quarterLength)
            idx += 1
        if abs(acc - length) > _EPS or idx == start:
            return None
        positions.append(start)
    return positions if idx == len(notes) else None


def attach_lyrics(tune_text: str, score, voice_order, prepare=None) -> int:
    """Lay the tune's `w:` lyrics onto `score`'s notes (see the module
    docstring). `tune_text` is the tune's ABC text as written; `voice_order`
    the voice ids in first-appearance order; `prepare` an optional
    function applied to the text before tokenizing (the importer passes
    the step that supplies a default note length). Returns the number of
    verse lines placed."""
    try:
        entries, problems, orphans = _read_lines(tune_text, prepare)
    except abcFormat.ABCHandlerException as e:
        warnings.warn(f"ABC lyrics skipped: the tune couldn't be tokenized ({e}).",
                      ABCLyricsWarning)
        return 0
    if problems and any(e['verses'] for e in entries):
        warnings.warn(
            f"ABC lyrics skipped: the tune has {len(problems)} music line(s) with an "
            f"inline voice change ({problems[0]}), which lyric alignment "
            f"doesn't support.", ABCLyricsWarning)
        return 0
    if not any(e['verses'] for e in entries):
        return 0

    parts = list(score.parts)
    by_voice = {}
    for e in entries:
        by_voice.setdefault(e['voice'], []).append(e)

    placed_lines = 0
    for voice_id, lines in by_voice.items():
        if not any(l['verses'] for l in lines):
            continue
        idx = voice_order.index(voice_id) if voice_id in voice_order else 0
        if idx >= len(parts):
            continue
        notes = _sung_notes(parts[idx])
        label = f"voice {voice_id}" if voice_id else "the tune"
        all_slots = [length for l in lines for length in l['slots']]
        positions = _match_slots(all_slots, notes)
        if positions is None:
            warnings.warn(
                f"ABC lyrics for {label} skipped: its {len(all_slots)} written notes "
                f"couldn't be matched exactly to the {len(notes)} notes in the score "
                f"(by duration), so they can't be placed safely.", ABCLyricsWarning)
            continue
        offset = 0
        for l in lines:
            n_slots = len(l['slots'])
            for verse_number, raw in enumerate(l['verses'], start=1):
                placed, overflow = align_line(parse_lyric_line(raw), n_slots, l['bars'])
                for slot, (text, syllabic) in placed.items():
                    notes[positions[offset + slot]].lyrics.append(
                        note.Lyric(text=text, number=verse_number,
                                   syllabic=syllabic, applyRaw=True))
                placed_lines += 1
                if overflow:
                    warnings.warn(
                        f"ABC lyrics for {label}: a w: line has {overflow} more "
                        f"syllable(s) than its music line has notes; they were dropped.",
                        ABCLyricsWarning)
            offset += n_slots
    return placed_lines
