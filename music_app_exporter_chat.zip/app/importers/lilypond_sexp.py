"""
importers/lilypond_sexp.py

A reader for the specific, fixed vocabulary of Scheme s-expressions
LilyPond's own built-in `display-scheme-music` function prints --
NOT a general-purpose Scheme reader. Confirmed against real output
from LilyPond 2.24.3 (see lilypond_importer.py's docstring for how
that output is produced) before writing this, rather than guessed:
every list is one of exactly six shapes --

    (make-music 'TypeName 'key1 val1 'key2 val2 ...)
    (ly:make-pitch OCTAVE NOTENAME [ALTERATION])
    (ly:make-duration LOG [DOTS [SCALE]])
    (ly:make-moment N [GRACE])        -- a fraction of a whole note
    (cons A B)
    (list A B C ...)

plus atoms: integers, rationals ("3/2"), decimals, `"strings"`, `#t`/
`#f`, quoted symbols (the leading `'` is dropped -- see Reader.read:
in this fixed grammar a bare identifier only ever appears in a list's
head position as one of the six operator names above, so the quoted/
unquoted distinction never needs to survive into the parsed value),
and `#<...>` -- Guile's printed form for objects that were never
meant to be read back (e.g. a compiled procedure closure shows up
this way inside a real articulation's properties). These are read
as an opaque token and discarded; we never need what's inside one.
"""

import re
from fractions import Fraction


class Symbol(str):
    """A bare Scheme identifier, e.g. Symbol('ContextSpeccedMusic').
    Subclasses str so `props.get('context-type') == 'Staff'` just works,
    while still being distinguishable from an actual MusicXML-ish string
    value if that's ever useful."""


class MusicNode:
    """One `(make-music 'TypeName ...)` form."""
    __slots__ = ('type', 'props')

    def __init__(self, type_, props):
        self.type = type_
        self.props = props

    def get(self, key, default=None):
        return self.props.get(key, default)

    def __repr__(self):
        return f"MusicNode({self.type!r})"


class Pitch:
    """One `(ly:make-pitch OCTAVE NOTENAME [ALTERATION])` form.
    octave: 0 = the octave starting at middle C (LilyPond's "c'").
    notename: 0=C, 1=D, 2=E, 3=F, 4=G, 5=A, 6=B.
    alteration: whole tones (0.5 = one sharp, -0.5 = one flat, etc.),
    already a plain Fraction/int/float -- never a symbol like 'sharp."""
    __slots__ = ('octave', 'notename', 'alteration')

    def __init__(self, octave, notename, alteration=0):
        self.octave = octave
        self.notename = notename
        self.alteration = alteration

    def __repr__(self):
        return f"Pitch(oct={self.octave}, name={self.notename}, alt={self.alteration})"


class Duration:
    """One `(ly:make-duration LOG [DOTS [SCALE]])` form.
    log: base-2 log of the duration, negated -- 0=whole, 1=half,
    2=quarter, 3=eighth, etc. dots: augmentation dots. scale: a
    Fraction multiplier (used for tuplets; 1 otherwise)."""
    __slots__ = ('log', 'dots', 'scale')

    def __init__(self, log, dots=0, scale=1):
        self.log = log
        self.dots = dots
        self.scale = scale

    def __repr__(self):
        return f"Duration(log={self.log}, dots={self.dots}, scale={self.scale})"


_TOKEN_RE = re.compile(r"""
    \s+                     # whitespace (skipped)
  | \#<[^>]*>                # opaque Guile object (skipped/discarded)
  | \#t | \#f
  | "(?:[^"\\]|\\.)*"
  | '
  | \(
  | \)
  | [^\s()"']+
""", re.VERBOSE)

_INT_RE = re.compile(r'-?\d+')
_RATIONAL_RE = re.compile(r'-?\d+/\d+')
_FLOAT_RE = re.compile(r'-?\d+\.\d+')


def _tokenize(text):
    return [m.group(0) for m in _TOKEN_RE.finditer(text) if not m.group(0).isspace()]


class Reader:
    """Parses a full `display-scheme-music` dump (or several, back to
    back -- one per top-level `\\score` LilyPond encountered) into
    MusicNode/Pitch/Duration/list/atom values. Use read_all()."""

    def __init__(self, text):
        self._tokens = _tokenize(text)
        self._i = 0

    def _peek(self):
        return self._tokens[self._i] if self._i < len(self._tokens) else None

    def _next(self):
        t = self._tokens[self._i]
        self._i += 1
        return t

    def _read(self):
        t = self._next()
        if t == "'":
            return self._read()  # quote marker -- see module docstring
        if t == '(':
            items = []
            while self._peek() != ')':
                items.append(self._read())
            self._next()  # consume ')'
            return self._interpret(items)
        if t.startswith('#<'):
            return None
        if t == '#t':
            return True
        if t == '#f':
            return False
        if t.startswith('"'):
            return t[1:-1].replace('\\"', '"').replace('\\\\', '\\')
        if _INT_RE.fullmatch(t):
            return int(t)
        if _RATIONAL_RE.fullmatch(t):
            return Fraction(t)
        if _FLOAT_RE.fullmatch(t):
            return float(t)
        return Symbol(t)

    def _interpret(self, items):
        if not items:
            return []
        head = items[0]
        if head == 'make-music':
            props = {}
            rest = items[2:]
            for k, v in zip(rest[0::2], rest[1::2]):
                props[str(k)] = v
            return MusicNode(str(items[1]), props)
        if head == 'ly:make-pitch':
            args = items[1:]
            return Pitch(args[0], args[1], args[2] if len(args) > 2 else 0)
        if head == 'ly:make-duration':
            args = items[1:]
            return Duration(args[0], args[1] if len(args) > 1 else 0,
                             args[2] if len(args) > 2 else 1)
        if head == 'ly:make-moment':
            # A moment is a fraction of a whole note. Every music node's
            # own 'length is one of these -- e.g. a quarter note's
            # 'length is (ly:make-moment 1/4) -- and multiplying by 4
            # converts it straight to music21's quarterLength units, so
            # this importer never needs to recompute timing from
            # duration-log/dots/scale itself. Grace-note moments carry a
            # second (grace-part) argument; for the plain-notation scope
            # here only the main part (args[0]) is used.
            return items[1] if len(items) > 1 else Fraction(0)
        if head == 'cons':
            return (items[1], items[2])
        if head == 'list':
            return items[1:]
        # Anything else we don't have a specific shape for (this
        # shouldn't happen for display-scheme-music output, but fail
        # soft rather than crash the whole import over a decoration
        # we don't care about anyway).
        return items

    def read_all(self):
        """Every top-level form in the dump -- one per `\\score` (explicit
        or implicit) LilyPond's toplevel-score-handler saw."""
        forms = []
        while self._peek() is not None:
            forms.append(self._read())
        return forms
