"""
importers/lilypond_metadata.py

LilyPond (.ly) -> the pipeline's format-neutral metadata dict (see
core/score_metadata.py). Reads the SOURCE TEXT: the importer proper
works from LilyPond's own `display-scheme-music` dump of the music,
which doesn't contain \\header blocks at all.

WHICH \\header BLOCKS COUNT. Only headers that apply to the score being
described are read (the first \\score, or the one `score_index` picks
when a file's scores are imported one by one): those at
the top level of the file, and those of any \\book / \\bookpart that
encloses the first \\score, and the first \\score's own. Applied in that
order (general -> specific), so a score-level `piece` overrides a
file-level one. Headers belonging to later scores are ignored.

VALUES. `title = "Plain string"`, `title = \\markup { Some \\italic
"Text" }` and `title = #"scheme string"` are all reduced to their
visible text (quoted strings and bare words; markup commands and
Scheme arguments like `#2` dropped). A value that contains no text at
all -- a bare variable reference such as `title = \\mytitle`, or Scheme
code -- can't be resolved without running LilyPond, so it is kept
verbatim, unresolved, in `miscellaneous` rather than guessed at. Headers
in \\included files are not read.

MAPPING TO THE DICT
  work_title      title              subtitle          subtitle
  movement_title  piece              work_number       opus
  composers       composer           arrangers         arranger
  poets           poet               rights            copyright,
                                                       license
  source          source             encoders          maintainer
  date_composed   date  (Mutopia's meaning: date of composition)
  date_engraved   lastupdated (Mutopia: when the file last changed)
  software        the \\version line, as "LilyPond X.Y.Z (\\version)"
  comments        comment text at the top of the file (before any
                  music/code) and inside the header blocks read
  everything else (subsubtitle, dedication, instrument, meter, tagline,
  mutopia*, style, footer, unresolved references, ...) ->
  miscellaneous, under LilyPond's own field name.
There is no `date_arranged` source in LilyPond headers.

LIMITS: a `\\header` written inside a Scheme `#{ ... #}` block, or
built by Scheme code, isn't seen; braces inside Scheme code that aren't
in strings could confuse the block matching (rare in real files).
"""

import re

from core.score_metadata import new_metadata

_TOKEN_RE = re.compile(r'''
    (?P<block_comment> %\{.*?%\} )
  | (?P<line_comment>  %[^\n]* )
  | (?P<string>        "(?:[^"\\]|\\.)*" )
  | (?P<lbrace>        \{ )
  | (?P<rbrace>        \} )
  | (?P<equals>        = )
  | (?P<command>       \\[A-Za-z][A-Za-z0-9_-]* )
  | (?P<word>          [^\s{}"%=\\]+ )
  | (?P<other>         \\. | . )
''', re.X | re.S)

_IDENT_RE = re.compile(r'^[A-Za-z][A-Za-z0-9_-]*$')
_STRUCT_COMMANDS = {'\\score', '\\book', '\\bookpart', '\\header'}


class _Tok:
    __slots__ = ('kind', 'text')

    def __init__(self, kind, text):
        self.kind, self.text = kind, text


def _tokenize(text):
    toks = []
    for m in _TOKEN_RE.finditer(text):
        kind = m.lastgroup
        if kind == 'other' and m.group(0).isspace():
            continue
        toks.append(_Tok(kind, m.group(0)))
    return toks


def _comment_text(tok):
    t = tok.text
    if tok.kind == 'block_comment':
        t = t[2:-2]
    else:
        t = t.lstrip('%')
    return re.sub(r'\s+', ' ', t).strip()


def _unescape(s):
    return s[1:-1].replace('\\"', '"').replace('\\\\', '\\')


def _value_text(vtoks):
    """Visible text of a header value's tokens, or None if it has none."""
    parts = []
    for t in vtoks:
        if t.kind == 'string':
            parts.append(_unescape(t.text))
        elif t.kind == 'word' and not t.text.startswith('#'):
            parts.append(t.text)
    text = re.sub(r'\s+', ' ', ' '.join(parts)).strip()
    return text or None


def _raw_value(vtoks):
    return re.sub(r'\s+', ' ', ' '.join(t.text for t in vtoks)).strip()


def _parse_header_body(body):
    """([(name, value_tokens)], [comment text]) from a header block's
    tokens (outer braces already removed)."""
    fields, comments = [], []
    depth = 0
    starts = []          # (name, index just after '=')
    n = len(body)
    i = 0
    while i < n:
        t = body[i]
        if t.kind in ('block_comment', 'line_comment'):
            c = _comment_text(t)
            if c:
                comments.append(c)
        elif t.kind == 'lbrace':
            depth += 1
        elif t.kind == 'rbrace':
            depth -= 1
        elif (depth == 0 and t.kind == 'word' and _IDENT_RE.match(t.text)
              and i + 1 < n and body[i + 1].kind == 'equals'):
            starts.append((t.text, i, i + 2))
        i += 1
    for k, (name, name_idx, val_start) in enumerate(starts):
        val_end = starts[k + 1][1] if k + 1 < len(starts) else n
        vtoks = [t for t in body[val_start:val_end]
                 if t.kind not in ('block_comment', 'line_comment')]
        fields.append((name, vtoks))
    return fields, comments


def _scan(toks):
    """Walk the token stream once, tracking block nesting.

    Returns (headers, scores, leading_comments, version) where
    headers is [(owner_id, kind_of_owner, fields, comments)] and
    scores is [(score_id, [ancestor block ids])] for EVERY \\score, in
    source order."""
    headers = []
    scores = []
    stack = []                      # [(kind, id)] for open braces
    next_id = 1
    owners = []                     # ids of open structural blocks, innermost last
    version = None
    leading, seen_code = [], False

    i, n = 0, len(toks)
    while i < n:
        t = toks[i]
        if t.kind in ('block_comment', 'line_comment'):
            if not seen_code:
                c = _comment_text(t)
                if c:
                    leading.append(c)
            i += 1
            continue

        if t.kind == 'command' and t.text == '\\version':
            if i + 1 < n and toks[i + 1].kind == 'string':
                version = _unescape(toks[i + 1].text)
                i += 2
                continue
        seen_code = True

        if t.kind == 'command' and t.text in _STRUCT_COMMANDS:
            j = i + 1
            while j < n and toks[j].kind in ('block_comment', 'line_comment'):
                j += 1
            if j < n and toks[j].kind == 'lbrace':
                kind = t.text[1:]
                if kind == 'header':
                    # collect the balanced body
                    depth, k = 1, j + 1
                    while k < n and depth:
                        if toks[k].kind == 'lbrace':
                            depth += 1
                        elif toks[k].kind == 'rbrace':
                            depth -= 1
                        k += 1
                    body = toks[j + 1:k - 1]
                    fields, comments = _parse_header_body(body)
                    owner = owners[-1] if owners else (0, 'toplevel')
                    headers.append((owner[0], owner[1], fields, comments))
                    i = k
                    continue
                bid = next_id
                next_id += 1
                if kind == 'score':
                    scores.append((bid, [o[0] for o in owners]))
                stack.append((kind, bid))
                owners.append((bid, kind))
                i = j + 1
                continue

        if t.kind == 'lbrace':
            stack.append((None, None))
        elif t.kind == 'rbrace' and stack:
            kind, bid = stack.pop()
            if kind is not None and owners and owners[-1][0] == bid:
                owners.pop()
        i += 1

    return headers, scores, leading, version


_KIND_ORDER = {'toplevel': 0, 'book': 1, 'bookpart': 2, 'score': 3}


def extract_metadata(text: str, path=None, score_index: int = 0) -> dict:
    md = new_metadata('lilypond', path)
    toks = _tokenize(text)
    headers, scores, leading, version = _scan(toks)
    first_score = scores[score_index] if 0 <= score_index < len(scores) else None

    # which headers apply to the chosen \score (the first, unless
    # score_index says otherwise)
    applicable = []
    for order, (owner_id, kind, fields, comments) in enumerate(headers):
        if kind == 'toplevel':
            ok = True
        elif first_score is None:
            ok = kind in ('book', 'bookpart')
        else:
            ok = owner_id == first_score[0] or owner_id in first_score[1]
        if ok:
            applicable.append((_KIND_ORDER[kind], order, fields, comments))
    applicable.sort(key=lambda a: (a[0], a[1]))    # general -> specific

    merged = {}                      # field name -> value tokens (later wins)
    header_comments = []
    for _rank, _order, fields, comments in applicable:
        for name, vtoks in fields:
            merged[name] = vtoks
        header_comments.extend(comments)

    def text_of(name):
        return _value_text(merged[name]) if name in merged else None

    consumed = set()

    def take(name):
        v = text_of(name)
        if v is not None:
            consumed.add(name)
        return v

    md['work_title'] = take('title')
    md['subtitle'] = take('subtitle')
    md['movement_title'] = take('piece')
    md['work_number'] = take('opus')
    for name, field in (('composer', 'composers'), ('arranger', 'arrangers'),
                        ('poet', 'poets')):
        v = take(name)
        if v:
            md[field].append(v)
    v = take('copyright')
    if v:
        md['rights'].append({'type': None, 'text': v})
    v = take('license')
    if v:
        md['rights'].append({'type': 'license', 'text': v})
    md['source'] = take('source')
    v = take('maintainer')
    if v:
        md['encoders'].append({'type': 'maintainer', 'name': v})
    md['date_composed'] = take('date')
    md['date_engraved'] = take('lastupdated')

    if version:
        md['software'].append(f'LilyPond {version} (\\version)')

    for name, vtoks in merged.items():
        if name in consumed:
            continue
        value = _value_text(vtoks)
        if value is None:
            value = _raw_value(vtoks)          # unresolved reference / Scheme
            if not value:
                continue
            md['miscellaneous'][name] = value + '  [unresolved]'
        else:
            md['miscellaneous'][name] = value

    for c in leading + header_comments:
        if c and c not in md['comments']:
            md['comments'].append(c)
    return md
