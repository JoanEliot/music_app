"""
importers/musedata_metadata.py

MuseData -> the pipeline's format-neutral metadata dict (see
core/score_metadata.py). Built from a real stage-2 file
(`Bus2007-In_hydraulis.md`); three sources, in this order of authority:

1. An EMBEDDED HUMDRUM REFERENCE BLOCK. MuseData allows comment lines
   starting with `@`; that file carries a whole block of them:
       @@START: HUMDRUMREFERENCE
       @!!!COM: Busnoys, Antoine
       @!!!CDT: ~1430///-1492/11/06
       @!!!OTL: In hydraulis        (also ENC, END, EED, ONB, SCT, ...)
   The lines are handed, `@` removed, to importers/humdrum_metadata.py, so
   composer, dates (normalized), title, encoder, notes and catalog number
   come out exactly as they do for a Humdrum file.

2. The 12 HEADER RECORDS every MuseData part opens with (from the first
   part; the fixed layout is documented on CCARH's MuseData pages and
   confirmed by this file):
       1 copyright notice          2 file identification
       3 timestamp                 4 "date encoder [date]"
       5 "WK#:n MV#:m"             6 source
       7 work title                8 movement title
       9 part / instrument name   10 (free)
      11 group memberships        12 "score: part i of n"
   A record still holding the editor's placeholder text ("Header Record 6:
   source") counts as empty. These only FILL what the Humdrum block left
   empty: work_title, movement_title, source, rights, encoder,
   date_engraved (the record-4 date, kept as written), work/movement
   numbers. The other records, and every part's name, go to
   `miscellaneous` (file_id, timestamp, parts, group).

3. muse2ps PRINT DIRECTIVES (`@muse2psv1==C^Antoine Busnoys^` and
   `==T^In hydraulis^`, the composer and title as printed on the page):
   a last-resort fallback for composers/title, recorded in
   origin['fallbacks'] when used.

Stage-1 files carry none of this beyond the header records; whatever is
missing simply stays empty.
"""

import re

from core.score_metadata import new_metadata
from importers.humdrum_metadata import extract_metadata as extract_humdrum_metadata
from importers.musedata_postprocess import is_attributes_record, read_part_chunks

_PLACEHOLDER_RE = re.compile(r'^Header Record\b', re.I)
_ENCODING_RE = re.compile(r'^(\d{1,2}/\d{1,2}/\d{2,4})\s+(.*?)(?:\s+(\d{1,2}/\d{1,2}/\d{2,4}))?$')
_WORK_RE = re.compile(r'WK#:\s*(\S+)')
_MOVEMENT_RE = re.compile(r'MV#:\s*(\S+)')
_MUSE2PS_RE = re.compile(r'^@muse2ps\w*==([A-Za-z])\^([^^]*)\^')


def _header_records(chunk):
    """The 12 header records of one part's raw lines, blanks included (an
    unused record is an EMPTY LINE, so skipping blanks would shift every
    later record). The layout is anchored on record 11, the one
    unmistakable line ("Group memberships: ..."), counting back from it;
    a chunk without one falls back to its non-blank lines in order."""
    lines = []
    for line in chunk:
        if is_attributes_record(line):
            break
        if line.startswith(('@', '/')):
            continue
        lines.append(line.rstrip())
    anchor = next((i for i in range(len(lines) - 1, -1, -1)
                   if lines[i].startswith('Group memberships:')), None)
    if anchor is None:
        return [l.strip() for l in lines if l.strip()][:12]
    before = lines[max(0, anchor - 10):anchor]
    before = [''] * (10 - len(before)) + before
    return (before + lines[anchor:anchor + 2])[:12]


def _real(record):
    return None if (not record or _PLACEHOLDER_RE.match(record)) else record


def extract_metadata(input_path, part_files=None) -> dict:
    chunks = read_part_chunks(input_path, part_files)

    # 1. embedded Humdrum reference records
    block = '\n'.join(line[1:] for chunk in chunks[:1] for line in chunk
                      if line.startswith('@!!!'))
    md = extract_humdrum_metadata(block, input_path) if block else new_metadata('musedata', input_path)
    md['origin']['format'] = 'musedata'
    md['origin']['path'] = str(input_path)

    if not chunks:
        return md
    rec = _header_records(chunks[0])
    rec += [None] * (12 - len(rec))

    # 2. header records: fill only what is still empty
    copyright_, file_id, timestamp, encoding, wk_mv, source, work, movement = (
        _real(r) for r in rec[:8])
    if copyright_ and not md['rights']:
        md['rights'].append({'type': None, 'text': copyright_})
    if file_id:
        md['miscellaneous']['file_id'] = file_id
    if timestamp:
        md['miscellaneous']['timestamp'] = timestamp
    if encoding:
        m = _ENCODING_RE.match(encoding)
        if m:
            if not md['date_engraved']:
                md['date_engraved'] = m.group(1)
            if m.group(2) and not md['encoders']:
                md['encoders'].append({'type': 'encoder', 'name': m.group(2)})
            if m.group(3):
                md['miscellaneous']['encoding_record_date2'] = m.group(3)
        else:
            md['miscellaneous']['encoding_record'] = encoding
    if wk_mv:
        w, v = _WORK_RE.search(wk_mv), _MOVEMENT_RE.search(wk_mv)
        if w and not md['work_number']:
            md['work_number'] = w.group(1)
        if v and not md['movement_number']:
            md['movement_number'] = v.group(1)
    if source and not md['source']:
        md['source'] = source
    if work and not md['work_title']:
        md['work_title'] = work
    if movement and not md['movement_title']:
        md['movement_title'] = movement

    part_names = []
    for chunk in chunks:
        r = _header_records(chunk)
        name = _real(r[8]) if len(r) > 8 else None
        if name:
            part_names.append(name)
    if part_names:
        md['miscellaneous']['parts'] = ' | '.join(part_names)
    group = _real(rec[10])
    if group:
        md['miscellaneous']['group'] = group

    # 3. muse2ps directives: last resort for composer and title
    printed = {}
    for line in chunks[0]:
        m = _MUSE2PS_RE.match(line)
        if m:
            printed.setdefault(m.group(1), m.group(2).strip())
    if printed.get('C') and not md['composers']:
        md['composers'] = [printed['C']]
        md['origin']['fallbacks'].append('composers')
    if printed.get('T') and not md['work_title']:
        md['work_title'] = printed['T']
        md['origin']['fallbacks'].append('work_title')
    return md
