"""
importers/musedata_importer.py

MuseData -> music21.stream.Score, extracted from the standalone
musedata_to_musicxml.py script so the pipeline can call it the same way
it calls every other format's importer (see import_score() below and
importers/__init__.py). All of the actual conversion logic here --
the monkeypatch and its rationale, forceSource=True, and the single-file
vs. directory handling -- is unchanged from that script; only the
final `score.write('musicxml', ...)` step has moved out, into
core.import_pipeline.run_job(), since writing output is the pipeline's
job now, not the importer's.

WHY THE PATCH (unchanged from musedata_to_musicxml.py)
--------------------------------------------------------
music21's built-in MuseData -> MusicXML pipeline is correct for parsing,
but has one real bug: for *stage 1* MuseData files, it crashes during
MusicXML export with:

    TypeError: cannot serialize <int> (type int)

Root cause (in music21/musedata/__init__.py and
music21/musedata/translate.py):
  - MuseDataPart.getPartName() unconditionally returns None when the
    file is stage 1 (stage 1 never carried a part-name field).
  - translate.musedataPartToStreamPart() does:
        p.id = museDataPart.getPartName()   # -> p.id = None
        p.partName = p.id
  - Music21Object.id, when set to None, falls back to returning Python's
    builtin id(self) -- a raw memory address (an int) -- from then on.
  - That int ends up as `partName`, and MusicXML's XML serializer can't
    write an int as element text, hence the crash.

This is not specific to any one file -- it fires on every stage 1
MuseData file that doesn't otherwise get a usable part name. The patch
assigns a fallback "Part N" name instead of letting None leak into a
memory address, and otherwise relies entirely on music21's existing
MuseData parsing. It's a no-op for stage 2 files or any file whose
part name is already resolvable (getPartName() returning a real string),
so applying it unconditionally, as import_score() does below, is safe.

SINGLE FILE vs. DIRECTORY (unchanged convention)
--------------------------------------------------
MuseData conventionally stores one physical file per instrument/part
(e.g. a string quartet as 01, 02, 03, 04 -- often with no file
extension -- in one folder, all belonging to the same work). Passing a
directory to import_score() follows music21's own convention: it feeds
every part-file in the directory into a single MuseDataWork and returns
ONE combined multi-part Score (all parts together), matching what
musedata_to_musicxml.py's directory mode did before writing it out.

A corpus laid out as one subfolder per movement (each subfolder holding
that movement's per-part files) is a batch of separate jobs from this
importer's point of view -- call import_score() (or, more usually,
core.import_pipeline.run_job()) once per subfolder rather than expecting
this function to walk a multi-movement tree itself; see
musedata_to_musicxml.py's --movements mode for that walking logic if a
CLI/GUI front end wants to offer it.

CROSS-STAFF / GRAND-STAFF NOTATION -- DETECTED, NOT (YET) PRESERVED
--------------------------------------------------------------------
MuseData's own official specification (CCARH wiki) is explicit: "Music
on the grand staff may be considered as one or two parts. If musical
notation or symbols cross between the staves of the grand staff, then
the music on the grand staff must be treated as one musical part."
Concretely, this means a single file's attributes ('$') record declares
more than one staff via its 'S:' field (e.g. 'S:2'), with per-record
staff assignment (the spec documents this explicitly for clef and
directive records; simultaneous tracks for the two staves are encoded
with the 'back' command to rewind the time cursor between them, per
CCARH's own published examples -- e.g. a Mozart piano excerpt encoded
this way).

Unlike importers/lilypond_importer.py's `\\change Staff` (verified
against a real, complete piece) or importers/humdrum_importer.py's
`*staff` (verified against the format's own documentation and a direct
statement from Humdrum's creator about tooling support), this importer
does NOT attempt to verify or preserve genuine cross-staff behavior:
there is no bundled multi-staff (S:2+) MuseData test file anywhere in
music21's own corpus, and none was available to test against here, so
whether music21's own MuseData reader correctly reconstructs the
'back'-based simultaneous tracks -- let alone any true per-note
mid-track staff reassignment, if MuseData even supports that
distinctly from static per-track staff assignment -- is simply
unverified. Rather than guess, this importer detects the S:2+
declaration (a reliable, spec-documented signal that the file is in
grand-staff/cross-staff territory) and raises
MuseDataMultiStaffNotPreservedWarning, naming the file, so the result
can be checked against the original by hand. Revisit with real
verification if a concrete multi-staff MuseData file surfaces.
"""

from pathlib import Path

from music21.musedata import translate as _musedataTranslate

_original_musedataPartToStreamPart = _musedataTranslate.musedataPartToStreamPart
_patch_applied = False


class MuseDataMultiStaffNotPreservedWarning(UserWarning):
    """Raised when a MuseData file's attributes ('$') record declares
    more than one staff (an 'S:' field > 1) -- MuseData's own spec-
    documented convention for grand-staff writing, required whenever
    notation crosses between the two staves (see module docstring).
    Whether music21's own reader correctly reconstructs this (there is
    no bundled multi-staff MuseData test file anywhere to verify
    against) is simply unverified here -- check the named file's
    output against the original by hand."""


def _make_patched_part_fn():
    counter = {"n": 0}

    def patched(museDataPart, inputM21=None):
        part_name = museDataPart.getPartName()

        if not part_name or not isinstance(part_name, str):
            counter["n"] += 1
            part_name = f"Part {counter['n']}"

        # Reuse music21's original, well-tested logic by temporarily
        # overriding getPartName() to return our fallback string
        # instead of None.
        orig_get_part_name = museDataPart.getPartName
        museDataPart.getPartName = lambda: part_name
        try:
            return _original_musedataPartToStreamPart(museDataPart, inputM21=inputM21)
        finally:
            museDataPart.getPartName = orig_get_part_name

    return patched


def apply_musedata_stage1_fix():
    """Monkeypatch music21 so stage-1 MuseData files export cleanly.
    Idempotent -- safe to call more than once (e.g. from more than one
    job in the same process)."""
    global _patch_applied
    if not _patch_applied:
        _musedataTranslate.musedataPartToStreamPart = _make_patched_part_fn()
        _patch_applied = True


class MuseDataMetadataWarning(UserWarning):
    """A MuseData header couldn't be read; the notes still import, with an
    empty metadata dict."""


class MuseDataBarTypeWarning(UserWarning):
    """A measure record used a bar-line type music21 doesn't know and no
    fix here covers; it was read as an ordinary bar line."""


_bar_patch_applied = False


def apply_musedata_bar_fix():
    """music21's MuseData reader raises MuseDataException ("cannot process
    bar data definition: silent") on a `msilent` measure record -- MuseData's
    INVISIBLE bar line -- because its table of bar types stops at plain,
    dotted, double and heavy. Confirmed on a real stage-2 file (Busnoys, "In
    hydraulis"): 83 `msilent` records, and the whole import died on the
    first. `msilent` is now read as a bar line that isn't drawn
    (music21's 'none' barline), and any OTHER bar type music21 doesn't know
    degrades to an ordinary bar line with a warning instead of aborting the
    import. Idempotent."""
    global _bar_patch_applied
    if _bar_patch_applied:
        return
    from music21 import bar
    from music21.musedata import MuseDataException, MuseDataMeasure
    import warnings as _warnings

    original = MuseDataMeasure.getBarObject

    def patched(self):
        data = self.src[0].strip()
        if data and data[0] == 'm' and data[1:7] == 'silent':
            return bar.Barline('none')
        try:
            return original(self)
        except MuseDataException as e:
            _warnings.warn(f"{e}; read as an ordinary bar line.", MuseDataBarTypeWarning)
            return bar.Barline('regular')

    MuseDataMeasure.getBarObject = patched
    _bar_patch_applied = True


def looks_like_musedata(path: Path) -> bool:
    """Best-effort content sniff for an extensionless MuseData part-file
    (MuseData corpora conventionally name part-files "01", "02", etc.
    with no extension at all -- see the module docstring). A MuseData
    file's very first non-blank line is free-text (a date/encoder credit
    line), which gives us nothing distinctive to match on the way
    Humdrum's leading '**' interpretation line does -- so this instead
    looks for the numeric "<voices> <sharps/flats>" header line (e.g.
    "1 0") within the first several lines, which is part of every
    MuseData file (stage 1 or 2) and not the kind of line a Humdrum,
    MusicXML, or other text format would ever produce that early.
    """
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for _, line in zip(range(40), f):
                stripped = line.strip()
                if not stripped:
                    continue
                # stage 2: the tagged attributes record, or the group-membership
                # header line; also files that open with muse2ps ("@muse2psv1")
                # print directives before the header, as in a real stage-2 file
                if stripped.startswith("$") and ("K:" in stripped or "Q:" in stripped):
                    return True
                if stripped.startswith("Group memberships:") or stripped.startswith("@muse2ps"):
                    return True
                parts = stripped.split()
                if len(parts) == 2 and all(p.lstrip('-').isdigit() for p in parts):
                    return True
    except OSError:
        return False
    return False


def describe_file(path) -> dict:
    """What a folder scan needs to know about one MuseData file:
      chunks -- how many parts the FILE holds (each ends at a `/END` line);
      part   -- (i, n) from its "score: part i of n" header line, or None;
      work   -- its work-title header record (record 7), or None.
    A file holding several parts is a complete work by itself; several
    single-part files that say "part i of n" (n > 1) and share a work
    title are the parts of one work."""
    import re
    try:
        text = Path(path).read_bytes().decode('utf-8', errors='ignore')
    except OSError:
        return {'chunks': 0, 'part': None, 'work': None}
    lines = text.replace('\r', '').split('\n')
    chunks = sum(1 for l in lines if l.startswith('/END')) or 1
    part = None
    for l in lines[:80]:
        m = re.match(r'^score:\s*part\s+(\d+)\s+of\s+(\d+)', l)
        if m:
            part = (int(m.group(1)), int(m.group(2)))
            break
    header = []
    for l in lines:
        if l.startswith('$'):
            break
        if l.startswith(('@', '/')) or not l.strip():
            continue
        header.append(l.strip())
    work = header[6] if len(header) > 6 and not header[6].startswith('Header Record') else None
    return {'chunks': chunks, 'part': part, 'work': work}


def _detect_multistaff_files(paths) -> list:
    """[(path, staff_count)] for every file in `paths` whose attributes
    ('$') record declares more than one staff via an 'S:' field -- see
    MuseDataMultiStaffNotPreservedWarning and the module docstring's
    CROSS-STAFF / GRAND-STAFF NOTATION section."""
    import re
    flagged = []
    for path in paths:
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except OSError:
            continue
        for line in text.splitlines():
            if not line.startswith('$'):
                continue
            m = re.search(r'\bS:(\d+)', line)
            if m and int(m.group(1)) > 1:
                flagged.append((path, int(m.group(1))))
                break
    return flagged


def import_score(input_path, **options):
    """Parse a single MuseData file, or a directory of MuseData part-files
    that together make up one multi-part work (see module docstring),
    into one music21 Score. Applies the stage-1 id-crash patch first --
    harmless for stage-2 files or any file whose part name already
    resolves on its own. `options` is accepted for interface
    consistency with the other importers; MuseData takes one:
      part_files -- a list of paths: import ONLY these files of the
          directory as the work's parts (a batch scan uses this when a
          folder holds other things -- other formats, a README -- besides
          the part files). They are copied into a temporary directory so
          music21 sees exactly them.
    """
    apply_musedata_stage1_fix()
    apply_musedata_bar_fix()
    from music21 import converter

    path = Path(input_path)
    part_files = options.get('part_files')
    if part_files and path.is_dir():
        import shutil
        import tempfile
        with tempfile.TemporaryDirectory(prefix='musedata_parts_') as tmp:
            for f in part_files:
                shutil.copy2(f, Path(tmp) / Path(f).name)
            score = import_score(tmp)
        md = getattr(score, '_app_metadata', None)
        if md is not None:                       # record the real folder, not the temp copy
            md['origin']['path'] = str(path)
        return score
    candidate_paths = [path] if path.is_file() else [p for p in path.iterdir() if p.is_file()]
    flagged = _detect_multistaff_files(candidate_paths)
    if flagged:
        import warnings
        details = '; '.join(f'{p.name} (S:{n})' for p, n in flagged)
        warnings.warn(
            f"{details}: declares more than one staff in a single file/part "
            f"-- MuseData's own convention for grand-staff writing, required "
            f"whenever notation crosses between the two staves. Whether this "
            f"importer's output correctly reflects that is unverified (no "
            f"real multi-staff MuseData file was available to test against) "
            f"-- check the result against the original by hand.",
            MuseDataMultiStaffNotPreservedWarning,
        )

    # `msilent N` records are invisible bar-NUMBER markers, not bar lines:
    # comment them out (in a temporary copy) so music21 builds whole bars --
    # see importers/musedata_postprocess.py, item 3.
    import warnings
    from .musedata_postprocess import (neutralize_text, postprocess)
    import shutil
    import tempfile
    tmp_dir = tempfile.mkdtemp(prefix='musedata_bars_')
    parse_path, neutralized, kept = path, 0, 0
    try:
        if path.is_dir():
            sources = sorted(p for p in path.iterdir() if p.is_file())
            (Path(tmp_dir) / path.name).mkdir()
            dest_root = Path(tmp_dir) / path.name
        else:
            sources, dest_root = [path], Path(tmp_dir)
        rewritten = {}
        for f in sources:
            text = f.read_bytes().decode('latin-1')            # lossless round trip
            new_text, n, k = neutralize_text(text)
            neutralized, kept = neutralized + n, kept + k
            rewritten[f] = new_text
        if neutralized:
            for f, new_text in rewritten.items():
                (dest_root / f.name).write_bytes(new_text.encode('latin-1'))
            parse_path = dest_root if path.is_dir() else dest_root / path.name
            warnings.warn(
                f"{neutralized} `msilent` record(s) sit inside bars of the parts' own length "
                f"and were read as invisible bar-number markers, not bar lines"
                + (f" ({kept} more were kept as real bar lines)" if kept else "")
                + " -- see importers/musedata_postprocess.py.", MuseDataBarTypeWarning)
        score = converter.parse(str(parse_path), forceSource=True)
        # repairs for what music21's stage-2 reader gets wrong (mid-part meter and
        # key changes, special meters, bar numbers, `_` melisma marks in lyrics)
        postprocess(score, parse_path)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    # Work-level metadata: header records, an embedded Humdrum reference
    # block, muse2ps directives -- see importers/musedata_metadata.py. It
    # must never block the notes.
    from core.score_metadata import attach_metadata, new_metadata
    try:
        from .musedata_metadata import extract_metadata
        attach_metadata(score, extract_metadata(path))
    except Exception as e:
        warnings.warn(f"{path}: could not read metadata ({e}); continuing with none.",
                      MuseDataMetadataWarning)
        attach_metadata(score, new_metadata('musedata', path))
    return score
