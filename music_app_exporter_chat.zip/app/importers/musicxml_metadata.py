"""
importers/musicxml_metadata.py

MusicXML -> the pipeline's format-neutral metadata dict (see
core/score_metadata.py). Reads the RAW XML rather than music21's parsed
Score, because music21 keeps only a fraction of what the format
defines: it has no slot for <source>, <relation>, <opus>,
<movement-number>, the <encoding> details, or <miscellaneous-field>,
and it flattens the rest into its own vocabulary.

WHAT THE MUSICXML SPEC DEFINES (all captured):
  <work>            work-number, work-title, opus (xlink:href)
  <movement-number>, <movement-title>
  <identification>  creator (type=composer/lyricist/arranger/poet/
                    translator/any other), rights (type=...),
                    encoding (encoding-date, encoder, software,
                    encoding-description), source, relation,
                    miscellaneous/miscellaneous-field
  <credit>          page text, optionally typed by <credit-type>
Not captured: <encoding>/<supports> (technical feature flags for
notation software, meaningless to a reader of the score).

THE SHARED TEXT BUCKET. <credit-words> is the one place MusicXML lets
printed page text live, and encoders use it for both real metadata
("J. S. Bach") and everything else printed on page 1 (part labels,
tempo text, "Score in C", page numbers). Only credits that carry an
explicit <credit-type> are treated as metadata; untyped credits are
kept verbatim in `credits` and never promoted to a field. Even a typed
credit only FILLS a field the proper elements left empty, and every
such fill is recorded in origin['fallbacks'] so a consumer can tell it
apart from a real <work-title>/<creator>.

PLACEHOLDERS. Notation programs print template text for fields the user
never filled in. Confirmed on Dorico 6 files: "Project Lyricist",
"Project Copyright", "Flow Title", "Page Number" appear as credits in
light grey (#C0C0C0), with NO matching <creator>/<rights> element. Any
credit whose colour is a light grey (R=G=B, 0xA0-0xD0) is flagged
placeholder=True: kept in `credits` (nothing is lost) but never used
for any fallback. This is a heuristic built on Dorico's convention; other
programs may need their own rule.

MOVEMENT NUMBER. <movement-number> is used if present. Dorico doesn't
write it -- the number exists only in the printed flow title ("2. Lately
Long Gone", credit-type 'flow title', a non-standard type). ONLY when
<movement-number> is absent, a leading numeral (arabic or roman,
followed by '.', ')' or ':') on the first non-placeholder 'flow title'
credit becomes movement_number, recorded in origin['fallbacks'].
A title credit with no work/movement title becomes work_title (also
recorded as a fallback); there is no stored 'title' -- see
core.score_metadata.display_title(). (Musical text -- tempo words,
expression marks, and the snippet markers -- lives in <direction>/
<words> inside measures, not here, and is not read by this module.)

DATES. Only <encoding-date> is defined by the spec (-> date_engraved).
Composition/arrangement dates have no standard home, so these
conventional <miscellaneous-field name="..."> names are accepted
(case-, space-, hyphen- and underscore-insensitive):
   date_composed  <- date-composed, composition-date, date-created
   date_arranged  <- date-arranged, arrangement-date
   date_engraved  <- date-engraved, engraving-date  (beats encoding-date)
   comments       <- comment, comments, note, notes
Any other miscellaneous field lands in metadata['miscellaneous'].
(Writing the same field names back out is the intended round trip for
the eventual MusicXML exporter.) An incoming date-processed field is
deliberately ignored: date_processed always means "this run".

XML COMMENTS in the file's header area (everything before the first
<part>) are captured in `comments`. Comments inside the music are not.
"""

import re
import xml.etree.ElementTree as ET
from pathlib import Path

from core.score_metadata import PEOPLE_FIELDS, new_metadata

_XLINK_HREF = '{http://www.w3.org/1999/xlink}href'


def _norm_name(name: str) -> str:
    return re.sub(r'[^a-z0-9]', '', (name or '').lower())


_MISC_TO_FIELD = {
    'datecomposed': 'date_composed', 'compositiondate': 'date_composed',
    'datecreated': 'date_composed',
    'datearranged': 'date_arranged', 'arrangementdate': 'date_arranged',
    'dateengraved': 'date_engraved', 'engravingdate': 'date_engraved',
    'comment': 'comments', 'comments': 'comments',
    'note': 'comments', 'notes': 'comments',
}
_IGNORED_MISC = {'dateprocessed'}


def _text(el):
    """An element's full text, whitespace-collapsed; None if empty."""
    if el is None:
        return None
    t = re.sub(r'\s+', ' ', ''.join(el.itertext())).strip()
    return t or None


def _add_unique(lst, value):
    if value and value not in lst:
        lst.append(value)


_PLACEHOLDER_RE = re.compile(r'^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$')
_LEADING_NUMERAL_RE = re.compile(
    r'^\s*(\d+|[IVXLCDM]+)\s*[.):]\s+\S', re.I)


def _is_placeholder_color(color) -> bool:
    """True for a light grey (equal R, G, B between 0xA0 and 0xD0)."""
    m = _PLACEHOLDER_RE.match((color or '').strip())
    if not m:
        return False
    r, g, b = (int(x, 16) for x in m.groups())
    return r == g == b and 0xA0 <= r <= 0xD0


def _header_comments(raw_xml: str) -> list:
    """XML comments before the first <part> (prolog + header area)."""
    m = re.search(r'<part[\s>]', raw_xml)
    header = raw_xml[:m.start()] if m else raw_xml
    out = []
    for c in re.findall(r'<!--(.*?)-->', header, re.S):
        c = re.sub(r'\s+', ' ', c).strip()
        if c:
            out.append(c)
    return out


def extract_metadata(raw_xml: str, path=None) -> dict:
    """Parse MusicXML text into a metadata dict."""
    md = new_metadata('musicxml', path)
    root = ET.fromstring(raw_xml.encode('utf-8') if raw_xml.lstrip().startswith('<?xml')
                         else raw_xml)

    # --- <work> -------------------------------------------------
    work = root.find('work')
    if work is not None:
        md['work_number'] = _text(work.find('work-number'))
        md['work_title'] = _text(work.find('work-title'))
        opus = work.find('opus')
        if opus is not None:
            md['opus_href'] = opus.get(_XLINK_HREF)

    md['movement_number'] = _text(root.find('movement-number'))
    md['movement_title'] = _text(root.find('movement-title'))

    # --- <identification> ---------------------------------------
    ident = root.find('identification')
    if ident is not None:
        for creator in ident.findall('creator'):
            name = _text(creator)
            if not name:
                continue
            ctype = (creator.get('type') or '').strip().lower()
            field = PEOPLE_FIELDS.get(ctype)
            if field:
                _add_unique(md[field], name)
            else:
                md['other_creators'].append({'type': ctype or None, 'name': name})

        for rights in ident.findall('rights'):
            text = _text(rights)
            if text:
                md['rights'].append({'type': rights.get('type'), 'text': text})

        md['source'] = _text(ident.find('source'))

        for rel in ident.findall('relation'):
            text = _text(rel)
            if text:
                md['relations'].append({'type': rel.get('type'), 'text': text})

        enc = ident.find('encoding')
        if enc is not None:
            md['date_engraved'] = _text(enc.find('encoding-date'))
            for e in enc.findall('encoder'):
                name = _text(e)
                if name:
                    md['encoders'].append({'type': e.get('type'), 'name': name})
            for s in enc.findall('software'):
                _add_unique(md['software'], _text(s))
            for d in enc.findall('encoding-description'):
                _add_unique(md['encoding_description'], _text(d))

        misc = ident.find('miscellaneous')
        if misc is not None:
            explicit_engraved = None
            for f in misc.findall('miscellaneous-field'):
                name = f.get('name') or ''
                value = _text(f)
                key = _norm_name(name)
                if not value or key in _IGNORED_MISC:
                    continue
                target = _MISC_TO_FIELD.get(key)
                if target == 'comments':
                    _add_unique(md['comments'], value)
                elif target == 'date_engraved':
                    explicit_engraved = value   # beats <encoding-date>
                elif target:
                    md[target] = md[target] or value
                else:
                    md['miscellaneous'][name] = value
            if explicit_engraved:
                md['date_engraved'] = explicit_engraved

    # --- <credit> page text ------------------------------------
    credit_by_type = {}
    for credit in root.findall('credit'):
        text = ''.join(''.join(w.itertext()) for w in credit.findall('credit-words'))
        text = re.sub(r'[ \t]+', ' ', text).strip()
        if not text:
            continue
        types = [t.text.strip().lower() for t in credit.findall('credit-type') if t.text]
        try:
            page = int(credit.get('page', '1'))
        except ValueError:
            page = 1
        color = next((w.get('color') for w in credit.findall('credit-words')
                      if w.get('color')), None)
        placeholder = _is_placeholder_color(color)
        md['credits'].append({'page': page, 'types': types, 'text': text,
                              'color': color, 'placeholder': placeholder})
        if not placeholder:
            for t in types:
                credit_by_type.setdefault(t, []).append(text)

    # typed credits only ever fill what the proper elements left empty
    def fallback(field, credit_type):
        texts = credit_by_type.get(credit_type)
        if not texts:
            return
        if isinstance(md[field], list):
            if not md[field]:
                md[field] = list(dict.fromkeys(texts))
                md['origin']['fallbacks'].append(field)
        elif md[field] is None:
            md[field] = texts[0]
            md['origin']['fallbacks'].append(field)

    fallback('subtitle', 'subtitle')
    fallback('composers', 'composer')
    fallback('arrangers', 'arranger')
    fallback('lyricists', 'lyricist')
    if not (md['movement_title'] or md['work_title']) and credit_by_type.get('title'):
        md['work_title'] = credit_by_type['title'][0]
        md['origin']['fallbacks'].append('work_title')

    if md['movement_number'] is None:
        for text in credit_by_type.get('flow title', []):
            m = _LEADING_NUMERAL_RE.match(text)
            if m:
                md['movement_number'] = m.group(1)
                md['origin']['fallbacks'].append('movement_number')
                break

    # --- free-text comments in the header -----------------------
    for c in _header_comments(raw_xml):
        _add_unique(md['comments'], c)

    return md
