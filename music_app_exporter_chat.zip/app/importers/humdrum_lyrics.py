"""
importers/humdrum_lyrics.py

Humdrum lyrics -> music21 note lyrics, replacing music21's own attachment
step, which has five weaknesses (each confirmed against real files):

  1. It only knows `**text` and `**lyrics` spines. The Bach chorales in
     music21's own corpus carry their words in `**silbe` spines, so their
     lyrics were dropped entirely.
  2. It needs a `*staff` tandem on the text spine AND its kern spine, and
     drops the words silently if either is missing.
  3. It assigns `note.lyric = text` for each text spine, so with several
     spines (verses) only the LAST survives.
  4. It works out syllable position (begin/middle/end) from each token in
     isolation: a trailing-hyphen-only convention ("Twin-" "kle") leaves
     the second syllable "single".
  5. It puts words on rests.

WHAT THIS DOES INSTEAD (installed once, in-process, by install(); like the
MuseData stage-1 fix it wraps a music21 method):
  - Recognises `**silbe`, `**text` and `**lyrics` spines.
  - A text spine belongs to the kern spine nearest on its LEFT (the
    Humdrum layout: each voice followed by its words); only if there is
    none does a matching `*staff` tandem decide.
  - Several text spines on one voice are several VERSES, numbered 1, 2, ...
    left to right. Each note keeps all of them.
  - A word sits on the note that shares its line. Null tokens (`.`, empty)
    and `|` (or `_`) put NO syllable on that note: a note sung on the
    previous syllable -- what `|` means under the second of a beamed pair.
  - Word continuation is read from hyphens on either side (the CCARH
    chorale convention: "To-" "-des-" "-ban-" "-den"; a leading hyphen alone
    ends a word) AND from the previous syllable, so "Twin-" "kle" works
    too. The hyphens are stripped from the stored text.
  - `\\u3` and the other vowel+3 codes are the umlaut ("S\\u3nd'" = "Sünd'",
    checked against the corpus); other backslash codes are left as written.
  - Words on a rest, or on a line with no note in that voice, can't be
    placed; they are counted and reported in one HumdrumLyricsWarning.
LIMITS: only top-level spines (a text spine that has split with `*^` is
skipped); a text spine with no kern spine to its left and no `*staff`
match is skipped with a warning.
"""

import unicodedata
import warnings

_LYRIC_TYPES = ('silbe', 'text', 'lyrics')
_NO_SYLLABLE = {'', '.', '|', '_'}
_UMLAUT_VOWELS = 'aeiouAEIOU'
_installed = False


class HumdrumLyricsWarning(UserWarning):
    """Humdrum lyrics that couldn't be placed as written: words on rests or
    on lines with no note in their voice, or a text spine with no voice to
    belong to. Everything else was placed."""


def decode_text(raw: str) -> str:
    """Humdrum text escapes -> Unicode (see module docstring)."""
    out, i = [], 0
    while i < len(raw):
        if (raw[i] == '\\' and i + 2 < len(raw) and raw[i + 1] in _UMLAUT_VOWELS
                and raw[i + 2] == '3'):
            out.append(unicodedata.normalize('NFC', raw[i + 1] + '\u0308'))
            i += 3
        else:
            out.append(raw[i])
            i += 1
    return ''.join(out)


def analyze_token(raw):
    """(text, hyphen_before, hyphen_after) for a word token, or None if it
    puts no syllable on its note."""
    token = (raw or '').strip()
    if token in _NO_SYLLABLE:
        return None
    lead = token.startswith('-') and len(token) > 1
    trail = token.endswith('-') and len(token) > 1
    core = token[1:] if lead else token
    core = core[:-1] if trail else core
    core = decode_text(core)
    return (core, lead, trail) if core else None


def _owner_kern(collection, text_spine, kern_spines, kern_by_staff):
    """The kern spine a text spine belongs to (see module docstring)."""
    left = [k for k in kern_spines if k.id < text_spine.id]
    if left:
        return max(left, key=lambda k: k.id)
    from music21.humdrum.spineParser import MiscTandem
    for tandem in text_spine.stream[MiscTandem]:
        if tandem.tandem.startswith('*staff'):
            try:
                return kern_by_staff.get(int(tandem.tandem[6:].split('/')[0]))
            except ValueError:
                return None
    return None


def _attach(collection, text_spines):
    from music21 import base, note
    from music21.humdrum.spineParser import MiscTandem

    kern_spines = [s for s in collection.spines
                   if s.parentSpine is None and s.spineType == 'kern']
    kern_by_staff = {}
    for k in kern_spines:
        for tandem in k.stream.getElementsByClass(MiscTandem):
            if tandem.tandem.startswith('*staff'):
                try:
                    kern_by_staff[int(tandem.tandem[6:].split('/')[0])] = k
                except ValueError:
                    pass
                break

    verse_of = {}
    unplaced = 0
    orphan_spines = 0
    for spine in sorted(text_spines, key=lambda s: s.id):
        owner = _owner_kern(collection, spine, kern_spines, kern_by_staff)
        if owner is None:
            orphan_spines += 1
            continue
        verse = verse_of[owner.id] = verse_of.get(owner.id, 0) + 1

        by_line = {}
        for wrapper in spine.stream[base.ElementWrapper]:
            line = collection.humdrumLineNumbers.get(wrapper)
            if line is not None:
                by_line[line] = wrapper.obj.contents

        elements = {}
        for el in owner.stream.recurse().getElementsByClass(note.GeneralNote):
            elements.setdefault(el.priority, []).append(el)

        continuing = False
        for line in sorted(by_line):
            parsed = analyze_token(by_line[line])
            if parsed is None:
                continue
            text, lead, trail = parsed
            targets = [e for e in elements.get(line, []) if not e.isRest]
            if not targets:
                unplaced += 1
                continue
            joined = lead or continuing
            if trail:
                syllabic = 'middle' if joined else 'begin'
            else:
                syllabic = 'end' if joined else 'single'
            continuing = trail
            for el in targets:
                el.lyrics.append(note.Lyric(text=text, number=verse,
                                            syllabic=syllabic, applyRaw=True))

    if orphan_spines:
        warnings.warn(f"{orphan_spines} Humdrum text spine(s) had no voice to belong to "
                      f"(no kern spine to their left and no matching *staff) and were skipped.",
                      HumdrumLyricsWarning)
    if unplaced:
        warnings.warn(f"{unplaced} Humdrum lyric syllable(s) sat on a rest or on a line "
                      f"with no note in their voice and could not be placed.",
                      HumdrumLyricsWarning)


def install():
    """Wrap music21's SpineCollection.attachNonKernEvents so lyric/text spines
    are handled here and everything else (dynamics, harmony) by music21's
    own code, untouched. Idempotent."""
    global _installed
    if _installed:
        return
    from music21.humdrum import spineParser
    original = spineParser.SpineCollection.attachNonKernEvents

    def attach_with_lyrics(self):
        text_spines = [s for s in self.spines
                       if s.parentSpine is None and s.spineType in _LYRIC_TYPES]
        if not text_spines:
            return original(self)
        everything = self.spines
        self.spines = [s for s in everything if s not in text_spines]
        try:
            original(self)
        finally:
            self.spines = everything
        _attach(self, text_spines)

    spineParser.SpineCollection.attachNonKernEvents = attach_with_lyrics
    _installed = True
