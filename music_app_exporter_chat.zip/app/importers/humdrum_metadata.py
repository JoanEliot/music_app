"""
importers/humdrum_metadata.py

Humdrum -> the pipeline's format-neutral metadata dict (see
core/score_metadata.py). Reads the file's own text: global REFERENCE
RECORDS (`!!!COM: Bach, Johann Sebastian`) and global COMMENTS
(`!! free text`).

The code table below follows music21's own (music21/humdrum/
spineParser.py, GlobalReference.humdrumKeyToUniqueName, itself taken
from the Humdrum guide's Appendix I) -- checked against that source
rather than written from memory.

RECORD SYNTAX HANDLED
  !!!CODE: value          ordinary record
  !!!COM1: / !!!COM2:     numbered repeats of one code -> several values
  !!!OTL@DE: value        translation into another language
  !!!OTL@@DE: value       the ORIGINAL-language version
  !!!!SEGMENT: ...        (four '!') segment markers -- ignored
  !!!filter: ...          processing directive (applied by the importer
                          itself, see humdrum_filters.py) -- ignored
A field takes the plain (unmarked) or '@@' version of a record; a
translation ('@LANG') never fills a field and is kept in
`miscellaneous` under its full code (e.g. 'OTL@DE'), as is every code
with no dedicated field, so nothing in the file is lost.

MAPPING TO THE DICT
  composers       COM   (COA, then COS, if there's no COM -- recorded in
                        origin['fallbacks'])
  lyricists       LYR          arrangers     LAR
  translators     TRN          other_creators LIB librettist,
                                 LOR orchestrator, OCL transcriber,
                                 ENC/EED are encoders (below)
  titles          A parent work title (OPR) makes OPR the work_title and
                  OTL the movement_title; otherwise OTL is the
                  work_title and a movement name (OMD), if any, the
                  movement_title. OMV -> movement_number. Whichever of
                  OTL/OPR/OMD isn't used lands in `miscellaneous`.
  work_number     SCT (scholarly catalog, e.g. 'BWV 551'), else OPS
  rights          YEC (electronic-edition copyright), YEM (message)
  source          first of YOR, SMS, PTL that exists
  relations       GTL group title, GAW associated work, GCO collection
  encoders        ENC (encoder), EED (electronic editor)
  encoding_desc.  EMD (one per modification)
  date_composed   ODT     date_engraved  END (encoding date)
  date_arranged   (Humdrum has no arrangement-date record)
  comments        ONB (note on the work), RNB (note on the encoding),
                  RWB (encoding warning), plus every `!!` global comment

Names are kept exactly as encoded, which in Humdrum is normally
"Last, First".

DATES. Date-valued records use Humdrum's **date / **Zeit syntax (Humdrum
Reference Manual, humdrum.org/Humdrum/representations/date.rep.html and
Zeit.rep.html; CDT is specified as **Zeit, ODT as **date or **Zeit):
`yyyy/mm/dd/HH:MM:SS` with any trailing part omitted but its slash kept
("1830///-1832///", "2005/01/05/", "1992//", "1685/3//-1750/7/28/"). A
**Zeit token is TWO **date sub-tokens joined by '-' (a period, e.g. life
dates). Within a sub-token:
    ~D  approximate          <D  before          >D  after
    ?D  uncertain            A^B between A and B (a moment somewhere in
                             the range -- "1554/^1557/")
    A|B either A or B
All of that is rendered as readable ISO-style text: "1830 - 1832" (spaced
en dash between the two Zeit halves), "2005-01-05", "1992",
"1685-03 - 1750-07-28", "ca. 1830", "before 1600", "1830?",
"between 1525 and 1526 - 1594-02-02", "1554 or 1557". Applied to
date_composed, date_engraved and every other record that is a date by
definition (see _DATE_CODES).

Not handled, and therefore left EXACTLY as written rather than guessed
at: the per-component approximate/uncertain markers `x` and `z`
("1921/6x//"), and a bare number with no slash (which the spec reads as
SECONDS, not a year -- except a bare four-digit value, taken as a year,
because that is the only sensible reading in a composition/encoding
date field). The original text of every value that was rewritten is
kept in origin['raw_dates'], keyed by record code.
"""

import re

from core.score_metadata import new_metadata

_RECORD_RE = re.compile(r'^!!!(?!!)([^:\s][^:]*):[ \t]?(.*)$')
_CODE_RE = re.compile(r'^([A-Za-z]+#?)(\d*)(?:@(@)?([A-Za-z-]+))?$')
_COMMENT_RE = re.compile(r'^!!(?!!)\s?(.*)$')

_IGNORED_CODES = {'filter'}

# records whose value is a Humdrum date by definition (**date / **zeit)
_DATE_CODES = {'ODT', 'END', 'PDT', 'CDT', 'YER', 'RDT', 'MRD', 'MPD', 'MDT',
               'RRD', 'YOY'}

_ONE_DATE_RE = re.compile(
    r'^(?P<pre>[~<>?]?)(?P<year>\d{1,4})'
    r'(?P<rest>(?:/(?P<month>\d{0,2})(?:/(?P<day>\d{0,2})(?:/(?P<time>[\d:]*))?)?)?)'
    r'(?P<post>\??)$')
_EN_DASH = '\u2013'
_PREFIX_WORDS = {'~': 'ca. ', '<': 'before ', '>': 'after ', '?': '', '': ''}


def _one_date(text):
    """One plain date (no '^', '|' or '-'), or None."""
    m = _ONE_DATE_RE.match(text.strip())
    if not m:
        return None
    year, month, day, time = (m.group(k) or '' for k in ('year', 'month', 'day', 'time'))
    if not m.group('rest') and len(year) != 4:
        return None      # bare number with no slash: seconds per the spec
    out = year
    if month:
        if not 1 <= int(month) <= 12:
            return None
        out += f'-{int(month):02d}'
        if day:
            if not 1 <= int(day) <= 31:
                return None
            out += f'-{int(day):02d}'
        elif time:
            return None
    elif day or time:
        return None                      # a day/time with no month
    if time:
        if not re.match(r'^\d{1,2}(:\d{2}){0,2}$', time):
            return None
        out += ' ' + time
    uncertain = '?' if (m.group('pre') == '?' or m.group('post')) else ''
    return _PREFIX_WORDS[m.group('pre')] + out + uncertain


def _sub_token(text):
    """One **date sub-token: a plain date, `A^B` (between) or `A|B`."""
    if '^' in text and '|' in text:
        return None
    if '^' in text:
        parts = [_one_date(p) for p in text.split('^')]
        if len(parts) == 2 and all(parts):
            return f'between {parts[0]} and {parts[1]}'
        return None
    if '|' in text:
        parts = [_one_date(p) for p in text.split('|')]
        return ' or '.join(parts) if len(parts) >= 2 and all(parts) else None
    return _one_date(text)


def normalize_humdrum_date(value: str):
    """Readable ISO-style text for a Humdrum **date or **Zeit value, or
    None if `value` isn't fully understood (callers keep the original
    then). See the module docstring for the rules."""
    value = (value or '').strip()
    if not value:
        return None
    # a trailing parenthetical remark ("2015/12/06/ (text added)") is carried
    # through as written; only the date itself is normalized
    remark = re.search(r'\s*(\([^)]*\))$', value)
    if remark:
        head = normalize_humdrum_date(value[:remark.start()])
        return f'{head} {remark.group(1)}' if head else None
    halves = value.split('-')
    if len(halves) == 1:
        return _sub_token(halves[0])
    if len(halves) == 2:
        a, b = _sub_token(halves[0]), _sub_token(halves[1])
        if a and b:
            return f'{a} {_EN_DASH} {b}'
    return None


def _parse_records(text: str):
    """[(code, index, lang, primary, value)] in file order, plus the
    list of `!!` global comments."""
    records, comments = [], []
    for line in text.splitlines():
        line = line.rstrip('\r\n')
        if line.startswith('!!!!'):
            continue
        m = _RECORD_RE.match(line)
        if m:
            key, value = m.group(1).strip(), m.group(2).strip()
            cm = _CODE_RE.match(key)
            if not cm:
                records.append((key, 0, None, False, value))
                continue
            code, idx, double, lang = cm.groups()
            if code.lower() in _IGNORED_CODES:
                continue
            records.append((code, int(idx) if idx else 0, lang, bool(double), value))
            continue
        c = _COMMENT_RE.match(line)
        if c and c.group(1).strip():
            comments.append(c.group(1).strip())
        elif line.startswith('!!!') and line[3:].strip():
            comments.append(line[3:].strip())   # '!!!' line with no 'CODE:'
    return records, comments


def extract_metadata(text: str, path=None) -> dict:
    md = new_metadata('humdrum', path)
    records, global_comments = _parse_records(text)

    # code -> [values] for records that may fill a dedicated field
    primary = {}
    used = set()      # (code, idx, lang, value) records consumed by a field
    for rec in records:
        code, idx, lang, is_primary, value = rec
        if not value:
            continue
        if lang is None or is_primary:
            primary.setdefault(code, []).append(value)

    def take(*codes):
        """All values for the first of `codes` that has any; marks that
        code consumed."""
        for c in codes:
            if primary.get(c):
                used.add(c)
                return list(dict.fromkeys(primary[c]))
        return []

    extras = {}       # extra values of a single-valued field -> misc

    def first(*codes):
        v = take(*codes)
        if len(v) > 1:
            used_code = next(c for c in codes if c in used)
            extras[used_code] = v[1:]
        return v[0] if v else None

    # --- people -------------------------------------------------
    composers = take('COM')
    if not composers:
        composers = take('COA', 'COS')
        if composers:
            md['origin']['fallbacks'].append('composers')
    md['composers'] = composers
    md['lyricists'] = take('LYR')
    md['arrangers'] = take('LAR')
    md['translators'] = take('TRN')
    for code, role in (('LIB', 'librettist'), ('LOR', 'orchestrator'),
                       ('OCL', 'transcriber')):
        for name in take(code):
            md['other_creators'].append({'type': role, 'name': name})

    # --- titles -------------------------------------------------
    otl, opr, omd = first('OTL'), first('OPR'), first('OMD')
    if opr:
        md['work_title'], md['movement_title'] = opr, otl
        if omd:                      # OMD not used: keep it visible
            primary.setdefault('OMD', [omd]); used.discard('OMD')
    else:
        md['work_title'], md['movement_title'] = otl, omd
    md['movement_number'] = first('OMV')
    md['work_number'] = first('SCT', 'OPS')

    # --- rights / source / relations ----------------------------
    for code, rtype in (('YEC', 'electronic-edition'), ('YEM', 'message')):
        for value in take(code):
            md['rights'].append({'type': rtype, 'text': value})
    md['source'] = first('YOR', 'SMS', 'PTL')
    for code, rtype in (('GTL', 'group-title'), ('GAW', 'associated-work'),
                        ('GCO', 'collection')):
        for value in take(code):
            md['relations'].append({'type': rtype, 'text': value})

    # --- encoding -----------------------------------------------
    for code, etype in (('ENC', 'encoder'), ('EED', 'editor')):
        for name in take(code):
            md['encoders'].append({'type': etype, 'name': name})
    md['encoding_description'] = take('EMD')

    # --- dates --------------------------------------------------
    raw_dates = {}

    def date_value(code):
        raw = first(code)
        if raw is None:
            return None
        norm = normalize_humdrum_date(raw)
        if norm is not None and norm != raw:
            raw_dates[code] = raw
        return norm if norm is not None else raw

    md['date_composed'] = date_value('ODT')
    md['date_engraved'] = date_value('END')

    # --- comments -----------------------------------------------
    for code in ('ONB', 'RNB', 'RWB'):
        for value in take(code):
            if value not in md['comments']:
                md['comments'].append(value)
    for c in global_comments:
        if c not in md['comments']:
            md['comments'].append(c)

    # --- everything else, verbatim ------------------------------
    for code, idx, lang, is_primary, value in records:
        if not value:
            continue
        consumed = (lang is None or is_primary) and code in used
        if consumed:
            continue
        key = code + (f'@{lang}' if lang else '')
        prev = md['miscellaneous'].get(key)
        md['miscellaneous'][key] = value if prev is None else f'{prev} | {value}'

    # date-valued records that only landed in `miscellaneous`
    for key, value in list(md['miscellaneous'].items()):
        if key.split('@')[0] not in _DATE_CODES:
            continue
        pieces = [v.strip() for v in value.split(' | ')]
        normed = [normalize_humdrum_date(v) for v in pieces]
        if all(n is not None for n in normed):
            new = ' | '.join(normed)
            if new != value:
                raw_dates[key] = value
                md['miscellaneous'][key] = new
    if raw_dates:
        md['origin']['raw_dates'] = raw_dates

    for code, values in extras.items():
        prev = md['miscellaneous'].get(code)
        joined = ' | '.join(values)
        md['miscellaneous'][code] = joined if prev is None else f'{prev} | {joined}'

    return md
