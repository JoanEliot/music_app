"""
importers/musedata_postprocess.py

Repairs applied to a MuseData score AFTER music21 has parsed it, for things
music21's stage-2 reader gets wrong. All were found on one real file (the
bundled `Bus2007-In_hydraulis.md`, a four-part Busnoys chanson with words:
"@muse2psv1" directives, four parts in one file, mensural meters); each
fix says what it does when the file doesn't match what it expects, so a
file it doesn't understand is left exactly as music21 read it.

1. MID-PART ATTRIBUTE RECORDS (`$ K:-1  T:61/0 ...`). music21 reads only a
   part's FIRST `$` record: later key and meter changes are silently lost.
   Here they are read from the raw text and inserted at the measure they
   belong to. The raw text is cut into SEGMENTS at each record whose line
   starts with `m` (measure/mdouble/mheavy/msilent), plus an initial one
   before the first. music21 builds a Measure only for a segment that
   HAS NOTES (translate.py: `if not mdm.hasNotes(): continue`, passing a
   note-less segment's bar type to the previous measure); this mirrors
   that, and a `$` record belongs to the first measure at or after its
   segment. The count must agree with the Measures music21 built; if it
   doesn't, that part is left alone with a warning.

2. SPECIAL METERS. A time signature `T:n/0` (this file uses 11/0, 31/0,
   61/0, 106/0) is a special CODE -- these are mensuration signs -- not a
   fraction. music21 turns every denominator-0 signature into 4/4, which
   wrecked the file: its bars are 12 or 8 quarter notes long, so every note
   overshot a 4/4 bar and music21's own MusicXML writer then crashed
   splitting them. What the codes mean isn't documented anywhere this was
   checked, so it is NOT guessed: the bar length is taken from the MUSIC --
   the most common measure length in the stretch the signature governs --
   and written as the simplest matching signature (12 quarters -> 3/1,
   8 -> 2/1, 6 -> 3/2, 4 -> 4/4, ...). A warning lists every code
   translated this way and its result. Ordinary `T:n/d` changes are
   applied as written.

3. BAR RECORDS: `measure` WITHOUT A NUMBER, and `msilent N`. Worked out
   from the arithmetic of the sample file (Bus2007), not from a spec:
   - an UNNUMBERED `measure` is a real, visible bar line that does not
     advance the bar numbering;
   - `msilent N` is an invisible NUMBER MARKER. In every part its position
     is on the 12-quarter grid of the score's numbering, while the bar
     lines (visible records) follow the part's own meter; treating it as a
     bar break chopped bars into 4/8/12-quarter fragments in all four
     parts (Superius, first section: 21 bars of 4, 22 of 8, 62 of 12),
     while ignoring it gives almost uniformly 12 (81 of 12). In the Tenor's
     `T:31/0` stretch it is the difference between a 4/4/8 mix and 33
     bars of 8. A few `msilent` records ARE the only marker of a real
     boundary (each part has one or two bars of exactly twice the normal
     length if they are ignored); those are kept as bar lines.
   plan_silent_bars()/neutralize_silent_barlines() decide this per part from
   the music's own bar lengths and comment out (`@msilent N`) the number
   markers before music21 reads the file, so music21 builds whole bars. The
   numbers are kept: a bar is labelled with the last number seen plus a
   letter (61, 61a, [62 marker], 62a, 63 ...). A warning says how many
   records were treated which way. Nothing about a file that has no
   `msilent` records changes.

4. LYRICS. In a stage-2 note record the text column holds syllables where
   `_` means "this note continues the previous syllable" (a melisma), and a
   trailing `_` on a syllable ("lis_", "re,_") the same. music21 stores
   every one as literal lyric text: 416 of the first part's 649 notes got
   the "lyric" `_`. They are dropped (the note simply carries no syllable),
   and begin/middle/end are recomputed from the hyphens and the run of
   syllables, as for Humdrum.
"""

import re
import warnings
from collections import Counter

from music21 import key, meter, note, stream

_ATTR_TAG_RE = {
    'K': re.compile(r'\bK:(-?\d+)'),
    'Q': re.compile(r'\bQ:(\d+)'),
    'T': re.compile(r'\bT:(\d+)/(\d+)'),
}


class MuseDataPostprocessWarning(UserWarning):
    """A MuseData repair was skipped (the raw records didn't line up with
    what music21 built) or translated something worth knowing about (a
    special meter code)."""


# ---------------------------------------------------------------------------
# reading the raw records
# ---------------------------------------------------------------------------

def _read_lines(path):
    raw = path.read_bytes()
    try:
        text = raw.decode('utf-8')
    except UnicodeDecodeError:
        text = raw.decode('latin-1')
    return text.replace('\r\n', '\n').replace('\r', '\n').split('\n')


def read_part_chunks(input_path, part_files=None):
    """The raw lines of each part, in the order music21 reads them: a file
    may hold several parts (each ends at a `/END` line); a folder holds one
    file per part, read in sorted order."""
    from pathlib import Path
    path = Path(input_path)
    files = ([Path(f) for f in part_files] if part_files
             else sorted(p for p in path.iterdir() if p.is_file()) if path.is_dir()
             else [path])
    chunks = []
    for f in sorted(files, key=lambda p: p.name) if path.is_dir() else files:
        cur = []
        for line in _read_lines(f):
            cur.append(line)
            if line.startswith('/END'):
                chunks.append(cur)
                cur = []
        if any(is_attributes_record(l) for l in cur):
            chunks.append(cur)
    return chunks


_NOTE_LINE_FIRST_CHARS = 'ABCDEFGrgc'      # what music21's hasNotes() looks for
_ATTRIBUTES_RE = re.compile(r'^\$.*\b[A-Za-z]:')


def is_attributes_record(line: str) -> bool:
    """A `$` line carrying tags (`$  K:0  Q:2  T:11/0  C:4`). A BARE `$` is
    not one: some files use it for an empty header record."""
    return bool(_ATTRIBUTES_RE.match(line))


_SILENT_MARKER_RE = re.compile(r'^@msilent\s+(\d+)')


def _letters(n):
    return chr(ord('a') + n - 1) if 1 <= n <= 26 else str(n)


def scan_chunk(lines):
    """Cut one part's raw lines into measure segments (see module docstring)
    and read what the repairs need:
      {'attrs': [(measure index, {K, Q, T})],      # index into the Measures music21 built
       'labels': [(number, suffix) per Measure, or None for the record-less first],
       'n_measures': how many Measures music21 should have built}
    A bar is labelled with the last number seen -- on a numbered record OR
    an `@msilent N` marker -- plus a letter per unnumbered bar since."""
    segments = []                  # each: {'label': ..., 'notes': bool, 'attrs': [info]}
    cur = None
    started = False
    last_number, since = None, 0
    for line in lines:
        if not started:
            if not is_attributes_record(line):
                continue
            started = True
            cur = {'label': None, 'notes': False, 'attrs': []}
            segments.append(cur)
        marker = _SILENT_MARKER_RE.match(line)
        if marker:                               # a number marker inside a bar
            last_number, since = int(marker.group(1)), 0
            continue
        if line.startswith(('@', '&', '/')) or not line.strip():
            continue
        if is_attributes_record(line):
            info = {}
            m = _ATTR_TAG_RE['K'].search(line)
            if m:
                info['K'] = int(m.group(1))
            m = _ATTR_TAG_RE['Q'].search(line)
            if m:
                info['Q'] = int(m.group(1))
            m = _ATTR_TAG_RE['T'].search(line)
            if m:
                info['T'] = (int(m.group(1)), int(m.group(2)))
            cur['attrs'].append(info)
        elif line.startswith('m'):
            m = re.match(r'^m\w*\s+(\d+)', line)
            if m:
                last_number, since = int(m.group(1)), 0
                label = (last_number, '')
            else:
                since += 1
                label = (last_number, _letters(since)) if last_number is not None else None
            cur = {'label': label, 'notes': False, 'attrs': []}
            segments.append(cur)
        elif line[0] in _NOTE_LINE_FIRST_CHARS:
            cur['notes'] = True

    attrs, labels, measure_index = [], [], 0
    for seg in segments:
        for info in seg['attrs']:
            attrs.append((measure_index, info))
        if seg['notes']:
            labels.append(seg['label'])
            measure_index += 1
    return {'attrs': attrs, 'labels': labels, 'n_measures': measure_index}


# ---------------------------------------------------------------------------
# `msilent` number markers (module docstring, item 3)
# ---------------------------------------------------------------------------

def plan_silent_bars(lines):
    """Indices (into `lines`, one part's raw lines) of the `msilent` records
    that are number markers inside a bar and should NOT break it. Empty if
    the part can't be analysed safely (no divisions value, or `back`
    records rewinding time)."""
    qm = next((int(m.group(1)) for l in lines if is_attributes_record(l)
               for m in [_ATTR_TAG_RE['Q'].search(l)] if m), None)
    if not qm or any(l.startswith('back') for l in lines):
        return set(), 0
    events, pos, started, section = [], 0.0, False, 0
    for i, line in enumerate(lines):
        if not started:
            if is_attributes_record(line):
                started = True
            else:
                continue
        if line.startswith(('@', '&', '/')) or not line.strip():
            continue
        if is_attributes_record(line):
            if _ATTR_TAG_RE['T'].search(line):
                section += 1
            continue
        if line.startswith('m'):
            events.append((i, line.startswith('msilent'), pos, section))
        elif line[0] in 'ABCDEFGr':
            fields = line.split()
            digits = re.match(r'\d+', fields[1]) if len(fields) > 1 else None
            if digits:
                pos += int(digits.group(0)) / qm
    # bars when NO msilent breaks: from the start and each visible record
    bounds = [(0.0, 0)] + [(p, sec) for (_i, silent, p, sec) in events if not silent]
    bars = []
    for n, (start, sec) in enumerate(bounds):
        end = bounds[n + 1][0] if n + 1 < len(bounds) else pos
        if end - start > 1e-9:
            bars.append((start, end, sec))
    modal = {}
    for sec in {b[2] for b in bars}:
        counts = Counter(round(e - st, 3) for st, e, sc in bars if sc == sec)
        modal[sec] = counts.most_common(1)[0][0]
    silents = [(i, p) for (i, silent, p, _s) in events if silent]
    keep = set()
    for start, end, sec in bars:
        length, unit = end - start, modal[sec]
        k = round(length / unit) if unit else 1
        if k >= 2 and abs(length / unit - k) < 0.01:
            for i, p in silents:
                j = (p - start) / unit
                if start + 1e-9 < p < end - 1e-9 and abs(j - round(j)) < 0.01 and 1 <= round(j) <= k - 1:
                    keep.add(i)
    neutralize = {i for i, _p in silents} - keep
    return neutralize, len(keep)


def neutralize_silent_barlines(lines):
    """(new lines, number neutralized, number kept as real bar lines) for one
    part's raw lines: the number markers are commented out with a leading
    `@` so music21 doesn't break bars there."""
    neutralize, kept = plan_silent_bars(lines)
    if not neutralize:
        return list(lines), 0, kept
    return [('@' + l if i in neutralize else l) for i, l in enumerate(lines)], len(neutralize), kept


def neutralize_text(text: str):
    """The same for a whole file's text (parts end at `/END`): (new text,
    neutralized, kept). Line endings and encoding-agnostic (works on str)."""
    lines = text.split('\n')
    out, chunk = [], []
    total = kept_total = 0
    for line in lines:
        chunk.append(line)
        if line.startswith('/END'):
            new, n, k = neutralize_silent_barlines(chunk)
            out.extend(new)
            total, kept_total, chunk = total + n, kept_total + k, []
    if chunk:
        new, n, k = neutralize_silent_barlines(chunk)
        out.extend(new)
        total, kept_total = total + n, kept_total + k
    return '\n'.join(out), total, kept_total


# ---------------------------------------------------------------------------
# meters
# ---------------------------------------------------------------------------

def meter_for_length(quarters: float) -> str:
    """The simplest time signature whose bar is `quarters` quarter notes."""
    if abs(quarters - 4.0) < 1e-6:
        return '4/4'
    for denominator, per_quarter in ((1, 0.25), (2, 0.5), (4, 1.0), (8, 2.0), (16, 4.0)):
        numerator = quarters * per_quarter
        if abs(numerator - round(numerator)) < 1e-6 and round(numerator) >= 1:
            return f'{int(round(numerator))}/{denominator}'
    return '4/4'


def _apply_attributes(part, info, part_label, translated):
    measures = list(part.getElementsByClass(stream.Measure))
    lengths = [float(m.duration.quarterLength) for m in measures]
    attrs = info['attrs']

    meter_changes = [(k, i['T']) for k, i in attrs if 'T' in i]
    # (measure index, ratio string, derived-from-the-music?) for each section
    sections = []
    for n, (k, (num, den)) in enumerate(meter_changes):
        if k >= len(measures):
            continue
        end = meter_changes[n + 1][0] if n + 1 < len(meter_changes) else len(measures)
        if den == 0:                                   # a special code: see module docstring
            counts = Counter(round(l, 3) for l in lengths[k:end] if l > 1e-6)
            if not counts:
                continue
            length = counts.most_common(1)[0][0]
            new = meter_for_length(length)
            translated.setdefault(f'T:{num}/{den}', set()).add((new, length))
            sections.append((k, end, new, True))
        else:
            sections.append((k, end, '4/4' if (num == 1 and den == 1) else f'{num}/{den}', False))

    def put(m, ratio):
        for old in list(m.getElementsByClass(meter.TimeSignature)):
            m.remove(old)
        m.insert(0, meter.TimeSignature(ratio))

    inserted = {}                      # measure index -> ratio inserted there
    for k, end, ratio, derived in sections:
        inserted[k] = ratio
        if derived:
            # A bar LONGER than the section's meter would be split into tied
            # pieces by the MusicXML writer, so it gets a meter of its own
            # (and the section's meter resumes after it).
            bar = float(meter.TimeSignature(ratio).barDuration.quarterLength)
            i = k
            while i < end:
                if lengths[i] > bar + 1e-6:
                    run_len, j = lengths[i], i
                    while j < end and abs(lengths[j] - run_len) < 1e-6:
                        j += 1
                    inserted[i] = meter_for_length(run_len)
                    if j < end and j not in inserted:
                        inserted[j] = ratio
                    i = j
                else:
                    i += 1
    previous = None
    for k in sorted(inserted):
        ratio = inserted[k]
        if ratio != previous:              # no redundant repeat of the signature in force
            put(measures[k], ratio)
        previous = ratio

    current_key = None
    for k, i in attrs:
        if 'K' not in i:
            continue
        if current_key is not None and i['K'] != current_key and k < len(measures):
            m = measures[k]
            for old in list(m.getElementsByClass(key.KeySignature)):
                m.remove(old)
            m.insert(0, key.KeySignature(i['K']))
        current_key = i['K']

    q_values = {i['Q'] for _k, i in attrs if 'Q' in i}
    if len(q_values) > 1:
        warnings.warn(f"{part_label}: the divisions-per-quarter value (Q:) changes "
                      f"mid-part ({sorted(q_values)}); music21 uses only the first, so "
                      f"durations after a change may be wrong.", MuseDataPostprocessWarning)


def _renumber_from_labels(part, info):
    """Apply the (number, suffix) labels from scan_chunk. The record-less
    initial measure (label None) keeps music21's own number."""
    measures = list(part.getElementsByClass(stream.Measure))
    for m, label in zip(measures, info['labels']):
        if label is None:
            continue
        number, suffix = label
        m.number = number
        m.numberSuffix = suffix or None


# ---------------------------------------------------------------------------
# lyrics
# ---------------------------------------------------------------------------

def normalize_lyrics(part) -> int:
    """Drop melisma `_` markers and recompute syllable positions (module
    docstring, item 4). Returns how many lyric entries were removed."""
    from importers.humdrum_lyrics import analyze_token
    removed = 0
    verses = {}
    for n in part.recurse().notes:
        for lyr in list(n.lyrics):
            verses.setdefault(lyr.number, []).append((n, lyr))
    for verse, entries in verses.items():
        continuing = False
        for n, lyr in entries:
            text = lyr.text or ''
            lead = lyr.syllabic in ('middle', 'end')
            trail = lyr.syllabic in ('begin', 'middle')
            raw = ('-' if lead else '') + text.rstrip('_') + ('-' if trail else '')
            parsed = analyze_token(raw if text.rstrip('_') else '')
            if parsed is None:
                n.lyrics.remove(lyr)
                removed += 1
                continue
            core, lead_h, trail_h = parsed
            joined = lead_h or continuing
            if trail_h:
                syllabic = 'middle' if joined else 'begin'
            else:
                syllabic = 'end' if joined else 'single'
            continuing = trail_h
            lyr.text = core
            lyr.syllabic = syllabic
    return removed


# ---------------------------------------------------------------------------
# entry point
# ---------------------------------------------------------------------------

def postprocess(score, input_path, part_files=None):
    """Apply every repair to `score` in place. Stage-1 files (no tagged `$`
    attribute records) get only the lyric step, which is a no-op for them."""
    parts = list(score.parts)
    try:
        chunks = read_part_chunks(input_path, part_files)
    except OSError:
        chunks = []
    infos = [scan_chunk(c) for c in chunks]
    stage2 = bool(infos) and all(any(('K' in i or 'T' in i) for _k, i in inf['attrs'])
                                 for inf in infos)

    if stage2 and len(infos) == len(parts):
        translated = {}
        for part, info in zip(parts, infos):
            label = part.partName or 'a part'
            n_measures = len(list(part.getElementsByClass(stream.Measure)))
            if n_measures != info['n_measures']:
                warnings.warn(f"{label}: the raw MuseData records imply {info['n_measures']} "
                              f"measures (segments with notes) but music21 built {n_measures}, "
                              f"so its mid-part meter/key changes and bar numbers were left "
                              f"as music21 read them.", MuseDataPostprocessWarning)
                continue
            _apply_attributes(part, info, label, translated)
            _renumber_from_labels(part, info)
        if translated:
            bits = '; '.join(f"{code} -> " + ' / '.join(f"{new} ({length:g} quarters)"
                                                        for new, length in sorted(vals))
                             for code, vals in sorted(translated.items()))
            warnings.warn(f"MuseData special meter code(s) taken from the music's own bar "
                          f"lengths (music21 would have read them all as 4/4): {bits}.",
                          MuseDataPostprocessWarning)
    elif stage2:
        warnings.warn(f"MuseData: found {len(infos)} part(s) in the raw text but music21 built "
                      f"{len(parts)}; mid-part meter/key changes and bar numbers were left as "
                      f"music21 read them.", MuseDataPostprocessWarning)

    for part in parts:
        normalize_lyrics(part)
    return score
