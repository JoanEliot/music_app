"""
importers/musicxml_importer.py

MusicXML -> music21.stream.Score. There is no project-specific logic
here for the common case -- MusicXML is already this pipeline's own
in-memory currency (see the architecture doc's "Core decision"
section: a music21.stream.Score *is* the shared representation, and
MusicXML export is close to free because of it). This module exists
mainly so MusicXML has the same import_score(input_path, **options)
-> Score interface as musedata_importer and humdrum_importer, so
core.import_pipeline can treat all three (and any future format)
identically rather than special-casing MusicXML as "the one that
doesn't need an importer."

Accepts .musicxml and .xml (uncompressed) and .mxl (zip-compressed) --
whatever music21's own converter recognizes as MusicXML.

ONE THING THIS MODULE DOES HANDLE: an input file that ALREADY correctly
encodes genuine cross-staff notation -- a single instrument's part
declaring more than one staff, with per-note <staff> tags -- e.g. a
piano piece with a passage crossing between the two hands' staves,
using a single continuous beam/tuplet bracket. Confirmed empirically,
independent of anything in this pipeline, that plain music21
parse-then-write on such a file corrupts it even with ZERO
modification in between: phantom tuplet ratios appear, because
music21's own reader splits a single multi-staff <part> into several
separate internal Part objects (named "{original-id}-Staff{n}",
confirmed reliable across a real reference file) before any writing
happens, and its writer cannot correctly rejoin them into one
continuous bracket. Since the ORIGINAL file's own encoding of this
content is, by definition, already correct, the fix here doesn't need
to rebuild anything (contrast importers/lilypond_importer.py, which
has no already-correct MusicXML to fall back on and so has to build
one from scratch via importers/multi_staff_emitter.py): it simply
preserves that part's original XML verbatim in the output, via the
same score._manual_multistaff_parts mechanism (see core/import_
pipeline.py's run_job()) multi_staff_emitter-based importers use,
rather than letting music21 touch it at all.
"""

import re
import warnings
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

from core.score_metadata import attach_metadata, new_metadata
from .musicxml_metadata import extract_metadata


class MusicXMLMetadataWarning(UserWarning):
    """Raised when a file's metadata block couldn't be read; the notes
    still import, with an empty metadata dict."""


def _read_raw_xml_text(input_path: Path) -> str:
    """The raw MusicXML text, transparently unzipping a compressed
    .mxl the same way music21's own converter does (via META-INF/
    container.xml's own pointer to the real entry, falling back to the
    first non-META .xml/.musicxml archive member if that's missing)."""
    if zipfile.is_zipfile(input_path):
        with zipfile.ZipFile(input_path) as zf:
            names = zf.namelist()
            target = None
            if 'META-INF/container.xml' in names:
                container = zf.read('META-INF/container.xml').decode('utf-8', errors='ignore')
                m = re.search(r'full-path="([^"]+)"', container)
                if m and m.group(1) in names:
                    target = m.group(1)
            if target is None:
                target = next((n for n in names if not n.startswith('META-INF')
                               and n.lower().endswith(('.xml', '.musicxml'))), None)
            if target is None:
                raise RuntimeError(f"Could not find a MusicXML entry inside {input_path}")
            return zf.read(target).decode('utf-8', errors='ignore')
    return input_path.read_text(encoding='utf-8', errors='ignore')


def _find_multistaff_parts(raw_xml: str) -> dict:
    """{part_id: (score_part_xml, part_xml)} for every <part> in the
    RAW input that declares more than one staff (<staves>N</staves>
    with N > 1) -- i.e. already-correct genuine cross-staff notation,
    to be preserved byte-for-byte rather than rebuilt (see module
    docstring)."""
    result = {}
    for part_match in re.finditer(r'<part id="([^"]+)">(.*?)</part>', raw_xml, re.S):
        part_id, part_body = part_match.group(1), part_match.group(0)
        staves_match = re.search(r'<staves>(\d+)</staves>', part_body)
        if staves_match and int(staves_match.group(1)) > 1:
            score_part_match = re.search(
                rf'<score-part id="{re.escape(part_id)}">.*?</score-part>', raw_xml, re.S)
            if score_part_match:
                result[part_id] = (score_part_match.group(0), part_body)
    return result


def import_score(input_path, **options):
    """Parse a MusicXML file into a music21 Score. `options` is accepted
    for interface consistency with the other importers but MusicXML
    currently takes none."""
    from music21 import converter

    input_path = Path(input_path)
    raw_xml = _read_raw_xml_text(input_path)
    multistaff_parts = _find_multistaff_parts(raw_xml)

    score = converter.parse(str(input_path), forceSource=True)

    # Work-level metadata (title, people, rights, source, dates, ...) is
    # read from the raw XML, not from music21's Score: see
    # importers/musicxml_metadata.py for why.
    try:
        attach_metadata(score, extract_metadata(raw_xml, input_path))
    except (ET.ParseError, ValueError) as e:
        warnings.warn(f"{input_path}: could not read metadata ({e}); "
                      f"continuing with none.", MusicXMLMetadataWarning)
        attach_metadata(score, new_metadata('musicxml', input_path))

    if multistaff_parts:
        manual_parts = []
        for original_id, (score_part_xml, part_xml) in multistaff_parts.items():
            # music21's reader splits a multi-staff part into several
            # Parts named "{original_id}-Staff{n}", in staff order --
            # confirmed against a real reference file. Their POSITIONS
            # in score.parts (not their ids, which core.import_
            # pipeline's splicer can't predict either way -- see its
            # own docstring) are what the splicer needs.
            prefix = f'{original_id}-Staff'
            indices = [i for i, p in enumerate(score.parts) if str(p.id).startswith(prefix)]
            if indices:
                manual_parts.append({
                    'original_part_indices': indices,
                    'score_part_xml': score_part_xml.replace(f'id="{original_id}"',
                                                              'id="PLACEHOLDER_PART_ID"'),
                    'part_xml': part_xml.replace(f'id="{original_id}"',
                                                  'id="PLACEHOLDER_PART_ID"'),
                })
        if manual_parts:
            score._manual_multistaff_parts = manual_parts

    return score
