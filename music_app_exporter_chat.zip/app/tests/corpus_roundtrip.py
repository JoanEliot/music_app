"""Round-trip music21-corpus pieces through the LilyPond exporter: python3 tests/corpus_roundtrip.py bach/bwv66.6 joplin/maple_leaf_rag ..."""
import sys, warnings, tempfile, traceback
from pathlib import Path; sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from music21 import corpus
from importers import musicxml_importer as mx
from tests.roundtrip import roundtrip
names = sys.argv[1:]
for n in names:
    w = corpus.getWork(n)
    ws = w if isinstance(w, list) else [w]
    p = str([x for x in ws if str(x).endswith(('.mxl','.xml','.musicxml'))][0])
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            s = mx.import_score(p)
        r = roundtrip(s, tempfile.mkdtemp(), n.replace('/','_'))
        print('==', n, 'rc', r['returncode'], 'parts', len(s.parts))
        print('  lilypond problems:', len(r['lilypond_problems']), r['lilypond_problems'][:3])
        print('  export warnings:', r['export_warnings'])
        print('  diffs:', len(r['diffs']), r['diffs'][:4])
        print('  ly:', r['ly'])
    except Exception as e:
        print('==', n, 'EXC', repr(e)[:300]); traceback.print_exc(limit=3)
