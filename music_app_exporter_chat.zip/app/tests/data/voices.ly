\version "2.24.3"
\score { \new Staff { \time 4/4
  << { c''4 d'' e'' f'' } \\ { c'2 g' } \\ { c4 c c c } >> |
  c''1 |
  << { c''2. d''4~ } \\ { e'4 r g' r } >> |
  << { d''2 r } \\ { r2 a'2 } >> |
  <c' e'~ g'>2 <c' e' g'> r1 |
} }
