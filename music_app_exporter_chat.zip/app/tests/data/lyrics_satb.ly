\version "2.24.3"
sop = { \time 4/4 c''4 d'' e'' f'' | g''2 e''2 | c''1 \bar "|." }
alto = { \time 4/4 e'4 f' g' a' | b'2 g'2 | e'1 }
tenor = { \clef bass \time 4/4 g4 a b c' | d'2 c'2 | g1 }
bass = { \clef bass \time 4/4 c4 f g f | g2 c2 | c1 }
\score { <<
  \new Staff << \new Voice = "s" { \voiceOne \sop } \new Voice = "a" { \voiceTwo \alto } >>
  \new Lyrics \lyricsto "s" { \lyricmode { A -- men, a -- men, praise "the" Lord } }
  \new Lyrics \lyricsto "a" { \lyricmode { A -- men, a -- men, sing "to" Lord } }
  \new Staff << \new Voice = "t" { \voiceOne \tenor } \new Voice = "b" { \voiceTwo \bass } >>
>> }
