\version "2.24.3"
melody = { \time 3/4 \partial 4 g'4 | c''2 b'4 | a'4 g' f' | e'2 r4 | c'2. \bar "|." }
\score { << \new Staff \new Voice = "m" \melody
  \new Lyrics \lyricsto "m" { \lyricmode { Hel -- lo dear, "good" -- bye my "friend." } }
  \new Lyrics \lyricsto "m" { \lyricmode { A -- ha, oh what a "day!" } } >> }
