\version "2.24.3"
\score { << \new Staff { \time 4/4 \clef treble
  \repeat volta 2 { c''1 | d''1 } \alternative { { e''1 } { f''1 | g''1 } } a''1 | b''1 \bar "|." }
  \new Staff { \time 4/4 \clef bass
  \repeat volta 2 { c1 | d1 } \alternative { { e1 } { f1 | g1 } } a1 | b1 \bar "|." } >> }
