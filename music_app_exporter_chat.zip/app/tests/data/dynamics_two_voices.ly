\version "2.24.3"
\score { \new Staff << \new Voice = "a" { \voiceOne c''4\p\< d'' e'' f''\! | g''4\f g'' g'' g'' } \new Voice = "b" { \voiceTwo e'2\mf g'2 | c'1 } >> }
