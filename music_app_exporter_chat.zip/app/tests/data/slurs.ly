\version "2.24.3"
\score { \new Staff { \time 4/4
  c'4( d' e' f') | g'4\( a'( b') c''\) | d''1( | e''1) | c''4( d'') e''( f'') | g''1 |
} }
