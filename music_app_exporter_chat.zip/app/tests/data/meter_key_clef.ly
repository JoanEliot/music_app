\version "2.24.3"
\score { \new Staff { \clef treble \key g \major \time 3/4
  g'4 a' b' | c''4 \clef bass c4 d | \key f \major \time 6/8 e8 f g a bes c' | \clef alto \key bes \minor \time 2/4 d'4 c' |
  \time 5/8 c'8 d' e' f' g' | \time 4/4 c'1 \bar "||" | \clef tenor c'1 \bar "|."
} }
