\version "2.24.3"
\score { \new Staff { \time 4/4
  c'1 | \repeat volta 2 { d'1 | e'1 } f'1 | \repeat volta 3 { g'1 } a'1 \bar "|." } }
