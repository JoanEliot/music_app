\version "2.24.3"
\score { \new Staff { \time 4/4
  c'4\p d' e'\< f' | g'4\f a'\> b' c''\! | d''4\mf\< e'' f'' g''\ff | a''1\sfz \bar "|." } }
