\version "2.24.3"
\score { \new Staff { \time 3/4 \partial 4 c'4 | d'4 e' f' | g'4 a' b' | \time 4/4 c''2 r | d''4 e'' \bar "|." } }
