\version "2.24.3"
\score { \new PianoStaff << \new Staff { \clef treble \time 2/4 c''8 d'' e'' f'' | g''2 } \new Staff { \clef bass \time 2/4 c4 g, | c2 } >> }
