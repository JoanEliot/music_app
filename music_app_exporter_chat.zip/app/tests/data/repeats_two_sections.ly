\version "2.24.3"
\score { \new Staff { \time 3/4 \partial 4 c'4 |
  \repeat volta 2 { d'2 e'4 | f'2 g'4 } \alternative { { a'2 b'4 } { c''2 r4 } }
  \repeat volta 2 { d''2. | c''2. } d''2. \bar "|." } }
