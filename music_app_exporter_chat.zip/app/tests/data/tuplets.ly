\version "2.24.3"
\score { \new Staff { \time 4/4
  \tuplet 3/2 { c'8 d' e' } \tuplet 3/2 { f'8 g' a' } \tuplet 3/2 { b'4 c'' d'' } |
  \tuplet 5/4 { c'16 d' e' f' g' } \tuplet 5/4 { a'16 b' c'' d'' e'' } r2 |
  \tuplet 3/2 { c'4 \tuplet 3/2 { d'8 e' f' } g'4 } c'2 |
  \tuplet 3/2 { c'2 d'2 e'2 } |
  \tuplet 3/2 { c'8. d'8. e'8. } r2 r8 |
} }
