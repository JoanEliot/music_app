\version "2.24.3"
\score { << \new Staff { \transposition bes \clef treble \key d \major \time 4/4 d''4 e'' fis'' g'' | a''1 }
            \new Staff { \transposition ees \clef treble \key b \major \time 4/4 b'4 cis'' dis'' e'' | fis''1 }
            \new Staff { \clef bass \key c \major \time 4/4 c4 d e f | g1 } >> }
