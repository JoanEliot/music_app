\version "2.24.3"
\score { \new Staff { \time 4/4
  \grace { c''8 } d''4 \acciaccatura { e''8 } f''4 \appoggiatura { g''8 } a''4 \grace { b'16 c''16 } d''4 | c''1 |
} }
