\version "2.24.3"
melody = { \time 4/4 c'2~ c'4 d'4 | e'4( f' g') a' | b'4 r c''2 | d''1 \bar "|." }
\score { << \new Staff \new Voice = "m" \melody
  \new Lyrics \lyricsto "m" { \lyricmode { one two three -- four five six } } >> }
