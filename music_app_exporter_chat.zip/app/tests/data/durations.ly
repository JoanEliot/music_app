\version "2.24.3"
\score { \new Staff {
  \time 8/4 c'\breve | \time 4/4 c'1~ | c'1 | c'2.~ c'4 | c'8.. c'64 c'128 r128 r8. c'4 r4 r16 | R1 | r1 | s1 | c'16 c' c' c' c'8 c' c'2 |
} }
