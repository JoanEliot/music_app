\version "2.24.3"
\score { \new Staff { \time 4/4 \tempo "Allegro" 4 = 120 c'1 | \tempo 4 = 90 d'1 | \tempo "Adagio" e'1 | \tempo 4. = 60 f'1 | } }
