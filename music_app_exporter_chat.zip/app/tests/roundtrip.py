r"""
tests/roundtrip.py

Verification harness for exporters/lilypond.py.

  score --emit--> .ly --lilypond--> (barcheck / warning / error lines)
                    \--importer--> score' ; compare(score, score')

`signature()` flattens a Score to what the export is responsible for
keeping, deliberately ignoring what a LilyPond round trip legitimately
changes (Voice object structure, measure offsets, beam objects, metadata):
per part, per measure, the sorted (offset, length, pitches, rest?, tied?)
of every note, plus the clef/key/time in force at each measure.
"""
import sys, warnings, tempfile
from fractions import Fraction
from pathlib import Path

from music21 import bar, chord, clef, dynamics, key, meter, note, spanner, stream, tempo
from music21.common import opFrac

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from exporters import lilypond as ly


def _f(x):
    return Fraction(opFrac(x))


def _lyric_texts(el):
    from core.lyrics import _key_of, _sortable
    # The LilyPond importer returns a soft hyphen (U+00AD) in lyric text as the
    # four characters \\xad (its s-expression reader does not decode the
    # escape); undone here so it does not mask real differences.
    import re
    fix = lambda t: re.sub(r'\\x([0-9a-fA-F]{2})', lambda m: chr(int(m.group(1), 16)), t)
    return tuple(fix(l.text) for l in sorted(el.lyrics, key=lambda l: _sortable(_key_of(l))))


def signature(score):
    sig = []
    for part in score.parts:
        rows = []
        slur_s, slur_e = {}, {}
        for sl in part.recurse().getElementsByClass(spanner.Slur):
            els = list(sl.getSpannedElements())
            if len(els) >= 2:
                slur_s[id(els[0])] = slur_s.get(id(els[0]), 0) + 1
                slur_e[id(els[-1])] = slur_e.get(id(els[-1]), 0) + 1
        brackets = {}
        for b in part.recurse().getElementsByClass(spanner.RepeatBracket):
            for mm in b.getSpannedElements():
                brackets.setdefault(id(mm), []).append(str(b.number))
        for mi, m in enumerate(part.getElementsByClass(stream.Measure)):
            notes = []
            for el in m.recurse().notesAndRests:
                if isinstance(el, chord.Chord) and type(el).__name__ != 'Chord':
                    continue                     # chord symbols
                off = _f(el.getOffsetInHierarchy(m))
                extra = (_lyric_texts(el), slur_s.get(id(el), 0), slur_e.get(id(el), 0))
                if isinstance(el, note.Rest):
                    notes.append((off, _f(el.quarterLength), (), True, False, (), 0, 0))
                elif isinstance(el, chord.Chord):
                    tied = all(n.tie is not None and n.tie.type in ('start', 'continue')
                               for n in el.notes)
                    notes.append((off, _f(el.quarterLength),
                                  tuple(sorted(n.pitch.nameWithOctave for n in el.notes)),
                                  False, tied) + extra)
                else:
                    tied = el.tie is not None and el.tie.type in ('start', 'continue')
                    notes.append((off, _f(el.quarterLength), (el.pitch.nameWithOctave,),
                                  False, tied) + extra)
            # spacer rests written by the exporter for voice padding are
            # invisible rests; drop rests when comparing (rest identity is
            # checked by the offsets/lengths of the sounding notes around them)
            notes = sorted(n for n in notes if not n[3])
            ks = m.getContextByClass(key.KeySignature)
            ts = m.getContextByClass(meter.TimeSignature)
            cl = m.getContextByClass(clef.Clef)
            rows.append({
                'length': _f(m.highestTime),
                'number': m.number,
                'notes': notes,
                'key': ks.sharps if ks is not None else 0,
                'time': f'{ts.numerator}/{ts.denominator}' if ts is not None else None,
                'clef': (getattr(cl, 'sign', None), getattr(cl, 'line', None)) if cl else None,
                # repeat structure: start bar, end bar, volta bracket numbers
                # (a start bar on the FIRST measure is not compared: LilyPond prints none
                # there, but its importer adds one when it reads \\repeat volta back)
                'rep': (mi > 0 and isinstance(m.leftBarline, bar.Repeat) and m.leftBarline.direction == 'start',
                        isinstance(m.rightBarline, bar.Repeat) and m.rightBarline.direction == 'end',
                        tuple(sorted(brackets.get(id(m), [])))),
            })
        # Grace notes written at the END of a bar in the source are exported
        # before the first note of the next bar (which is where they sound);
        # compare them there.
        for i, row in enumerate(rows):
            end = [n for n in row['notes'] if n[1] == 0 and n[0] >= row['length'] > 0]
            if end and i + 1 < len(rows):
                row['notes'] = sorted(n for n in row['notes'] if n not in end)
                rows[i + 1]['notes'] = sorted(rows[i + 1]['notes'] + [(0,) + n[1:] for n in end])
        wedges = []
        for w in part.recurse().getElementsByClass(dynamics.DynamicWedge):
            els = list(w.getSpannedElements())
            if not els:
                continue
            def where(e):
                mm = e.getContextByClass(stream.Measure)
                return (mm.number if mm is not None else None, _f(e.getOffsetInHierarchy(mm)) if mm is not None else None)
            wedges.append((type(w).__name__, where(els[0]), where(els[-1]), len(els)))
        # Dynamics as a sequence over the whole part: one that stands where no
        # note starts (a pickup bar of rests, a gap between notes) is written
        # on the next note, so its bar can change. Marks LilyPond has no command
        # for are written as text and cannot be read back, so they are left out.
        dseq = [d.value for d in sorted(part.recurse().getElementsByClass(dynamics.Dynamic),
                                        key=lambda d: d.getOffsetInHierarchy(part))
                if d.value in ly._DYNAMIC_KNOWN]
        rows.append({'wedges': sorted(wedges, key=lambda x: str(x[1])), 'dseq': dseq})
        sig.append(rows)
    marks = set()
    for part in score.parts:
        for m in part.recurse().getElementsByClass(tempo.TempoIndication):
            num = None if getattr(m, 'numberImplicit', False) else getattr(m, 'number', None)
            text = None if getattr(m, 'textImplicit', False) else getattr(m, 'text', None)
            if num is None and not text:
                continue                      # music21 placeholder marks
            mm = m.getContextByClass(stream.Measure)
            marks.add((mm.number if mm is not None else None,
                       _f(m.getOffsetInHierarchy(mm)) if mm is not None else None,
                       round(float(num)) if num is not None else None, text or None))
    sig.append({'tempo': marks})
    return sig


def compare(a, b):
    """List of human-readable differences between two signatures."""
    diffs = []
    ta, tb = a[-1]['tempo'], b[-1]['tempo']
    if ta != tb:
        diffs.append(f'tempo marks: original-only {sorted(ta - tb, key=str)[:3]} '
                     f'export-only {sorted(tb - ta, key=str)[:3]}')
    a, b = a[:-1], b[:-1]
    if len(a) != len(b):
        return diffs + [f'part count {len(a)} vs {len(b)}']
    for pi, (pa, pb) in enumerate(zip(a, b)):
        wa, wb = pa[-1]['wedges'], pb[-1]['wedges']
        if pa[-1]['dseq'] != pb[-1]['dseq']:
            diffs.append(f'part {pi}: dynamics differ; original {pa[-1]["dseq"][:8]} '
                         f'export {pb[-1]["dseq"][:8]}')
        pa, pb = pa[:-1], pb[:-1]
        # a hairpin over ONE note is written to end on the next note
        same = (len(wa) == len(wb) and all(
            x[0] == y[0] and x[1] == y[1] and (x[2] == y[2] or x[3] == 1 or y[3] == 1)
            for x, y in zip(wa, wb)))
        if not same:
            diffs.append(f'part {pi}: hairpins differ; original {wa[:3]} export {wb[:3]}')
        if len(pa) != len(pb):
            diffs.append(f'part {pi}: {len(pa)} vs {len(pb)} measures')
        for ma, mb in zip(pa, pb):
            for field in ('key', 'time', 'clef', 'rep'):
                if ma[field] != mb[field]:
                    diffs.append(f'part {pi} m{ma["number"]}: {field} {ma[field]} vs {mb[field]}')
            if ma['notes'] != mb['notes']:
                only_a = [n for n in ma['notes'] if n not in mb['notes']]
                only_b = [n for n in mb['notes'] if n not in ma['notes']]
                diffs.append(f'part {pi} m{ma["number"]}: notes differ; '
                             f'original-only {only_a[:3]} export-only {only_b[:3]}')
    return diffs


def roundtrip(score, workdir, name='rt', keep_png=True):
    """Emit, compile, reimport, compare. Returns a dict of results."""
    from importers import lilypond_importer as li
    workdir = Path(workdir); workdir.mkdir(parents=True, exist_ok=True)
    ly_path = workdir / f'{name}.ly'
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        ly.write_lilypond(score, ly_path, midi=True)
    export_warnings = [str(x.message) for x in w if issubclass(x.category, ly.LilyExportWarning)]
    rc, err = ly.compile_lilypond(ly_path, workdir, formats=('png',) if keep_png else ())
    problems = ly.lilypond_problems(err)
    # (The LilyPond importer reads each ChordNames line as an extra staff, so the
    # copy it reads back is written without them; chord names are checked by
    # tests/test_chords.py and the unit tests.)
    ly_read = workdir / f'{name}_nochords.ly'
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        ly.write_lilypond(score, ly_read, midi=False, chord_names=False)
    # "unterminated tie" means the SOURCE has a tie with no note to end on
    # (seen in corpus files); LilyPond is reporting the source, not us.
    source_ties = [l for l in problems if 'unterminated tie' in l]
    problems = [l for l in problems if 'unterminated tie' not in l]
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        back = li.import_score(ly_read)
    diffs = compare(signature(score), signature(back))
    return {'ly': ly_path, 'returncode': rc, 'lilypond_problems': problems, 'source_tie_defects': len(source_ties),
            'export_warnings': export_warnings, 'diffs': diffs}


if __name__ == '__main__':
    from importers import lilypond_importer as li
    src = sys.argv[1]
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        s = li.import_score(src)
    r = roundtrip(s, tempfile.mkdtemp(), Path(src).stem)
    for k, v in r.items():
        print(k, ':', v)
