"""
tests/midi_compare.py

Independent check of the LilyPond exporter: the .midi LilyPond writes from
our .ly must contain the same notes as the MIDI music21 writes from the
same Score -- same pitches at the same times for the same lengths. Any
pitch, duration, tie, or transposition bug in the exporter shows up here
without any human reading the notation. (Velocity and instrument are not
compared; the exporter writes neither yet.)
"""
import sys, tempfile, warnings
from collections import Counter
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from music21 import converter, chord, note
from exporters import lilypond as ly


def midi_notes(path):
    """Multiset of (onset, length, midi pitch), in quarters, rounded."""
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        s = converter.parse(str(path))
    out = Counter()
    for el in s.flatten().notes:
        ps = [n.pitch.midi for n in el.notes] if isinstance(el, chord.Chord) else [el.pitch.midi]
        for p in ps:
            out[(round(float(el.offset), 2), round(float(el.quarterLength), 2), p)] += 1
    return out


def _relay_measures(score):
    """WORKAROUND, remove when the LilyPond importer is fixed: it places the
    first full bar after a pickup at offset = a full bar's length, leaving a
    phantom gap that music21's MIDI writer (unlike MusicXML output) plays
    as silence. Lay every part's measures end to end by their real length."""
    from music21 import stream
    for part in score.parts:
        pos = 0
        for m in part.getElementsByClass(stream.Measure):
            part.setElementOffset(m, pos)
            pos += float(m.highestTime) if m.highestTime else float(m.duration.quarterLength)


def compare_midi(score, workdir, name='m'):
    # The pipeline marks pickups / short bars before any export
    # (import_pipeline.prepare_score); without it music21's MIDI writer pads
    # a short bar to full length. Idempotent, so safe on prepared scores.
    from core.measures import mark_short_measures
    import copy
    mark_short_measures(score)
    # Grace notes sit outside bar time and LilyPond plays them BEFORE the
    # beat, stealing time from the note before, while music21 places them
    # differently; the two MIDI files cannot be compared on them. Both sides
    # are compared without grace notes (the notation round trip and the
    # rendered page are what check them).
    score = copy.deepcopy(score)
    for n in list(score.recurse().notes):
        if n.duration.isGrace:
            n.activeSite.remove(n)
    workdir = Path(workdir); workdir.mkdir(parents=True, exist_ok=True)
    ly_path = workdir / f'{name}.ly'
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        ly.write_lilypond(score, ly_path, midi=True)
    rc, err = ly.compile_lilypond(ly_path, workdir, formats=())
    ly_mid = workdir / f'{name}.midi'
    m21_mid = workdir / f'{name}_m21.mid'
    # LilyPond's MIDI plays every repeat pass (\\unfoldRepeats), so the
    # music21 side must be unfolded the same way before writing.
    from transforms.unfold_repeats import unfold_repeats
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        unfolded = unfold_repeats(score)
        _relay_measures(unfolded)
        unfolded.write('midi', fp=str(m21_mid))
    a, b = midi_notes(m21_mid), midi_notes(ly_mid)
    # Onset + pitch must match exactly. LilyPond's MIDI shortens articulated
    # notes (staccato etc.) where music21 does not, so a SHORTER LilyPond note
    # is not a finding; a note that is LONGER in LilyPond's MIDI is.
    ka = Counter((o, p) for (o, _, p), n in a.items() for _ in range(n))
    kb = Counter((o, p) for (o, _, p), n in b.items() for _ in range(n))
    only_m21, only_ly = ka - kb, kb - ka
    da, db = {}, {}
    for (o, l, p), n in a.items():
        da.setdefault((o, p), []).append(l)
    for (o, l, p), n in b.items():
        db.setdefault((o, p), []).append(l)
    longer = sorted((k, max(db[k]), max(da[k])) for k in db
                    if k in da and max(db[k]) > max(da[k]) + 0.011)
    return {'m21_notes': sum(a.values()), 'ly_notes': sum(b.values()),
            'onset_pitch_only_music21': sorted(only_m21.elements())[:5],
            'onset_pitch_only_lilypond': sorted(only_ly.elements())[:5],
            'n_onset_pitch_diff': sum(only_m21.values()) + sum(only_ly.values()),
            'n_longer_in_lilypond': len(longer), 'longer_examples': longer[:3]}


if __name__ == '__main__':
    from music21 import corpus
    from importers import musicxml_importer as mx, lilypond_importer as li
    for n in sys.argv[1:]:
        if n.endswith('.ly'):
            with warnings.catch_warnings():
                warnings.simplefilter('ignore'); s = li.import_score(n)
        else:
            w = corpus.getWork(n); ws = w if isinstance(w, list) else [w]
            p = [x for x in ws if str(x).endswith(('.mxl', '.xml', '.musicxml'))][0]
            with warnings.catch_warnings():
                warnings.simplefilter('ignore'); s = mx.import_score(str(p))
        r = compare_midi(s, tempfile.mkdtemp(), Path(n).stem)
        print(n, r)
