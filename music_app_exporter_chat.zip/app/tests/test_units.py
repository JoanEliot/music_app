"""
tests/test_units.py -- checks that build a Score directly in music21 (so they
do not depend on what the LilyPond importer can read back), emit it, and check
the text AND that LilyPond compiles it with no warnings.  Run:
    python3 tests/test_units.py
"""
import sys, tempfile, warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from music21 import (chord, clef, instrument, meter, note, spanner, stream, tie,
                     harmony)
from exporters import lilypond as ly


def part_score(measure_items, *, part_setup=None, spanners=()):
    p = stream.Part()
    if part_setup:
        part_setup(p)
    m = stream.Measure(number=1)
    m.append([clef.TrebleClef(), meter.TimeSignature('4/4')])
    m.append(measure_items)
    p.append(m)
    for sp in spanners:
        p.insert(0, sp)
    sc = stream.Score()
    sc.append(p)
    return sc


def emit(sc):
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        text = ly.score_to_lilypond(sc)
    d = tempfile.mkdtemp()
    Path(d, 'x.ly').write_text(text)
    rc, err = ly.compile_lilypond(Path(d, 'x.ly'), d, formats=())
    return text, ly.lilypond_problems(err), [str(x.message) for x in w]


def test_slur_ending_on_grace_note():
    a, b = note.Note('G5', quarterLength=1), note.Note('A5', quarterLength=1)
    g = note.Note('B4').getGrace(); g.duration.type = '16th'
    c = note.Note('C6', quarterLength=2)
    text, problems, _ = emit(part_score([a, b, g, c], spanners=[spanner.Slur([a, b, g])]))
    assert "g''4( a'' \\acciaccatura { b'16) } c'''2" in text, text
    assert not problems, problems


def test_partial_chord_tie_is_per_pitch():
    c1 = chord.Chord(['C4', 'E4', 'G4'], quarterLength=2); c1.notes[1].tie = tie.Tie('start')
    c2 = chord.Chord(['E4', 'A4'], quarterLength=2); c2.notes[0].tie = tie.Tie('stop')
    text, problems, _ = emit(part_score([c1, c2]))
    assert "<c' e'~ g'>2 <e' a'>" in text, text
    assert not problems, problems


def test_transposing_instruments():
    cases = [(instrument.Clarinet, 'bes'), (instrument.EnglishHorn, 'f'),
             (instrument.AltoSaxophone, 'ees'), (instrument.Piccolo, "c''"),
             (instrument.Contrabass, 'c')]
    for cls, expected in cases:
        def setup(p, cls=cls):
            p.insert(0, cls()); p.atSoundingPitch = False
        text, problems, _ = emit(part_score([note.Note('C5', quarterLength=4)], part_setup=setup))
        assert f'\\transposition {expected}\n' in text, (cls.__name__, text)
        assert not problems, problems


def test_lyrics_melisma_default_and_ignore_modes():
    # tie + slur where the source agrees with LilyPond's melisma rule: default mode
    ns = [note.Note('C5', quarterLength=2), note.Note('C5', quarterLength=1),
          note.Note('D5', quarterLength=1)]
    ns[0].tie = tie.Tie('start'); ns[1].tie = tie.Tie('stop')
    ns[0].addLyric('one'); ns[2].addLyric('two')
    text, problems, _ = emit(part_score(ns))
    assert 'ignoreMelismata' not in text and 'one two' in text, text
    assert not problems, problems
    # the tied-to note carries its own syllable: the verse must switch to ignoreMelismata
    ns2 = [note.Note('C5', quarterLength=2), note.Note('C5', quarterLength=1),
           note.Note('D5', quarterLength=1)]
    ns2[0].tie = tie.Tie('start'); ns2[1].tie = tie.Tie('stop')
    ns2[0].addLyric('one'); ns2[1].addLyric('two'); ns2[2].addLyric('three')
    text, problems, _ = emit(part_score(ns2))
    assert 'ignoreMelismata = ##t' in text and 'one two three' in text, text
    assert not problems, problems


def test_no_dangling_hyphen_at_end_of_verse():
    ns = [note.Note('C5', quarterLength=2), note.Note('D5', quarterLength=2)]
    ns[0].addLyric('la', applyRaw=False); ns[0].lyrics[0].syllabic = 'begin'
    ns[1].addLyric('la'); ns[1].lyrics[0].syllabic = 'begin'      # source says "continues"
    text, problems, _ = emit(part_score(ns))
    assert 'la -- la\n' in text and 'la -- la --' not in text, text
    assert not problems, problems


def test_trailing_grace_goes_before_next_bar():
    p = stream.Part()
    m1, m2 = stream.Measure(number=1), stream.Measure(number=2)
    m1.append([clef.TrebleClef(), meter.TimeSignature('4/4'), note.Note('C5', quarterLength=4)])
    g = note.Note('B4').getGrace()
    m1.append(g)                                        # at the very end of bar 1
    m2.append(note.Note('D5', quarterLength=4))
    p.append([m1, m2]); sc = stream.Score(); sc.append(p)
    text, problems, _ = emit(sc)
    assert "{ b'4 } d''1" in text and text.index("b'4") > text.index("c''1"), text   # (getGrace keeps the quarter value)
    assert not problems, problems


# --- beams, chord names, tempo, dynamics -------------------------------------

def _eighths_measure(n_notes=4, pitches=('C5', 'D5', 'E5', 'F5'), lyrics=False):
    ns = [note.Note(p, quarterLength=0.5) for p in pitches[:n_notes]]
    return ns


def test_explicit_beams_and_autobeam_off():
    ns = _eighths_measure(8, ('C5', 'D5', 'E5', 'F5', 'G5', 'A5', 'B5', 'C6'))
    sc = part_score(ns)
    sc.parts[0].getElementsByClass(stream.Measure)[0].makeBeams(inPlace=True)
    text, problems, _ = emit(sc)
    assert '\\autoBeamOff' in text, text
    # (music21 beams eighths in pairs in 4/4; the export reproduces exactly that)
    assert "c''8[ d''] e''[ f''] g''[ a''] b''[ c''']" in text, text
    assert not problems, problems


def test_no_beam_data_leaves_automatic_beaming():
    text, problems, _ = emit(part_score(_eighths_measure(4)))
    assert '\\autoBeamOff' not in text and '[' not in text.split('music')[1].split('\\score')[0], text
    assert not problems, problems


def test_unbeamed_notes_stay_unbeamed_when_source_has_beams():
    # one beamed pair and two deliberately flagged (unbeamed) eighths
    ns = _eighths_measure(4, ('C5', 'D5', 'E5', 'F5'))
    from music21 import beam
    ns[0].beams.append('start'); ns[1].beams.append('stop')       # E5, F5 carry no beams
    text, problems, _ = emit(part_score(ns + [note.Rest(quarterLength=2)]))
    assert "c''8[ d''] e'' f''" in text and '\\autoBeamOff' in text, text
    assert not problems, problems


def test_secondary_beam_break_is_reproduced():
    ns = [note.Note(p, quarterLength=0.25) for p in ('C5', 'D5', 'E5', 'F5')]
    ns[0].beams.fill(2, 'start'); ns[1].beams.fill(2, 'continue')
    ns[2].beams.fill(2, 'continue'); ns[3].beams.fill(2, 'stop')
    # break the secondary beam between the 2nd and 3rd notes (one beam continues)
    for n, types in ((ns[0], ['start', 'start']), (ns[1], ['continue', 'stop']),
                     (ns[2], ['continue', 'start']), (ns[3], ['stop', 'stop'])):
        n.beams.beamsList = []
        for lvl, t in enumerate(types, start=1):
            n.beams.append(t) if lvl == 1 else n.beams.append(t)
    text, problems, _ = emit(part_score(ns + [note.Rest(quarterLength=3)]))
    assert 'stemRightBeamCount = #1' in text and 'stemLeftBeamCount = #1' in text, text
    assert not problems, problems


def test_lyrics_not_swallowed_by_explicit_beams():
    ns = _eighths_measure(4)
    ns[0].beams.append('start'); ns[1].beams.append('continue')
    ns[2].beams.append('continue'); ns[3].beams.append('stop')
    for i, w in enumerate(('one', 'two', 'three', 'four')):
        ns[i].addLyric(w)
    text, problems, _ = emit(part_score(ns + [note.Rest(quarterLength=2)]))
    assert 'melismaBusyProperties' in text and 'ignoreMelismata' not in text, text
    assert not problems, problems


def test_chord_names_line():
    from music21 import harmony
    m_items = [harmony.ChordSymbol('Cm7'), note.Note('C5', quarterLength=2),
               note.Note('D5', quarterLength=2)]
    cs2 = harmony.ChordSymbol('G7'); cs2.offset = 2
    sc = part_score(m_items)
    sc.parts[0].getElementsByClass(stream.Measure)[0].insert(2.0, cs2)
    text, problems, _ = emit(sc)
    assert '\\new ChordNames \\chordmode' in text and 'c2:m7 g2:7' in text, text
    assert not problems, problems


def test_no_chord_and_bar_carry_over():
    from music21 import harmony
    p = stream.Part()
    for n in (1, 2, 3):
        m = stream.Measure(number=n)
        if n == 1:
            m.append([clef.TrebleClef(), meter.TimeSignature('4/4')])
        m.append(note.Note('C5', quarterLength=4))
        p.append(m)
    cs = harmony.ChordSymbol('F'); nc = harmony.NoChord()
    p.getElementsByClass(stream.Measure)[0].insert(0, cs)
    p.getElementsByClass(stream.Measure)[2].insert(0, nc)
    sc = stream.Score(); sc.append(p)
    text, problems, _ = emit(sc)
    lines = [l.strip() for l in text.split('\n')]
    i = lines.index('\\new ChordNames \\chordmode {')
    assert lines[i + 1].startswith('f1 |') and lines[i + 2].startswith('s1*1 |') or lines[i + 2].startswith('s1 |'), lines[i:i + 5]
    assert lines[i + 3].startswith('r1 |'), lines[i:i + 5]
    assert not problems, problems


def test_tempo_forms_and_only_one_part_writes_it():
    from music21 import tempo as t
    def mk():
        p = stream.Part(); m = stream.Measure(number=1)
        m.append([clef.TrebleClef(), meter.TimeSignature('4/4')])
        m.insert(0, t.MetronomeMark(number=96, text='Andante'))
        m.append(note.Note('C5', quarterLength=4)); p.append(m); return p
    sc = stream.Score(); sc.append(mk()); sc.append(mk())
    text, problems, _ = emit(sc)
    assert text.count('\\tempo "Andante" 4 = 96') == 1, text
    assert not problems, problems


def test_text_only_tempo_sets_hidden_midi_tempo():
    from music21 import tempo as t
    p = stream.Part(); m = stream.Measure(number=1)
    m.append([clef.TrebleClef(), meter.TimeSignature('4/4')])
    mm = t.MetronomeMark(text='Allegro')                    # number implied by the word
    m.insert(0, mm); m.append(note.Note('C5', quarterLength=4)); p.append(m)
    sc = stream.Score(); sc.append(p)
    text, problems, _ = emit(sc)
    assert '\\tempo "Allegro"' in text and 'tempoWholesPerMinute' in text, text
    assert not problems, problems


def test_two_dynamics_on_one_note_keep_the_later():
    from music21 import dynamics as d
    a = note.Note('C5', quarterLength=4)
    p = stream.Part(); m = stream.Measure(number=1)
    m.append([clef.TrebleClef(), meter.TimeSignature('4/4')])
    m.insert(0, d.Dynamic('p')); m.insert(0.0, d.Dynamic('f')); m.append(a); p.append(m)
    sc = stream.Score(); sc.append(p)
    text, problems, warns = emit(sc)
    assert "c''1\\f" in text and '\\p' not in text.split('music')[1].split('\\score')[0], text
    assert not problems, problems


def test_hairpin_and_dynamic_placement():
    from music21 import dynamics as d
    ns = [note.Note(p, quarterLength=1) for p in ('C5', 'D5', 'E5', 'F5')]
    m_extra = [d.Dynamic('p')]
    wedge = d.Crescendo(ns[0], ns[2])
    sc = part_score(ns, spanners=[wedge])
    sc.parts[0].getElementsByClass(stream.Measure)[0].insert(0, d.Dynamic('p'))
    sc.parts[0].getElementsByClass(stream.Measure)[0].insert(2, d.Dynamic('f'))
    text, problems, _ = emit(sc)
    assert "c''4\\p\\< d'' e''\\f f''" in text, text          # `\f` ends the hairpin: no `\!`
    assert not problems, problems


def test_midi_channels_not_taken_by_lyrics_or_chord_names():
    from music21 import harmony
    sc = stream.Score()
    for k in range(5):                                   # 5 staves, 2 verses each, chord names
        p = stream.Part(); m = stream.Measure(number=1)
        m.append([clef.TrebleClef(), meter.TimeSignature('4/4')])
        n = note.Note('C5', quarterLength=4)
        n.addLyric('la', lyricNumber=1); n.addLyric('da', lyricNumber=2)
        m.insert(0, harmony.ChordSymbol('Cm7')); m.append(n); p.append(m); sc.insert(0, p)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        text = ly.score_to_lilypond(sc, midi=True)
    d = tempfile.mkdtemp()
    Path(d, 'x.ly').write_text(text)
    rc, err = ly.compile_lilypond(Path(d, 'x.ly'), d, formats=())
    assert '\\remove "Staff_performer"' in text, text
    assert not ly.lilypond_problems(err), ly.lilypond_problems(err)      # no "MIDI channel wrapped around"


def test_grace_note_diagnostics_are_reported():
    # a grace note recorded as a quarter, in a voice that holds nothing else
    p = stream.Part(); m = stream.Measure(number=1)
    m.append([clef.TrebleClef(), meter.TimeSignature('4/4')])
    v1, v2 = stream.Voice(), stream.Voice()
    v1.id, v2.id = '1', '2'
    for q in ('C5', 'D5', 'E5', 'F5'):
        v1.append(note.Note(q, quarterLength=1))
    g = note.Note('E5').getGrace()                       # getGrace() keeps the quarter value
    v2.insert(0, note.Rest(quarterLength=1)); v2.insert(1, g); v2.insert(1, note.Rest(quarterLength=3))
    m.insert(0, v1); m.insert(0, v2); p.append(m)
    sc = stream.Score(); sc.append(p)
    text, problems, warns = emit(sc)
    joined = ' '.join(warns)
    assert 'grace notes written as quarter notes' in joined, joined
    assert 'voices holding only rests and grace notes' in joined, joined
    assert not problems, problems


if __name__ == '__main__':
    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith('test_') and callable(fn):
            try:
                fn(); print('ok  ', name)
            except AssertionError as e:
                failed += 1; print('FAIL', name, '\n    ', str(e)[:300])
    sys.exit(1 if failed else 0)
