"""
tests/test_synthetic.py -- feature-by-feature checks for exporters/lilypond.py

Each file in tests/data/*.ly is imported with the LilyPond importer, exported
with the exporter, compiled with LilyPond (any warning -- bar checks
included -- fails), reimported and compared. Run:  python3 tests/test_synthetic.py
"""
import sys, tempfile, warnings
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from tests.roundtrip import roundtrip
from importers import lilypond_importer as li

def run(paths=None):
    ok = True
    for f in sorted(HERE.joinpath('data').glob('*.ly')):
        if paths and f.stem not in paths:
            continue
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            s = li.import_score(f)
        r = roundtrip(s, tempfile.mkdtemp(), f.stem)
        from tests.midi_compare import compare_midi
        mid = compare_midi(s, tempfile.mkdtemp(), f.stem)
        bad = (r['returncode'] != 0 or r['lilypond_problems'] or r['diffs']
               or mid['n_onset_pitch_diff'] or mid['n_longer_in_lilypond'])
        ok &= not bad
        print(('FAIL ' if bad else 'ok   ') + f.stem, '' if not bad else
              f"\n   problems={r['lilypond_problems'][:3]}\n   diffs={r['diffs'][:3]}\n   midi={mid}\n   ly={r['ly']}")
    return ok

if __name__ == '__main__':
    sys.exit(0 if run(sys.argv[1:]) else 1)
