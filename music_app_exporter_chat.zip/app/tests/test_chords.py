"""
tests/test_chords.py -- is the ChordSymbol -> LilyPond \\chordmode mapping right?

Independent check: every chord (all of music21's chord kinds x several roots,
plus modifications and slash chords) is written as \\chordmode NOTES, LilyPond
writes the MIDI, and the pitch classes it plays are compared with what music21
itself says the symbol contains. Run: python3 tests/test_chords.py
"""
import sys, tempfile, warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import mido
from music21 import harmony, interval
from exporters import lilypond as ly


def symbols():
    out = []
    for kind in sorted(harmony.CHORD_TYPES):
        for root in ('C', 'F#', 'B-', 'E-'):
            try:
                out.append((f'{root} {kind}', harmony.ChordSymbol(root=root, kind=kind)))
            except Exception:
                pass
    mods = [('add', 9, 0), ('add', 9, 1), ('add', 9, -1), ('add', 11, 1), ('add', 13, -1),
            ('add', 5, -1), ('add', 5, 1), ('subtract', 5, 0), ('subtract', 3, 0),
            ('alter', 5, 1), ('alter', 5, -1)]
    # (Not tested: adding an ALTERED 9th to a chord kind that already has a 9th,
    # e.g. "dominant-ninth add #9". music21 leaves such a chord unchanged; the
    # mapping applies the alteration. Nobody writes a symbol that way.)
    for kind in ('dominant-seventh', 'major', 'minor-seventh', 'major-seventh'):
        for t, d, a in mods:
            cs = harmony.ChordSymbol(root='G', kind=kind)
            cs.addChordStepModification(harmony.ChordStepModification(t, d, interval.Interval(a)))
            out.append((f'G {kind} {t} {d} {a:+d}', cs))
    for fig in ('C/E', 'C/G', 'C7/B-', 'Dm7/A', 'C/F#', 'F/A', 'C/D'):
        try:
            out.append((fig, harmony.ChordSymbol(fig)))
        except Exception:
            pass
    return out


def run():
    syms = symbols()
    toks, expected, labels, skipped = [], [], [], []
    for label, cs in syms:
        spec, why = ly._chord_spec(cs)
        if spec is None:
            skipped.append((label, why)); continue
        root, rest = spec.split('\x00')
        toks.append(root + '1' + rest)
        expected.append(sorted({p.pitchClass for p in cs.pitches}))
        labels.append((label, root + '1' + rest))
    d = tempfile.mkdtemp()
    Path(d, 'c.ly').write_text('\\version "2.24.3"\n\\score { \\new Staff { \\chordmode {\n'
                               + '\n'.join(toks) + '\n} } \\midi { } }\n')
    rc, err = ly.compile_lilypond(Path(d, 'c.ly'), d, formats=())
    problems = ly.lilypond_problems(err)
    m = mido.MidiFile(Path(d, 'c.midi'))
    onsets = {}
    for tr in m.tracks:
        t = 0
        for msg in tr:
            t += msg.time
            if msg.type == 'note_on' and msg.velocity > 0:
                onsets.setdefault(t, set()).add(msg.note % 12)
    played = [sorted(onsets[k]) for k in sorted(onsets)]
    bad = [(labels[i], expected[i], played[i]) for i in range(min(len(labels), len(played)))
           if expected[i] != played[i]]
    return len(labels), bad, skipped, problems, len(played)


if __name__ == '__main__':
    n, bad, skipped, problems, played = run()
    print(f'{n} chords checked ({played} played by LilyPond); {len(bad)} mismatches; '
          f'{len(skipped)} not mappable; LilyPond problems: {problems[:2]}')
    for (label, tok), want, got in bad[:15]:
        print('  MISMATCH', label, tok, 'music21', want, 'lilypond', got)
    for label, why in skipped[:10]:
        print('  skipped', label, why)
    sys.exit(1 if bad or problems or played != n else 0)
