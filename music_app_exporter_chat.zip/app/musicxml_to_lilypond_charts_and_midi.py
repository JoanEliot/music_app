#!/usr/bin/env python3
"""
musicxml_to_lilypond_charts_and_midi.py

Read a MusicXML file, pull out its chord symbols -- transposing them to
concert pitch if they live on a transposing-instrument part -- and write
a LilyPond (.ly) file, a plain .txt chord list, and a .mid preview.

The .ly file can hold any combination of these charts (see --add-chart),
each independently in treble or bass clef:

  * slash    -- the original rhythmic "slash" chart (one slash per beat,
                via \\improvisationOn) with chord symbols placed as text
                exactly where they change.
  * roots    -- a melody of just each chord's root, held/repeated at the
                time signature's denominator value until the next chord
                (e.g. Ebmin7b5b9 -> Eb Eb Eb ... in 4/4).
  * basic    -- a melody using only each chord's fundamental tones (1,
                3rd-or-suspension, 5th, 7th -- no 9th/11th/13th/altered
                tension), either arpeggiated or more freely chosen (see
                --add-chart's MODE), with voice leading into each chord
                change and a fixed, ledger-line-minimizing register.
  * extended -- the same as basic, but including whatever 9th/11th/13th/
                altered tensions the chord actually has.

The plain .txt file always just lists the chord symbols themselves, in
order, separated by single spaces, regardless of which charts are built.

Chord symbols are (re)formatted in a modern jazz "real book" style
(root name + quality shorthand), e.g.:

    C        Cmin7      D7        Gmaj7       F#o7
    Abmin7   Bb13       E7#9      Cmin7b5     CminMaj7
    G7sus4   D/F#       N.C.

Why not use LilyPond's own \\chordmode chord-name engraver?  LilyPond's
ChordNames context has its own built-in naming logic/exceptions table
that is fiddly to bend into an exact, opinionated jazz spelling (case
of "Maj7", the "-" for minor, the "o" and "\u00f8" glyphs, etc). Instead
this script computes the exact display string itself and stamps it onto
each chart as markup text at the right beat, which is both simpler and
fully controllable.

Slash-rhythm grid: the rhythmic voice normally shows one slash per beat
(the standard jazz "comp in time" convention), regardless of how long a
chord is held. The one exception is a chord that changes off the beat
(an anticipation, e.g. on the "and" of 4): the script splits just that
beat so the new chord symbol still lands exactly where it should,
instead of only being able to show it a fraction of a beat early/late.

Melodic charts (roots/basic/extended) move at exactly one note per
denominator-value beat instead (a quarter note for 3/4, an eighth note
for 5/8) -- a coarser grid than the slash chart's, so a chord that lasts
less than one denominator-unit (e.g. that same off-the-beat anticipation)
is invisible to these charts; the melody just carries on to whatever
comes after it. Register is confined to a fixed, roughly-a-10th-wide
window per clef (MELODY_WINDOWS) chosen to sit mostly on/near the staff;
the note choice on every chord change favors whichever available chord
tone (in any in-window octave) is closest to the last note played, and
within a held chord (or the same chord recurring later in the piece)
'arpeggio' mode steps up/down an octave-spanning ladder of that chord's
tones, reversing at the window's edges, while 'random' mode instead
picks from that same ladder, softly weighted toward whatever's closest
to the last note.

Note on MIDI: because chord symbols are plain text markup rather than
\\chordmode/ChordNames data, LilyPond's own MIDI export of this file
won't play the chords (there's no pitched chord data to play -- only
rhythm). Instead, this script separately builds a concert-pitch chord
progression directly in music21 -- one held chord per change, using
the same root/kind/bass/alterations as the chart, re-struck on the
first beat of any bar that doesn't already start with a change -- plus
a metronome click track on the GM percussion channel, and writes both
to a standalone .mid file so you can hear the changes even though the
notation itself is just slashes. This MIDI preview is independent of
which charts --add-chart builds into the .ly file.

Requires: music21  (pip install music21)
Produces LilyPond source only; you need a LilyPond installation to
compile the .ly into a PDF/PNG (this script does not do that for you).

Usage:
    python musicxml_to_lilypond_charts_and_midi.py input.musicxml
    python musicxml_to_lilypond_charts_and_midi.py input.musicxml -o my_tune
    python musicxml_to_lilypond_charts_and_midi.py input.musicxml --part 2
    python musicxml_to_lilypond_charts_and_midi.py input.musicxml --part "Trumpet"
    python musicxml_to_lilypond_charts_and_midi.py input.musicxml --layout 4-portrait
    python musicxml_to_lilypond_charts_and_midi.py input.musicxml --paper-size a4 --tempo 144
    python musicxml_to_lilypond_charts_and_midi.py input.musicxml --no-click
    python musicxml_to_lilypond_charts_and_midi.py input.musicxml --compound-click beats
    python musicxml_to_lilypond_charts_and_midi.py input.musicxml --ask-odd-meters
    python musicxml_to_lilypond_charts_and_midi.py input.musicxml --add-chart slash:treble \\
        --add-chart roots:bass --add-chart basic:treble:arpeggio \\
        --add-chart extended:bass:random
    python musicxml_to_lilypond_charts_and_midi.py input.musicxml --add-chart basic:bass --melody-seed 3

Outputs (next to the input file, or wherever -o points):
    <name>.ly     One LilyPond file holding every requested chart (see
                  --add-chart), each in its own \\book with an explicit
                  \\bookOutputName -- so compiling this one file with
                  `lilypond` produces a separate PDF per chart, not one
                  combined PDF. With only one chart requested (or
                  --add-chart never given, which defaults to a single
                  slash:treble chart, same as every earlier version of
                  this script), that PDF is plain <name>.pdf; with more
                  than one, each gets its own <name>_<chart>_<clef>
                  [_<mode>].pdf to match its .mid/_chords.txt below.
    <name>[_<chart>_<clef>[_<mode>]]_chords.txt
                  Just the chord symbols, space separated -- identical
                  content for every chart (it doesn't depend on which
                  chart it's paired with), one copy per chart so each
                  chart's PDF/MIDI/chord-list trio is self-contained.
    <name>[_<chart>_<clef>[_<mode>]].mid
                  A concert-pitch MIDI preview for that one chart: chord
                  comping + metronome click, plus that chart's own
                  melody track if it's roots/basic/extended (using the
                  exact notes in its score, not a separate random draw)
                  (whole file: --no-midi; click only: --no-click)
"""

import argparse
import random
import sys

from music21 import converter, harmony, instrument as instrument_mod
from music21 import meter, stream, duration, pitch, tempo, note, key


# ---------------------------------------------------------------------------
# Chord-symbol formatting: modern jazz "real book" style
# ---------------------------------------------------------------------------

# music21's normalized "chordKind" strings -> jazz shorthand.
# (This is the full, authoritative list from music21.harmony.CHORD_TYPES.)
KIND_TO_JAZZ = {
    'major': '',
    'minor': 'min',
    'augmented': '+',
    'diminished': 'o',
    'dominant-seventh': '7',
    'major-seventh': 'Maj7',
    'minor-major-seventh': 'minMaj7',
    'minor-seventh': 'min7',
    'augmented-major-seventh': '+Maj7',
    'augmented-seventh': '+7',
    'half-diminished-seventh': 'min7b5',
    'diminished-seventh': 'o7',
    'seventh-flat-five': '7b5',
    'major-sixth': '6',
    'minor-sixth': 'min6',
    'major-ninth': 'Maj9',
    'dominant-ninth': '9',
    'minor-major-ninth': 'minMaj9',
    'minor-ninth': 'min9',
    'augmented-major-ninth': '+Maj9',
    'augmented-dominant-ninth': '+9',
    'half-diminished-ninth': 'min9b5',
    'half-diminished-minor-ninth': 'min7b5b9',
    'diminished-ninth': 'o9',
    'diminished-minor-ninth': 'ob9',
    'dominant-11th': '11',
    'major-11th': 'Maj11',
    'minor-major-11th': 'minMaj11',
    'minor-11th': 'min11',
    'augmented-major-11th': '+Maj11',
    'augmented-11th': '+11',
    'half-diminished-11th': 'min11b5',
    'diminished-11th': 'o11',
    'major-13th': 'Maj13',
    'dominant-13th': '13',
    'minor-major-13th': 'minMaj13',
    'minor-13th': 'min13',
    'augmented-major-13th': '+Maj13',
    'augmented-dominant-13th': '+13',
    'half-diminished-13th': 'min13b5',
    'suspended-second': 'sus2',
    'suspended-fourth': 'sus4',
    'suspended-fourth-seventh': '7sus4',
    'Neapolitan': 'N6',
    'Italian': 'It+6',
    'French': 'Fr+6',
    'German': 'Ger+6',
    'pedal': 'ped',
    'power': '5',
    'Tristan': 'Tristan',
    'none': '',
}


def format_pitch(p: pitch.Pitch) -> str:
    """music21 spells flats as '-'; jazz charts spell them 'b'."""
    return p.name.replace('-', 'b')


def format_modification(mod: harmony.ChordStepModification) -> str:
    semis = 0
    if mod.interval is not None:
        semis = mod.interval.chromatic.semitones
    sign = '#' * semis if semis > 0 else ('b' * -semis if semis < 0 else '')
    if mod.modType == 'add':
        # An unaltered added tone (e.g. add9) keeps the "add"; an altered
        # tension (#9, b13, ...) is written bare, the way real books do
        # ("C7#9", not "C7add#9").
        if semis == 0:
            return f'add{mod.degree}'
        return f'{sign}{mod.degree}'
    if mod.modType == 'alter':
        return f'{sign}{mod.degree}'
    if mod.modType == 'subtract':
        return f'no{mod.degree}'
    return ''


class ConcertChord:
    """A lightweight, detached snapshot of the data needed to print a jazz
    chord symbol -- deliberately NOT a music21 Chord/ChordSymbol, so we
    don't have to fight that class's internal pitch-list bookkeeping just
    to move a root/bass to a new pitch."""
    __slots__ = ('root', 'bass', 'kind', 'kind_str', 'mods', 'is_no_chord')

    def __init__(self, root, bass, kind, kind_str, mods, is_no_chord=False):
        self.root = root
        self.bass = bass
        self.kind = kind
        self.kind_str = kind_str
        self.mods = mods
        self.is_no_chord = is_no_chord


def jazz_chord_symbol(cc: ConcertChord) -> str:
    """Build a modern-jazz-style chord symbol string from a ConcertChord.
    Assumes cc is already in the pitch space you want displayed (i.e.
    call this AFTER transposing to concert pitch)."""
    if cc.is_no_chord or cc.root is None:
        return 'N.C.'

    root_str = format_pitch(cc.root)
    kind = cc.kind
    kind_str = cc.kind_str or ''
    mods = list(cc.mods)

    if kind == 'other' and 'alt' in kind_str.lower():
        body = '7alt'
    elif kind in KIND_TO_JAZZ:
        body = KIND_TO_JAZZ[kind]
    else:
        # Unknown/unsupported kind: fall back to whatever text was given.
        body = kind_str if kind_str else (kind or '')

    # Some encoders write a half-diminished chord as "minor-seventh" plus
    # a separate "flat 5" step modification instead of using music21's
    # 'half-diminished-seventh' kind directly. Normalize that case too.
    if kind == 'minor-seventh':
        flat5 = next(
            (m for m in mods
             if m.degree == 5 and m.interval is not None
             and m.interval.chromatic.semitones == -1),
            None,
        )
        if flat5 is not None:
            body = KIND_TO_JAZZ['half-diminished-seventh']
            mods = [m for m in mods if m is not flat5]

    extras = ''.join(format_modification(m) for m in mods
                      if m.modType in ('alter', 'add'))
    subtractions = ''.join(format_modification(m) for m in mods
                            if m.modType == 'subtract')

    symbol = f'{root_str}{body}{extras}{subtractions}'

    if cc.bass is not None and format_pitch(cc.bass) != root_str:
        symbol += f'/{format_pitch(cc.bass)}'
    return symbol


# ---------------------------------------------------------------------------
# Concert-pitch transposition
# ---------------------------------------------------------------------------

def concert_pitch_chord(cs: harmony.ChordSymbol, transposition) -> ConcertChord:
    """Turn a (written-pitch) ChordSymbol into a ConcertChord moved to
    concert pitch by `transposition` (a music21 Interval, or None for no
    change). The kind/modifications are unaffected by transposition."""
    if isinstance(cs, harmony.NoChord) or cs.chordKind == 'none':
        return ConcertChord(None, None, 'none', cs.chordKindStr, [], is_no_chord=True)

    root = cs.root()
    bass = cs.bass()
    if transposition is not None:
        if root is not None:
            root = root.transpose(transposition)
        if bass is not None:
            bass = bass.transpose(transposition)
    return ConcertChord(root, bass, cs.chordKind, cs.chordKindStr,
                         list(cs.getChordStepModifications()))


def find_chord_parts(score):
    """Return list of (index, part, [ChordSymbol,...]) for every part that
    contains at least one chord symbol."""
    found = []
    for i, part in enumerate(score.parts):
        chords = list(part.recurse().getElementsByClass(harmony.ChordSymbol))
        if chords:
            found.append((i, part, chords))
    return found


def select_part(score, part_selector):
    candidates = find_chord_parts(score)
    if not candidates:
        sys.exit('No chord symbols found anywhere in this score.')

    if part_selector is not None:
        # Try as an integer index into score.parts first.
        try:
            idx = int(part_selector)
            for i, part, chords in candidates:
                if i == idx:
                    return part, chords
            sys.exit(f'Part index {idx} has no chord symbols '
                      f'(parts with chords: {[i for i, _, _ in candidates]}).')
        except ValueError:
            pass
        # Fall back to a case-insensitive substring match on part/instrument name.
        needle = part_selector.lower()
        for i, part, chords in candidates:
            name = (part.partName or '')
            inst = part.getInstrument(returnDefault=False)
            inst_name = inst.instrumentName if inst else ''
            if needle in name.lower() or needle in (inst_name or '').lower():
                return part, chords
        sys.exit(f'No part matching {part_selector!r} was found among the '
                  f'parts that contain chord symbols.')

    if len(candidates) > 1:
        names = []
        for i, part, chords in candidates:
            names.append(f'  [{i}] {part.partName or "(unnamed)"} '
                          f'({len(chords)} chord symbols)')
        print('Multiple parts contain chord symbols; using the first one.\n'
              'Pass --part <index or name> to choose a different one:\n'
              + '\n'.join(names), file=sys.stderr)

    _, part, chords = candidates[0]
    return part, chords


def get_transposition_for(cs, part):
    """Find the Interval that converts this chord symbol's written pitch
    to concert (sounding) pitch, or None if it's already concert pitch."""
    inst = cs.getContextByClass(instrument_mod.Instrument)
    if inst is None:
        inst = part.getInstrument(returnDefault=False)
    if inst is None:
        return None
    return inst.transposition


# ---------------------------------------------------------------------------
# Rhythmic grid / LilyPond duration helpers
# ---------------------------------------------------------------------------

TYPE_TO_LY = {
    'whole': '1', 'half': '2', 'quarter': '4', 'eighth': '8',
    '16th': '16', '32nd': '32', '64th': '64', '128th': '128',
    '256th': '256',
}


def ql_to_ly_tokens(ql):
    """Convert a quarterLength into one or more (possibly tied) LilyPond
    duration strings, e.g. 1.5 -> ['4.'], 5.0 -> ['1', '4']."""
    if ql <= 0:
        return []
    d = duration.Duration(ql)
    tokens = []
    for c in d.components:
        base = TYPE_TO_LY.get(c.type)
        if base is None:
            base = '4'  # extremely unlikely fallback
        tokens.append(base + ('.' * c.dots))
    return tokens


def get_beat_offsets_and_weights(ts: meter.TimeSignature):
    """List of (local_offset, local_duration, accent_weight) for each beat
    within one measure of `ts`, robust to compound and asymmetric meters.

    accent_weight is roughly 1.0 for the downbeat, 0.5 for a secondary
    accent (e.g. beat 3 of 4/4, or the second group of 6/8), and lower
    for a plain/regular beat -- taken from music21's own metrical-accent
    machinery, with one deliberate override: music21's default beat
    grouping treats a "lone triple" at the eighth-note-or-faster level
    (e.g. 3/8, 3/16) as a single one-in-a-bar beat, which is the right
    reading for a fast tempo but not what a literal per-beat slash/click
    wants; we split that case into three simple beats instead (matching
    3/4's beat-3 in a bar, this deliberately doesn't apply the same
    override to a genuinely one-in-a-bar denominator like 3/4, 3/2).
    """
    try:
        durs = [mt.duration.quarterLength for mt in ts.beatSequence]
    except Exception:
        durs = None

    if durs and len(durs) == 1 and ts.numerator == 3:
        beat_dur = durs[0] / 3
        durs = [beat_dur, beat_dur, beat_dur]
        weights = [1.0, 0.5, 0.5]
    else:
        if not durs:
            try:
                durs = [ts.beatDuration.quarterLength] * ts.beatCount
            except Exception:
                durs = [1.0] * max(1, int(round(ts.barDuration.quarterLength)))
        offsets = []
        pos = 0.0
        for d in durs:
            offsets.append(pos)
            pos += d
        try:
            weights = [ts.getAccentWeight(o) for o in offsets]
        except Exception:
            weights = [1.0] + [0.5] * (len(offsets) - 1)

    result = []
    pos = 0.0
    for d, w in zip(durs, weights):
        result.append((pos, d, w))
        pos += d
    return result


def accent_tier(weight):
    """Bucket a music21 accent weight into one of three click tiers."""
    if weight >= 0.75:
        return 'strong'
    if weight >= 0.375:
        return 'secondary'
    return 'regular'


def get_click_events(ts: meter.TimeSignature, subdivide_eighths=True):
    """List of (local_offset, tier) metronome clicks for one measure of
    `ts`, tier in {'strong', 'secondary', 'regular', 'subdivision'}.

    This is independent of get_beat_offsets_and_weights (which drives the
    printed slash chart) -- the two are allowed to disagree, e.g. a click
    track can subdivide more finely than the chart shows slashes.

    If `subdivide_eighths` is True (the default) and `ts` has an eighth-
    note denominator (3/8, 5/8, 6/8, 7/8, 9/8, 2/8+3/8, ...), every eighth
    note gets a click: music21's own beat grouping is used to find each
    "group" (a bare 5/8 is five 1-eighth groups; an explicitly additive
    meter like 2/8+3/8 or 4/8+3/8 is two groups matching what's actually
    written; 6/8 is two 3-eighth groups; etc.), the FIRST eighth of each
    group keeps that group's own strong/secondary/regular accent tier
    (from music21's accent weight at the group's downbeat -- so a second
    or later grouping's own accent, e.g. the secondary accent on the
    "3/8" half of 2/8+3/8, is preserved), and every other eighth in the
    group gets a new, weaker 'subdivision' tier. A group that's already
    just one eighth long (bare 5/8, 7/8, ...) has nothing to subdivide,
    so this is a no-op for those and matches the non-subdivided reading.

    Otherwise -- subdivide_eighths is False, or `ts` isn't an eighth-
    denominator meter -- this clicks once per beat using music21's own,
    UNMODIFIED beat grouping (unlike get_beat_offsets_and_weights, this
    does not split a lone 3/8-style triple into three beats: a bare
    "beat" reading of 3/8 is one click per bar, the standard "conducted
    in one" pulse).
    """
    if subdivide_eighths and ts.denominator == 8:
        try:
            group_durs = [mt.duration.quarterLength for mt in ts.beatSequence]
        except Exception:
            group_durs = None
        if group_durs:
            events = []
            pos = 0.0
            for group_dur in group_durs:
                try:
                    weight = ts.getAccentWeight(pos)
                except Exception:
                    weight = 1.0 if pos == 0 else 0.5
                tier = accent_tier(weight)
                num_eighths = max(1, round(group_dur / 0.5))
                for i in range(num_eighths):
                    events.append((pos + i * 0.5, tier if i == 0 else 'subdivision'))
                pos += group_dur
            return events

    try:
        durs = [mt.duration.quarterLength for mt in ts.beatSequence]
    except Exception:
        durs = None
    if not durs:
        try:
            durs = [ts.beatDuration.quarterLength] * ts.beatCount
        except Exception:
            durs = [1.0] * max(1, int(round(ts.barDuration.quarterLength)))

    offsets = []
    pos = 0.0
    for d in durs:
        offsets.append(pos)
        pos += d
    try:
        weights = [ts.getAccentWeight(o) for o in offsets]
    except Exception:
        weights = [1.0] + [0.5] * (len(offsets) - 1)
    return [(o, accent_tier(w)) for o, w in zip(offsets, weights)]


def get_measures(part):
    measures = list(part.getElementsByClass(stream.Measure))
    if not measures:
        sys.exit('The chosen part has no <measure> content to work from.')
    return measures


def build_grid(measures, part):
    """Returns:
        barline_offsets: sorted list of absolute offsets at each measure start
                          (plus the final end-of-piece offset)
        beat_offsets:    sorted set of absolute offsets at each beat
        measure_info:    list of (start_offset, end_offset, TimeSignature)
        key_at_offset:   dict of measure-start-offset -> Key/KeySignature,
                          already transposed to concert pitch, or None if
                          the source never specifies one
    """
    barline_offsets = []
    beat_offsets = set()
    measure_info = []
    key_at_offset = {}
    current_ts = None
    current_ks = None
    for m in measures:
        start = m.getOffsetInHierarchy(part)
        ts = m.timeSignature or m.getContextByClass(meter.TimeSignature) or current_ts
        if ts is None:
            ts = meter.TimeSignature('4/4')
        current_ts = ts

        ks = m.keySignature or m.getContextByClass(key.KeySignature) or current_ks
        if ks is not None:
            transp = get_transposition_for(m, part)
            if transp is not None:
                try:
                    ks = ks.transpose(transp)
                except Exception:
                    pass
        current_ks = ks
        key_at_offset[start] = ks

        # Use the measure's ACTUAL filled duration, not the time signature's
        # nominal bar length -- these differ for pickup/anacrusis measures
        # and for a truncated final measure, and using the nominal length
        # there would push every later offset out of alignment. Fall back
        # to the nominal length only if a measure has no timed content at
        # all (e.g. a bare chord symbol with no rest/note alongside it).
        bar_len = m.duration.quarterLength
        if bar_len <= 0:
            bar_len = ts.barDuration.quarterLength
        end = start + bar_len
        barline_offsets.append(start)
        for local, local_dur, weight in get_beat_offsets_and_weights(ts):
            if local < bar_len - 1e-6:
                beat_offsets.add(start + local)
        measure_info.append((start, end, ts))
    barline_offsets.append(measure_info[-1][1])
    return barline_offsets, beat_offsets, measure_info, key_at_offset


# ---------------------------------------------------------------------------
# Main extraction + emission
# ---------------------------------------------------------------------------

def escape_ly_string(s):
    return s.replace('\\', '\\\\').replace('"', '\\"')


def build_score(input_path, part_selector):
    try:
        score = converter.parse(input_path)
    except FileNotFoundError:
        sys.exit(f'Input file not found: {input_path}')
    except Exception as e:
        sys.exit(f'Could not parse {input_path!r} as a music21 score: {e}')
    part, raw_chords = select_part(score, part_selector)
    measures = get_measures(part)
    barline_offsets, beat_offsets, measure_info, key_at_offset = build_grid(measures, part)
    piece_end = barline_offsets[-1]

    # Concert-pitch chords, deduplicated by offset (last one wins if two
    # chord symbols were stacked at the same instant).
    by_offset = {}
    for cs in raw_chords:
        off = cs.getOffsetInHierarchy(part)
        if off >= piece_end:
            continue
        transp = get_transposition_for(cs, part)
        by_offset[off] = concert_pitch_chord(cs, transp)
    chord_offsets = sorted(by_offset)

    if not chord_offsets:
        sys.exit('The selected part has no usable chord symbols before the end of the piece.')

    grid = sorted(set(barline_offsets) | beat_offsets | set(chord_offsets))

    return {
        'chord_offsets': chord_offsets,
        'by_offset': by_offset,
        'grid': grid,
        'barline_offsets': barline_offsets,
        'measure_info': measure_info,
        'key_at_offset': key_at_offset,
        'piece_end': piece_end,
        'part': part,
    }


def emit_chord_text(data):
    symbols = [jazz_chord_symbol(data['by_offset'][off])
               for off in data['chord_offsets']]
    return ' '.join(symbols)


# ---------------------------------------------------------------------------
# MIDI (separate from the LilyPond chart -- see module docstring)
# ---------------------------------------------------------------------------

def chord_symbol_for_playback(cc: ConcertChord) -> harmony.ChordSymbol:
    """Rebuild a real, pitched ChordSymbol from a ConcertChord for MIDI
    purposes. Not used for display text -- see jazz_chord_symbol for that."""
    bass = cc.bass if cc.bass is not None else cc.root
    cs = harmony.ChordSymbol(root=cc.root, kind=cc.kind, kindStr=cc.kind_str,
                              bass=bass)
    for mod in cc.mods:
        try:
            cs.addChordStepModification(mod, updatePitches=True)
        except Exception:
            pass  # an odd/unsupported modification just gets skipped for audio
    if len(cs.pitches) <= 1 and cc.kind not in ('major', 'power', 'pedal', 'none'):
        # music21 doesn't know how to voice some kinds automatically (e.g.
        # kind='other', used for things like a bare "alt" dominant) -- fall
        # back to a plain dominant seventh so it's still audible as *a*
        # chord rather than a single held note.
        cs = harmony.ChordSymbol(root=cc.root, kind='dominant-seventh', bass=bass)
    return cs


def build_comping_part(data, tempo_bpm=120):
    """The concert-pitch chord-progression track: one held chord per
    change, PLUS a re-attack of the still-active chord at the first beat
    of any bar that doesn't already start with an explicit chord change
    (so a chord held across several bars still gets struck on each new
    downbeat, the way a comper would actually play it)."""
    chord_offsets = data['chord_offsets']
    by_offset = data['by_offset']
    piece_end = data['piece_end']
    measure_starts = sorted(start for start, end, ts in data['measure_info'])

    attack_points = sorted(set(chord_offsets) | set(measure_starts))
    attack_points = [o for o in attack_points if o < piece_end]

    part = stream.Part()
    part.insert(0, instrument_mod.Piano())
    part.insert(0, tempo.MetronomeMark(number=tempo_bpm))

    active_cc = None
    for i, off in enumerate(attack_points):
        end = attack_points[i + 1] if i + 1 < len(attack_points) else piece_end
        dur = end - off
        if dur <= 0:
            continue
        if off in by_offset:
            active_cc = by_offset[off]
        cc = active_cc
        if cc is None or cc.is_no_chord or cc.root is None:
            part.insert(off, note.Rest(quarterLength=dur))
            continue
        try:
            cs = chord_symbol_for_playback(cc)
        except Exception:
            cs = note.Note(cc.root)
        cs.duration.quarterLength = dur
        part.insert(off, cs)

    return part


# General MIDI drum-map note numbers and velocities for the four click
# tiers. These are just reasonable clicky placeholders -- swap the note
# numbers below for any other GM percussion sound you'd rather hear.
CLICK_NOTES = {'strong': 75, 'secondary': 37, 'regular': 77, 'subdivision': 76}
# claves,       side stick,   low wood block,  hi wood block
CLICK_VELOCITIES = {'strong': 127, 'secondary': 100, 'regular': 75, 'subdivision': 55}
CLICK_LENGTH = 0.1  # quarterLengths -- short and percussive regardless of tempo


# ---------------------------------------------------------------------------
# Ambiguous meters: an odd numerator that isn't a multiple of 3 (5, 7, 11,
# 13, ...) has no single obviously-correct accent pattern for the click --
# unlike a multiple of 3 (compound, groups of 3) or an even numerator (just
# equal beats), it could reasonably be played as N equal beats, or split
# into two (or more) unequal groups. Rather than silently guessing, this
# lets a caller ask -- and is written so "ask" is a single, swappable
# function call rather than anything tied to stdin/stdout.
# ---------------------------------------------------------------------------

def suggest_groupings(numerator, denominator):
    """Return [(label, grouping), ...] options for an ambiguous meter,
    where `grouping` is a tuple of denominator-unit counts (e.g. (2, 3)
    for a 2+3 split) or None for the plain, undivided reading. The
    common cases (5, 7) get their standard two-way splits, in both
    orders; anything else gets a couple of generic "pairs plus one
    three" splits, with the odd group first or last, as a reasonable
    default -- assumes `numerator` is odd (that's the only case this is
    meant to be called for)."""
    def label(grouping):
        if grouping is None:
            return f'{numerator}/{denominator} (undivided)'
        return '+'.join(f'{g}/{denominator}' for g in grouping)

    if numerator == 5:
        groupings = [None, (2, 3), (3, 2)]
    elif numerator == 7:
        groupings = [None, (3, 4), (4, 3)]
    else:
        pairs = (numerator - 3) // 2
        groupings = [None, (3,) + (2,) * pairs, (2,) * pairs + (3,)]

    seen = set()
    options = []
    for g in groupings:
        if g in seen:
            continue
        seen.add(g)
        options.append((label(g), g))
    return options


def ask_meter_grouping_cli(time_sig_label, options):
    """Default, command-line implementation of the "how should this meter
    be grouped" question: prints a numbered list and reads a line from
    stdin. Returns whichever option's `grouping` value was chosen (see
    suggest_groupings) -- None for the plain/undivided reading, or a
    tuple of denominator-unit counts.

    To use this in a GUI app instead, just point ASK_METER_GROUPING (see
    below) at a different function with this same signature -- e.g. one
    that shows a message box or dropdown listing `[label for label, _ in
    options]` and returns the `grouping` paired with whichever label the
    person clicked. Nothing else in this script needs to change.
    """
    print(f'What accent pattern should the metronome play for {time_sig_label}?')
    for i, (label, _grouping) in enumerate(options, 1):
        print(f'  {i}. {label}')
    while True:
        choice = input(f'Choice [1-{len(options)}]: ').strip()
        if choice.isdigit() and 1 <= int(choice) <= len(options):
            return options[int(choice) - 1][1]
        print(f'Please enter a number from 1 to {len(options)}.')


# The single point of contact for asking this question. Reassign this
# (e.g. `musicxml_to_lilypond_charts_and_midi.ASK_METER_GROUPING = my_dialog_fn`) to
# route the question through a GUI instead of the command line; nothing
# else needs to change. Only ever called when --ask-odd-meters is on.
ASK_METER_GROUPING = ask_meter_grouping_cli


def resolve_click_meter(ts: meter.TimeSignature, ask=False, cache=None):
    """Return the TimeSignature to actually generate clicks from: `ts`
    unchanged, unless `ts` is an ambiguous bare meter -- odd numerator,
    not a multiple of 3, and not already explicitly grouped by the
    source file (beatCount == numerator means every unit is still its
    own separate beat, i.e. nothing grouped it) -- AND `ask` is True, in
    which case ASK_METER_GROUPING supplies a grouping and this returns a
    new TimeSignature built from it (e.g. "2/4+3/4" for a 5/4 given the
    (2, 3) grouping). An explicitly pre-grouped meter from the source
    file (e.g. a MusicXML additive time signature) is always respected
    as-is and never prompts, regardless of `ask`.

    `cache`, if given, is a dict keyed by ts.ratioString so the same
    recurring meter within one piece is only asked about once.
    """
    is_ambiguous = (ts.numerator % 2 == 1 and ts.numerator % 3 != 0
                    and ts.beatCount == ts.numerator)
    if not (ask and is_ambiguous):
        return ts

    key = ts.ratioString
    if cache is not None and key in cache:
        grouping = cache[key]
    else:
        options = suggest_groupings(ts.numerator, ts.denominator)
        grouping = ASK_METER_GROUPING(key, options)
        if cache is not None:
            cache[key] = grouping

    if grouping is None:
        return ts
    return meter.TimeSignature('+'.join(f'{g}/{ts.denominator}' for g in grouping))


def build_metronome_part(data, tempo_bpm=120, subdivide_eighths=True, ask_odd_meters=False,
                          grouping_cache=None):
    """A click track on the GM percussion channel (MIDI channel 10, i.e.
    channel index 9). Beats on every beat of whatever time signature is
    active at each point, with three accent tiers: strong (downbeat),
    secondary (e.g. beat 3 of 4/4, or the second group of 6/8), and a
    plain regular click for everything else. See get_click_events for
    what subdivide_eighths does in compound x/8 meters, and
    resolve_click_meter for what ask_odd_meters does. `grouping_cache`
    can be supplied (and reused across calls, e.g. once per chart's own
    MIDI file for the same piece) so an ambiguous meter is only ever
    asked about once rather than once per call; a fresh one is used if
    none is given."""
    piece_end = data['piece_end']
    part = stream.Part()
    part.insert(0, instrument_mod.UnpitchedPercussion())

    if grouping_cache is None:
        grouping_cache = {}
    for start, end, ts in data['measure_info']:
        click_ts = resolve_click_meter(ts, ask=ask_odd_meters, cache=grouping_cache)
        for local_off, tier in get_click_events(click_ts, subdivide_eighths=subdivide_eighths):
            abs_off = start + local_off
            if abs_off >= piece_end:
                continue
            n = note.Note()
            n.pitch.midi = CLICK_NOTES[tier]
            n.volume.velocity = CLICK_VELOCITIES[tier]
            n.duration.quarterLength = CLICK_LENGTH
            part.insert(abs_off, n)

    return part


def build_midi_score(data, charts=None, melody_cache=None, tempo_bpm=120, click=True,
                      subdivide_eighths=True, ask_odd_meters=False, grouping_cache=None):
    """A concert-pitch MIDI preview: the chord-comping part, a metronome
    click part on the GM percussion channel (unless click=False), and --
    if `charts`/`melody_cache` are given -- one more track per melodic
    chart (roots/basic/extended) requested via --add-chart, using the
    exact same notes as its printed score (see compute_melodies).
    `grouping_cache` is passed straight through to build_metronome_part
    -- share one across multiple calls for the same piece (e.g. one
    call per chart's own MIDI file) so an ambiguous odd meter is only
    ever asked about once, not once per call."""
    score = stream.Score()
    score.insert(0, build_comping_part(data, tempo_bpm=tempo_bpm))
    if click:
        score.insert(0, build_metronome_part(data, tempo_bpm=tempo_bpm,
                                              subdivide_eighths=subdivide_eighths,
                                              ask_odd_meters=ask_odd_meters,
                                              grouping_cache=grouping_cache))
    if charts and melody_cache:
        for i, (chart_type, clef, mode) in enumerate(charts):
            if i not in melody_cache:
                continue
            label = CHART_TYPE_LABELS[chart_type]
            if chart_type in ('basic', 'extended'):
                label += f' ({mode})'
            score.insert(0, build_melody_midi_part(melody_cache[i], label))
    return score


# ---------------------------------------------------------------------------
# Melodic charts: besides the slash chart, this can also generate a
# "melody" of just chord roots, or of chord tones (basic or extended),
# each in treble or bass clef. All of these are independent of the MIDI
# section above and of each other -- see build_lilypond_file, which
# assembles whichever combination is requested into one .ly file.
# ---------------------------------------------------------------------------

STEP_TO_LY = {'C': 'c', 'D': 'd', 'E': 'e', 'F': 'f', 'G': 'g', 'A': 'a', 'B': 'b'}


def pitch_to_ly(p: pitch.Pitch) -> str:
    """A music21 Pitch to LilyPond absolute-pitch notation (Dutch note
    names, LilyPond's default -- e.g. C#4 -> "cis'", Eb2 -> "ees,").
    Both the long ("aes", "ees") and short ("as", "es") Dutch spellings
    for flat A/E are valid and identical in LilyPond; this always uses
    the long form so no A/E special-case is needed."""
    name = STEP_TO_LY[p.step]
    alter = int(round(p.alter))
    if alter > 0:
        name += 'is' * alter
    elif alter < 0:
        name += 'es' * (-alter)
    octave = p.octave if p.octave is not None else p.implicitOctave
    marks = octave - 3
    if marks > 0:
        name += "'" * marks
    elif marks < 0:
        name += ',' * (-marks)
    return name


LY_MODES = {'major', 'minor', 'dorian', 'phrygian', 'lydian',
            'mixolydian', 'aeolian', 'locrian', 'ionian'}


def key_to_ly(ks):
    """A music21 Key/KeySignature (already transposed to concert pitch --
    see build_grid) to a LilyPond \\key command, e.g. "\\key g \\major".
    A bare KeySignature with no mode (the source file gave a sharps/flats
    count but no explicit major/minor) is read as major, the usual
    convention when mode isn't specified; a mode outside the handful
    LilyPond recognizes by name falls back to major too."""
    if ks is None:
        return None
    mode = getattr(ks, 'mode', None)
    if mode in LY_MODES:
        tonic = ks.tonic
    else:
        as_major = ks.asKey('major')
        tonic, mode = as_major.tonic, 'major'
    tonic_name = pitch_to_ly(tonic).rstrip("',")
    return f'\\key {tonic_name} \\{mode}'


# The register each melodic chart is confined to, one per clef. Chosen to
# sit mostly on/near the staff (minimizing ledger lines) and to be no
# more than a major 10th (16 semitones) wide, the widest range asked for;
# the bass window sits well inside the explicitly requested D2-C4 outer
# bounds. There's no single "right" choice here since neither window was
# spelled out exactly -- change these two lines to taste.
MELODY_WINDOWS = {
    'treble': (pitch.Pitch('C4'), pitch.Pitch('E5')),  # 16 semitones
    'bass': (pitch.Pitch('E2'), pitch.Pitch('G3')),  # 15 semitones, inside D2-C4
}


def basic_chord_tones(cc: ConcertChord):
    """The 'fundamental' chord tones only: 1, 3 (or a suspension in its
    place), 5, and a 6th/7th if the chord kind has one -- never a 9th,
    11th, 13th, or altered tension, whether that comes from the kind
    itself or from an explicit degree modification. music21 always
    stacks a kind's own pitches in ascending-third order (root, third-
    or-suspension, fifth, then a sixth or seventh if the kind has one,
    then any 9th/11th/13th), so the first four are always exactly the
    fundamental tones regardless of kind -- for a plain triad, sus
    chord, or power chord there are only 2-3 to begin with, so this is a
    no-op for those. Degree modifications are deliberately not applied
    here (that's the difference from extended_chord_tones)."""
    if cc.is_no_chord or cc.root is None:
        return []
    bass = cc.bass if cc.bass is not None else cc.root
    try:
        cs = harmony.ChordSymbol(root=cc.root, kind=cc.kind, kindStr=cc.kind_str, bass=bass)
        pitches = list(cs.pitches)
    except Exception:
        pitches = []
    if len(pitches) <= 1 and cc.kind not in ('major', 'power', 'pedal', 'none'):
        # Same fallback as chord_symbol_for_playback, for kinds music21
        # can't voice on its own (e.g. kind='other', as in a bare "alt").
        try:
            pitches = list(harmony.ChordSymbol(root=cc.root, kind='dominant-seventh',
                                                bass=bass).pitches)
        except Exception:
            pitches = [cc.root]
    if not pitches:
        pitches = [cc.root]
    return pitches[:4]


def extended_chord_tones(cc: ConcertChord):
    """All chord tones, including whatever 9th/11th/13th/altered
    tensions the kind or its degree modifications add -- built the same
    way as the MIDI comping part's pitches (chord_symbol_for_playback)."""
    if cc.is_no_chord or cc.root is None:
        return []
    try:
        pitches = list(chord_symbol_for_playback(cc).pitches)
    except Exception:
        pitches = [cc.root]
    if not pitches:
        pitches = [cc.root]
    return pitches


def ladder_in_window(tone_pitches, window):
    """Every octave-transposition of each pitch CLASS in `tone_pitches`
    that falls within window=(low_pitch, high_pitch) inclusive, as a
    sorted list of music21 Pitch objects (no duplicates). Since the
    window is at most a major 10th (16 semitones, more than an octave),
    every pitch class is guaranteed at least one placement in it."""
    low_midi = int(round(window[0].ps))
    high_midi = int(round(window[1].ps))
    seen = set()
    for tp in tone_pitches:
        base = int(round(tp.ps)) % 12
        for oct_num in range(0, 11):
            m = base + 12 * oct_num
            if low_midi <= m <= high_midi:
                seen.add(m)
    return [pitch.Pitch(m) for m in sorted(seen)]


def closest_in_ladder(ladder, last_pitch):
    """The ladder entry closest to `last_pitch` (or, if this is the very
    first note of the piece, the one closest to the window's center)."""
    if last_pitch is None:
        center = (ladder[0].ps + ladder[-1].ps) / 2
        return min(ladder, key=lambda p: abs(p.ps - center))
    return min(ladder, key=lambda p: abs(p.ps - last_pitch.ps))


def step_arpeggio(ladder, last_pitch, direction):
    """One step along the ladder from `last_pitch` in `direction` (+1 up,
    -1 down), reversing direction instead of stepping past either end.
    Returns (new_pitch, new_direction)."""
    idx = next(i for i, p in enumerate(ladder) if p.ps == last_pitch.ps)
    new_idx = idx + direction
    if new_idx < 0 or new_idx >= len(ladder):
        direction = -direction
        new_idx = idx + direction
    return ladder[new_idx], direction


def weighted_random_pick(ladder, last_pitch, rng):
    """A random ladder entry, softly weighted toward whichever are
    closer to `last_pitch` -- "more random" than the arpeggio mode, but
    still leaning toward smooth movement rather than pure chance. Never
    returns `last_pitch` itself if any other choice exists (repeats are
    only allowed across a chord change, handled elsewhere by
    closest_in_ladder -- within a held chord every note should move)."""
    if last_pitch is None:
        return rng.choice(ladder)
    candidates = [p for p in ladder if p.ps != last_pitch.ps]
    if not candidates:
        return last_pitch  # a single-tone ladder -- nothing else available
    weights = [1.0 / (1 + abs(p.ps - last_pitch.ps)) ** 0.6 for p in candidates]
    return rng.choices(candidates, weights=weights, k=1)[0]


def denominator_grid(measure_info):
    """Yield (offset, duration, ts) once for every denominator-value note
    across the whole piece -- e.g. one entry per quarter note for 3/4,
    one per eighth note for 5/8 -- regardless of any beat/compound
    grouping (unlike get_beat_offsets_and_weights, which drives the
    slash chart's comping pulse). Each measure's own actual filled
    duration is used, so pickup measures come out right."""
    for start, end, ts in measure_info:
        measure_dur = end - start
        unit_ql = 4.0 / ts.denominator
        num_units = max(1, int(round(measure_dur / unit_ql)))
        for i in range(num_units):
            yield start + i * unit_ql, unit_ql, ts


def active_chord_at(offset, chord_offsets, by_offset):
    """The ConcertChord in effect at `offset` (the one at the largest
    chord_offsets entry <= offset), or None before the first chord."""
    result = None
    for off in chord_offsets:
        if off <= offset + 1e-9:
            result = by_offset[off]
        else:
            break
    return result


def generate_melody(data, chart_type, mode, clef, rng):
    """The core note-choice algorithm, shared by the roots/basic/extended
    charts. Returns a list of (offset, duration, Pitch or None) tuples
    for the whole piece -- None marks a rest (an N.C. stretch).

    One note per denominator-grid position (see denominator_grid). On
    every chord CHANGE, the next note is whichever available chord tone
    (in any in-window octave) is closest to the last note played --
    "good" voice leading, and the reason a held chord's very first note
    often lands on or near the previous chord's last note. While a
    chord's tones are otherwise unchanged from one note to the next
    (holding within one chord, or a chord that recurs at the same pitch
    material later in the piece), 'arpeggio' mode steps one place up or
    down an octave-spanning ladder of that chord's tones each note,
    reversing at the register window's edges instead of leaving it;
    'random' mode instead picks from that same ladder at each note,
    softly weighted toward whatever's closest to the last note (more
    movement and variety than the arpeggio walk, while still leaning
    smooth rather than jumping wildly). For chart_type='roots' there's
    only one pitch class in play at all, so a held chord just repeats
    the same note (e.g. Ebmin7b5b9 -> Eb Eb Eb ...) and only the voice-
    led choice on a chord change ever moves anything.
    """
    window = MELODY_WINDOWS[clef]
    chord_offsets = data['chord_offsets']
    by_offset = data['by_offset']

    notes = []
    last_pitch = None
    direction = 1
    last_cc = None

    for offset, duration, ts in denominator_grid(data['measure_info']):
        if offset >= data['piece_end']:
            continue
        cc = active_chord_at(offset, chord_offsets, by_offset)
        if cc is None or cc.is_no_chord or cc.root is None:
            notes.append((offset, duration, None))
            last_cc = cc
            continue

        chord_changed = (cc is not last_cc)

        if chart_type == 'roots':
            tones = [cc.root]
        elif chart_type == 'basic':
            tones = basic_chord_tones(cc)
        else:
            tones = extended_chord_tones(cc)
        if not tones:
            tones = [cc.root]
        ladder = ladder_in_window(tones, window)

        if chord_changed or last_pitch is None:
            new_pitch = closest_in_ladder(ladder, last_pitch)
            if last_pitch is not None:
                if new_pitch.ps > last_pitch.ps:
                    direction = 1
                elif new_pitch.ps < last_pitch.ps:
                    direction = -1
                # equal: keep whatever direction was already running
        elif chart_type == 'roots':
            new_pitch = last_pitch  # same note held/repeated (e.g. Eb Eb Eb)
        elif mode == 'random':
            new_pitch = weighted_random_pick(ladder, last_pitch, rng)
        else:  # arpeggio
            new_pitch, direction = step_arpeggio(ladder, last_pitch, direction)

        notes.append((offset, duration, new_pitch))
        last_pitch = new_pitch
        last_cc = cc

    return notes


def build_melody_midi_part(notes, label):
    """A MIDI Part from a melody's (offset, duration, Pitch-or-None)
    notes (see generate_melody) -- the same notes used for that chart's
    printed score, so the MIDI melody matches what's on the page. Given
    a distinct instrument (flute) from the comping part's piano so the
    two are easy to tell apart by ear, and named `label` (music21's
    MIDI writer takes the track name from the instrument object's own
    name, not Part.partName, so that's set directly here -- this still
    keeps the flute's own GM program/sound)."""
    part = stream.Part()
    flute = instrument_mod.Flute()
    flute.instrumentName = label
    part.partName = label
    part.insert(0, flute)
    for offset, duration, p in notes:
        if p is None:
            part.insert(offset, note.Rest(quarterLength=duration))
        else:
            n = note.Note(p)
            n.duration.quarterLength = duration
            part.insert(offset, n)
    return part


def emit_melody_score_body(data, notes, clef, bars_per_line, spacing_increment, font_size):
    """The \\score { } block for a roots/basic/extended melodic chart, in
    the given clef, from `notes` (see generate_melody) -- passed in
    rather than generated here so the exact same notes can also become
    the matching MIDI track (see build_melody_midi_part)."""
    by_offset = data['by_offset']
    barline_set = set(data['barline_offsets'])
    measure_info = data['measure_info']
    key_at_offset = data['key_at_offset']
    ts_at_offset = {start: ts for start, end, ts in measure_info}

    lines = []
    current_line = []
    measure_count = 0

    def flush_measure():
        nonlocal measure_count
        if current_line:
            lines.append(' '.join(current_line) + ' |')
            current_line.clear()
            measure_count += 1
            if bars_per_line and measure_count % bars_per_line == 0:
                lines.append('\\break')

    last_ts_str = None
    last_key_str = None
    current_ts = None
    for offset, duration, p in notes:
        if offset in ts_at_offset:
            key_str = key_to_ly(key_at_offset.get(offset))
            if key_str and key_str != last_key_str:
                current_line.append(key_str)
                last_key_str = key_str

            current_ts = ts_at_offset[offset]
            ts_str = f'{current_ts.numerator}/{current_ts.denominator}'
            if ts_str != last_ts_str:
                current_line.append(f'\\time {ts_str}')
                last_ts_str = ts_str

        # Every note in this grid is exactly one denominator-unit long by
        # construction (see denominator_grid), so the duration token is
        # always just the active time signature's own denominator.
        tok = str(current_ts.denominator) if current_ts is not None else '4'

        markup = None
        if offset in by_offset:
            symbol = jazz_chord_symbol(by_offset[offset])
            markup = f'^\\markup{{\\bold "{escape_ly_string(symbol)}"}}'

        note_str = f'r{tok}' if p is None else f'{pitch_to_ly(p)}{tok}'
        if markup:
            note_str += markup
        current_line.append(note_str)

        if any(abs((offset + duration) - b) < 1e-6 for b in barline_set):
            flush_measure()

    flush_measure()
    body = '\n  '.join(lines)

    clef_name = 'treble' if clef == 'treble' else 'bass'
    return f'''\\new Staff {{
  \\clef {clef_name}
  {body}
}}'''


def emit_slash_score_body(data, clef, bars_per_line, spacing_increment, font_size):
    """The \\score { } inner music for the plain slash-notation chart --
    factored out of the single-chart emit_lilypond of earlier versions
    of this script so it can sit alongside the melodic charts below."""
    grid = data['grid']
    by_offset = data['by_offset']
    barline_set = set(data['barline_offsets'])
    measure_info = data['measure_info']
    key_at_offset = data['key_at_offset']
    ts_at_offset = {start: ts for start, end, ts in measure_info}

    middle_line_pitch = "b'" if clef == 'treble' else 'd'
    clef_name = 'treble' if clef == 'treble' else 'bass'

    lines = []
    current_line = []
    measure_count = 0

    def flush_measure():
        nonlocal measure_count
        if current_line:
            lines.append(' '.join(current_line) + ' |')
            current_line.clear()
            measure_count += 1
            if bars_per_line and measure_count % bars_per_line == 0:
                lines.append('\\break')

    last_ts_str = None
    last_key_str = None
    for i in range(len(grid) - 1):
        start = grid[i]
        end = grid[i + 1]
        seg_len = end - start

        if start in ts_at_offset:
            key_str = key_to_ly(key_at_offset.get(start))
            if key_str and key_str != last_key_str:
                current_line.append(key_str)
                last_key_str = key_str

            ts = ts_at_offset[start]
            ts_str = f'{ts.numerator}/{ts.denominator}'
            if ts_str != last_ts_str:
                current_line.append(f'\\time {ts_str}')
                last_ts_str = ts_str

        tokens = ql_to_ly_tokens(seg_len)
        if not tokens:
            continue

        markup = None
        if start in by_offset:
            symbol = jazz_chord_symbol(by_offset[start])
            markup = f'^\\markup{{\\bold "{escape_ly_string(symbol)}"}}'

        for j, tok in enumerate(tokens):
            note_str = f"{middle_line_pitch}{tok}"
            if j == 0 and markup:
                note_str += markup
            if j < len(tokens) - 1:
                note_str += '~'
            current_line.append(note_str)

        if end in barline_set:
            flush_measure()

    flush_measure()
    body = '\n  '.join(lines)

    return f'''\\new Staff {{
  \\clef {clef_name}
  % Plain jazz "slash" notation: a stemless slash notehead centered on
  % the staff's middle line, with no accidentals, stems, beams, or ties
  % -- just the rhythm and the chord text.
  \\improvisationOn
  \\override Stem.stencil = ##f
  \\override Flag.stencil = ##f
  \\override Beam.stencil = ##f
  \\override Tie.stencil = ##f
  % Chord-symbol text is plain markup (not \\chordmode/ChordNames -- see
  % the module docstring), so LilyPond's spacing engine doesn't know to
  % leave room for it. This spacing-increment/font-size pair was tuned
  % against a worst-case bar (four different, fairly long chord names
  % on four consecutive beats) landing without literal overlap at
  % {bars_per_line} bars per line; a bar that dense still ends up with
  % its chord names on two staggered rows rather than one.
  \\override Score.SpacingSpanner.spacing-increment = {spacing_increment}
  \\override TextScript.font-size = {font_size}
  {body}
  \\revert Stem.stencil
  \\revert Flag.stencil
  \\revert Beam.stencil
  \\revert Tie.stencil
  \\improvisationOff
}}'''


CHART_TYPE_LABELS = {
    'slash': 'Slash chart',
    'roots': 'Root-note melody',
    'basic': 'Chord-tone melody (basic)',
    'extended': 'Chord-tone melody (extended)',
}


def parse_chart_specs(spec_strings):
    """Turn the --add-chart strings (each "type:clef[:mode]") into a list
    of (chart_type, clef, mode) tuples. None or an empty list means
    --add-chart was never given at all, which defaults to a single
    slash:treble chart -- exactly what every earlier version of this
    script produced."""
    if not spec_strings:
        return [('slash', 'treble', 'arpeggio')]

    charts = []
    for spec in spec_strings:
        parts = spec.split(':')
        if len(parts) not in (2, 3):
            sys.exit(f'--add-chart {spec!r}: expected TYPE:CLEF or TYPE:CLEF:MODE')
        chart_type, clef = parts[0].strip().lower(), parts[1].strip().lower()
        mode = parts[2].strip().lower() if len(parts) == 3 else 'arpeggio'
        if chart_type not in CHART_TYPE_LABELS:
            sys.exit(f'--add-chart {spec!r}: TYPE must be one of '
                      f'{", ".join(CHART_TYPE_LABELS)}')
        if clef not in ('treble', 'bass'):
            sys.exit(f'--add-chart {spec!r}: CLEF must be treble or bass')
        if mode not in ('arpeggio', 'random'):
            sys.exit(f'--add-chart {spec!r}: MODE must be arpeggio or random')
        charts.append((chart_type, clef, mode))
    return charts


def chart_label(chart_type, mode):
    label = CHART_TYPE_LABELS[chart_type]
    if chart_type in ('basic', 'extended'):
        label += f', {mode}'
    return label


def chart_output_stem(base, charts, index):
    """The output filename stem for one chart's own outputs -- the PDF
    LilyPond produces from its \\book (see build_lilypond_file), plus
    this script's own .mid and _chords.txt for that same chart (see
    main). Requesting only one chart (--add-chart never given, or given
    just once) keeps the plain, unsuffixed `base` -- matching every
    earlier version of this script exactly -- since there's nothing to
    disambiguate; two or more charts each get `base` plus a slug
    identifying that chart, so every chart's PDF/MIDI/chord-list trio
    has its own distinct name and none of them collide."""
    if len(charts) <= 1:
        return base
    chart_type, clef, mode = charts[index]
    slug = f'{chart_type}_{clef}'
    if chart_type in ('basic', 'extended'):
        slug += f'_{mode}'
    return f'{base}_{slug}'


def compute_melodies(data, charts, rng):
    """Generate the note list (see generate_melody) for every melodic
    chart (roots/basic/extended) in `charts`, once each, keyed by that
    chart's index in the list. Computing these once and sharing the
    result between build_lilypond_file and build_midi_score is what
    makes the MIDI melody track match the notation exactly, rather than
    being a second, different random draw."""
    cache = {}
    for i, (chart_type, clef, mode) in enumerate(charts):
        if chart_type in ('roots', 'basic', 'extended'):
            cache[i] = generate_melody(data, chart_type, mode, clef, rng)
    return cache


def build_lilypond_file(data, charts, melody_cache, base, title=None, bars_per_line=8,
                         paper_size='letter', orientation='landscape',
                         spacing_increment=3, font_size=-3):
    """Assemble one .ly file containing one \\book { } per requested
    chart, each with its own \\bookOutputName -- so compiling this one
    file with `lilypond` produces a separate PDF per chart (named to
    match that chart's .mid/_chords.txt from main), rather than one PDF
    with every chart as a separate page. `charts` is a list of
    (chart_type, clef, mode) tuples -- chart_type in
    {'slash','roots','basic','extended'}, clef in {'treble','bass'},
    mode in {'arpeggio','random'} (mode is ignored for 'slash'/'roots',
    which have nothing to choose between). `melody_cache` supplies the
    actual notes for every non-'slash' chart (see compute_melodies) --
    keyed by each chart's index in `charts`. `base` is the shared output
    basename (see chart_output_stem) used to name each \\book's output."""
    book_blocks = []
    for i, (chart_type, clef, mode) in enumerate(charts):
        if chart_type == 'slash':
            inner = emit_slash_score_body(data, clef, bars_per_line,
                                           spacing_increment, font_size)
        else:
            inner = emit_melody_score_body(data, melody_cache[i], clef, bars_per_line,
                                            spacing_increment, font_size)
        label = chart_label(chart_type, mode)
        stem = chart_output_stem(base, charts, i)

        header_lines = [f'piece = "{escape_ly_string(label)}"']
        if title:
            header_lines.append(f'title = "{escape_ly_string(title)}"')
        header_block = '\\header {\n    ' + '\n    '.join(header_lines) + '\n  }'

        book_blocks.append(f'''\\book {{
  \\bookOutputName "{escape_ly_string(stem)}"
  {header_block}
  \\score {{
    {inner}
    \\layout {{ }}
  }}
}}''')

    blocks_text = '\n\n'.join(book_blocks)

    return f'''\\version "2.24.0"

% Landscape/portrait orientation and the explicit \\break commands inside
% each chart below are both there so bars-per-line comes out as asked
% for, rather than however many LilyPond's automatic breaking picks.
#(set-default-paper-size "{paper_size}" '{orientation})

% Each chart is its own \\book with an explicit \\bookOutputName, so
% compiling this single .ly file with `lilypond` produces one separate
% PDF per chart instead of one combined PDF.
{blocks_text}
'''


LAYOUT_PRESETS = {
    # name: (bars_per_line, orientation, spacing_increment, font_size)
    '8-landscape': (8, 'landscape', 3, -3),
    '4-portrait': (4, 'portrait', 2, -3),
}


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('input', help='Input MusicXML file (.musicxml/.xml/.mxl)')
    ap.add_argument('-o', '--output', default=None,
                     help='Output basename (default: derived from input filename). '
                          'Produces <basename>.ly and <basename>_chords.txt')
    ap.add_argument('--part', default=None,
                     help='Which part to read chord symbols from: a 0-based index '
                          '(e.g. 0) or a substring of the part/instrument name '
                          '(e.g. "Trumpet"). Default: auto-detect.')
    ap.add_argument('--title', default=None,
                     help='Title to put in the LilyPond \\header (default: none)')
    ap.add_argument('--layout', choices=sorted(LAYOUT_PRESETS), default='8-landscape',
                     help='Page layout preset (default: 8-landscape). '
                          '8-landscape: 8 bars/line, landscape page. '
                          '4-portrait: 4 bars/line, portrait page.')
    ap.add_argument('--bars-per-line', type=int, default=None,
                     help='Override the bars/line from --layout. Use 0 to let '
                          "LilyPond's automatic line breaking decide instead.")
    ap.add_argument('--paper-size', default='letter',
                     help='Paper size for the generated LilyPond file '
                          '(default: letter; try "a4" outside the US).')
    ap.add_argument('--tempo', type=int, default=120,
                     help='Tempo (BPM) for the generated MIDI preview (default: 120)')
    ap.add_argument('--no-midi', action='store_true',
                     help="Don't generate the .mid preview at all")
    ap.add_argument('--no-click', action='store_true',
                     help='Generate the .mid preview without the metronome click track')
    ap.add_argument('--compound-click', choices=['eighths', 'beats'], default='eighths',
                     help='In any x/8 meter (3/8, 5/8, 6/8, 7/8, 9/8, 2/8+3/8, ...), click '
                          'on every eighth note, with a 4th, softer subdivision sound on '
                          'the off-beat eighths within each group (default: eighths), or '
                          'just once per group -- e.g. one click total for 3/8, two for '
                          '2/8+3/8 -- like a fast "in one" pulse (beats). Either way, a '
                          "second or later group's own accent (e.g. the secondary accent "
                          'on the "3/8" half of 2/8+3/8) is preserved. Meters with a '
                          "denominator other than 8 aren't affected either way.")
    ap.add_argument('--ask-odd-meters', action='store_true',
                     help='For a bare meter with an odd numerator that\'s not a multiple '
                          'of 3 (5/4, 7/8, 11/8, ...) and no grouping already specified in '
                          'the file, ask how to split it for the click (e.g. 5/4 as 5/4, '
                          '2/4+3/4, or 3/4+2/4) instead of just clicking N equal beats. '
                          'Off by default, so this never blocks waiting for input unless '
                          'asked for; a meter the source file already groups explicitly '
                          '(e.g. a MusicXML additive time signature) is always honored '
                          'as-is and never prompts.')
    ap.add_argument('--add-chart', action='append', default=None, metavar='TYPE:CLEF[:MODE]',
                     help='Add a score to the .ly file. Repeat for any combination. TYPE is '
                          'one of: slash (the plain slash-notation lead sheet), roots (a '
                          "melody of just each chord's root, e.g. Ebmin7b5b9 -> Eb Eb Eb "
                          '..., held until the next chord), basic (a melody using only each '
                          "chord's 1st/3rd-or-suspension/5th/7th, no 9th/11th/13th/altered "
                          'tensions), or extended (same as basic, but with those tensions '
                          'included). CLEF is treble or bass. MODE (basic/extended only, '
                          'default arpeggio) is arpeggio (walks up or down the chord tones, '
                          'reversing at the range limit) or random (picks more freely, still '
                          'favoring nearby notes). Examples: --add-chart slash:treble '
                          '--add-chart basic:bass:random. Default if this is never given: '
                          'a single slash:treble chart, matching every earlier version of '
                          'this script.')
    ap.add_argument('--melody-seed', type=int, default=0,
                     help='Random seed for the roots/basic/extended melodies (default: 0, '
                          'so the same input always produces the same melody -- pass a '
                          'different number for a different take).')
    args = ap.parse_args()

    charts = parse_chart_specs(args.add_chart)

    data = build_score(args.input, args.part)

    if args.output:
        base = args.output
    else:
        base = args.input.rsplit('.', 1)[0]

    ly_path = base + '.ly'

    bars_per_line, orientation, spacing_increment, font_size = LAYOUT_PRESETS[args.layout]
    if args.bars_per_line is not None:
        bars_per_line = args.bars_per_line

    # Generated once and shared between the .ly and every chart's own
    # .mid, so each chart's MIDI melody track (if any) matches its
    # printed notation exactly rather than being a second, different
    # random draw.
    melody_cache = compute_melodies(data, charts, random.Random(args.melody_seed))

    with open(ly_path, 'w', encoding='utf-8') as f:
        f.write(build_lilypond_file(data, charts, melody_cache, base, title=args.title,
                                     bars_per_line=bars_per_line,
                                     paper_size=args.paper_size,
                                     orientation=orientation,
                                     spacing_increment=spacing_increment,
                                     font_size=font_size))
    print(f'Wrote {ly_path}  '
          f'(compiling it with `lilypond` produces one PDF per chart below)')

    # One shared cache so an ambiguous odd meter (--ask-odd-meters) is
    # only ever asked about once across every chart's MIDI, not re-asked
    # per chart.
    grouping_cache = {}

    for i, (chart_type, clef, mode) in enumerate(charts):
        stem = chart_output_stem(base, charts, i)
        txt_path = stem + '_chords.txt'
        midi_path = stem + '.mid'

        with open(txt_path, 'w', encoding='utf-8') as f:
            f.write(emit_chord_text(data) + '\n')
        print(f'Wrote {txt_path}')

        if not args.no_midi:
            chart_melody_cache = {0: melody_cache[i]} if i in melody_cache else None
            midi_score = build_midi_score(data, charts=[(chart_type, clef, mode)],
                                           melody_cache=chart_melody_cache,
                                           tempo_bpm=args.tempo, click=not args.no_click,
                                           subdivide_eighths=(args.compound_click == 'eighths'),
                                           ask_odd_meters=args.ask_odd_meters,
                                           grouping_cache=grouping_cache)
            midi_score.write('midi', fp=midi_path)
            print(f'Wrote {midi_path}')


if __name__ == '__main__':
    main()