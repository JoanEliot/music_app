"""
exporters/lilypond.py

music21 Score -> LilyPond source text: the general, "as-is" exporter.

WHAT "AS-IS" MEANS
------------------------------------------------------------------
The notation the Score actually contains -- pitches, rhythms, ties,
tuplets, voices, staves, clefs, key and time signatures, pickups,
barlines, transposing-instrument marking -- and nothing else. No
title/composer header, no instrument names, no layout tuning: those are
formatting, and formatting is added by later, separate steps. The .ly it
writes is plain and readable on purpose (one measure per line, bar-number
comments, a bar check `|` after every bar) so it can be opened and
re-engraved with LilyPond alone, without this app.

WHERE IT CAME FROM
------------------------------------------------------------------
pitch_to_ly(), key_to_ly() and escape_ly_string() are the helpers of the
lead sheet script (musicxml_to_lilypond_charts_and_midi.py), moved here
so there is one copy; that script's own emitters work from a chord grid
rather than a Score and are NOT reused. When the lead sheet transform is
re-homed it should import these from here.

THE BAR CHECK IS THE BUILT-IN TEST
------------------------------------------------------------------
Every complete bar ends in `|`. If this module gets any duration,
tuplet, or voice wrong, LilyPond reports "barcheck failed" when it
compiles the file -- see verify_lilypond() for how the test harness
treats that as a failure. Bars that are deliberately not full length
(pickup, short final bar) get a `\\partial` and are checked too.

NOT YET EMITTED (each is reported through ONE summary
LilyExportWarning per export, never silently dropped)
------------------------------------------------------------------
lyrics, slurs, dynamics and hairpins, repeat barlines / volta brackets
(written flat with plain barlines), chord symbols, grace notes,
cross-staff voices (`\\change Staff`), explicit beam marks (LilyPond
beams automatically), courtesy/forced accidentals, unpitched percussion.
"""

import re
import subprocess
import tempfile
import warnings
from collections import Counter
from dataclasses import dataclass, field
from fractions import Fraction
from pathlib import Path

from music21 import (articulations, bar, chord, clef as m21clef, dynamics,
                     expressions, harmony, key as m21key, layout, meter, note,
                     pitch, spanner, stream, tempo)
from music21.common import opFrac


class LilyExportWarning(UserWarning):
    """Something in the Score was not (fully) written to the .ly."""


LILYPOND_VERSION = '2.24.3'

_EPS = Fraction(1, 10000)

# ---------------------------------------------------------------------------
# Small text helpers (pitch / key / duration)
# ---------------------------------------------------------------------------

_STEP = {'C': 'c', 'D': 'd', 'E': 'e', 'F': 'f', 'G': 'g', 'A': 'a', 'B': 'b'}
_ALTER = {0: '', 1: 'is', 2: 'isis', -1: 'es', -2: 'eses',
          0.5: 'ih', -0.5: 'eh', 1.5: 'isih', -1.5: 'eseh'}

_TYPE_TO_LY = {
    'longa': '\\longa', 'breve': '\\breve', 'whole': '1', 'half': '2',
    'quarter': '4', 'eighth': '8', '16th': '16', '32nd': '32', '64th': '64',
    '128th': '128', '256th': '256',
}


def escape_ly_string(s):
    return s.replace('\\', '\\\\').replace('"', '\\"')


def pitch_to_ly(p: pitch.Pitch) -> str:
    """A music21 Pitch to LilyPond absolute-pitch notation in Dutch note
    names (LilyPond's default): C#4 -> "cis'", Eb2 -> "ees,". The long
    Dutch flat spellings for A and E ("aes", "ees") are identical to the
    short ones, so no special case is needed."""
    name = _STEP[p.step]
    alter = p.alter
    suffix = _ALTER.get(alter)
    if suffix is None:
        warnings.warn(f'pitch {p.nameWithOctave}: alteration {alter} has no '
                      f'LilyPond name; rounded to the nearest semitone',
                      LilyExportWarning)
        suffix = _ALTER[int(round(alter))]
    name += suffix
    octave = p.octave if p.octave is not None else p.implicitOctave
    marks = octave - 3
    if marks > 0:
        name += "'" * marks
    elif marks < 0:
        name += ',' * (-marks)
    return name


_LY_MODES = {'major', 'minor', 'dorian', 'phrygian', 'lydian',
             'mixolydian', 'aeolian', 'locrian', 'ionian'}


def key_to_ly(ks):
    """A music21 Key/KeySignature to a `\\key` command. A bare
    KeySignature (a sharps/flats count, no mode) is written as the major
    key with those accidentals: the printed signature is identical, and
    that's all the source said."""
    if ks is None:
        return None
    mode = getattr(ks, 'mode', None)
    if mode in _LY_MODES and getattr(ks, 'tonic', None) is not None:
        tonic = ks.tonic
    else:
        as_major = ks.asKey('major')
        tonic, mode = as_major.tonic, 'major'
    tonic_name = pitch_to_ly(tonic).rstrip("',")
    return f'\\key {tonic_name} \\{mode}'


def _frac(x) -> Fraction:
    return Fraction(opFrac(x))


def _mult(ql: Fraction) -> str:
    """A whole-note-relative duration multiplier for `ql` quarter lengths,
    e.g. 3 quarters -> "1*3/4". Always valid, whatever the length."""
    whole = Fraction(ql) / 4
    if whole.denominator == 1:
        return f'1*{whole.numerator}'
    return f'1*{whole.numerator}/{whole.denominator}'


def _dur_tokens(d):
    """LilyPond duration strings, one per tied component, for a music21
    Duration -- or None if the duration has no ordinary written form."""
    toks = []
    for c in d.components:
        base = _TYPE_TO_LY.get(c.type)
        if base is None:
            return None
        toks.append(base + '.' * c.dots)
    return toks or None


def _written_ql(d) -> Fraction:
    """The length, in quarters, of the note value this Duration is WRITTEN
    as (type, dots, tuplet ratio) -- which is what this module emits. It
    normally equals d.quarterLength. It does not in a few real files
    (seen in the music21 corpus: sixteenths with quarterLength 4/17 or 1/2),
    where the sounding length and the printed note value disagree; then
    the printed value wins, because the printed value is what a
    notation file states, and bar lengths must be computed from what is
    actually written or every following bar check fails."""
    comps = list(d.components)
    if not comps:
        return _frac(d.quarterLength)
    q = sum(Fraction(c.quarterLength) for c in comps)
    for t in d.tuplets:
        q *= Fraction(t.tupletMultiplier())
    return q


def _spacer_tokens(ql: Fraction):
    """Duration string(s) for a silent gap. Multiplier form: exact for
    any length, so a gap never needs its own tuplet."""
    return _mult(ql)


_CLEF_BY_SIGN_LINE = {('G', 2): 'treble', ('F', 4): 'bass', ('C', 3): 'alto',
                      ('C', 4): 'tenor', ('G', 1): 'french', ('F', 3): 'varbaritone',
                      ('F', 5): 'subbass', ('C', 1): 'soprano',
                      ('C', 2): 'mezzosoprano', ('C', 5): 'baritone'}


def clef_to_ly(c) -> str | None:
    if c is None:
        return None
    sign = getattr(c, 'sign', None)
    if sign == 'percussion':
        return '\\clef percussion'
    if sign == 'TAB':
        return '\\clef tab'
    line = getattr(c, 'line', None)
    name = _CLEF_BY_SIGN_LINE.get((sign, line))
    if name is None:
        name = f'{sign}{line}'
    shift = getattr(c, 'octaveChange', 0) or 0
    suffix = {-1: '_8', 1: '^8', -2: '_15', 2: '^15'}.get(shift, '')
    if suffix:
        return f'\\clef "{name}{suffix}"'
    return f'\\clef {name}' if name.isalpha() else f'\\clef "{name}"'


_BAR_TO_LY = {'double': '||', 'final': '|.', 'heavy': '.', 'dashed': '!',
              'dotted': ';', 'tick': "'", 'short': "'", 'none': '""',
              'light-light': '||', 'light-heavy': '|.', 'heavy-light': '.|',
              'heavy-heavy': '..'}

_ARTICULATION = {
    'Staccato': '-.', 'Staccatissimo': '-!', 'Accent': '->',
    'StrongAccent': '-^', 'Tenuto': '--', 'Portato': '-_',
}
_EXPRESSION = {
    'Fermata': '\\fermata', 'Trill': '\\trill', 'Turn': '\\turn',
    'InvertedTurn': '\\reverseturn', 'Mordent': '\\prall',
    'InvertedMordent': '\\mordent',
}


# ---------------------------------------------------------------------------
# Tempo, dynamics, chord symbols: text helpers
# ---------------------------------------------------------------------------

def _tempo_commands(el):
    """The LilyPond text for a tempo mark, or None if it says nothing.

    `\\tempo "Allegro" 4 = 120` prints the words and the metronome mark and
    sets the MIDI tempo. Words alone (`\\tempo "Allegro"`) print but do not
    move the MIDI tempo, so when the source implies a number for them a
    hidden `tempoWholesPerMinute` is set as well. A mark with neither words
    nor a number (music21 makes such placeholders) is skipped."""
    text = None
    number, ref_ql, implicit = None, Fraction(1), False
    if isinstance(el, tempo.MetronomeMark):
        raw = getattr(el, 'text', None)
        if raw and not getattr(el, 'textImplicit', False):
            text = str(raw)
        number = el.number
        implicit = bool(getattr(el, 'numberImplicit', False))
        if el.referent is not None:
            ref_ql = _frac(el.referent.quarterLength)
    elif isinstance(el, tempo.TempoText):
        text = str(el.text) if el.text else None
    else:
        return None
    if number is None and not text:
        return None
    parts = []
    if text:
        parts.append(f'"{escape_ly_string(text)}"')
    if number is not None and not implicit:
        toks = _dur_tokens(el.referent) if el.referent is not None else ['4']
        num = float(number)
        if not toks or len(toks) != 1:
            toks, num = ['4'], num * float(ref_ql)     # quarters per minute instead
        if abs(num - round(num)) > 1e-6:
            warnings.warn(f'tempo {number} is not a whole number; rounded',
                          LilyExportWarning)
        parts.append(f'{toks[0]} = {int(round(num))}')
        return '\\tempo ' + ' '.join(parts)
    out = '\\tempo ' + ' '.join(parts) if parts else ''
    if number is not None and implicit:
        wholes = Fraction(float(number)).limit_denominator(1000) * ref_ql / 4
        out += (' ' if out else '') + (
            f'\\set Score.tempoWholesPerMinute = #(ly:make-moment '
            f'{wholes.numerator} {wholes.denominator})')
    return out or None


_DYNAMIC_KNOWN = {'ppppp', 'pppp', 'ppp', 'pp', 'p', 'mp', 'mf', 'f', 'ff', 'fff',
                  'ffff', 'fffff', 'fp', 'sf', 'sff', 'sp', 'spp', 'sfz', 'rfz'}


def _dynamic_text(d) -> str | None:
    """`\\p`, `\\sfz`, ... ; a marking LilyPond has no command for is
    written as a `\\dynamic` markup so it still prints."""
    v = str(getattr(d, 'value', '') or '').strip()
    if not v:
        return None
    if v in _DYNAMIC_KNOWN:
        return '\\' + v
    if re.fullmatch(r'[sfzrmpn]+', v):
        return f'_\\markup {{ \\dynamic {v} }}'
    return None


_MAJOR_SEMITONES = {1: 0, 2: 2, 3: 4, 4: 5, 5: 7, 6: 9, 7: 11, 9: 14, 11: 17, 13: 21}

# Chord shapes LilyPond has a short name for (steps as (degree, alteration in
# LilyPond's own convention, where the plain step 7 is the FLAT seventh).
# Anything not listed is written as an explicit step list, which is exact.
_COMPACT = {
    frozenset({(1, 0), (3, 0), (5, 0)}): '',
    frozenset({(1, 0), (3, -1), (5, 0)}): 'm',
    frozenset({(1, 0), (3, 0), (5, 1)}): 'aug',
    frozenset({(1, 0), (3, -1), (5, -1)}): 'dim',
    frozenset({(1, 0), (3, 0), (5, 0), (7, 0)}): '7',
    frozenset({(1, 0), (3, 0), (5, 0), (7, 1)}): 'maj7',
    frozenset({(1, 0), (3, -1), (5, 0), (7, 0)}): 'm7',
    frozenset({(1, 0), (3, -1), (5, -1), (7, -1)}): 'dim7',
    frozenset({(1, 0), (3, -1), (5, -1), (7, 0)}): 'm7.5-',
    frozenset({(1, 0), (3, 0), (5, 0), (6, 0)}): '6',
    frozenset({(1, 0), (3, -1), (5, 0), (6, 0)}): 'm6',
    frozenset({(1, 0), (2, 0), (5, 0)}): 'sus2',
    frozenset({(1, 0), (4, 0), (5, 0)}): 'sus4',
    frozenset({(1, 0), (3, 0), (5, 0), (7, 0), (9, 0)}): '9',
    frozenset({(1, 0), (3, 0), (5, 0), (7, 1), (9, 0)}): 'maj9',
    frozenset({(1, 0), (3, -1), (5, 0), (7, 0), (9, 0)}): 'm9',
}


def _root_name(p) -> str:
    """A pitch name with no octave marks (a chord root, not a note)."""
    return pitch_to_ly(p).rstrip("',")


def _chord_spec(cs):
    """`root:steps/bass` for a music21 ChordSymbol as LilyPond chordmode text
    WITHOUT a duration (`c:1.3.5.7.9+`), or (None, reason).

    The steps come from music21's own chord-kind table plus the symbol's
    modifications, so every kind is handled the same way and nothing here
    depends on how the symbol was spelled. music21 counts alterations from
    the major scale, LilyPond from a scale whose seventh is FLAT, so the
    seventh is shifted by one."""
    kind = cs.chordKind
    row = harmony.CHORD_TYPES.get(kind) if kind else None
    if not row:
        return None, f'chord kind {kind!r}'
    steps = {}
    for tok in row[0].split(','):
        m = re.fullmatch(r'([#-]*)(\d+)', tok.strip())
        if not m:
            return None, f'chord steps {row[0]!r}'
        steps[int(m.group(2))] = m.group(1).count('#') - m.group(1).count('-')
    for mod in cs.chordStepModifications:
        alt = mod.interval.chromatic.semitones if mod.interval is not None else 0
        if mod.modType == 'add':
            steps[mod.degree] = alt
        elif mod.modType == 'subtract':
            steps.pop(mod.degree, None)
        elif mod.modType == 'alter':
            steps[mod.degree] = steps.get(mod.degree, 0) + alt
        else:
            return None, f'chord modification {mod.modType!r}'
    ly_steps = {d: (a + 1 if d == 7 else a) for d, a in steps.items()}
    if any(d not in _MAJOR_SEMITONES or abs(a) > 1 for d, a in ly_steps.items()):
        return None, f'chord steps {sorted(steps.items())}'
    root = cs.root()
    if root is None:
        return None, 'a chord with no root'
    compact = _COMPACT.get(frozenset(ly_steps.items()))
    if compact is None:
        body = '.'.join(f'{d}{"+" if a > 0 else "-" if a < 0 else ""}'
                        for d, a in sorted(ly_steps.items()))
        suffix = ':' + body
    else:
        suffix = (':' + compact) if compact else ''
    text = _root_name(root) + '\x00' + suffix
    bass = cs.bass()
    if bass is not None and bass.name != root.name:
        tones = {(root.pitchClass + _MAJOR_SEMITONES[d] + (a - (1 if d == 7 else 0))) % 12
                 for d, a in ly_steps.items()}
        text += ('/' if bass.pitchClass in tones else '/+') + _root_name(bass)
    return text, None


def _chord_measure_tokens(chords, length: Fraction, stats) -> str:
    """One measure of a ChordNames line: each symbol lasts until the next
    one or the end of the bar, and a bar with none is a silent spacer, so a
    chord that carries over several bars is named once, where it starts."""
    evs = {}
    for off, cs in chords:
        if off < length - _EPS:
            evs[off] = cs
    toks, pos = [], Fraction(0)
    keys = sorted(evs)
    for k, off in enumerate(keys):
        if off > pos + _EPS:
            toks.append('s' + _mult(off - pos))
        end = keys[k + 1] if k + 1 < len(keys) else length
        dur = end - off
        from music21 import duration as m21dur
        d = m21dur.Duration(dur)
        dtok = _dur_tokens(d)
        dtok = dtok[0] if dtok and len(dtok) == 1 and not d.tuplets else _mult(dur)
        cs = evs[off]
        if isinstance(cs, harmony.NoChord):
            toks.append('r' + dtok)
        else:
            spec, why = _chord_spec(cs)
            if spec is None:
                stats.ignored[f'chord symbols not written ({why})'] += 1
                toks.append('s' + dtok)
            else:
                root, rest = spec.split('\x00')
                toks.append(root + dtok + rest)
        pos = end
    if pos < length - _EPS:
        toks.append('s' + _mult(length - pos))
    return ' '.join(toks)


# ---------------------------------------------------------------------------
# Events: what a bar's voices are made of
# ---------------------------------------------------------------------------

@dataclass
class _Ev:
    off: Fraction
    ql: Fraction
    obj: object            # Note / Chord / Rest
    ctx: bool = False      # True: obj is a Clef/KeySignature/... command
    text: str = ''         # for ctx events: the command text
    wql: Fraction = Fraction(0)   # length of the NOTE VALUE as written
    full_rest: bool = False       # a whole-bar rest: sounding length rules
    graces: list = field(default_factory=list)   # grace notes written before it
    grace_cmd: str = '\\grace'                   # or \\acciaccatura / \\appoggiatura
    dyns: list = field(default_factory=list)      # dynamic marks written after the note


@dataclass
class _Lane:
    """One voice-worth of one bar. `key` says which persistent voice
    (track) of the part it continues: ('v', voice id, n) for a music21
    Voice, ('d', n) for notes sitting directly in the Measure."""
    key: tuple
    evs: list


def _is_sounding_or_rest(el) -> bool:
    if isinstance(el, harmony.Harmony):
        return False       # a chord SYMBOL is a Chord subclass; not notes
    return isinstance(el, (note.Note, chord.Chord, note.Rest))


def _assign_lanes(evs):
    """Greedy first-fit: split events that overlap in time into as many
    sequential lanes (LilyPond voices) as needed. Events already sorted by
    offset. Returns a list of event lists."""
    lanes, ends = [], []
    for ev in evs:
        for i, end in enumerate(ends):
            if end <= ev.off + _EPS:
                lanes[i].append(ev)
                ends[i] = ev.off + ev.ql
                break
        else:
            lanes.append([ev])
            ends.append(ev.off + ev.ql)
    return lanes


# ---------------------------------------------------------------------------
# Note-level text
# ---------------------------------------------------------------------------

def _tie_next(n) -> bool:
    t = getattr(n, 'tie', None)
    return t is not None and t.type in ('start', 'continue')


def _post_events(el) -> str:
    out = ''
    for a in getattr(el, 'articulations', ()):
        s = _ARTICULATION.get(type(a).__name__)
        if s:
            out += s
    for e in getattr(el, 'expressions', ()):
        s = _EXPRESSION.get(type(e).__name__)
        if s:
            out += s
    return out


def _body(el) -> str:
    """The pitch part of a Note/Chord/Rest, no duration."""
    if isinstance(el, note.Rest):
        return 's' if el.style.hideObjectOnPrint else 'r'
    if isinstance(el, chord.Chord):
        return '<' + ' '.join(pitch_to_ly(n.pitch) for n in el.notes) + '>'
    return pitch_to_ly(el.pitch)


def _note_tokens(el, tokens_out, last_dur, marks=None, dyns=()):
    """Append the text for one Note/Chord/Rest (all tied components) to
    `tokens_out`; returns the new "last duration written" so repeated
    durations can be left out, as LilyPond allows. `marks` maps id(note) to
    the slur / hairpin / beam text planned for it; `dyns` are its dynamics.

    After the note: articulations; then, on the first component, a hairpin
    end, the dynamic, a hairpin start, a slur start, a beam start; on the last
    component, the slur and beam ends (which come before a new start when one
    note both ends and starts something); then the tie."""
    d = el.duration
    toks = _dur_tokens(d)
    if toks is None:
        warnings.warn(f'duration {d.quarterLength} has no written form; '
                      f'written as a multiplier', LilyExportWarning)
        toks = [_mult(_frac(d.quarterLength))]
    is_rest = isinstance(el, note.Rest)

    if isinstance(el, chord.Chord):
        ties = [_tie_next(n) for n in el.notes]
        tied_all, tied_some = all(ties), any(ties)
    else:
        tied_all = tied_some = _tie_next(el)
    per_pitch = tied_some and not tied_all

    if per_pitch:
        body = '<' + ' '.join(pitch_to_ly(n.pitch) + ('~' if _tie_next(n) else '')
                              for n in el.notes) + '>'
    else:
        body = _body(el)

    m = (marks or {}).get(id(el)) or {}
    if not is_rest:
        tokens_out.extend(m.get('pre', ()))
    ends = ''.join(m.get('end', ()))
    firsts = (''.join(m.get('hend', ())) + ''.join(dyns) + ''.join(m.get('hstart', ()))
              + ''.join(m.get('start', ())) + ''.join(m.get('bstart', ())))

    for i, tok in enumerate(toks):
        last = i == len(toks) - 1
        text = body + ('' if tok == last_dur else tok)
        if i == 0 and not is_rest:
            text += _post_events(el)
        if not is_rest:
            if last:
                text += ends
            if i == 0:
                text += firsts
            if not last or tied_all:
                text += '~'
        tokens_out.append(text)
        last_dur = tok
    return last_dur


def _grace_text(ev, marks=None) -> str:
    """`\\grace { ... }` (or \\acciaccatura / \\appoggiatura) for the grace
    notes that precede `ev`."""
    parts = []
    for g in ev.graces:
        d = g.duration
        base = _TYPE_TO_LY.get(d.type, '8') + '.' * d.dots
        m = (marks or {}).get(id(g)) or {}
        parts.append(_body(g) + base + ''.join(m.get('end', ())) + ''.join(m.get('start', ())))
    return f'{ev.grace_cmd} {{ ' + ' '.join(parts) + ' }'


# ---------------------------------------------------------------------------
# A lane (one voice of one bar)
# ---------------------------------------------------------------------------

def _tuplet_spec(el):
    """[(actual, normal, type)] for a note's tuplets, outermost first."""
    return [(t.numberNotesActual, t.numberNotesNormal, t.type)
            for t in el.duration.tuplets]


def _emit_lane(events, marks=None):
    """(tokens, written_end) for one lane of one bar.

    Notes are laid end to end by their WRITTEN lengths. A gap is written
    as a silent spacer only where the source itself leaves a gap (the
    next event starts later than the previous one's sounding end), so a
    note whose sounding length and note value disagree does not turn
    into a phantom gap."""
    tokens, w_pos, src_end, last_dur = [], Fraction(0), Fraction(0), None
    open_groups = []          # ratios of currently open \\tuplet blocks

    def close_all():
        while open_groups:
            open_groups.pop()
            tokens.append('}')

    for ev in events:
        if ev.ctx:
            if ev.off > src_end + _EPS:          # a command later in a silent stretch
                close_all()
                tokens.append('s' + _spacer_tokens(ev.off - src_end))
                w_pos += ev.off - src_end
                src_end = ev.off
                last_dur = None
            tokens.append(ev.text)
            continue
        gap = ev.off - src_end
        if gap > _EPS:
            close_all()
            tokens.append('s' + _spacer_tokens(gap))
            last_dur = None
            w_pos += gap
        el = ev.obj
        specs = _tuplet_spec(el)

        if specs:
            for actual, normal, ttype in specs:
                starts = ttype in ('start', 'startStop')
                if starts or (not open_groups and len(open_groups) < len(specs)):
                    open_groups.append((actual, normal))
                    tokens.append(f'\\tuplet {actual}/{normal} {{')
        elif open_groups:
            close_all()

        if ev.graces:
            tokens.append(_grace_text(ev, marks))
            last_dur = None

        if ev.full_rest:
            tokens.append('R' + _mult(ev.ql))
            last_dur = None
        else:
            last_dur = _note_tokens(el, tokens, last_dur, marks, ev.dyns)

        if specs:
            for actual, normal, ttype in reversed(specs):
                if ttype in ('stop', 'startStop') and open_groups:
                    open_groups.pop()
                    tokens.append('}')
        src_end = ev.off + ev.ql
        w_pos += ev.wql

    close_all()
    return tokens, w_pos


# ---------------------------------------------------------------------------
# A part
# ---------------------------------------------------------------------------

@dataclass
class _Stats:
    ignored: Counter = field(default_factory=Counter)
    warned: set = field(default_factory=set)      # measure numbers already warned about
    repeat_unhandled: set = field(default_factory=set)   # (measure index, 'L'/'R') marks written plain
    plan_notes: list = field(default_factory=list)       # why a repeat was not written as one
    tempo_at_start: bool = False                         # the piece sets a MIDI tempo at time 0


def _bar_length(ts) -> Fraction:
    return _frac(ts.barDuration.quarterLength) if ts is not None else Fraction(4)


def _ctx_events(container, into, first_measure, state):
    """Clef/key/time/tempo commands sitting directly in `container`."""
    for el in container:
        off = _frac(el.offset)
        if isinstance(el, m21clef.Clef):
            text = clef_to_ly(el)
            if text and text != state['clef']:
                state['clef'] = text
                into.append(_Ev(off, Fraction(0), el, True, text))
        elif isinstance(el, m21key.KeySignature) and off == 0:
            text = key_to_ly(el)
            if text and text != state['key']:
                state['key'] = text
                into.append(_Ev(off, Fraction(0), el, True, text))
        elif isinstance(el, meter.TimeSignature) and off == 0:
            text = f'\\time {el.numerator}/{el.denominator}'
            if text != state['time']:
                state['time'] = text
                state['ts'] = el
                into.append(_Ev(off, Fraction(0), el, True, text))
        elif isinstance(el, tempo.TempoIndication):
            text = _tempo_commands(el)
            if text:
                into.append(_Ev(off, Fraction(0), el, True, text))


def _measure_lanes(m, state, stats):
    """(ctx_at_start, ctx_mid_bar, lanes) for one measure. Each lane is one
    voice-worth of events; which persistent voice of the part it continues
    is decided later, across all the measures (see _assign_tracks)."""
    ctx = []
    _ctx_events(m, ctx, False, state)

    trailing, chords, dyn_items = [], [], []

    def gather(container, base=Fraction(0), vid=None):
        evs, pending = [], []
        for el in container:
            if _is_sounding_or_rest(el):
                if el.duration.isGrace:
                    if getattr(el, 'lyrics', None):
                        stats.ignored['lyrics on grace notes (not written)'] += 1
                    if el.duration.type == 'quarter':
                        # The LilyPond importer records EVERY grace note as a
                        # quarter, whatever the source said; a real quarter
                        # grace note is rare, so this is worth pointing out.
                        stats.ignored['grace notes written as quarter notes (the LilyPond '
                                      'importer keeps no grace-note value; check them)'] += 1
                    pending.append(el)
                    continue
                q = _frac(el.duration.quarterLength)
                w = _written_ql(el.duration)
                full = False
                if isinstance(el, note.Rest) and (
                        getattr(el, 'fullMeasure', False) in (True, 'always')
                        or (el.duration.type in ('whole', 'breve') and abs(q - w) > _EPS)):
                    # A whole-bar rest: "whole" is the convention for a rest
                    # that fills ANY bar (3 quarters in 3/4), not a note
                    # value, so its sounding length is the truth.
                    full, w = True, q
                elif abs(q - w) > _EPS:
                    stats.ignored['notes whose sounding length differs from '
                                  'their written value (written value used)'] += 1
                ev = _Ev(_frac(el.offset), q, el, wql=w, full_rest=full)
                if pending:
                    ev.graces = pending
                    ev.grace_cmd = ('\\acciaccatura' if pending[0].duration.slash
                                    else '\\grace')
                    pending = []
                evs.append(ev)
            elif isinstance(el, harmony.Harmony):
                chords.append((_frac(el.offset) + base, el))
            elif isinstance(el, dynamics.Dynamic):
                t = _dynamic_text(el)
                if t:
                    dyn_items.append((_frac(el.offset) + base, t, vid))
            elif isinstance(el, note.Unpitched):
                stats.ignored['unpitched notes'] += 1
        if pending:
            trailing.extend(pending)       # they precede the next bar's first note
        return evs

    lanes = []
    for v in m.voices:
        base = _frac(v.offset)
        evs = gather(v, base, str(v.id))
        for e in evs:
            e.off += base
        for n, lane in enumerate(_assign_lanes(evs)):
            lanes.append(_Lane(('v', str(v.id), n), lane))
    direct = gather(m)
    for n, lane in enumerate(_assign_lanes(direct)):
        lanes.append(_Lane(('d', n), lane))
    # A dynamic belongs to the note it stands at (or, failing that, the next
    # note) in its own voice if it sits in one, else in any voice; one with
    # no note left in the bar goes to the next bar's first note.
    carry = []
    for off, text, vid in sorted(dyn_items, key=lambda x: x[0]):
        pref = [l for l in lanes if vid is not None and l.key[0] == 'v' and l.key[1] == vid]
        order = pref + [l for l in lanes if not any(l is q for q in pref)]

        def notes_of(lane):
            return [e for e in lane.evs if not e.ctx
                    and isinstance(e.obj, (note.Note, chord.Chord))]
        target = next((e for l in order for e in notes_of(l)
                       if abs(e.off - off) <= _EPS), None)
        if target is None:
            target = next((e for l in order for e in notes_of(l)
                           if e.off >= off - _EPS), None)
        if target is None:
            carry.append(text)
        else:
            if target.dyns:
                stats.ignored['dynamics dropped where two fall on one note (the later kept)'] += 1
            target.dyns = [text]
    state['trailing_graces'] = trailing
    state['md_chords'] = chords
    state['carry_dyn'] = carry
    return ([e for e in ctx if e.off == 0], [e for e in ctx if e.off > 0], lanes)


def _partial_text(ql: Fraction) -> str:
    d = _frac(ql)
    from music21 import duration as m21dur
    try:
        toks = _dur_tokens(m21dur.Duration(d))
    except Exception:
        toks = None
    if toks and len(toks) == 1 and not m21dur.Duration(d).tuplets:
        return f'\\partial {toks[0]}'
    return f'\\partial {_mult(d)}'


def _transposition_text(part) -> str | None:
    """`\\transposition` for a part whose notes are WRITTEN pitch. LilyPond
    wants the SOUNDING pitch of a written middle C (the same convention
    the LilyPond importer decodes; see its docstring)."""
    inst = part.getInstrument(returnDefault=False)
    intv = getattr(inst, 'transposition', None) if inst is not None else None
    if intv is None or part.atSoundingPitch is True:
        return None
    sounding = intv.transposePitch(pitch.Pitch('C4'))
    if sounding.name == 'C' and sounding.octave == 4:
        return None
    return f'\\transposition {pitch_to_ly(sounding)}'


# ---------------------------------------------------------------------------
# Repeats: written as real \\repeat volta structure in the PRINTED score
# ---------------------------------------------------------------------------

@dataclass
class _Rep:
    """One repeat section of a part, as measure INDEXES (0-based)."""
    start: int                 # first measure inside the repeat
    body_end: int              # last measure of the repeated body
    times: int
    endings: tuple = ()        # ((first, last), ...) 1st ending, 2nd ending
    inferred_ending: bool = False   # 2nd ending was not bracketed in the source
    marks: tuple = ()          # ((index, 'L'|'R'), ...) barlines this replaces

    def key(self):
        return (self.start, self.body_end, self.times, self.endings)

    @property
    def last(self):
        return self.endings[-1][1] if self.endings else self.body_end


def _bracket_table(part, measures):
    """[(numbers, sorted measure indexes)] for every volta bracket."""
    index = {id(m): i for i, m in enumerate(measures)}
    table = []
    for b in part.recurse().getElementsByClass(spanner.RepeatBracket):
        nums = getattr(b, 'numberRange', None)
        if not nums:
            try:
                nums = [int(x) for x in re.split(r'[,\s]+', str(b.number).strip()) if x]
            except ValueError:
                nums = []
        idxs = sorted(index[id(m)] for m in b.getSpannedElements() if id(m) in index)
        table.append((list(nums), idxs))
    return table


def _contiguous(idxs) -> bool:
    return bool(idxs) and idxs == list(range(idxs[0], idxs[-1] + 1))


def _repeat_plan(part, notes: list):
    """The repeat sections of `part` that can be written as `\\repeat volta`,
    or a list of reasons (appended to `notes`) for each that cannot.

    Supported: plain start/end repeats, an end repeat with no start bar
    (the section then starts right after the previous repeat, or at the top),
    and first/second endings. A second ending the source did not bracket is
    inferred only when the unmarked measures between the end of the first
    ending and the next repeat start are exactly as many as the first
    ending had; anything less clear is left as plain barlines and reported.
    Not supported (reported): nested repeats, endings numbered other than
    1 and 2, repeat bars without a partner."""
    ms = list(part.getElementsByClass(stream.Measure))
    left = {i for i, m in enumerate(ms)
            if isinstance(m.leftBarline, bar.Repeat) and m.leftBarline.direction == 'start'}
    right = {i: m.rightBarline for i, m in enumerate(ms)
             if isinstance(m.rightBarline, bar.Repeat) and m.rightBarline.direction == 'end'}
    if not left and not right:
        return []
    brs = _bracket_table(part, ms)

    pairs, open_start, prev_end = [], None, -1
    for i in range(len(ms)):
        if i in left:
            if open_start is not None:
                notes.append('nested repeats')
                return []
            open_start = i
        if i in right:
            start = open_start if open_start is not None else prev_end + 1
            pairs.append((start, i, right[i].times))
            open_start, prev_end = None, i
    if open_start is not None:
        notes.append(f'repeat start at measure {ms[open_start].number} has no matching end')

    plan = []
    for start, e, times in pairs:
        num = lambda k: ms[k].number
        b1 = next(((n, ix) for n, ix in brs if n == [1] and e in ix), None)
        endings, inferred = (), False
        body_end = e
        if b1:
            ix1 = b1[1]
            if not _contiguous(ix1) or ix1[-1] != e or ix1[0] <= start:
                notes.append(f'first ending near measure {num(e)} is not a clean bracket')
                continue
            body_end = ix1[0] - 1
            b2 = next(((n, ix) for n, ix in brs if n == [2] and ix and ix[0] == e + 1), None)
            if b2 and _contiguous(b2[1]):
                endings = ((ix1[0], e), (b2[1][0], b2[1][-1]))
            else:
                next_start = min([i for i in left if i > e] + [len(ms)])
                gap = next_start - (e + 1)
                if gap == len(ix1):
                    endings = ((ix1[0], e), (e + 1, e + gap))
                    inferred = True
                else:
                    notes.append(f'first ending at measure {num(e)} has no second ending bracket '
                                 f'and its extent cannot be inferred')
                    continue
            others = [(n, ix) for n, ix in brs
                      if ix and start <= ix[0] <= endings[-1][1] and n not in ([1], [2])]
            if others:
                notes.append(f'endings other than 1 and 2 near measure {num(e)}')
                continue
        else:
            if any(n and ix and start <= ix[0] <= e for n, ix in brs):
                notes.append(f'volta bracket inside the repeat ending at measure {num(e)} '
                             f'does not end at the repeat bar')
                continue
        marks = tuple(([(start, 'L')] if start in left else []) + [(e, 'R')])
        plan.append(_Rep(start, body_end, times or 2, endings, inferred, marks))
    return plan


def _plan_items(n_measures, plan):
    """[measure index | _Rep] in printed order."""
    starts = {r.start: r for r in plan}
    items, i = [], 0
    while i < n_measures:
        r = starts.get(i)
        if r is not None:
            items.append(r)
            i = r.last + 1
        else:
            items.append(i)
            i += 1
    return items


def _assemble(mlines, items, pad) -> list:
    out = []
    for it in items:
        if isinstance(it, int):
            out.append(pad + mlines[it])
            continue
        out.append(f'{pad}\\repeat volta {it.times} {{')
        out += [pad + '  ' + mlines[i] for i in range(it.start, it.body_end + 1)]
        if it.endings:
            out.append(pad + '}')
            out.append(pad + '\\alternative {')
            for a, b in it.endings:
                out.append(pad + '  {')
                out += [pad + '    ' + mlines[i] for i in range(a, b + 1)]
                out.append(pad + '  }')
            out.append(pad + '}')
        else:
            out.append(pad + '}')
    return out


def _part_lengths(part) -> list:
    """The written length of each measure of `part` (None for an empty
    one), computed the same way _emit_part will emit them."""
    state = {'clef': None, 'key': None, 'time': None, 'ts': None}
    out = []
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        for m in part.getElementsByClass(stream.Measure):
            _, _, lanes = _measure_lanes(m, state, _Stats())
            emitted = [_emit_lane(l.evs) for l in lanes]
            out.append(max((w for _, w in emitted), default=None))
    return out


def _canonical_lengths(parts, stats):
    """One length per measure index, shared by every staff. LilyPond keeps
    ONE bar clock for the whole score, so if staves disagree about how long
    a bar is (a corrupt source; a real pickup is short in every staff), the
    longest reading wins and the shorter staves are padded with spacers --
    otherwise one staff's odd bar breaks every other staff's bar checks."""
    per_part = [_part_lengths(p) for p in parts]
    counts = {len(x) for x in per_part}
    if len(counts) != 1:
        warnings.warn('the parts do not all have the same number of measures; '
                      'bar lengths were not reconciled across staves',
                      LilyExportWarning)
        return None
    canon, disagreements = [], 0
    for col in zip(*per_part):
        vals = [v for v in col if v is not None]
        top = max(vals, default=None)
        canon.append(top)
        if any(v is not None and abs(v - top) > _EPS for v in vals):
            disagreements += 1
    if disagreements:
        stats.ignored['measures where staves disagreed on the bar length '
                      '(shorter staves padded with silence)'] += disagreements
    return canon


_VOICE_CMD = ['\\voiceOne', '\\voiceTwo', '\\voiceThree', '\\voiceFour']


def _assign_tracks(per_measure_lanes):
    """Decide which PERSISTENT voice ("track") of the part each bar's lanes
    continue, so ties, slurs and lyrics run unbroken across barlines.

    A music21 Voice keeps its id from bar to bar, so its id names its track.
    Notes sitting directly in a Measure (no Voice) continue the part's first
    track when the bar has no Voices of its own; overlapping direct notes get
    tracks of their own. Returns (track keys in order, [ {track index: lane}
    per measure ])."""
    def vsort(k):
        vid = k[1]
        return (int(vid) if str(vid).isdigit() else 10 ** 6, str(vid), k[2])

    explicit = sorted({l.key for lanes in per_measure_lanes for l in lanes
                       if l.key[0] == 'v'}, key=vsort)
    extra, rows_keyed = set(), []
    for lanes in per_measure_lanes:
        has_v = any(l.key[0] == 'v' for l in lanes)
        row = []
        for l in lanes:
            if l.key[0] == 'v':
                tk = l.key
            elif not has_v and l.key[1] == 0 and explicit:
                tk = explicit[0]
            else:
                tk = l.key
                extra.add(tk)
            row.append((tk, l))
        rows_keyed.append(row)
    tracks = explicit + sorted(extra, key=lambda k: k[1])
    if not tracks:
        tracks = [('d', 0)]
    index = {k: i for i, k in enumerate(tracks)}
    rows = [{index[tk]: l for tk, l in row} for row in rows_keyed]
    return tracks, rows


def _tie_cont(el) -> bool:
    """True if this note/chord is tied FROM the previous one."""
    if isinstance(el, chord.Chord):
        ties = [n.tie for n in el.notes]
        return bool(ties) and all(t is not None and t.type in ('stop', 'continue') for t in ties)
    t = getattr(el, 'tie', None)
    return t is not None and t.type in ('stop', 'continue')


def _plan_slurs(part, track_notes, grace_owner, stats):
    """Work out, before anything is written, which slurs can be written and
    how. Returns (marks, covered, appoggiatura):
      marks:  {id(note): {'start': ['('], 'end': [')']}}
      covered: per track, the set of note positions LilyPond will treat as a
               melisma (every note after the first under a `(`..`)` slur)
      appoggiatura: ids of main notes whose grace notes carry the slur.
    One slur per voice is written as `( )`; a second, overlapping one as the
    phrasing slur `\\( \\)`. Anything else is counted, not silently lost."""
    pos = {}
    for t, notes in enumerate(track_notes):
        for i, el in enumerate(notes):
            pos[id(el)] = (t, i)

    def where(el, as_end):
        """(track, position) of a slur endpoint. A grace note sounds just
        before its main note, so it sits half a step earlier; only the END
        of a slur can be a grace note (LilyPond puts the `)` inside it)."""
        if id(el) in pos:
            return pos[id(el)]
        owner = grace_owner.get(id(el))
        if as_end and owner is not None and id(owner) in pos:
            t, k = pos[id(owner)]
            return (t, k - 0.5)
        return None

    marks, appog = {}, set()
    cands = {t: [] for t in range(len(track_notes))}
    for sl in part.recurse().getElementsByClass(spanner.Slur):
        els = list(sl.getSpannedElements())
        if len(els) < 2:
            continue
        first, last = els[0], els[-1]
        if id(first) in grace_owner and grace_owner[id(first)] is last:
            appog.add(id(last))
            continue
        w1, w2 = where(first, False), where(last, True)
        if w1 is None or w2 is None:
            stats.ignored['slurs not written (they start on a grace note or touch an unwritten note)'] += 1
            continue
        (t1, i), (t2, j) = w1, w2
        if t1 != t2:
            stats.ignored['slurs not written (they cross between voices)'] += 1
            continue
        if i > j:
            i, j, first, last = j, i, last, first
        if i == j:
            continue
        cands[t1].append((i, j, first, last))
    covered = [set() for _ in track_notes]
    for t, cs in cands.items():
        end_a = end_p = -1
        for i, j, first, last in sorted(cs, key=lambda c: (c[0], -c[1])):
            if end_a <= i:
                start, end, end_a = '(', ')', j
                # melisma: every whole note after the first, up to the end
                # (a slur ending on a grace note stops before its main note)
                covered[t].update(range(int(i) + 1, int(j - 0.5) + 1 if j % 1 else int(j) + 1))
            elif end_p <= i:
                start, end, end_p = '\\(', '\\)', j
            else:
                stats.ignored['slurs not written (nested more than two deep)'] += 1
                continue
            marks.setdefault(id(first), {'start': [], 'end': []})['start'].append(start)
            marks.setdefault(id(last), {'start': [], 'end': []})['end'].append(end)
    return marks, covered, appog


def _plan_hairpins(part, track_notes, dyn_ids, grace_owner, marks, stats):
    """`\\<` on the first note of a crescendo (`\\>` for a diminuendo) and `\\!`
    on the last note it spans, which is where music21 puts the end of a
    hairpin. A hairpin over a single note ends on the next one. A note that
    ends a hairpin AND carries a dynamic needs no `\\!`: the dynamic ends it."""
    pos = {}
    for t, notes in enumerate(track_notes):
        for i, el in enumerate(notes):
            pos[id(el)] = (t, i)
    cands = {t: [] for t in range(len(track_notes))}
    for w in part.recurse().getElementsByClass(dynamics.DynamicWedge):
        cmd = ('\\<' if isinstance(w, dynamics.Crescendo)
               else '\\>' if isinstance(w, dynamics.Diminuendo) else None)
        # (a grace note stands for the main note it precedes)
        els = [grace_owner.get(id(e), e) for e in w.getSpannedElements()]
        els = [e for e in els if id(e) in pos]
        if cmd is None or not els:
            stats.ignored['hairpins not written (unknown kind, or on no written note)'] += 1
            continue
        places = sorted(pos[id(e)] for e in els)      # music21's own order is not chronological
        (t, i), (t2, j) = places[0], places[-1]
        if t != t2:
            stats.ignored['hairpins not written (they cross between voices)'] += 1
            continue
        if j <= i:
            j = i + 1
        if j >= len(track_notes[t]):
            stats.ignored['hairpins not written (they run past the last note)'] += 1
            continue
        cands[t].append((i, j, cmd))
    for t, cs in cands.items():
        prev_end = -1
        for i, j, cmd in sorted(cs):
            if i < prev_end:
                stats.ignored['hairpins not written (overlapping another in the same voice)'] += 1
                continue
            marks.setdefault(id(track_notes[t][i]), {}).setdefault('hstart', []).append(cmd)
            end_note = track_notes[t][j]
            if id(end_note) not in dyn_ids:
                marks.setdefault(id(end_note), {}).setdefault('hend', []).append('\\!')
            prev_end = j


_FLAGS = {'eighth': 1, '16th': 2, '32nd': 3, '64th': 4, '128th': 5, '256th': 6}


def _beam_levels(el):
    bl = getattr(el, 'beams', None)
    return {b.number: b.type for b in (bl.beamsList if bl else [])}


def _plan_beams(rows, marks, stats):
    """Explicit beam groups: `[` on the first note and `]` on the last, taken
    from the source's level-1 beams, wherever the source has beam data at
    all. A group must open and close inside one bar of one voice. Where the
    source breaks an inner (secondary) beam that LilyPond would draw straight
    through, the number of beams either side of the break is set."""
    def finish(group):
        if len(group) < 2:
            return
        marks.setdefault(id(group[0]), {}).setdefault('bstart', []).append('[')
        marks.setdefault(id(group[-1]), {}).setdefault('end', []).append(']')
        for a, b in zip(group, group[1:]):
            la, lb = _beam_levels(a), _beam_levels(b)
            conn = sum(1 for lv, ta in la.items()
                       if ta in ('start', 'continue') and lb.get(lv) in ('continue', 'stop'))
            default = min(_FLAGS.get(a.duration.type, 0), _FLAGS.get(b.duration.type, 0))
            if conn < default:
                marks.setdefault(id(a), {}).setdefault('pre', []).append(
                    f'\\set stemRightBeamCount = #{conn}')
                marks.setdefault(id(b), {}).setdefault('pre', []).append(
                    f'\\set stemLeftBeamCount = #{conn}')

    for row in rows:
        for lane in row.values():
            group = None
            for ev in lane.evs:
                if ev.ctx or isinstance(ev.obj, note.Rest):
                    continue                     # a rest does not interrupt a beam
                typ = _beam_levels(ev.obj).get(1)
                if typ == 'start':
                    if group:
                        stats.ignored['beam groups not closed in their bar (not written)'] += 1
                    group = [ev.obj]
                elif typ == 'continue' and group is not None:
                    group.append(ev.obj)
                elif typ == 'stop' and group is not None:
                    group.append(ev.obj)
                    finish(group)
                    group = None
                elif typ is None and group is not None:
                    stats.ignored['beam groups broken by an unbeamed note (not written)'] += 1
                    group = None
            if group:
                stats.ignored['beam groups not closed in their bar (not written)'] += 1


def _lyric_token(text: str) -> str:
    if re.fullmatch(r'[^\W\d_]+', text):
        return text
    return '"' + text.replace('\\', '\\\\').replace('"', '\\"') + '"'


def _lyric_blocks(notes, covered, stats):
    """[(ignore_melismata, [tokens])] -- one entry per verse of one voice.

    LilyPond's own rule gives a syllable to each note except: a rest, a note
    tied from the one before, and every note after the first under a slur (a
    melisma). When the source agrees with that (none of those notes carries
    a syllable) the verse is written that way. When it does not, the verse
    is written with `ignoreMelismata`, which gives every note a slot, and
    `_` marks the ones with no syllable."""
    from core.lyrics import _key_of, _sortable
    verses = sorted({_key_of(l) for el in notes for l in el.lyrics}, key=_sortable)
    skipped = [_tie_cont(el) or i in covered for i, el in enumerate(notes)]
    out = []
    for v in verses:
        lyr = [next((l for l in el.lyrics if _key_of(l) == v), None) for el in notes]
        ignore = any(lyr[i] is not None and skipped[i] for i in range(len(notes)))
        toks = []
        for i in range(len(notes)):
            if skipped[i] and not ignore:
                continue
            l = lyr[i]
            if l is None:
                toks.append('_')
                continue
            toks.append(_lyric_token(l.text))
            if l.syllabic in ('begin', 'middle'):
                toks.append('--')
        while toks and toks[-1] in ('_', '--'):
            toks.pop()             # a hyphen with nothing after it is dropped by LilyPond anyway
        if toks:
            out.append((ignore, toks))
    return out


@dataclass
class _PartOut:
    named: bool                # written with named Voices (lyrics or several voices)
    tracks: list               # per track: its lines (no base indentation)
    lyrics: list               # [(track index, ignore_melismata, [tokens])]
    chords: list = field(default_factory=list)   # ChordNames lines, one per measure


def _emit_part(part, stats, canonical=None, plan=(), emit_tempo=True,
               chord_names=True) -> _PartOut:
    """One part as per-track lines of LilyPond."""
    measures = list(part.getElementsByClass(stream.Measure))
    if not measures:
        warnings.warn('a part has no Measures; it was written as empty',
                      LilyExportWarning)
        return _PartOut(False, [[]], [])
    state = {'clef': None, 'key': None, 'time': None, 'ts': None}
    handled = {mk for r in plan for mk in r.marks}

    mdata, carried, carried_dyn = [], [], []
    for idx, m in enumerate(measures):
        ctx, mid, lanes = _measure_lanes(m, state, stats)
        # One part's tempo marks are enough: LilyPond keeps them score-wide,
        # and several staves each saying "Allegro" would print it several times.
        is_tempo = lambda e: isinstance(e.obj, tempo.TempoIndication)
        if not emit_tempo:
            ctx = [e for e in ctx if not is_tempo(e)]
            mid = [e for e in mid if not is_tempo(e)]
        elif idx == 0 and any(is_tempo(e) and ('=' in e.text or 'tempoWholes' in e.text)
                              for e in ctx):
            stats.tempo_at_start = True
        if isinstance(m.leftBarline, bar.Repeat) and (idx, 'L') not in handled:
            stats.repeat_unhandled.add((idx, 'L'))
        if isinstance(m.rightBarline, bar.Repeat) and (idx, 'R') not in handled:
            stats.repeat_unhandled.add((idx, 'R'))
        if idx == 0:
            # Give the very first bar a clef/time even when the objects
            # live above the measure (a Part-level or Score-level context).
            if state['clef'] is None:
                c = m.getContextByClass(m21clef.Clef)
                text = clef_to_ly(c)
                if text:
                    state['clef'] = text
                    ctx.insert(0, _Ev(Fraction(0), Fraction(0), c, True, text))
            if state['time'] is None:
                ts = m.getContextByClass(meter.TimeSignature)
                if ts is not None:
                    state['time'] = f'\\time {ts.numerator}/{ts.denominator}'
                    state['ts'] = ts
                    ctx.append(_Ev(Fraction(0), Fraction(0), ts, True, state['time']))
        mdata.append((ctx, mid, lanes, state['ts'], state.pop('md_chords', [])))
        trailing = state.pop('trailing_graces', [])
        if trailing:
            carried.append((idx, trailing))
        cd = state.pop('carry_dyn', [])
        if cd:
            carried_dyn.append((idx, cd))

    # Grace notes at the end of a bar are written before the first note of
    # the next bar; only ones with no next bar are dropped (and counted).
    for idx, graces in carried:
        target = None
        if idx + 1 < len(mdata):
            for lane in mdata[idx + 1][2]:
                target = next((e for e in lane.evs if not e.ctx), None)
                if target is not None:
                    break
        if target is None:
            stats.ignored['grace notes after the last note of the piece (not written)'] += len(graces)
            continue
        target.graces = graces + target.graces
        target.grace_cmd = '\\acciaccatura' if graces[0].duration.slash else '\\grace'

    for idx, texts in carried_dyn:
        target = None
        if idx + 1 < len(mdata):
            for lane in mdata[idx + 1][2]:
                target = next((e for e in lane.evs if not e.ctx
                               and isinstance(e.obj, (note.Note, chord.Chord))), None)
                if target is not None:
                    break
        if target is None:
            stats.ignored['dynamics after the last note (not written)'] += len(texts)
        else:
            if target.dyns or len(texts) > 1:
                stats.ignored['dynamics dropped where two fall on one note (the later kept)'] += \
                    len(texts) + len(target.dyns) - 1
            target.dyns = target.dyns or texts[-1:]

    tracks, rows = _assign_tracks([d[2] for d in mdata])
    nt = len(tracks)

    # Note order per track, grace-note owners, slurs and lyrics, all decided
    # before any text is written.
    track_notes = [[] for _ in range(nt)]
    grace_owner = {}
    for idx in range(len(measures)):
        for ti, lane in rows[idx].items():
            for ev in lane.evs:
                if isinstance(ev.obj, (note.Note, chord.Chord)):
                    track_notes[ti].append(ev.obj)
                    for g in ev.graces:
                        grace_owner[id(g)] = ev.obj
    # What the LilyPond importer makes of \afterGrace: a voice of rests and
    # spacers carrying only the grace note, at the start of the note it follows.
    only_graces = sum(1 for ti in range(nt) if not track_notes[ti]
                      and any(ev.graces for row in rows for ev in (row[ti].evs if ti in row else [])))
    if only_graces:
        stats.ignored['voices holding only rests and grace notes (typically \\afterGrace '
                      'as read by the LilyPond importer; the grace note is at the wrong time)'] += only_graces
    marks, covered, appog = _plan_slurs(part, track_notes, grace_owner, stats)
    dyn_ids = {id(ev.obj) for row in rows for lane in row.values()
               for ev in lane.evs if ev.dyns}
    _plan_hairpins(part, track_notes, dyn_ids, grace_owner, marks, stats)
    # Where the source has beam data at all it is followed exactly (every group
    # written by hand, automatic beaming off); a source with none is left to
    # LilyPond's automatic beaming.
    explicit_beams = any(_beam_levels(el) for notes in track_notes for el in notes)
    if explicit_beams:
        _plan_beams(rows, marks, stats)
    for idx in range(len(measures)):
        for lane in rows[idx].values():
            for ev in lane.evs:
                if id(ev.obj) in appog and ev.graces and ev.grace_cmd == '\\grace':
                    ev.grace_cmd = '\\appoggiatura'
    lyrics = [(ti, ig, toks) for ti in range(nt)
              for ig, toks in _lyric_blocks(track_notes[ti], covered[ti], stats)]
    named = nt > 1 or bool(lyrics)
    if nt > 4 and 'more than four voices' not in stats.warned:
        stats.warned.add('more than four voices')
        warnings.warn(f'a part has {nt} voices; stem directions are set for four',
                      LilyExportWarning)

    pre = [[] for _ in range(nt)]
    tr = _transposition_text(part)
    if tr:
        pre[0].append(tr)
    if explicit_beams:
        lyric_tracks = {ti for ti, _, _ in lyrics}
        for ti in range(nt):
            pre[ti].append('\\autoBeamOff')
            if ti in lyric_tracks:
                # LilyPond reads a hand-written beam as a melisma, which would
                # swallow syllables; the lyrics here follow slurs and ties only.
                pre[ti].append("\\set melismaBusyProperties = "
                               "#'(melismaBusy slurMelismaBusy tieMelismaBusy)")
    mlines = [[] for _ in range(nt)]
    chord_lines = []
    has_chords = chord_names and any(d[4] for d in mdata)
    cur_mode = ['\\oneVoice'] * nt

    for idx, m in enumerate(measures):
        ctx, mid, lanes, ts, chords_m = mdata[idx]
        row = rows[idx]
        bar_len = _bar_length(ts) if ts is not None else Fraction(4)

        emitted = {}
        for ti in range(nt):
            lane = row.get(ti)
            evs = list(lane.evs) if lane else []
            if ti == 0 and mid:
                evs = sorted(evs + mid, key=lambda e: (e.off, not e.ctx))
            if lane or (ti == 0 and mid):
                emitted[ti] = _emit_lane(evs, marks)
        length = max((w for _, w in emitted.values()), default=Fraction(0))
        if canonical is not None and canonical[idx] is not None \
                and canonical[idx] > length + _EPS:
            length = canonical[idx]
        if not row:
            length = length or bar_len

        head = [e.text for e in sorted(ctx, key=lambda e: _CTX_ORDER(e))]
        checkable, overfull = True, False
        if length < bar_len - _EPS:
            head.append(_partial_text(length))
        elif length > bar_len + _EPS:
            if m.number not in stats.warned:
                stats.warned.add(m.number)
                warnings.warn(f'measure {m.number}: holds {float(length)} quarters '
                              f'but the meter allows {float(bar_len)}; written as '
                              f'one irregular bar (\\cadenzaOn) so it cannot '
                              f'shift the bars after it', LilyExportWarning)
            checkable, overfull = False, True

        rb = m.rightBarline
        barcmd = ''
        if rb is not None and not isinstance(rb, bar.Repeat):
            sym = _BAR_TO_LY.get(rb.type)
            if sym:
                barcmd = f' \\bar "{sym}"'

        if has_chords:
            chord_lines.append(
                _chord_measure_tokens(chords_m, length, stats)
                + (' |' if checkable else '') + f'  % {m.number}')

        n_active = len(row)
        for ti in range(nt):
            seg = list(head) if ti == 0 else []
            if ti in emitted:
                if ti in row:
                    mode = '\\oneVoice' if n_active == 1 else _VOICE_CMD[min(ti, 3)]
                    if mode != cur_mode[ti]:
                        seg.append(mode)
                        cur_mode[ti] = mode
                toks, w_end = emitted[ti]
                if w_end < length - _EPS:
                    toks = toks + ['s' + _spacer_tokens(length - w_end)]
                body = ' '.join(toks)
            else:
                body = 's' + _spacer_tokens(length)
            tail = ''
            if ti == 0:
                if overfull:
                    # Without this LilyPond would split the bar at the meter's
                    # length and every later bar check would drift.
                    body = '\\cadenzaOn ' + body + ' \\cadenzaOff'
                    tail = barcmd or ' \\bar "|"'
                else:
                    tail = barcmd
            seg.append(body + tail)
            text = ' '.join(x for x in seg if x)
            mlines[ti].append(f'{text} {"|" if checkable else ""}'.rstrip()
                              + f'  % {m.number}')

    items = _plan_items(len(measures), plan)
    out_tracks = []
    for ti in range(nt):
        lines = list(pre[ti]) + _assemble(mlines[ti], items, '')
        out_tracks.append(lines)
    return _PartOut(named, out_tracks, lyrics, chord_lines)


def _CTX_ORDER(e):
    t = e.text
    for i, prefix in enumerate(('\\clef', '\\key', '\\time', '\\tempo')):
        if t.startswith(prefix):
            return i
    return 9


# ---------------------------------------------------------------------------
# The score
# ---------------------------------------------------------------------------

def _scan_unsupported(score, stats):
    """Count what this export does not carry, for the one summary warning."""
    n = len(score.recurse().getElementsByClass(expressions.TextExpression))
    if n:
        stats.ignored['text expressions (words such as "dolce", "cresc.")'] += n
    if getattr(score, '_manual_multistaff_parts', None):
        stats.ignored['cross-staff structure (staves written independently)'] += 1


def _staff_groups(score):
    """[(kind, [part indices])] where kind is 'staff', 'piano' or 'group'.
    Grouping comes from StaffGroup spanners (what music21's MusicXML reader
    makes for a grand staff); parts outside any group are single staves."""
    parts = list(score.parts)
    index = {id(p): i for i, p in enumerate(parts)}
    in_group, out = {}, {}
    for g in score.getElementsByClass(layout.StaffGroup):
        members = [index[id(p)] for p in g.getSpannedElements() if id(p) in index]
        if len(members) < 2:
            continue
        kind = 'piano' if g.symbol == 'brace' else 'group'
        first = min(members)
        out[first] = (kind, sorted(members))
        for i in members:
            in_group[i] = first
    result, i = [], 0
    while i < len(parts):
        if i in out:
            result.append(out[i])
            i = max(out[i][1]) + 1
        elif i in in_group:
            i += 1
        else:
            result.append(('staff', [i]))
            i += 1
    return result


def _lyric_lines(tokens, per_line=12, indent='      '):
    return '\n'.join(indent + ' '.join(tokens[k:k + per_line])
                     for k in range(0, len(tokens), per_line))


def _staff_block(n, po) -> str:
    """The text of one part: a plain Staff, or -- when it has lyrics or
    several voices -- a Staff of named, persistent Voices with its Lyrics
    lines beside it."""
    chord_text = ''
    if po.chords:
        cbody = '\n'.join('        ' + l for l in po.chords)
        chord_text = f'    \\new ChordNames \\chordmode {{\n{cbody}\n    }}\n'
    if not po.named:
        body = '\n'.join('        ' + l for l in po.tracks[0])
        return chord_text + f'    \\new Staff = "p{n}" {{\n{body}\n    }}'
    voices = []
    for k, lines in enumerate(po.tracks, start=1):
        body = '\n'.join('          ' + l for l in lines)
        voices.append(f'      \\new Voice = "p{n}v{k}" {{\n{body}\n      }}')
    text = chord_text + f'    \\new Staff = "p{n}" <<\n' + '\n'.join(voices) + '\n    >>'
    for ti, ignore, toks in po.lyrics:
        with_ = ' \\with { ignoreMelismata = ##t }' if ignore else ''
        text += (f'\n    \\new Lyrics{with_} \\lyricsto "p{n}v{ti + 1}" {{ \\lyricmode {{\n'
                 f'{_lyric_lines(toks)}\n    }} }}')
    return text


def _plans_for(parts, stats):
    """One repeat plan per part, or all-empty if the parts disagree: LilyPond
    keeps one clock for every staff, and a MIDI unfolded from staves that
    repeat differently would go out of step."""
    plans = []
    for p in parts:
        notes = []
        plans.append(_repeat_plan(p, notes))
        for n in notes:
            stats.plan_notes.append(n)
    keys = [[r.key() for r in pl] for pl in plans]
    if any(k != keys[0] for k in keys):
        stats.plan_notes.append('the staves do not all repeat the same way')
        return [[] for _ in parts]
    for r in plans[0] if plans else []:
        if r.inferred_ending:
            stats.ignored['second endings inferred (not bracketed in the source)'] += 1
    return plans


def score_to_lilypond(score, *, midi: bool = False, midi_tempo: int | None = 120,
                      chord_names: bool = True) -> str:
    """The .ly text for `score`.

    The music is defined once, as `music`, and used by two \\score blocks:
    the printed one (\\layout) keeps every repeat as a repeat; with
    `midi=True` a second, MIDI-only block (\\midi, no \\layout, so it
    prints nothing) wraps the same music in \\unfoldRepeats so the MIDI
    file plays every pass."""
    stats = _Stats()
    _scan_unsupported(score, stats)
    parts = list(score.parts) if hasattr(score, 'parts') and score.parts else [score]

    canonical = _canonical_lengths(parts, stats) if len(parts) > 1 else None
    plans = _plans_for(parts, stats)
    staff_text = {}
    def has_tempo(p):
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            return any(isinstance(x, tempo.TempoIndication) and _tempo_commands(x)
                       for x in p.recurse())
    tempo_part = next((i for i, p in enumerate(parts) if has_tempo(p)), None)
    for i, p in enumerate(parts):
        po = _emit_part(p, stats, canonical=canonical, plan=plans[i],
                        emit_tempo=(tempo_part is None or i == tempo_part),
                        chord_names=chord_names)
        staff_text[i] = _staff_block(i + 1, po)

    blocks = []
    for kind, members in _staff_groups(score) if len(parts) > 1 else [('staff', [0])]:
        if kind == 'staff':
            blocks.append(staff_text[members[0]])
        else:
            wrapper = '\\new PianoStaff' if kind == 'piano' else '\\new StaffGroup'
            inner = '\n'.join('  ' + ln for i in members
                              for ln in staff_text[i].split('\n'))
            blocks.append(f'    {wrapper} <<\n{inner}\n    >>')

    if stats.repeat_unhandled:
        stats.ignored['repeat barlines written as plain barlines'] += len(stats.repeat_unhandled)
    if stats.ignored or stats.plan_notes:
        bits = [f'{k}: {v}' for k, v in sorted(stats.ignored.items())]
        bits += [f'repeat not written as a repeat -- {n}' for n in dict.fromkeys(stats.plan_notes)]
        warnings.warn('not written to the LilyPond output -- ' + '; '.join(bits),
                      LilyExportWarning)

    out = [f'\\version "{LILYPOND_VERSION}"', '', 'music = <<']
    out.extend(blocks)
    out.append('>>')
    out += ['', '\\score {', '  \\music', '  \\layout { }', '}']
    if midi:
        # LilyPond's own default MIDI tempo is 60; a piece that sets none of
        # its own at the start is played at `midi_tempo` instead.
        dflt = '' if stats.tempo_at_start or midi_tempo is None else f'\\tempo 4 = {midi_tempo}'
        # Every Staff, Lyrics and ChordNames context would otherwise claim a MIDI
        # channel (LilyPond has 15 usable ones), so a large score with lyrics and
        # chord names overruns them; only the staves make sound.
        out += ['', '\\score {', '  \\unfoldRepeats \\music', '  \\midi {']
        if dflt:
            out.append('    ' + dflt)
        out += ['    \\context { \\ChordNames \\remove "Staff_performer" }',
                '    \\context { \\Lyrics \\remove "Staff_performer" }',
                '  }', '}']
    return '\n'.join(out) + '\n'


def write_lilypond(score, path, *, midi: bool = False, midi_tempo: int | None = 120,
                   chord_names: bool = True) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(score_to_lilypond(score, midi=midi, midi_tempo=midi_tempo,
                                      chord_names=chord_names), encoding='utf-8')
    return path


# ---------------------------------------------------------------------------
# Compile + verify
# ---------------------------------------------------------------------------

_WARN_RE = re.compile(r'(barcheck|warning|error)', re.I)


def compile_lilypond(ly_path, out_dir=None, formats=('png',), lilypond_bin='lilypond',
                     resolution=90):
    """Run LilyPond on `ly_path`. Returns (returncode, stderr text).

    LilyPond takes ONE output backend per run (svg and pdf cannot come out
    of the same invocation), so each requested format is its own run; the
    MIDI file, if the .ly asks for one, is written by every run. With
    `formats` empty a single default (PDF) run happens, as before."""
    ly_path = Path(ly_path)
    out_dir = Path(out_dir) if out_dir else ly_path.parent
    out_dir.mkdir(parents=True, exist_ok=True)
    runs = [f for f in dict.fromkeys(formats)] or [None]
    rc, errs = 0, []
    for f in runs:
        cmd = [lilypond_bin, '-o', str(out_dir / ly_path.stem)]
        if f == 'png':
            cmd += ['--png', f'-dresolution={resolution}']
        elif f == 'svg':
            cmd += ['-dbackend=svg']
        cmd.append(str(ly_path))
        r = subprocess.run(cmd, capture_output=True, text=True)
        rc = rc or r.returncode
        errs.append(r.stderr)
    return rc, '\n'.join(errs)


def lilypond_problems(stderr: str) -> list:
    """The lines of LilyPond's output that mean the .ly is not right:
    every 'barcheck failed', warning, or error."""
    # (LilyPond prints "ignoring unsupported formats (pdf)" on every SVG run,
    # because its default format list includes pdf; it means nothing.)
    return [l for l in stderr.splitlines()
            if _WARN_RE.search(l) and 'GNU LilyPond' not in l
            and 'ignoring unsupported formats' not in l]
