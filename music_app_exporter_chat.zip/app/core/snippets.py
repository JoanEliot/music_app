"""
core/snippets.py

Splits one marked-up Score into several independent Scores ("snippets"):
the rhythm exercises, licks or excerpts an author has strung together in
one file. Format-independent -- it works on the Score's text expressions,
so anything an importer turns into a music21 TextExpression can carry the
markers (MusicXML <words>, and LilyPond `^"SS: ..."` annotations via the
LilyPond importer). Adapted from the author's experimental
musicxml_to_lilypond_charts_and_midi.py, whose marker language and
end-of-snippet rules are kept.

MARKERS (text, in the first part that has any; one per line, case-
insensitive, `CODE: value`):
    SS: title     Snippet Start. Starts a snippet and closes any snippet
                  still open just before it. The title may be empty.
    SR: name      Rhythm name for a snippet.
    SD: text      Source of a snippet (the script's `source` field).
    SE:           Snippet End.
SR/SD apply to the snippet currently open, or -- if none is open -- to
the NEXT one to start. A snippet also ends at the end of a measure whose
right barline is anything but a plain single bar (double, final, repeat).
A snippet still open at the end of the piece ends with the last measure.

WHERE A MARKER POINTS. A marker sits at a position in the music, and that
position is the cut:
  - `SS:` on the FIRST note of a measure (offset 0) starts the snippet at
    that measure. `SS:` on any LATER note starts it AT THAT NOTE: that
    note is the snippet's first note, and the rest of its bar becomes the
    snippet's opening pickup bar (an anacrusis). A pickup has no downbeat
    of its own -- its first note is where the snippet begins, so that is
    where the marker goes. A source that already has a short pickup
    MEASURE needs nothing special: `SS:` on its first note is offset 0.
  - `SE:` on the first note of a measure ends the snippet at the end of
    that measure (the original rule). `SE:` on any later note ends it
    AFTER THAT NOTE: it is the snippet's last note, and its bar stays
    short. (A snippet meant to end on the first note of a bar can't say so
    with SE alone -- end it with a double bar or start the next snippet.)
  - `SS:` in the middle of a bar also closes the snippet before it right
    there, mid-bar, when that one had no `SE:`.
Cutting mid-bar affects every part at that position. A note held across
the cut point in another part is SHORTENED to the part inside the
snippet (and the cut says so in a SnippetCutWarning); a cut that falls
inside a tuplet is made anyway, with a warning, since the group can't be
kept whole. Source beams in a trimmed bar are recomputed.

WHAT AN EXTRACTED SNIPPET IS: a deep copy of the whole Score (every
part, so lyrics, dynamics, articulations, chord symbols etc. all come
along) cut down to the snippet's measures, with
  - clef, key and time signature in force at the snippet's start
    re-inserted if the cut lost them;
  - slurs/hairpins/other spanners that reached outside the cut dropped,
    and ties that crossed the cut trimmed so none dangle;
  - measures renumbered from 1 (0 if the snippet opens on an anacrusis);
  - the marker text itself removed;
  - a metadata dict derived from the parent's: the snippet's title
    becomes movement_title (the parent's work title stays), SD becomes
    source, and a `snippet` entry records index/count/title/rhythm name/
    source/measure range and what was overridden. See score_metadata.
A snippet whose first measure is short is an anacrusis (numbered 0, padded
as a pickup); one whose last measure is short simply stops short -- see
core/measures.py.
Measures are addressed by POSITION, not by printed number, so repeated or
duplicate measure numbers (first/second endings) can't confuse the cut.
"""

import copy
import re
from dataclasses import dataclass
from typing import Optional

import warnings

from music21 import beam, bar, chord, clef, expressions, key, meter, note, stream
from music21.stream.makeNotation import makeBeams

from core.measures import mark_short_measures
from core.score_metadata import display_title, get_metadata

_EPS = 1e-6


class SnippetCutWarning(UserWarning):
    """A mid-bar cut had to shorten a held note or split a tuplet group."""

MARKER_RE = re.compile(r'^\s*(SS|SR|SD|SE)\s*:\s*(.*?)\s*$', re.IGNORECASE)


@dataclass
class Snippet:
    index: int                       # 1-based position among the snippets
    start: int                       # 0-based measure position, inclusive
    end: int                         # 0-based measure position, inclusive
    title: Optional[str] = None
    rhythm_name: Optional[str] = None
    source: Optional[str] = None
    start_offset: float = 0.0            # quarter notes into the START measure
    end_offset: Optional[float] = None   # None: through the end of the END
                                         # measure; else the cut point, in
                                         # quarter notes into the END measure


def parse_markers(text):
    """[(CODE, value)] for every marker line in a text expression."""
    out = []
    for line in (text or '').splitlines():
        m = MARKER_RE.match(line)
        if m:
            out.append((m.group(1).upper(), m.group(2).strip()))
    return out


def _measure_markers(measure):
    """[(code, value, offset in the measure)] in music order."""
    found = []
    for te in measure.recurse().getElementsByClass(expressions.TextExpression):
        offset = float(te.getOffsetInHierarchy(measure))
        for code, value in parse_markers(te.content):
            found.append((code, value, offset))
    return found


def _end_after_note(measure, offset) -> float:
    """Where the note(s) starting at `offset` in this measure end (or
    `offset` itself if none start there)."""
    ends = [offset]
    for n in measure.recurse().notesAndRests:
        if n.duration.isGrace:
            continue
        if abs(float(n.getOffsetInHierarchy(measure)) - offset) <= _EPS:
            ends.append(offset + float(n.duration.quarterLength))
    return max(ends)


def _marker_part(score):
    """The first Part that carries any snippet marker, or None."""
    for part in score.parts:
        for m in part.getElementsByClass(stream.Measure):
            if _measure_markers(m):
                return part
    return None


def detect_snippets(score) -> list:
    """Snippet definitions found in `score` (empty list if it has no
    markers). See the module docstring for the marker language."""
    part = _marker_part(score)
    if part is None:
        return []
    measures = list(part.getElementsByClass(stream.Measure))

    snippets, current, pending = [], None, {}

    def close(end):
        nonlocal current
        if current is not None:
            current.end = end
            current.end_offset = None
            snippets.append(current)
            current = None

    for i, measure in enumerate(measures):
        for code, value, off in _measure_markers(measure):
            if code == 'SS':
                if current is not None:
                    if off > _EPS:               # a mid-bar start closes it mid-bar
                        current.end, current.end_offset = i, off
                    else:
                        current.end, current.end_offset = i - 1, None
                    snippets.append(current)
                    current = None
                current = Snippet(index=0, start=i, end=-1, title=value or None,
                                  rhythm_name=pending.get('rhythm_name'),
                                  source=pending.get('source'),
                                  start_offset=off if off > _EPS else 0.0)
                pending = {}
            elif code == 'SR':
                if current is not None:
                    current.rhythm_name = value or None
                else:
                    pending['rhythm_name'] = value or None
            elif code == 'SD':
                if current is not None:
                    current.source = value or None
                else:
                    pending['source'] = value or None
            elif code == 'SE':
                if current is not None:
                    current.end = i
                    current.end_offset = (None if off <= _EPS
                                          else _end_after_note(measure, off))
                    snippets.append(current)
                    current = None
        rb = measure.rightBarline
        if current is not None and rb is not None and rb.type != 'regular':
            close(i)
    close(len(measures) - 1)

    snippets = [s for s in snippets
                if (s.end, s.end_offset if s.end_offset is not None else 1e9)
                > (s.start, s.start_offset)]
    for n, s in enumerate(snippets, start=1):
        s.index = n
    return snippets


# ---------------------------------------------------------------------------
# extraction
# ---------------------------------------------------------------------------

def _trim_boundary_ties(first_measure, last_measure):
    """Ties that started before / continue past the cut would dangle."""
    def notes_of(m):
        for n in m.recurse().notes:
            if isinstance(n, chord.Chord):
                yield n
                yield from n.notes
            else:
                yield n

    for n in notes_of(first_measure):
        if n.tie is not None:
            if n.tie.type == 'stop':
                n.tie = None
            elif n.tie.type == 'continue':
                n.tie.type = 'start'
    for n in notes_of(last_measure):
        if n.tie is not None:
            if n.tie.type == 'start':
                n.tie = None
            elif n.tie.type == 'continue':
                n.tie.type = 'stop'


_GLOBALS = (clef.Clef, key.KeySignature, meter.TimeSignature)


def _containers(measure):
    """The measure itself plus each of its voices (offsets in a voice are
    taken as relative to the measure, which is how music21 keeps them)."""
    return [measure] + list(measure.getElementsByClass(stream.Voice))


def _cut_measure(measure, start_offset, end_offset, stats):
    """Trim one measure IN PLACE to the span [start_offset, end_offset) --
    offsets in quarter notes from the measure's start, end_offset None
    meaning "to the end". Content before the start is dropped and what
    remains slides back to offset 0 (so a start cut leaves a short opening
    pickup bar); content from the end on is dropped (a short closing bar).
    A note that straddles a cut is SHORTENED to the part inside (counted in
    `stats`). Padding info is reset; core.measures re-derives it."""
    from importers.notation_repair import _split_segments

    # a cut inside a tuplet group can't keep the group whole
    for c in _containers(measure):
        els = [e for e in c.notesAndRests if not e.duration.isGrace]
        for kind, seg in _split_segments(els) if els else []:
            if kind != 'group':
                continue
            lo = min(float(e.offset) for e in seg)
            hi = max(float(e.offset + e.duration.quarterLength) for e in seg)
            for cut_at in [start_offset] + ([end_offset] if end_offset is not None else []):
                if cut_at > _EPS and lo < cut_at - _EPS and hi > cut_at + _EPS:
                    stats['tuplet'] += 1

    def is_structural(el):
        return isinstance(el, (stream.Voice, bar.Barline))

    if end_offset is not None:
        for c in _containers(measure):
            for el in list(c.elements):
                if is_structural(el):
                    continue
                off = float(el.offset)
                if isinstance(el, note.GeneralNote):
                    dur = float(el.duration.quarterLength)
                    if off >= end_offset - _EPS:
                        c.remove(el)
                    elif off + dur > end_offset + _EPS:
                        el.duration.quarterLength = end_offset - off
                        stats['shortened'] += 1
                elif off >= end_offset - _EPS and not isinstance(el, _GLOBALS):
                    c.remove(el)

    if start_offset > _EPS:
        for c in _containers(measure):
            last_global = {}
            for el in list(c.elements):
                if is_structural(el):
                    continue
                off = float(el.offset)
                if isinstance(el, note.GeneralNote):
                    dur = float(el.duration.quarterLength)
                    if off + dur <= start_offset + _EPS:
                        c.remove(el)
                    elif off >= start_offset - _EPS:
                        c.setElementOffset(el, off - start_offset)
                    else:                                  # straddles the cut
                        el.duration.quarterLength = off + dur - start_offset
                        c.setElementOffset(el, 0.0)
                        stats['shortened'] += 1
                elif isinstance(el, _GLOBALS):
                    if off <= start_offset + _EPS:         # in force at the cut
                        prev = last_global.get(type(el))
                        if prev is not None:
                            c.remove(prev)
                        last_global[type(el)] = el
                    else:
                        c.setElementOffset(el, off - start_offset)
                elif off < start_offset - _EPS:
                    c.remove(el)
                else:
                    c.setElementOffset(el, off - start_offset)
            for el in last_global.values():
                c.setElementOffset(el, 0.0)

    measure.paddingLeft = 0.0
    measure.paddingRight = 0.0


def extract_snippet(score, snippet: Snippet, count: int, strip_markers=True):
    """One snippet as an independent Score (see module docstring)."""
    work = copy.deepcopy(score)
    kept_ids = set()
    ctx = {}
    stats = {'shortened': 0, 'tuplet': 0}
    cut_by_part = {}

    for part in work.parts:
        measures = list(part.getElementsByClass(stream.Measure))
        if snippet.start >= len(measures):
            keep = []
        else:
            keep = measures[snippet.start:snippet.end + 1]
        if keep:
            first = keep[0]
            ctx[id(part)] = (first.getContextByClass(clef.Clef),
                             first.getContextByClass(key.KeySignature),
                             first.getContextByClass(meter.TimeSignature))
        for m in measures:
            if m not in keep:
                part.remove(m)
        cut_ms = []
        if keep:
            if len(keep) == 1:
                if snippet.start_offset > _EPS or snippet.end_offset is not None:
                    _cut_measure(keep[0], snippet.start_offset, snippet.end_offset, stats)
                    cut_ms.append(keep[0])
            else:
                if snippet.start_offset > _EPS:
                    _cut_measure(keep[0], snippet.start_offset, None, stats)
                    cut_ms.append(keep[0])
                if snippet.end_offset is not None:
                    _cut_measure(keep[-1], 0.0, snippet.end_offset, stats)
                    cut_ms.append(keep[-1])
        cut_by_part[id(part)] = cut_ms
        for m in keep:
            kept_ids.add(id(m))
            for el in m.recurse():
                kept_ids.add(id(el))
        if keep:
            _trim_boundary_ties(keep[0], keep[-1])

    # spanners (slurs, hairpins, ...) that reach outside the kept measures
    for sp in list(work.recurse().getElementsByClass('Spanner')):
        if any(id(el) not in kept_ids for el in sp.getSpannedElements()):
            for site in list(sp.sites.get()):
                try:
                    site.remove(sp)
                except Exception:
                    pass

    for part in work.parts:
        keep = list(part.getElementsByClass(stream.Measure))
        if not keep:
            continue
        first = keep[0]
        c, k, t = ctx.get(id(part), (None, None, None))
        if c is not None and first.clef is None:
            first.insert(0, copy.deepcopy(c))
        if k is not None and first.keySignature is None:
            first.insert(0, copy.deepcopy(k))
        if t is not None and first.timeSignature is None:
            first.insert(0, copy.deepcopy(t))
        # A snippet that opens on a short measure opens on an anacrusis:
        # number it 0 (padding is recorded by core.measures at write time).
        # (the measure's OWN time signature first: getContextByClass looks at
        # what comes BEFORE a measure, so it misses one in the very measure
        # the snippet opens in)
        ts_now = first.timeSignature or t
        bar = float(ts_now.barDuration.quarterLength) if ts_now is not None else None
        opens_short = (bar is not None
                       and float(first.duration.quarterLength) < bar - 1e-6)
        base = 0 if (first.number == 0 or opens_short) else 1
        for n, m in enumerate(keep, start=base):
            m.number = n
            m.numberSuffix = None

    # Padding for the trimmed bars, then re-beam them: source beams in a
    # trimmed bar point at notes that are gone (or at the wrong span).
    mark_short_measures(work)
    for part in work.parts:
        for m in cut_by_part.get(id(part), []):
            for n in m.recurse().notes:
                n.beams = beam.Beams()
            try:
                makeBeams(m, inPlace=True)
            except Exception as e:      # never let beaming block the cut
                warnings.warn(f"Could not re-beam a trimmed bar ({e}).", SnippetCutWarning)
    if stats['shortened']:
        warnings.warn(f"Snippet {snippet.index}: {stats['shortened']} note(s) held across "
                      f"a mid-bar cut were shortened to the part inside the snippet.",
                      SnippetCutWarning)
    if stats['tuplet']:
        warnings.warn(f"Snippet {snippet.index}: a mid-bar cut falls inside a tuplet group, "
                      f"which can't be kept whole.", SnippetCutWarning)

    if strip_markers:
        for te in list(work.recurse().getElementsByClass(expressions.TextExpression)):
            if MARKER_RE.match((te.content or '').strip().splitlines()[0]
                               if (te.content or '').strip() else ''):
                for site in list(te.sites.get()):
                    try:
                        site.remove(te)
                    except Exception:
                        pass

    # metadata derived from the parent's
    parent = get_metadata(score)
    md = copy.deepcopy(parent)
    parent_title = display_title(parent)
    overridden = {}
    if parent.get('movement_title'):
        overridden['movement_title'] = parent['movement_title']
    if parent.get('movement_number'):
        overridden['movement_number'] = parent['movement_number']
    md['movement_number'] = None
    if snippet.title:
        md['movement_title'] = snippet.title
    else:
        md['movement_title'] = f'Snippet {snippet.index}'
        md['origin'].setdefault('fallbacks', []).append('movement_title')
    if snippet.source:
        if parent.get('source'):
            overridden['source'] = parent['source']
        md['source'] = snippet.source
    md['snippet'] = {
        'index': snippet.index,
        'count': count,
        'title': snippet.title,
        'rhythm_name': snippet.rhythm_name,
        'source': snippet.source,
        'measures': [snippet.start + 1, snippet.end + 1],   # 1-based, in the parent
        'start_offset': snippet.start_offset,               # quarter notes into the first bar
        'end_offset': snippet.end_offset,                   # None: end of the last bar
        'parent_title': parent_title,
        'overridden_from_parent': overridden,
    }
    work._app_metadata = md

    # music21's own metadata (what its writer exports) must carry the
    # snippet's title too: fill_music21_metadata() only fills gaps, and a
    # movement name inherited from the parent would otherwise win.
    from music21 import metadata as m21metadata
    if work.metadata is None:
        work.metadata = m21metadata.Metadata()
    work.metadata.movementName = md['movement_title']
    work.metadata.movementNumber = str(snippet.index)
    return work


def split_snippets(score, strip_markers=True):
    """[Score, ...], one per snippet, or None if `score` has no snippet
    markers (or can't be split -- see below). Cross-staff scores built by
    the LilyPond multi-staff emitter carry hand-written XML that a cut
    can't be applied to; those return None, and the caller keeps the
    whole score."""
    if getattr(score, '_manual_multistaff_parts', None):
        return None
    snippets = detect_snippets(score)
    if not snippets:
        return None
    return [extract_snippet(score, s, len(snippets), strip_markers) for s in snippets]
