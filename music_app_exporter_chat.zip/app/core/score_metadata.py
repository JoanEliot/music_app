"""
core/score_metadata.py

The pipeline's format-neutral description of a score AS A WORK -- title,
people, rights, source, dates, free-text comments -- as opposed to the
notes on the staves. Every importer fills in as much of this as its
source format can express; exporters (LilyPond, MusicXML) and bundlers
(Anki, WebKit app) read it. It is a plain JSON-serializable dict, not a
custom class, so it drops straight into an Anki note field or a webapp
manifest.

WHERE IT LIVES: on the Score as `score._app_metadata`, next to (and in
the same spirit as) `_manual_multistaff_parts` -- see the architecture
doc's "verbatim side channel" section. It is deliberately NOT stored
inside music21's own Metadata object: music21 has no slots for much of
what MusicXML defines (source, relation, opus, movement number,
encoding info, miscellaneous fields) and its vocabulary differs from
format to format. TRANSFORMS THAT BUILD A NEW Score instead of editing
the one they were given must carry this over (use copy_metadata()).

SCHEMA (all keys always present; see new_metadata()):

  Titles        subtitle
                work_title, work_number, opus_href
                movement_number, movement_title
                (there is deliberately NO stored 'title': what to show
                 depends on the consumer -- see display_title())
  People        composers, lyricists, arrangers, poets, translators
                                 (each a list of names)
                other_creators   [{'type', 'name'}] for any other role
  Rights        rights           [{'type', 'text'}]
  Provenance    source           where the music was taken from
                relations        [{'type', 'text'}] links to related works
  Encoding      encoders         [{'type', 'name'}]
                software         [str]
                encoding_description  [str]
  Dates         date_composed    date of composition
                date_arranged    date of arrangement
                date_engraved    date the score was engraved/encoded
                date_processed   date THIS APP processed the file
                (all kept as the source's own strings -- a composition
                date is often "1723", "ca. 1720" or "1685-1750"-style
                fuzz, so nothing here is parsed into a date object)
  Text          credits          [{'page', 'types', 'text', 'color',
                                  'placeholder'}] page text as the source
                                 typed it (see musicxml_metadata.py for
                                 what 'placeholder' means)
                comments         free-text comments stored in the file
                miscellaneous    {name: value} for source-defined extras
                                 with no dedicated field here
                snippet          None, or for a score cut out of a longer
                                 marked-up one (core/snippets.py):
                                 {'index', 'count', 'title', 'rhythm_name',
                                  'source', 'measures' [first, last] in the
                                 parent, 'parent_title',
                                 'overridden_from_parent'}
  Bookkeeping   origin           {'format', 'path', 'fallbacks'} -- which
                                 importer, which file, and which fields
                                 were filled by a lower-confidence
                                 fallback (e.g. title taken from page
                                 text because no proper title element
                                 existed)
                schema_version

ON DATES: MusicXML's own spec defines only ONE date (encoding-date),
which we map to date_engraved. Composition and arrangement dates have
no standard home in MusicXML; importers accept a small set of
conventional <miscellaneous-field> names (see musicxml_metadata.py) and
the other formats have their own (Humdrum !!!ODT, LilyPond \\header
`date`, ABC `H:` history, ...). date_processed is set by run_job() on
every run, never by an importer.
"""

import contextlib
import copy
import datetime

SCHEMA_VERSION = 1

# metadata field <- MusicXML creator/@type values that fill it
PEOPLE_FIELDS = {
    'composer': 'composers',
    'lyricist': 'lyricists',
    'arranger': 'arrangers',
    'poet': 'poets',
    'translator': 'translators',
}


def new_metadata(format_name=None, path=None) -> dict:
    """A fresh, fully-populated (all-empty) metadata dict."""
    return {
        'schema_version': SCHEMA_VERSION,
        'subtitle': None,
        'work_title': None,
        'work_number': None,
        'opus_href': None,
        'movement_number': None,
        'movement_title': None,
        'composers': [],
        'lyricists': [],
        'arrangers': [],
        'poets': [],
        'translators': [],
        'other_creators': [],
        'rights': [],
        'source': None,
        'relations': [],
        'encoders': [],
        'software': [],
        'encoding_description': [],
        'date_composed': None,
        'date_arranged': None,
        'date_engraved': None,
        'date_processed': None,
        'credits': [],
        'comments': [],
        'miscellaneous': {},
        'snippet': None,
        'origin': {'format': format_name,
                   'path': str(path) if path is not None else None,
                   'fallbacks': []},
    }


def attach_metadata(score, metadata: dict) -> dict:
    """Attach `metadata` to `score` (replacing any existing) and return it."""
    score._app_metadata = metadata
    return metadata


def get_metadata(score) -> dict:
    """The score's metadata dict, creating an empty one if the importer
    didn't attach any (so callers never need a None check)."""
    md = getattr(score, '_app_metadata', None)
    if md is None:
        md = attach_metadata(score, new_metadata())
    return md


def copy_metadata(source_score, target_score) -> None:
    """For transforms that build a brand-new Score: carry the metadata
    over (deep-copied, so later edits to one don't leak into the other)."""
    md = getattr(source_score, '_app_metadata', None)
    if md is not None:
        target_score._app_metadata = copy.deepcopy(md)


def stamp_processed(metadata: dict, when=None) -> None:
    """Set date_processed (ISO date; defaults to today)."""
    metadata['date_processed'] = (when or datetime.date.today()).isoformat()


def display_title(metadata: dict, separator: str = ': ') -> str | None:
    """The title to show a human. When a work title AND a movement title
    both exist and differ, both, as "Work: Movement" -- a movement name
    alone ("First movement") loses what it's a movement OF. Otherwise
    whichever one exists. Computed on demand, never stored, so it can't
    go stale when either field is edited."""
    work = metadata.get('work_title')
    movement = metadata.get('movement_title')
    if work and movement and work.strip().lower() != movement.strip().lower():
        return f"{work}{separator}{movement}"
    return movement or work


# ---------------------------------------------------------------------------
# Handing the dict to music21's MusicXML writer
# ---------------------------------------------------------------------------

@contextlib.contextmanager
def no_music21_placeholder_metadata():
    """While active, music21's MusicXML writer won't invent a title
    ("Music21 Fragment") or a composer ("Music21") for a score that has
    none. It only does so by reading music21.defaults.title/.author when
    the score's own metadata has no title or creator; blanking them
    leaves those elements out of the file instead."""
    from music21 import defaults
    saved = (defaults.title, defaults.author)
    defaults.title, defaults.author = '', ''
    try:
        yield
    finally:
        defaults.title, defaults.author = saved


def fill_music21_metadata(score, metadata: dict) -> None:
    """Copy what this pipeline knows about the work into music21's own
    Metadata so its MusicXML writer includes it -- but ONLY into fields
    music21 has nothing for. (music21's ABC and MusicXML readers already
    fill in title/composer themselves; for LilyPond, Humdrum and MuseData
    it fills nothing, and this is what gets those into the export.)

    Exported: work title (<work-title>), movement title and number,
    composers, lyricists, arrangers, translators, librettists and
    orchestrators (<creator type=...>), and rights (<rights>). NOT
    exported yet: poets and other creator roles -- music21 has no
    standard slot for them; they stay in the dict for other outputs.
    """
    from music21 import metadata as m21metadata
    md = score.metadata
    if md is None:
        md = score.metadata = m21metadata.Metadata()

    def missing(name):
        return not md[name]

    def add(name, value):
        if value:
            md.add(name, value)

    if missing('title'):
        add('title', metadata.get('work_title'))
    if missing('movementName'):
        add('movementName', metadata.get('movement_title'))
    if missing('movementNumber'):
        add('movementNumber', metadata.get('movement_number'))

    for role, key in (('composer', 'composers'), ('lyricist', 'lyricists'),
                      ('arranger', 'arrangers'), ('translator', 'translators')):
        if missing(role):
            for name in metadata.get(key, []):
                add(role, name)
    for other in metadata.get('other_creators', []):
        role = other.get('type')
        if role in ('librettist', 'orchestrator') and missing(role):
            add(role, other.get('name'))

    if missing('copyright'):
        for r in metadata.get('rights', []):
            add('copyright', r.get('text'))
