"""
core/lyrics.py

Reading lyrics OUT of a Score. The lyrics themselves live where music21
keeps them, on the notes: each note's `.lyrics` list holds one Lyric per
verse (text, syllabic = single/begin/middle/end, number). Importers put
them there (MusicXML natively; the LilyPond importer from \\addlyrics /
\\lyricsto), and every later step -- MusicXML export, snippet cutting --
carries them along untouched, so there is no separate lyrics side channel
to keep in sync. This module is the other direction: given a Score or
Part, list its verses and render one as plain text or as LilyPond
\\lyricmode text (for the eventual LilyPond exporter and the Anki output).

ALL VERSES, not just the first. (The experimental snippet script this
grew out of read only `note.lyric`, i.e. verse 1; nothing in the pipeline
has that limit.)

VOICES. A part can hold several Voices, each with its own words (a
grand-staff SATB chorale: soprano and alto share a staff, each singing its
own text). Reading such a part as one long note sequence would splice the
voices' words together, so extraction is per VOICE. music21 makes a
separate Voice object in every measure, all sharing an id, so a voice is
identified by its ID across the whole part: `lyric_voices()` lists the
(label, voice id) pairs to read -- one per id that carries lyrics, or
[(None, None)] (the whole part) when there is only one -- and the functions
below take an optional `voice=` id. `all_verses()` keys a verse "N" for a
one-voice part and "N/voice ID" when a part has several lyric-bearing
voices.

VERSE KEYS. A verse is identified by the Lyric's `number` (the MusicXML
`number` attribute), else its `identifier`, else 1 -- the same rule for
every note, so one verse's syllables line up across the piece.

NOTE SLOTS. A verse is a sequence over the part's notes and chords in
order (rests skipped): a note with a syllable in that verse contributes
it; a note WITHOUT one is a melisma continuation (or a gap), rendered as
`_` in lyricmode and simply omitted from plain text.
"""

from music21 import chord, note, stream


def _key_of(lyric):
    if lyric.number is not None:
        return lyric.number
    if lyric.identifier is not None:
        return lyric.identifier
    return 1


def _sortable(key):
    return (0, key, '') if isinstance(key, (int, float)) else (1, 0, str(key))


def _sung_notes(part, voice=None):
    """The part's notes/chords in order (all of them, or only those in the
    Voice(s) with this id)."""
    if voice is None:
        source = part.recurse().notes
    else:
        source = [n for v in part.recurse().getElementsByClass(stream.Voice)
                  if str(v.id) == str(voice) for n in v.recurse().notes]
    return [n for n in source
            if isinstance(n, (note.Note, chord.Chord)) and not n.duration.isGrace]


def lyric_voices(part):
    """[(label, voice id)] to read lyrics from: one per voice id that has
    lyrics when the part has several voices, else [(None, None)]."""
    ids = []
    for v in part.recurse().getElementsByClass(stream.Voice):
        if v.id not in ids:
            ids.append(v.id)
    if len(ids) > 1:
        with_lyrics = [(f'voice {i}', i) for i in ids
                       if any(n.lyrics for v in part.recurse().getElementsByClass(stream.Voice)
                              if v.id == i for n in v.recurse().notes)]
        if with_lyrics:
            return with_lyrics
    return [(None, None)]


def verse_keys(stream_obj, voice=None) -> list:
    """Every verse key used in a Score/Part (or in one of its voices, by
    id), in order."""
    if voice is None:
        notes = stream_obj.recurse().notes
    else:
        notes = _sung_notes(stream_obj, voice)
    keys = {_key_of(l) for n in notes for l in n.lyrics}
    return sorted(keys, key=_sortable)


def verse_syllables(part, verse, voice=None):
    """[(text or None, syllabic or None)] for one verse, one entry per
    note/chord of `part` -- or of just `voice`, one of its Voices (None where
    the note carries no syllable of it)."""
    out = []
    for n in _sung_notes(part, voice):
        match = next((l for l in n.lyrics if _key_of(l) == verse), None)
        out.append((match.text, match.syllabic) if match else (None, None))
    return out


def verse_text(part, verse, voice=None) -> str:
    """The verse as plain text: syllables of one word joined, words
    separated by spaces."""
    words, current = [], ''
    for text, syllabic in verse_syllables(part, verse, voice):
        if text is None:
            continue
        current += text
        if syllabic in (None, 'single', 'end'):
            words.append(current)
            current = ''
    if current:
        words.append(current)
    return ' '.join(words)


def to_lyricmode(part, verse, voice=None) -> str:
    """The verse as LilyPond \\lyricmode text: `--` after a syllable that
    continues its word, `_` for a note that carries no syllable."""
    tokens = []
    for text, syllabic in verse_syllables(part, verse, voice):
        if text is None:
            tokens.append('_')
            continue
        escaped = text.replace('"', '\\"')
        token = f'"{escaped}"' if any(c in text for c in ' "{}$#%\\') else text
        tokens.append(token)
        if syllabic in ('begin', 'middle'):
            tokens.append('--')
    return ' '.join(tokens)


def all_verses(score) -> dict:
    """{part index: {verse key: plain text}} for every part that has
    lyrics. The key is the verse ("1") for a one-voice part and
    "verse/voice ID" ("1/voice 2") when a part has several lyric-bearing
    voices."""
    result = {}
    for i, part in enumerate(score.parts):
        per_verse = {}
        for label, voice in lyric_voices(part):
            for k in verse_keys(part, voice):
                key = k if label is None else f'{k}/{label}'
                per_verse[key] = verse_text(part, k, voice)
        if per_verse:
            result[i] = per_verse
    return result
