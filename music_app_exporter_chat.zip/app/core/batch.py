"""
core/batch.py

Batch processing: many inputs in, one report out. The CLI and (later) the
GUI both sit on this module, so everything a front end needs is here as
plain data and callbacks -- nothing prints, nothing exits.

    items, ignored = expand_inputs(["corpus/", "extra.abc", "more/*.ly"],
                                   recursive=True)
    plan_outputs(items, output_dir="out/")            # decide every path
    report = run_batch(items, jobs=4,
                       progress=on_event, cancel=should_stop)

WHAT AN INPUT CAN BE
  - a file: imported as it stands (format from its extension, or the
    `fmt` override).
  - a folder: scanned for music files (see importers.scan_format --
    README files, config XML and the like are ignored, not failed).
    Non-recursive unless `recursive`. MuseData is different: its
    convention is one FILE PER PART with the whole work in one folder, so
    the MuseData part files found in a folder together form ONE job for
    that folder (other files in the same folder are not fed to it). With
    `recursive`, a corpus of one-subfolder-per-movement becomes one job
    per subfolder -- the walking the MuseData importer's docs leave to
    the front end.
  - a glob pattern (`songs/**/*.abc`): expanded here, for shells that
    don't do it.
An input that can't be used (missing, unknown format) is still an ITEM,
carrying `plan_error`, so it appears in the report as a failure instead of
vanishing.

WHERE OUTPUT GOES. With `output_dir`, each item's output mirrors its place
under the folder it was scanned from (`flatten=True` puts everything in one
folder); without it, output goes beside each input. Two items that would
write the same file (`a.abc` and `a.ly` both -> `a.musicxml`) are
disambiguated up front, deterministically, by adding the format
(`a-abc.musicxml`, `a-ly.musicxml`), never by silently overwriting one with
the other. A file that yields several scores (multi-tune ABC, several
`\\score`s, snippets) is written as `<stem>_<NN>_<title>.musicxml`, as
core.import_pipeline.run_job_all does.

ISOLATION. One bad file never stops the batch: each item runs inside its
own try/except and is reported as ok / failed (with the exception and a
traceback tail) / skipped / cancelled. `stop_on_error=True` opts out.

REPORT DATA. Results are plain dataclasses of JSON-safe values -- no music21
objects -- so they cross process boundaries (`jobs > 1` runs items in a
process pool) and go straight into a JSON file or a GUI table. Each output
carries the metadata dict and the lyric verses, which is what the Anki and
webapp bundlers will read.

PROGRESS AND CANCELLATION. `progress(event)` gets dicts:
    {'type': 'start', 'index', 'total', 'label'}      (serial runs only)
    {'type': 'done',  'index', 'total', 'result': BatchItemResult}
`cancel()` is polled between items: return True to stop; items not yet
started come back as 'cancelled' (items already running finish).
"""

import glob
import os
import time
import traceback
import warnings
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from importers import detect_format, scan_format
from importers.musedata_importer import describe_file as describe_musedata_file

OUTPUT_SUFFIX = '.musicxml'
_GLOB_CHARS = set('*?[')


# ---------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------

@dataclass
class BatchItem:
    index: int
    input_path: Path
    format: Optional[str]                  # None if it couldn't be determined
    label: str                             # how the item is shown in reports
    rel: Path = None                       # place under its scan root (for mirroring)
    importer_options: dict = field(default_factory=dict)
    output_path: Optional[Path] = None     # planned output (or base for several)
    plan_error: Optional[str] = None       # set if the input can't be used


@dataclass
class BatchItemResult:
    index: int
    input_path: str
    format: Optional[str]
    status: str                            # 'ok' | 'failed' | 'skipped' | 'cancelled'
    outputs: list = field(default_factory=list)     # see _summarize()
    warnings: list = field(default_factory=list)    # [{'category', 'message'}]
    error: Optional[dict] = None           # {'type', 'message', 'traceback'}
    seconds: float = 0.0
    note: Optional[str] = None             # e.g. why it was skipped


@dataclass
class BatchReport:
    items: list
    seconds: float
    cancelled: bool = False

    @property
    def counts(self) -> dict:
        c = {'ok': 0, 'failed': 0, 'skipped': 0, 'cancelled': 0}
        for r in self.items:
            c[r.status] = c.get(r.status, 0) + 1
        c['outputs'] = sum(len(r.outputs) for r in self.items)
        c['warnings'] = sum(len(r.warnings) for r in self.items)
        return c

    @property
    def ok(self) -> bool:
        return self.counts['failed'] == 0 and not self.cancelled

    def to_dict(self) -> dict:
        return {'summary': {**self.counts, 'seconds': round(self.seconds, 2),
                            'cancelled': self.cancelled},
                'items': [asdict(r) for r in self.items]}


# ---------------------------------------------------------------------------
# expanding inputs
# ---------------------------------------------------------------------------

def _hidden(p: Path) -> bool:
    return p.name.startswith('.')


def _musedata_items(folder: Path, root: Path, files) -> list:
    """BatchItems for the MuseData files found in one folder. A file that
    holds several parts, or says it is part 1 of 1 (or says nothing), is a
    work by itself. Single-part files that say "part i of n" with n > 1
    are the parts of one work; those sharing a work title become ONE item
    for the folder (its `part_files`), a differently titled set another."""
    items, groups = [], {}
    for f in files:
        info = describe_musedata_file(f)
        part = info['part']
        if info['chunks'] > 1 or part is None or part[1] <= 1:
            items.append(BatchItem(0, f, 'musedata', str(f), rel=f.relative_to(root)))
        else:
            groups.setdefault(info['work'] or '', []).append(f)
    for work, members in groups.items():
        rel = folder.relative_to(root) if folder != root else Path(root.name)
        if len(groups) > 1 and work:
            rel = rel / work
        items.append(BatchItem(0, folder, 'musedata',
                               str(folder) + (f' [{work}]' if len(groups) > 1 and work else ''),
                               rel=rel,
                               importer_options={'part_files': [str(p) for p in members]}))
    return items


def _scan_directory(root: Path, recursive: bool, fmt, start_index, ignored):
    """Items for one folder (and, if recursive, its subfolders)."""
    items = []
    folders = [root]
    if recursive:
        folders = []
        for d, dirs, _files in os.walk(root):
            dirs[:] = sorted(x for x in dirs if not x.startswith('.'))   # prune hidden folders
            folders.append(Path(d))
    for folder in folders:
        try:
            files = sorted(f for f in folder.iterdir() if f.is_file() and not _hidden(f))
        except OSError as e:
            ignored.append((str(folder), f'unreadable: {e}'))
            continue
        muse_parts = []
        for f in files:
            if fmt == 'musedata':
                # forced: files that merely look like MuseData (odd names are
                # the reason for forcing it), not every file in the folder
                if scan_format(f) == 'musedata' or f.suffix.lower() in ('.md', '.musedata'):
                    muse_parts.append(f)
                else:
                    ignored.append((str(f), 'not a MuseData file'))
                continue
            kind = scan_format(f)
            if kind is None or (fmt and kind != fmt):
                ignored.append((str(f), 'not a music file'))
            elif kind == 'musedata':
                muse_parts.append(f)
            else:
                items.append(BatchItem(0, f, kind, str(f), rel=f.relative_to(root)))
        items.extend(_musedata_items(folder, root, muse_parts))
    return items


def expand_inputs(inputs, recursive=False, fmt=None):
    """(items, ignored): the BatchItems for `inputs` (see module docstring),
    numbered in order, and a list of (path, reason) for files a folder scan
    passed over."""
    items, ignored = [], []

    def add_path(p: Path, given: str):
        if p.is_dir():
            items.extend(_scan_directory(p, recursive, fmt, len(items), ignored))
        elif p.exists():
            kind = fmt
            error = None
            if kind is None:
                try:
                    kind = detect_format(p)
                except ValueError as e:
                    error = str(e)
            items.append(BatchItem(0, p, kind, given, rel=Path(p.name), plan_error=error))
        else:
            items.append(BatchItem(0, p, fmt, given, rel=Path(p.name),
                                   plan_error=f'input not found: {given}'))

    for given in inputs:
        given = str(given)
        p = Path(given)
        if not p.exists() and _GLOB_CHARS & set(given):
            matches = sorted(glob.glob(given, recursive=True))
            if not matches:
                items.append(BatchItem(0, p, fmt, given, rel=Path(p.name),
                                       plan_error=f'no files match {given}'))
            for m in matches:
                add_path(Path(m), m)
        else:
            add_path(p, given)

    for n, it in enumerate(items):
        it.index = n
    return items, ignored


# ---------------------------------------------------------------------------
# planning output paths
# ---------------------------------------------------------------------------

def plan_outputs(items, output_dir=None, flatten=False):
    """Fill in every item's `output_path`, resolving collisions (see module
    docstring). Returns the items."""
    for it in items:
        if it.plan_error:
            continue
        if output_dir is None:
            if it.input_path.is_dir():
                base = it.input_path.parent / (it.input_path.name + OUTPUT_SUFFIX)
            else:
                base = it.input_path.with_suffix(OUTPUT_SUFFIX)
        else:
            rel = Path(it.rel.name) if flatten else it.rel
            is_folder = it.input_path.is_dir()          # a MuseData work: keep its full name
            stem_path = rel.parent / (rel.name if is_folder or not rel.suffix else rel.stem)
            base = Path(output_dir) / stem_path
            base = base.with_name(base.name + OUTPUT_SUFFIX)
        it.output_path = base

    groups = {}
    for it in items:
        if it.output_path is not None:
            groups.setdefault(str(it.output_path).lower(), []).append(it)
    for group in groups.values():
        if len(group) < 2:
            continue
        taken = set()
        for it in group:
            stem = it.output_path.stem + '-' + (it.format or 'x')
            candidate, n = it.output_path.with_name(stem + OUTPUT_SUFFIX), 2
            while str(candidate).lower() in taken:
                candidate = it.output_path.with_name(f'{stem}-{n}{OUTPUT_SUFFIX}')
                n += 1
            taken.add(str(candidate).lower())
            it.output_path = candidate
    return items


def _existing_outputs(output_path: Path) -> list:
    stem = output_path.stem
    found = [output_path] if output_path.exists() else []
    found += sorted(output_path.parent.glob(f'{stem}_[0-9][0-9]*{OUTPUT_SUFFIX}'))
    return found


# ---------------------------------------------------------------------------
# running
# ---------------------------------------------------------------------------

def _summarize(result) -> dict:
    """One JobResult as JSON-safe data."""
    from core import lyrics
    verses = {}
    for part_index, per_verse in lyrics.all_verses(result.score).items():
        verses[str(part_index)] = {str(k): v for k, v in per_verse.items()}
    md = result.metadata
    return {
        'path': str(result.output_path),
        'format': result.format,
        'n_parts': len(result.score.parts),
        'beams_repaired': result.beams_repaired,
        'snippet': md.get('snippet'),
        'metadata': md,
        'lyrics': verses,
    }


def _ignore_sigint():
    """Pool workers leave Ctrl+C to the parent, which stops cleanly."""
    import signal
    signal.signal(signal.SIGINT, signal.SIG_IGN)


def _process_item(payload) -> BatchItemResult:
    """Worker: run ONE item. Module-level and picklable so it can run in a
    process pool. Never raises."""
    item, options = payload
    t0 = time.time()
    res = BatchItemResult(item.index, str(item.input_path), item.format, 'ok')
    try:
        if item.plan_error:
            raise ValueError(item.plan_error)
        if options.get('skip_existing'):
            existing = _existing_outputs(item.output_path)
            if existing:
                res.status = 'skipped'
                res.note = f'output exists: {existing[0].name}'
                res.seconds = time.time() - t0
                return res
        from core.import_pipeline import JobSpec, run_job_all
        importer_options = dict(options.get('importer_options') or {})
        importer_options.update(item.importer_options)
        spec = JobSpec(input_path=item.input_path, format=item.format,
                       output_path=item.output_path, importer_options=importer_options,
                       multi=options.get('multi', 'all'),
                       split_snippets=options.get('split_snippets', True))
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            results = run_job_all(spec)
        res.outputs = [_summarize(r) for r in results]
        res.warnings = [{'category': w.category.__name__, 'message': str(w.message)}
                        for w in caught]
    except Exception as e:                       # one bad file must not stop the batch
        res.status = 'failed'
        res.error = {'type': type(e).__name__, 'message': str(e),
                     'traceback': ''.join(traceback.format_exception(
                         type(e), e, e.__traceback__)[-4:])}
    res.seconds = time.time() - t0
    return res


def run_batch(items, *, multi='all', split_snippets=True, skip_existing=False,
              importer_options=None, jobs=1, stop_on_error=False,
              progress: Optional[Callable[[dict], Any]] = None,
              cancel: Optional[Callable[[], bool]] = None) -> BatchReport:
    """Run every item (see module docstring for isolation, progress and
    cancellation). `jobs` > 1 uses a process pool. Returns a BatchReport
    with one result per item, in input order."""
    options = {'multi': multi, 'split_snippets': split_snippets,
               'skip_existing': skip_existing, 'importer_options': importer_options or {}}
    total = len(items)
    t0 = time.time()
    emit = progress or (lambda event: None)
    results = {}
    cancelled = False

    def cancelled_result(it):
        return BatchItemResult(it.index, str(it.input_path), it.format, 'cancelled')

    if jobs <= 1 or total <= 1:
        for it in items:
            if cancelled or (cancel and cancel()):
                cancelled = True
                results[it.index] = cancelled_result(it)
                continue
            emit({'type': 'start', 'index': it.index, 'total': total, 'label': it.label})
            r = _process_item((it, options))
            results[it.index] = r
            emit({'type': 'done', 'index': it.index, 'total': total, 'result': r})
            if stop_on_error and r.status == 'failed':
                cancelled = True
    else:
        with ProcessPoolExecutor(max_workers=jobs, initializer=_ignore_sigint) as pool:
            futures = {pool.submit(_process_item, (it, options)): it for it in items}
            for fut in as_completed(futures):
                it = futures[fut]
                if fut.cancelled():
                    results[it.index] = cancelled_result(it)
                    continue
                try:
                    r = fut.result()
                except Exception as e:               # a crashed worker process
                    r = BatchItemResult(it.index, str(it.input_path), it.format, 'failed',
                                        error={'type': type(e).__name__, 'message': str(e),
                                               'traceback': ''})
                results[it.index] = r
                emit({'type': 'done', 'index': it.index, 'total': total, 'result': r})
                stop = (cancel and cancel()) or (stop_on_error and r.status == 'failed')
                if stop and not cancelled:
                    cancelled = True
                    for other in futures:
                        other.cancel()
        for it in items:                              # cancelled before running
            if it.index not in results:
                results[it.index] = cancelled_result(it)

    ordered = [results[it.index] for it in items]
    return BatchReport(items=ordered, seconds=time.time() - t0, cancelled=cancelled)
