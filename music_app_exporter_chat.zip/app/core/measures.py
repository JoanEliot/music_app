"""
core/measures.py

Short measures -- an anacrusis (pickup) at the start, a bar cut short by
the end of the music, a deliberately short bar in the middle -- and how
to keep music21 from "fixing" them.

THE PROBLEM. music21's MusicXML writer pads any measure shorter than its
time signature with a REST unless the measure carries explicit padding
info (Measure.paddingLeft for a pickup, .paddingRight for a bar that is
meant to stop short). Confirmed by writing a 3/4 piece whose last bar held
2 beats: it came out with 3, the missing beat filled by an invented rest;
a short bar in the MIDDLE of a piece was padded the same way. For a piece
that opens on a one-beat pickup and ends on the two-beat bar that
completes it, that invents a rest at the end.

Some readers set the padding themselves (music21's ABC, Humdrum and
MusicXML readers mark a pickup's paddingLeft); none marks a short final
or interior bar, and the LilyPond importer marks neither.

mark_short_measures() records the missing length on every short measure
that has no padding info yet: the FIRST measure of a part, if short, as
paddingLeft (a pickup, also written implicit="yes" so its number isn't
printed); any other short measure as paddingRight. Nothing
is added to or removed from the music; only what the writer will do with
the measure changes. Runs once, in core.import_pipeline._finish_job(),
for every format and for every snippet cut out of a longer score.
"""

from music21 import meter, stream
from music21.stream.enums import ShowNumber

_EPS = 1e-6


def _bar_length(measure) -> float | None:
    ts = measure.timeSignature or measure.getContextByClass(meter.TimeSignature)
    return float(ts.barDuration.quarterLength) if ts is not None else None


def mark_short_measures(score) -> int:
    """Mark every unmarked short measure (see module docstring). Returns
    how many measures were marked."""
    marked = 0
    parts = list(score.parts) if hasattr(score, 'parts') else [score]
    for part in parts:
        measures = list(part.getElementsByClass(stream.Measure))
        if measures and measures[0].paddingLeft:
            # A pickup's number isn't printed: MusicXML's implicit="yes".
            measures[0].showNumber = ShowNumber.NEVER
        for i, m in enumerate(measures):
            bar = _bar_length(m)
            if bar is None or m.paddingLeft or m.paddingRight:
                continue
            length = float(m.duration.quarterLength)
            missing = bar - length
            if missing <= _EPS or length <= _EPS:
                continue
            if i == 0:
                m.paddingLeft = missing          # an anacrusis
                m.showNumber = ShowNumber.NEVER
            else:
                m.paddingRight = missing
            marked += 1
    return marked
