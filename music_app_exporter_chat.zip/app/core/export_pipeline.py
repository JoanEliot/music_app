"""
core/export_pipeline.py

The export half of the pipeline in the architecture doc:

    import (import_pipeline._import_pieces)
      -> prepare (import_pipeline.prepare_score: beam repair, short-measure
         marking, metadata)
      -> transforms (each Score -> Score, applied in order; the splitter
         is the one Score -> [Score] and, by convention, comes last)
      -> exporters (LilyPond now; MusicXML/MIDI join later)

There are no transforms yet, so `transforms=[]` is the identity case and
what this writes is the score as imported -- the baseline every later
transform is checked against.

A front end (CLI or GUI) builds a JobSpec (which file) and an ExportSpec
(what to do to it and what to write) and calls run_export_job(); neither
contains musical logic. `python -m core.export_pipeline FILE` is a bare
command-line entry so the exporter can be tried before the real CLI
grows flags for it.
"""

import argparse
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from core.import_pipeline import JobSpec, _import_pieces, prepare_score
from exporters import lilypond as ly


@dataclass
class ExportSpec:
    """What to do with an imported Score and what to write.

    transforms: callables applied in order, each Score -> Score.
    output_dir: where files go (default: next to the input file).
    midi: also have LilyPond write a MIDI file from the same .ly.
    render: LilyPond output formats to produce from the .ly, any of
        'png', 'svg', 'pdf' -- empty means write the .ly only.
    lilypond_bin: path to the lilypond executable.
    """
    transforms: list = field(default_factory=list)
    output_dir: Optional[str] = None
    midi: bool = False
    render: tuple = ()
    lilypond_bin: str = 'lilypond'


@dataclass
class ExportResult:
    ly_path: Path
    score: object
    export_warnings: list
    lilypond_problems: list = field(default_factory=list)   # empty if not rendered


def apply_transforms(score, transforms):
    for t in transforms:
        score = t(score)
    return score


def run_export_job(job: JobSpec, export: ExportSpec) -> list:
    """Import `job`, prepare and transform each resulting Score, and write
    one .ly per Score (numbered when the file held several). Returns one
    ExportResult per Score."""
    input_path, format_name, importer, pieces = _import_pieces(job)
    out_dir = Path(export.output_dir) if export.output_dir else input_path.parent
    results = []
    for n, score in enumerate(pieces, start=1):
        prepare_score(score, importer, format_name, input_path)
        score = apply_transforms(score, export.transforms)
        stem = input_path.stem + (f'_{n:02d}' if len(pieces) > 1 else '')
        ly_path = out_dir / f'{stem}.ly'
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            ly.write_lilypond(score, ly_path, midi=export.midi)
        problems = []
        if export.render:
            _, err = ly.compile_lilypond(ly_path, out_dir, formats=export.render,
                                         lilypond_bin=export.lilypond_bin)
            problems = ly.lilypond_problems(err)
        results.append(ExportResult(
            ly_path=ly_path, score=score,
            export_warnings=[str(w.message) for w in caught
                             if issubclass(w.category, ly.LilyExportWarning)],
            lilypond_problems=problems))
    return results


def main(argv=None):
    ap = argparse.ArgumentParser(description='Import a score and export it as LilyPond, as-is.')
    ap.add_argument('input')
    ap.add_argument('-o', '--output-dir', default=None)
    ap.add_argument('--format', default=None)
    ap.add_argument('--midi', action='store_true', help='also write MIDI (via LilyPond)')
    ap.add_argument('--render', nargs='*', default=[], choices=['png', 'svg', 'pdf'])
    ap.add_argument('--lilypond-bin', default='lilypond')
    a = ap.parse_args(argv)
    job = JobSpec(input_path=a.input, format=a.format,
                  importer_options={'lilypond_bin': a.lilypond_bin})
    exp = ExportSpec(output_dir=a.output_dir, midi=a.midi, render=tuple(a.render),
                     lilypond_bin=a.lilypond_bin)
    for r in run_export_job(job, exp):
        print('wrote', r.ly_path)
        for w in r.export_warnings:
            print('  note:', w)
        for p in r.lilypond_problems:
            print('  LilyPond:', p)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
