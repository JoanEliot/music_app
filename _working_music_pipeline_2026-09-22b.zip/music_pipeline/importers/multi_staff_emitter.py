"""
importers/multi_staff_emitter.py

Merges N already-built, already-measured music21 Parts (one per staff
of the SAME instrument -- e.g. treble+bass of a piano) into a single
multi-staff MusicXML <part>, with correct per-note <staff> tags, built
directly here rather than via music21's own Score.write().

WHY THIS EXISTS AT ALL
------------------------------------------------------------------
Confirmed empirically, independent of anything in this pipeline: a
hand-verified, completely correct one-part/two-staff MusicXML file
(one continuous voice/beam/tuplet bracket legitimately crossing from
one staff to the other) gets corrupted by plain music21
parse-then-write with NO modification in between -- phantom tuplet
ratios appear, and the reader even splits the single <part> into two
separate internal Part objects before any writing happens at all. So
representing a piece with real cross-staff notation as two independent
per-staff Parts and asking music21 to write them can never correctly
reproduce a single continuous beam/tuplet bracket spanning the staff
change, no matter how correct the note DATA in those two Parts is --
MusicXML has no way for a beam or tuplet bracket to span two different
<part> elements in the first place. This module is the fix: it reads
already-correct note/duration/tuplet/articulation data straight off
music21 objects (which the rest of this pipeline already builds and
verifies correctly, regardless of which importer produced them) and
emits the MusicXML for the whole merged instrument itself.

WHY THE WHOLE PART, NOT JUST THE AFFECTED MEASURE(S)
------------------------------------------------------------------
MusicXML's <staves> count is declared once (in the first measure's
<attributes>) and applies for the part's entire duration; there is no
supported way to declare 1 staff for most measures and 2 for just the
ones with cross-staff content. So once ANY measure in an instrument's
staff group needs 2 staves, EVERY measure of that instrument has to be
emitted with 2 staves declared and a <staff> tag on every note -- this
module always merges the WHOLE set of parts for an affected
instrument, not a slice of it.

WHAT THIS DOES NOT ATTEMPT (yet)
------------------------------------------------------------------
Repeat barlines/volta brackets (see importers/lilypond_importer.py's
_apply_repeat_structure) are not reconstructed here -- if a merged
instrument's measures also contain repeat structure, only plain
barlines are emitted. Real-world testing so far has not hit this
combination; it's a known gap to revisit if it does.

HOW A "LOGICAL VOICE" IS IDENTIFIED ACROSS A STAFF CHANGE
------------------------------------------------------------------
A note run that crosses staves needs ONE consistent identity so its
notes can be beamed together correctly, even though they end up in
different music21 Parts. Each importer that can produce cross-staff
notation is responsible for tagging every Note/Rest/Chord it creates
with `.editorial.lily_lane_id` (or an equivalently-named tag; see e.g.
importers/lilypond_importer.py's _StaffWalker._append) identifying
which logical voice it belongs to, independent of which staff it's
currently attached to. A note with no such tag is treated as its own
singleton logical voice (safe default for ordinary, non-crossing
content, or for a format that hasn't been wired up to tag anything).
Cross-staff beam/tuplet CONTINUITY doesn't actually depend on reusing
the same MusicXML <voice> NUMBER across the staff change (confirmed:
beams and tuplet brackets are per-note elements in MusicXML, not tied
to voice-number matching) -- only on correctly grouping which notes
belong to one logical run for beaming purposes -- but consistent
voice numbering is a reasonable, low-cost thing to also get right, so
this module assigns one stable voice number per logical voice for the
whole piece.
"""

from fractions import Fraction
from math import gcd


from .notation_repair import compute_beam_states

_TYPE_TO_BEAMS = {'eighth': 1, '16th': 2, '32nd': 3, '64th': 4, '128th': 5, '256th': 6}

_ARTICULATION_CLASS_TO_MXML = {
    'Staccato': 'staccato',
    'Staccatissimo': 'staccatissimo',
    'Accent': 'accent',
    'StrongAccent': 'strong-accent',
    'Tenuto': 'tenuto',
    'Portato': 'detached-legato',
}

# Ornament expressions nest inside <notations><ornaments>...</ornaments>;
# fermata is a direct child of <notations> instead (handled separately
# in _emit_note_xml) -- matching MusicXML's own schema shape, and the
# same class names importers/lilypond_importer.py's own
# _EXPRESSION_TABLE already produces, so nothing new needs to be
# taught to any importer to get these emitted correctly here.
_ORNAMENT_CLASS_TO_MXML = {
    'Turn': 'turn',
    'InvertedTurn': 'inverted-turn',
    'Trill': 'trill-mark',
    'Mordent': 'mordent',
    'InvertedMordent': 'inverted-mordent',
}


def _lcm(a, b):
    return a * b // gcd(a, b) if a and b else (a or b or 1)


def _xml_escape(s):
    return (str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            .replace('"', '&quot;'))


def _compute_divisions(parts):
    """The smallest whole-number-of-divisions-per-quarter that makes
    every note/rest's own quarterLength an exact integer in that unit
    -- the LCM of every quarterLength's reduced denominator actually
    present, so the file uses the smallest workable divisions value
    rather than an arbitrarily large fixed one."""
    d = 1
    for part in parts:
        for n in part.recurse().notesAndRests:
            frac = Fraction(n.duration.quarterLength).limit_denominator(100000)
            d = _lcm(d, frac.denominator)
    return max(d, 1)


def _lane_id_of(obj, fallback):
    return getattr(obj.editorial, 'lily_lane_id', None) or fallback


def _clef_glyph(clef_obj):
    """(sign, line, octave-change-or-None) for a music21 Clef, matching
    MusicXML's <clef> element shape."""
    sign = getattr(clef_obj, 'sign', 'G')
    line = getattr(clef_obj, 'line', 2)
    octave_change = getattr(clef_obj, 'octaveChange', 0) or 0
    return sign, line, (octave_change or None)


def _duration_ratio_for(m21_duration):
    """Given a linked music21 Duration, the exact tuplet-adjusted
    fraction of its base type it represents relative to a plain
    (non-tupleted) note of the same type -- used only to sanity-check
    nothing upstream is unlinked/inconsistent; not used for the actual
    emitted <duration>, which always comes from quarterLength directly."""
    return Fraction(m21_duration.quarterLength)


class _NoteEvent:
    """One emittable event within a single physical staff+voice, in a
    single measure -- a thin wrapper around a music21 GeneralNote plus
    the bookkeeping this emitter needs (absolute offset within the
    measure, which physical staff it prints on, its logical voice id,
    and its resolved MusicXML voice number)."""

    __slots__ = ('obj', 'offset', 'staff', 'lane_id', 'voice_number',
             'clef_sign', 'clef_line')

    def __init__(self, obj, offset, staff, lane_id):
        self.obj = obj
        self.offset = offset
        self.staff = staff
        self.lane_id = lane_id
        self.voice_number = None


def _collect_measure_events(parts, measure_index, measure_length):
    """Every Note/Rest/Chord in measure `measure_index` across all
    `parts`, each tagged with its physical staff number (1-based,
    matching `parts` order) and logical voice id (see module
    docstring). A part with explicit Voice objects contributes one
    event list per Voice; a flat (single-voice) part's measure
    contributes its own notes directly.

    A staff with literally NOTHING recorded for this measure (typically
    one originally covered by a multi-measure rest -- confirmed against
    a real piece that music21's own makeMeasures() does not duplicate
    a long Rest object across every measure it spans, leaving the
    measures after the first genuinely empty when queried directly)
    gets an explicit synthetic whole-measure Rest instead of being left
    with no content at all: MusicXML expects every staff to account for
    a measure's full duration somehow, even if that's silence, and
    simply emitting nothing for a staff would leave it structurally
    incomplete for that measure."""
    from music21 import stream as m21stream, note as m21note, clef as m21clef
    events = []
    staves_with_content = set()
    for staff_index, part in enumerate(parts):
        staff_number = staff_index + 1
        measures = list(part.getElementsByClass(m21stream.Measure))
        if measure_index >= len(measures):
            continue
        measure = measures[measure_index]
        voices = list(measure.getElementsByClass(m21stream.Voice))
        containers = voices if voices else [measure]
        for container_index, container in enumerate(containers):
            fallback_lane = f'__part{staff_index}_voice{container_index}__'
            for obj in container.notesAndRests:
                lane_id = _lane_id_of(obj, fallback_lane)
                ev = _NoteEvent(obj, Fraction(obj.offset), staff_number, lane_id)
                active = obj.getContextByClass(m21clef.Clef)
                ev.clef_sign = active.sign if active is not None else 'G'
                ev.clef_line = active.line if active is not None else 2
                events.append(ev)   
                staves_with_content.add(staff_number)

    for staff_index in range(len(parts)):
        staff_number = staff_index + 1
        if staff_number not in staves_with_content and measure_length > 0:
            silent_rest = m21note.Rest(quarterLength=measure_length)
            events.append(_NoteEvent(silent_rest, Fraction(0), staff_number,
                                      f'__silent_staff{staff_number}_m{measure_index}__'))
    return events


def _collect_measure_signatures(parts, measure_index):
    """(clef_changes_per_staff, key_signature, time_signature) as of
    this measure. Clef changes are a list of (in-measure offset in
    quarterLengths, Clef object) tuples per staff, sorted by offset --
    because a clef can change partway through a measure, and MusicXML
    permits a <clef> element in an <attributes> block positioned
    anywhere in the measure's event stream. Key and time signatures
    are still read as a single first element, because in practice
    they really are barline-scoped -- every source we've seen states
    them at bar starts."""
    from music21 import stream as m21stream, clef as m21clef, key as m21key, meter
    clef_changes = [[] for _ in parts]
    key_sig = None
    time_sig = None
    for staff_index, part in enumerate(parts):
        measures = list(part.getElementsByClass(m21stream.Measure))
        if measure_index >= len(measures):
            continue
        measure = measures[measure_index]
        for c in measure.getElementsByClass(m21clef.Clef):
            clef_changes[staff_index].append((Fraction(c.offset), c))
        clef_changes[staff_index].sort(key=lambda t: t[0])
        if key_sig is None:
            key_sig = measure.getElementsByClass(m21key.KeySignature).first()
        if time_sig is None:
            time_sig = measure.getElementsByClass(meter.TimeSignature).first()
    return clef_changes, key_sig, time_sig

def _collect_measure_tempo(parts, measure_index):
    """The first TempoText found in this measure across any staff, or
    None -- a tempo marking isn't staff-specific, so the first hit is
    enough."""
    from music21 import stream as m21stream, tempo as m21tempo
    for part in parts:
        measures = list(part.getElementsByClass(m21stream.Measure))
        if measure_index >= len(measures):
            continue
        t = measures[measure_index].getElementsByClass(m21tempo.TempoText).first()
        if t is not None:
            return t
    return None


def _collect_measure_barlines(parts, measure_index):
    """(left_barline, right_barline) for this measure -- read from the
    first staff that has each set. importers.lilypond_importer's
    _apply_repeat_structure applies the same repeat_markers to every
    staff of one instrument identically, so any staff's own barlines
    are representative of the whole merged measure."""
    from music21 import stream as m21stream
    left = right = None
    for part in parts:
        measures = list(part.getElementsByClass(m21stream.Measure))
        if measure_index >= len(measures):
            continue
        m = measures[measure_index]
        if left is None and m.leftBarline is not None:
            left = m.leftBarline
        if right is None and m.rightBarline is not None:
            right = m.rightBarline
    return left, right


def _emit_barline_xml(barline_obj, location):
    """One <barline location="left"|"right">...</barline> block for a
    music21 Barline/Repeat object, or [] if there's nothing to say
    (a plain, unremarkable barline -- most of them -- needs no
    explicit element at all)."""
    if barline_obj is None:
        return []
    from music21 import bar
    lines = [f'      <barline location="{location}">']
    if isinstance(barline_obj, bar.Repeat):
        bar_style = 'heavy-light' if barline_obj.direction == 'start' else 'light-heavy'
        lines.append(f'        <bar-style>{bar_style}</bar-style>')
        repeat_attrs = f' direction="{"forward" if barline_obj.direction == "start" else "backward"}"'
        if barline_obj.direction != 'start' and barline_obj.times and barline_obj.times != 2:
            repeat_attrs += f' times="{barline_obj.times}"'
        lines.append(f'        <repeat{repeat_attrs}/>')
    elif getattr(barline_obj, 'type', None) == 'final':
        lines.append('        <bar-style>light-heavy</bar-style>')
    else:
        return []
    lines.append('      </barline>')
    return lines

def _emit_clef_xml(clef_obj, staff_number):
    """One <clef number="N"> block. Extracted so the opening
    <attributes> and any mid-measure <attributes> (see
    _emit_measure_xml) share the same emission."""
    sign, line, octave_change = _clef_glyph(clef_obj)
    out = [f'        <clef number="{staff_number}">',
           f'          <sign>{sign}</sign>',
           f'          <line>{line}</line>']
    if octave_change:
        out.append(f'          <clef-octave-change>{octave_change}</clef-octave-change>')
    out.append('        </clef>')
    return out


def _assign_voice_numbers(all_events_by_measure):
    """One stable MusicXML voice number per distinct logical voice id,
    for the whole piece -- assigned in first-appearance order. Not
    required for correct beam/tuplet rendering (see module docstring)
    but a reasonable, low-cost thing to get right too."""
    lane_to_number = {}
    next_number = [1]
    for events in all_events_by_measure:
        for ev in events:
            if ev.lane_id not in lane_to_number:
                lane_to_number[ev.lane_id] = next_number[0]
                next_number[0] += 1
            ev.voice_number = lane_to_number[ev.lane_id]


def _beam_states(events_in_voice_order, time_sig=None, pickup_padding=0.0):
    """MusicXML beam state per beam level, per event (keyed by id(event)),
    for one logical voice's own chronological sequence within one
    measure. This applies uniformly to the voice's REAL chronological
    sequence regardless of which physical staff each note ends up
    printed on -- which is exactly what makes a cross-staff run beam
    correctly: the notes on either side of the staff change are still
    adjacent in this sequence.

    The grouping itself is the shared beaming logic in
    importers/notation_repair.py: standard meter-based beaming (by
    beat, per the active time signature -- NOT one beam across every
    adjacent same-value note in the bar, which is what this function
    used to do), with tuplet groups beamed as units of their own.
    Confirmed on a cross-staff LilyPond file: eight plain eighths in 4/4
    came out as one beam across the whole bar, and a run of triplets
    and plain eighths as a single twelve-note beam."""
    if not events_in_voice_order:
        return {}
    states = compute_beam_states(
        [ev.obj for ev in events_in_voice_order], time_sig,
        first_offset=float(events_in_voice_order[0].offset) + pickup_padding)
    return {id(ev): st for ev, st in zip(events_in_voice_order, states) if st}




# def _stem_direction(ev, cross_staff_lane_ids, num_staves):
#     """'up' or 'down'. For a note that's part of a run known to cross
#     staves (see cross_staff_lane_ids), stems point toward the crossing
#     -- down on the upper staff, up on any lower staff -- matching the
#     convention a real hand-verified reference file used. Otherwise,
#     ordinary pitch-register-relative-to-a-per-staff-middle-line stems,
#     the same heuristic used previously in the standalone
#     lilypond2musicxml_crossstaff_measures.py this module's approach was
# #     modeled on."""
#     if ev.lane_id in cross_staff_lane_ids:
#         return 'down' if ev.staff == 1 else 'up'
#     n = ev.obj
#     if n.isRest:
#         return 'up'
#     pitches = n.pitches if n.isChord else [n.pitch]
#     avg_midi = sum(p.midi for p in pitches) / len(pitches)
#     middle = 71 if ev.staff == 1 else 50  # B4 for a treble-ish staff, D3 for a bass-ish one
#     return 'down' if avg_midi > middle else 'up'

def _stem_direction(ev, cross_staff_lane_ids, num_staves, same_staff_lanes_sorted):
    """'up' or 'down'. 
    
    For a note that's part of a run known to cross
    staves, stems point toward the crossing (see module docstring).
    In a measure with two or more voices on the same staff, voice
    ORDER decides -- first voice up, later voices down -- which is
    exactly what LilyPond's own \\voiceOne/\\voiceTwo set up, and what
    the source means when it engraves one voice stems-up and the
    other stems-down. Only in a single-voice measure (or one where we
    couldn't determine the lane ordering) do we fall back to a
    pitch-register guess, which matches the source's implicit behavior
    when it has no explicit voice structure and lets stems follow the
    staff position.

    'up' or 'down'. Priority order:
      1. Notes that were actually redirected mid-piece via
         \\change Staff (see lilypond_importer._StaffWalker._append,
         which tags them) point toward the crossing.
      2. An explicit source override (\\voiceOne/\\voiceTwo/\\stemUp/
         \\stemDown, via lilypond_importer._StaffWalker._apply_events)
         wins where present.
      3. In a measure with two or more voices on the same staff,
         voice order decides: first voice up, later voices down.
      4. Otherwise, pitch register relative to a per-staff middle line.
    """
    # Middle-line pitch (MIDI) for each clef, i.e. the line above which the
# pitch heuristic sends stems down. Equivalent to what the old "71 if
# staff 1 else 50" was approximating, but keyed on the clef actually in
# force rather than the staff number -- which matters when a staff has
# changed clef mid-piece (e.g. the Haydn bar with a bass->treble change
# on the lower staff).
    _CLEF_MIDDLE_MIDI = {
        ('G', 1): 74,  # french violin
        ('G', 2): 71,  # treble
        ('C', 1): 67,  # soprano
        ('C', 2): 64,  # mezzo-soprano
        ('C', 3): 60,  # alto
        ('C', 4): 57,  # tenor
        ('C', 5): 53,  # baritone (C)
        ('F', 3): 53,  # baritone (F)
        ('F', 4): 50,  # bass
        ('F', 5): 45,  # subbass
    }
    n = ev.obj
    if n.isRest:
        return 'up'
    if getattr(n.editorial, 'lily_redirected', False):
        return 'down' if ev.staff == 1 else 'up'
    explicit = getattr(n.editorial, 'lily_stem_dir', None)
    if explicit is not None:
        return explicit
    if len(same_staff_lanes_sorted) >= 2 and ev.lane_id in same_staff_lanes_sorted:
        position = same_staff_lanes_sorted.index(ev.lane_id)
        return 'up' if position == 0 else 'down'
    pitches = n.pitches if n.isChord else [n.pitch]
    avg_midi = sum(p.midi for p in pitches) / len(pitches)
    middle = _CLEF_MIDDLE_MIDI.get(
        (ev.clef_sign, ev.clef_line),
        71 if ev.staff == 1 else 50)   # fall back to the old default if unknown
    return 'down' if avg_midi > middle else 'up'


def _slur_notations(n, open_slurs):
    """<slur> notations for note/chord `n` (chord-level, like tuplet/
    articulations -- called only at pitch_index == 0). `open_slurs`
    maps id(spanner) -> the MusicXML slur number assigned to it, and
    is threaded through every measure of one merged instrument (see
    merge_parts_to_xml) so numbers stay consistent across barlines,
    same convention as music21's own writer uses for the parts this
    emitter doesn't have to hand-build. A number is freed as soon as
    its slur closes, so a later, unrelated slur can reuse it -- MusicXML
    only requires numbers to be unique among slurs open AT THE SAME
    TIME, not across the whole part."""
    lines = []
    for sp in n.getSpannerSites('Slur'):
        spanned = sp.getSpannedElements()
        if not spanned:
            continue
        if spanned[0] is n:
            used = set(open_slurs.values())
            num = 1
            while num in used:
                num += 1
            open_slurs[id(sp)] = num
            lines.append(f'<slur number="{num}" type="start"/>')
        if spanned[-1] is n and len(spanned) > 1:
            num = open_slurs.pop(id(sp), 1)
            lines.append(f'<slur number="{num}" type="stop"/>')
    return lines


def _emit_note_xml(ev, divisions, beam_state, stem, pitch_index=0, num_pitches=1, open_slurs=None):
    """Emits ONE <note> element for pitch index `pitch_index` of ev.obj
    (0 for a plain Note/Rest, which has exactly one; 0..num_pitches-1
    for a Chord, one call per pitch, each identical except for pitch
    and the <chord/> marker on every call after the first). 
    Detects grace notes and emits them as such."""
    n = ev.obj
    is_grace = bool(getattr(n.duration, 'isGrace', False))
    lines = ['      <note>']
    # MusicXML DTD order: (grace?) comes before (chord? | pitch/rest),
    # and (duration?) is absent for graces -- they occupy no notated time.
    if is_grace:
        # <grace slash="yes"/> marks an acciaccatura; a bare <grace/>
        # is an appoggiatura. The importer tags slashed graces with
        # .editorial.grace_slash (see lilypond_importer._visit_GraceMusic).
        if getattr(n.editorial, 'grace_slash', False):
            lines.append('        <grace slash="yes"/>')
        else:
            lines.append('        <grace/>')
    if pitch_index > 0:
        lines.append('        <chord/>')
    if n.isRest:
        lines.append('        <rest/>')
    else:
        p = n.pitches[pitch_index] if n.isChord else n.pitch
        lines.append('        <pitch>')
        lines.append(f'          <step>{p.step}</step>')
        if p.accidental is not None and p.accidental.alter:
            lines.append(f'          <alter>{int(p.accidental.alter)}</alter>')
        lines.append(f'          <octave>{p.octave}</octave>')
        lines.append('        </pitch>')
    if not is_grace:
        duration_divisions = int(round(float(n.duration.quarterLength) * divisions))
        lines.append(f'        <duration>{duration_divisions}</duration>')

    if n.tie is not None:
        tie_type = {'start': 'start', 'stop': 'stop', 'continue': 'stop'}.get(n.tie.type, 'start')
        lines.append(f'        <tie type="{tie_type}"/>')
    lines.append(f'        <voice>{ev.voice_number}</voice>')
    if n.duration.type and n.duration.type not in ('zero', 'complex'):
        lines.append(f'        <type>{n.duration.type}</type>')
        for _ in range(n.duration.dots or 0):
            lines.append('        <dot/>')
    tuplets = n.duration.tuplets
    if tuplets:
        t = tuplets[0]
        lines.append('        <time-modification>')
        lines.append(f'          <actual-notes>{t.numberNotesActual}</actual-notes>')
        lines.append(f'          <normal-notes>{t.numberNotesNormal}</normal-notes>')
        lines.append('        </time-modification>')
    if not n.isRest and pitch_index == 0:
        lines.append(f'        <stem>{stem}</stem>')
    lines.append(f'        <staff>{ev.staff}</staff>')
    if beam_state and pitch_index == 0:
        for lvl in sorted(beam_state):
            lines.append(f'        <beam number="{lvl}">{beam_state[lvl]}</beam>')

    notations = []
    if pitch_index == 0 and tuplets and tuplets[0].type in ('start', 'stop'):
        notations.append(f'<tuplet type="{tuplets[0].type}" bracket="yes"/>')
    if n.tie is not None:
        tie_notation_type = {'start': 'start', 'stop': 'stop', 'continue': 'stop'}.get(n.tie.type, 'start')
        notations.append(f'<tied type="{tie_notation_type}"/>')
    if pitch_index == 0 and not n.isRest and open_slurs is not None:
        notations.extend(_slur_notations(n, open_slurs))
    # Articulations, ornaments, and fermata are chord-level markings in
    # MusicXML -- they belong once, on the chord's first <note> only,
    # NOT repeated on every pitch (unlike <tie>/<tied> just above, which
    # DO correctly repeat per pitch: a tie connects pitch-for-pitch
    # between one chord and the next). Confirmed the hard way: without
    # this guard, a 2-note chord carrying a turn or fermata emitted that
    # marking twice.
    if pitch_index == 0:
        arts = [a for a in getattr(n, 'articulations', [])
                if type(a).__name__ in _ARTICULATION_CLASS_TO_MXML]
        if arts:
            inner = ''.join(f'<{_ARTICULATION_CLASS_TO_MXML[type(a).__name__]}/>' for a in arts)
            notations.append(f'<articulations>{inner}</articulations>')
        # Ornaments (turn/trill/mordent) and fermata are read straight
        # off n.expressions -- populated correctly upstream (e.g.
        # importers/lilypond_importer.py's _EXPRESSION_TABLE) regardless
        # of which importer built this note, same as everything else
        # this emitter reads.
        exprs = getattr(n, 'expressions', [])
        ornaments = [e for e in exprs if type(e).__name__ in _ORNAMENT_CLASS_TO_MXML]
        if ornaments:
            inner = ''.join(f'<{_ORNAMENT_CLASS_TO_MXML[type(e).__name__]}/>' for e in ornaments)
            notations.append(f'<ornaments>{inner}</ornaments>')
        if any(type(e).__name__ == 'Fermata' for e in exprs):
            notations.append('<fermata/>')
    if notations:
        lines.append('        <notations>')
        for nn in notations:
            lines.append(f'          {nn}')
        lines.append('        </notations>')

    lines.append('      </note>')
    return lines


def _emit_measure_xml(measure_number, events, divisions, num_staves,
                       clef_changes, key_sig, time_sig, is_first_measure, cross_staff_lane_ids,
                       tempo_text=None, left_barline=None, right_barline=None,
                       time_sig_active=None, measure_length=None, implicit=False, open_slurs=None):
    """One <measure> block.

    `clef_changes`: a list with one entry per staff, each a list of
    (in-measure offset in quarterLengths, Clef) tuples sorted by offset.
    Offset-0 changes go in this measure's opening <attributes>; any
    later change is emitted in its own <attributes> block positioned at
    that offset within the note stream, so a mid-bar clef change takes
    effect at the correct time. An earlier version hoisted every clef
    to the barline, and then forced each one into the first voice's
    stream the moment that voice's NEXT event came up -- for the Haydn
    bar with an eighth-note Eb2 in the bass then a mid-bar \\Treble,
    that placed the change one full quarter later than the source, so
    the following dyad was notated under the old clef and Dorico/
    MuseScore both drew it on top of the clef. The fix lets whichever
    voice's stream naturally reaches the clef's own offset host it.
    """
    lines = [f'    <measure number="{measure_number}"' + (' implicit="yes"' if implicit else '') + '>']

    lines.extend(_emit_barline_xml(left_barline, 'left'))

    # Partition clef changes: offset-0 into the opening <attributes>,
    # later ones queued for in-stream emission.
    initial_clefs = [None] * num_staves
    later_clefs = []   # (offset, staff_index, clef_obj), kept sorted
    for staff_index, changes in enumerate(clef_changes):
        for off, c in changes:
            if off == 0:
                initial_clefs[staff_index] = c
            else:
                later_clefs.append((off, staff_index, c))
    later_clefs.sort(key=lambda t: t[0])

    if is_first_measure or key_sig is not None or time_sig is not None or any(initial_clefs):
        lines.append('      <attributes>')
        if is_first_measure:
            lines.append(f'        <divisions>{divisions}</divisions>')
        if key_sig is not None:
            lines.append(f'        <key><fifths>{key_sig.sharps}</fifths></key>')
        if time_sig is not None:
            lines.append(f'        <time><beats>{time_sig.numerator}</beats>'
                          f'<beat-type>{time_sig.denominator}</beat-type></time>')
        if is_first_measure:
            lines.append(f'        <staves>{num_staves}</staves>')
        for i, c in enumerate(initial_clefs):
            if c is not None:
                lines.extend(_emit_clef_xml(c, i + 1))
        lines.append('      </attributes>')

    if tempo_text is not None:
        lines.append('      <direction placement="above">')
        lines.append('        <direction-type>')
        lines.append(f'          <words>{_xml_escape(tempo_text.text)}</words>')
        lines.append('        </direction-type>')
        lines.append('      </direction>')

    # Group events by logical voice, in first-appearance (== voice
    # number) order, each internally offset-sorted.
    by_voice = {}
    for ev in events:
        by_voice.setdefault(ev.voice_number, []).append(ev)
    for v in by_voice.values():
        v.sort(key=lambda e: e.offset)

    # Same-staff lane ordering, for stem direction. Lanes that cross
    # staves are excluded -- they keep the crossing-relative stems.
    lanes_by_staff = {}
    for ev in events:
        if ev.lane_id in cross_staff_lane_ids:
            continue
        lanes_by_staff.setdefault(ev.staff, set()).add(ev.lane_id)
    lanes_by_staff = {s: sorted(ls) for s, ls in lanes_by_staff.items()}

    voice_order = sorted(by_voice)

    total_ql = None
    cursor = Fraction(0)
    for voice_number in voice_order:
        voice_events = by_voice[voice_number]
        gap = voice_events[0].offset - cursor
        if gap != 0:
            gap_divisions = int(round(float(gap) * divisions))
            if gap_divisions > 0:
                lines.append(f'      <forward><duration>{gap_divisions}</duration></forward>')
            elif gap_divisions < 0:
                lines.append(f'      <backup><duration>{-gap_divisions}</duration></backup>')
            cursor = voice_events[0].offset

        pickup_padding = 0.0
        if is_first_measure and time_sig_active is not None:
            bar_ql = float(time_sig_active.barDuration.quarterLength)
            if float(measure_length) < bar_ql:
                pickup_padding = bar_ql - float(measure_length)   # anacrusis
        beam_state = _beam_states(voice_events, time_sig_active, pickup_padding)

        for ev in voice_events:
            # Emit any pending mid-measure clef whose offset falls at
            # or before this event's own offset, provided THIS voice's
            # cursor hasn't already passed it. If it has, leave the
            # clef pending for a later voice rather than backing up --
            # voice 2 (the one the change actually applies to, and the
            # one whose natural timeline reaches the offset) will host
            # it without any forward/backup sandwich.
            while later_clefs and later_clefs[0][0] <= ev.offset + 1e-6:
                _off, staff_index, clef_obj = later_clefs[0]
                if _off < cursor - 1e-6:
                    break
                later_clefs.pop(0)
                if _off > cursor + 1e-6:
                    fwd_div = int(round(float(_off - cursor) * divisions))
                    if fwd_div > 0:
                        lines.append(f'      <forward><duration>{fwd_div}</duration></forward>')
                    cursor = _off
                lines.append('      <attributes>')
                lines.extend(_emit_clef_xml(clef_obj, staff_index + 1))
                lines.append('      </attributes>')

            stem = _stem_direction(ev, cross_staff_lane_ids, num_staves,
                                   lanes_by_staff.get(ev.staff, []))
            num_pitches = len(ev.obj.pitches) if ev.obj.isChord else 1
            for pitch_index in range(num_pitches):
                lines.extend(_emit_note_xml(ev, divisions, beam_state.get(id(ev)), stem,
                                             pitch_index, num_pitches, open_slurs))
            if not getattr(ev.obj.duration, 'isGrace', False):
                cursor += Fraction(ev.obj.duration.quarterLength)

        voice_total = cursor
        if total_ql is None or voice_total > total_ql:
            total_ql = voice_total

    # Fallback for the rare case where a clef's offset doesn't coincide
    # with any voice's natural cursor position (e.g., a clef change
    # partway through a sustained note with no onset there). Emit it at
    # the correct position via a backup/forward pair on the final
    # voice's stream, so a clef can never be silently dropped.
    if later_clefs:
        for _off, staff_index, clef_obj in sorted(later_clefs, key=lambda t: t[0]):
            if _off < cursor - 1e-6:
                back_div = int(round(float(cursor - _off) * divisions))
                if back_div > 0:
                    lines.append(f'      <backup><duration>{back_div}</duration></backup>')
                lines.append('      <attributes>')
                lines.extend(_emit_clef_xml(clef_obj, staff_index + 1))
                lines.append('      </attributes>')
                if back_div > 0:
                    lines.append(f'      <forward><duration>{back_div}</duration></forward>')

    lines.extend(_emit_barline_xml(right_barline, 'right'))
    lines.append('    </measure>')
    return lines, (total_ql or Fraction(0))


def merge_parts_to_xml(parts, part_id, part_name=None, cross_staff_lane_ids=None):
    """Builds the full <part id="...">...</part> body (and its matching
    <score-part> entry for <part-list>) for `parts` merged into one
    multi-staff instrument. `cross_staff_lane_ids`: the set of logical
    voice ids (see module docstring) known to actually cross staves --
    used only to pick the "leaning into the crossing" stem convention
    for those specific notes; every other note gets ordinary
    pitch-based stems. Returns (score_part_xml, part_xml) as strings.
    """
    from music21 import stream as m21stream

    cross_staff_lane_ids = cross_staff_lane_ids or set()
    num_staves = len(parts)
    divisions = _compute_divisions(parts)
    num_measures = max(len(list(p.getElementsByClass(m21stream.Measure))) for p in parts)

    def _measure_length(i):
        lengths = []
        for p in parts:
            measures = list(p.getElementsByClass(m21stream.Measure))
            if i < len(measures):
                lengths.append(Fraction(measures[i].duration.quarterLength))
        return max(lengths) if lengths else Fraction(4)

    all_events_by_measure = [_collect_measure_events(parts, i, _measure_length(i))
                              for i in range(num_measures)]
    _assign_voice_numbers(all_events_by_measure)

    measure_blocks = []
    prev_key_sharps = None
    prev_time_str = None
    open_slurs = {}   # spanner id -> assigned MusicXML slur number, kept
                       # across measures/barlines for this one instrument
    for i in range(num_measures):
        clef_changes, key_sig, time_sig = _collect_measure_signatures(parts, i)        
        show_key = key_sig is not None and (i == 0 or key_sig.sharps != prev_key_sharps)
        show_time = time_sig is not None and (
            i == 0 or f'{time_sig.numerator}/{time_sig.denominator}' != prev_time_str)
        if key_sig is not None:
            prev_key_sharps = key_sig.sharps
        if time_sig is not None:
            prev_time_str = f'{time_sig.numerator}/{time_sig.denominator}'
        tempo_text = _collect_measure_tempo(parts, i)
        left_barline, right_barline = _collect_measure_barlines(parts, i)
        first_measures = [m for m in parts[0].getElementsByClass(m21stream.Measure)]
        printed_number = first_measures[i].number if i < len(first_measures) else i + 1
        is_pickup = (i == 0 and bool(first_measures) and bool(first_measures[0].paddingLeft))
        block, _ = _emit_measure_xml(
            printed_number, all_events_by_measure[i], divisions, num_staves,
            clef_changes,
            key_sig if show_key else None, time_sig if show_time else None,
            i == 0, cross_staff_lane_ids,
            tempo_text=tempo_text, left_barline=left_barline, right_barline=right_barline,
            time_sig_active=time_sig, measure_length=_measure_length(i),
            implicit=is_pickup, open_slurs=open_slurs,
        )
        measure_blocks.append('\n'.join(block))

    part_name_xml = _xml_escape(part_name) if part_name else ''
    score_part_xml = (f'<score-part id="{part_id}"><part-name>{part_name_xml}</part-name></score-part>')
    part_xml = f'<part id="{part_id}">\n' + '\n'.join(measure_blocks) + '\n  </part>'
    return score_part_xml, part_xml
