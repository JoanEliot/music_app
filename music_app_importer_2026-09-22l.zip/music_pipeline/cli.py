#!/usr/bin/env python3
r"""
cli.py

Minimal command-line front end for core.import_pipeline. Collects a
JobSpec from the command line and hands it to run_job() -- see the
architecture doc: this is meant to stay a "thin front end" with no
musical logic of its own.

USAGE
-----
    python3 cli.py INPUT
    python3 cli.py INPUT -o OUTPUT.musicxml
    python3 cli.py INPUT --format humdrum
    python3 cli.py INPUT --no-filters          (Humdrum only -- skip
                                                 embedded !!!filter: records)
    python3 cli.py --build-satb2gs                (optional: build the full satb2gs tool)
    python3 cli.py INPUT --no-snippets            (don't cut marked-up scores into snippets)
    python3 cli.py INPUT --first-only             (multi-tune / multi-\\score files: first only)
    python3 cli.py DIR -r --output-dir OUT --jobs 4 --report r.json   (batch: folders/globs/many files)
    python3 cli.py INPUT --show-lyrics            (print all lyric verses found)
    python3 cli.py INPUT --show-metadata          (print the score's metadata)
    python3 cli.py INPUT --metadata-json OUT.json (write the metadata as JSON)
    python3 cli.py INPUT.mid --musescore-bin "C:\Program Files\MuseScore 3\bin\MuseScore3.exe"

INPUT can be a single file (Humdrum .krn/.hum, MusicXML .musicxml/.xml/.mxl,
LilyPond .ly/.ily, ABC .abc, MIDI .mid/.midi) or, for MuseData, a directory
of per-part files (see importers/musedata_importer.py's docstring).

Format is auto-detected from the extension/content if --format is omitted.
Output defaults to INPUT with a .musicxml suffix if -o is omitted.
"""

import argparse
from pathlib import Path
import json
import sys
import warnings

from core.import_pipeline import JobSpec, run_job_all


def _print_lyrics(score):
    """All verses of lyrics, per part (per voice where a part has several),
    as plain text and LilyPond lyricmode (see core/lyrics.py)."""
    from core import lyrics
    print("-- lyrics --")
    found = False
    for i, part in enumerate(score.parts):
        for label, voice in lyrics.lyric_voices(part):
            for verse in lyrics.verse_keys(part, voice):
                found = True
                name = part.partName or f'part {i + 1}'
                where = f"{name}, {label}" if label else name
                print(f"  {where}, verse {verse}: {lyrics.verse_text(part, verse, voice)}")
                print(f"      lyricmode: {lyrics.to_lyricmode(part, verse, voice)}")
    if not found:
        print("  (none)")


def _print_metadata(md):
    """Human-readable dump of a metadata dict: only fields that have a
    value, so an almost-empty file doesn't print a wall of blanks."""
    from core.score_metadata import display_title
    print("-- metadata --")
    shown = display_title(md)
    if shown:
        print(f"  {'display title':<22} {shown}")
    for key, value in md.items():
        if key in ('schema_version',) or value in (None, [], {}):
            continue
        if key == 'origin':
            print(f"  {'origin':<22} {value.get('format')} <- {value.get('path')}")
            if value.get('fallbacks'):
                print(f"  {'  filled by fallback':<22} {', '.join(value['fallbacks'])}")
        elif key == 'credits':
            print(f"  {'credits':<22}")
            for c in value:
                tag = ','.join(c['types']) or 'untyped'
                flag = ' [placeholder]' if c.get('placeholder') else ''
                print(f"      p{c['page']} ({tag}){flag}: {c['text']!r}")
        elif isinstance(value, dict):
            print(f"  {key:<22}")
            for k, v in value.items():
                print(f"      {k}: {v}")
        elif isinstance(value, list):
            print(f"  {key:<22}")
            for item in value:
                print(f"      {item}")
        else:
            print(f"  {key:<22} {value}")


def _parse_snippet_ranges(range_args, ap):
    """[(start_bar, end_bar), ...] from --snippet-range's raw "START-END"
    strings, 1-based inclusive; ap.error() on anything malformed so
    argparse's own usual usage-error path handles it."""
    ranges = []
    for raw in range_args or []:
        parts = raw.split('-')
        if len(parts) != 2 or not all(p.strip().lstrip('+').isdigit() for p in parts):
            ap.error(f"--snippet-range {raw!r}: expected START-END, e.g. 5-7")
        ranges.append((int(parts[0]), int(parts[1])))
    return ranges


def _parse_staff_list(raw, ap):
    """[int, ...] from --staves' raw comma-separated "1,3" string, or
    None if `raw` is None."""
    if raw is None:
        return None
    staves = []
    for piece in raw.split(','):
        piece = piece.strip()
        if not piece.isdigit():
            ap.error(f"--staves {raw!r}: expected comma-separated staff numbers, e.g. 1,3")
        staves.append(int(piece))
    return staves


_GLOB_CHARS = set('*?[')


def _wants_batch(args, inputs) -> bool:
    """One plain file with no batch options is a single job (the original
    behavior); anything else -- several inputs, a folder, a glob, or a
    batch option -- is a batch."""
    if (len(inputs) > 1 or args.output_dir or args.recursive or args.flatten
            or args.skip_existing or args.jobs > 1 or args.stop_on_error
            or args.report or args.dry_run):
        return True
    only = inputs[0]
    return Path(only).is_dir() or (not Path(only).exists() and bool(_GLOB_CHARS & set(only)))


def _first_line(text, limit=110):
    line = (text or '').strip().splitlines()[0] if (text or '').strip() else ''
    return line if len(line) <= limit else line[:limit - 1] + '\u2026'


def _failure_line(message, limit=170):
    """One useful line for a failure: the message's first line, plus -- when
    that line just introduces detail ("... failed (exit 1):") -- the first
    detail line that names an error."""
    lines = [l.strip() for l in (message or '').splitlines() if l.strip()]
    if not lines:
        return ''
    head = lines[0]
    if head.endswith(':') and len(lines) > 1:
        head += ' ' + next((l for l in lines[1:] if 'error' in l.lower()), lines[1])
    return head if len(head) <= limit else head[:limit - 1] + '\u2026'


def _print_lyrics_verses(verses):
    print("-- lyrics --")
    if not verses:
        print("  (none)")
    for part, per_verse in verses.items():
        for verse, text in per_verse.items():
            print(f"  part {int(part) + 1}, verse {verse}: {text}")


def _run_batch_cli(args, inputs, importer_options) -> int:
    import signal
    from core.batch import expand_inputs, plan_outputs, run_batch

    items, ignored = expand_inputs(inputs, recursive=args.recursive, fmt=args.format)
    if not items:
        print("Error: no music files found in the input(s)."
              + ("" if args.recursive else " (Folders are scanned without their subfolders "
                 "unless you pass -r; a folder of MuseData part-files with unusual names "
                 "needs --format musedata.)"), file=sys.stderr)
        return 1
    plan_outputs(items, output_dir=args.output_dir, flatten=args.flatten)

    if args.dry_run:
        for it in items:
            if it.plan_error:
                print(f"ERROR   {it.label}: {it.plan_error}")
            else:
                print(f"{it.format:9} {it.label} -> {it.output_path}")
        print(f"\n{len(items)} item(s); {len(ignored)} file(s) passed over as not music. (dry run)")
        return 0

    stop = {'flag': False}

    def on_sigint(signum, frame):
        stop['flag'] = True
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        print("\nInterrupted: finishing the current file, then stopping "
              "(Ctrl+C again to abort now).", file=sys.stderr)
    try:
        signal.signal(signal.SIGINT, on_sigint)
    except ValueError:
        pass                                            # not the main thread

    total = len(items)
    width = len(str(total))

    def on_event(e):
        if e['type'] != 'done':
            return
        r = e['result']
        tag = f"[{e['index'] + 1:>{width}}/{total}]"
        notes = f"  [{len(r.warnings)} note(s)]" if r.warnings else ''
        if r.status == 'ok':
            outs = r.outputs
            where = outs[0]['path'] if len(outs) == 1 else f"{len(outs)} scores"
            print(f"{tag} OK    {r.input_path} -> {where}  ({r.seconds:.1f}s){notes}", flush=True)
        elif r.status == 'skipped':
            print(f"{tag} SKIP  {r.input_path}  ({r.note})", flush=True)
        elif r.status == 'failed':
            print(f"{tag} FAIL  {r.input_path}  {r.error['type']}: {_failure_line(r.error['message'])}",
                  flush=True)
        if args.verbose:
            for w in r.warnings:
                print(f"        note: {_first_line(w['message'], 200)}", flush=True)
        if args.show_metadata:
            for out in r.outputs:
                print(f"    {out['path']}")
                _print_metadata(out['metadata'])
        if args.show_lyrics:
            for out in r.outputs:
                print(f"    {out['path']}")
                _print_lyrics_verses(out['lyrics'])

    report = run_batch(items, multi='first' if args.first_only else 'all',
                       split_snippets=not args.no_snippets, skip_existing=args.skip_existing,
                       importer_options=importer_options, jobs=max(1, args.jobs),
                       stop_on_error=args.stop_on_error, progress=on_event,
                       cancel=lambda: stop['flag'])

    c = report.counts
    print(f"\nBatch: {len(report.items)} input(s): {c['ok']} ok, {c['failed']} failed, "
          f"{c['skipped']} skipped" + (f", {c['cancelled']} not run" if c['cancelled'] else '')
          + f"  ->  {c['outputs']} output file(s), {c['warnings']} note(s), {report.seconds:.1f}s")
    failed = [r for r in report.items if r.status == 'failed']
    if failed:
        print("\nFailed:")
        for r in failed:
            print(f"  {r.input_path}: {r.error['type']}: {_failure_line(r.error['message'])}")
    if ignored and not args.verbose:
        print(f"({len(ignored)} file(s) in scanned folders were passed over as not music; -v lists them)")
    if ignored and args.verbose:
        for path, why in ignored:
            print(f"  passed over: {path} ({why})")
    if args.report:
        with open(args.report, 'w', encoding='utf-8') as f:
            json.dump({**report.to_dict(),
                       'passed_over': [{'path': p, 'reason': w} for p, w in ignored]},
                      f, indent=2, ensure_ascii=False)
        print(f"report -> {args.report}")
    return 0 if report.ok else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('inputs', nargs='*', default=[], metavar='INPUT',
                     help='Input file(s), folder(s) or glob pattern(s). One file = a single job; '
                          'several, or any folder/glob or batch option, = a batch (see below). '
                          'A folder of MuseData part-files is one job for that folder.')
    ap.add_argument('-o', '--output', default=None,
                     help='Output .musicxml path for a SINGLE input (default: INPUT with a .musicxml '
                          'suffix). For a batch use --output-dir.')
    ap.add_argument('--format', choices=['musedata', 'humdrum', 'musicxml', 'lilypond', 'abc', 'midi'],
                     default=None, help='Force a format instead of auto-detecting it')
    ap.add_argument('--no-filters', action='store_true',
                     help="Humdrum only: skip embedded '!!!filter:' records (e.g. satb2gs)")
    ap.add_argument('--lilypond-bin', default=None,
                     help="LilyPond only: path to the lilypond executable, if it's not on PATH "
                          "(e.g. on Windows: --lilypond-bin \"C:\\Program Files\\LilyPond\\bin\\lilypond.exe\")")
    ap.add_argument('--musescore-bin', default=None,
                     help="MIDI only: path to the MuseScore executable, if it's not one of the "
                          "common names already on PATH (e.g. on Windows: --musescore-bin "
                          "\"C:\\Program Files\\MuseScore 3\\bin\\MuseScore3.exe\")")
    ap.add_argument('--satb2gs-bin', default=None, metavar='PATH',
                     help='Humdrum: use this compiled satb2gs tool for embedded satb2gs '
                          'filters (else one found on PATH / in the cache, else the '
                          'built-in Python merger)')
    ap.add_argument('--build-satb2gs', action='store_true',
                     help='Clone and compile humlib\'s satb2gs tool (several minutes; needs '
                          'git, g++, make, network), then exit. Optional: without it, '
                          'Humdrum satb2gs filters use the built-in Python merger.')
    ap.add_argument('--no-snippets', action='store_true',
                     help='Do not cut a score into snippets at all (any --snippet-mode); write it whole')
    ap.add_argument('--snippet-mode', choices=['markers', 'ranges', 'division', 'harmonic_moments'],
                     default='markers', metavar='MODE',
                     help="How to define a snippet's boundaries (single-file jobs only; a batch always "
                          "uses markers): 'markers' (default: SS:/SR:/SD:/SE: text embedded in the "
                          "score), 'ranges' (--snippet-range), 'division' (--snippet-size/--snippet-"
                          "stride), or 'harmonic_moments' (automatic chord detection, no other options "
                          "needed). See core/snippets.py for what each one means in full.")
    ap.add_argument('--snippet-range', action='append', default=None, metavar='START-END',
                     help="With --snippet-mode ranges: one bar range, 1-based printed bar numbers, "
                          "e.g. --snippet-range 5-7. Repeat for several ranges; each becomes its own "
                          "snippet, numbered in the order given.")
    ap.add_argument('--snippet-size', type=int, default=None, metavar='BARS',
                     help='With --snippet-mode division: bars per chunk')
    ap.add_argument('--snippet-stride', type=int, default=None, metavar='BARS',
                     help='With --snippet-mode division: bars between chunk starts (default: same as '
                          '--snippet-size, i.e. no overlap; a smaller value overlaps chunks, e.g. '
                          'size=2 stride=1 gives bars 1-2, 2-3, 3-4, ...)')
    ap.add_argument('--staves', default=None, metavar='LIST',
                     help="Keep only these staves in the output (1-based, comma-separated, e.g. "
                          "\"1,3\" -- see --list-staves for what a file has). Applies after whichever "
                          "--snippet-mode produced the boundaries. Default: use the score's own SK: "
                          "text markers if it has any, else keep every staff.")
    ap.add_argument('--list-staves', action='store_true',
                     help='Print the staves (number, and part/instrument name if there is one) found '
                          'in INPUT, then exit without converting anything -- for choosing --staves.')
    ap.add_argument('--first-only', action='store_true',
                     help='If the file holds several scores (ABC tunes, LilyPond \\score blocks), '
                          'import only the first')
    ap.add_argument('--show-lyrics', action='store_true',
                     help='Print every verse of lyrics found, per part, as plain text and LilyPond lyricmode')
    ap.add_argument('--show-metadata', action='store_true',
                     help='Print the metadata read from the input (title, people, dates, ...)')
    ap.add_argument('--metadata-json', default=None, metavar='FILE',
                     help='Write the full metadata dict to FILE as JSON')
    batch = ap.add_argument_group('batch processing')
    batch.add_argument('--output-dir', default=None, metavar='DIR',
                       help='Write every output under DIR (mirroring each input\'s place under the folder '
                            'it was found in); default: beside each input')
    batch.add_argument('-r', '--recursive', action='store_true',
                       help='Scan folders\' subfolders too')
    batch.add_argument('--flatten', action='store_true',
                       help='With --output-dir: put every output directly in DIR (no subfolders)')
    batch.add_argument('--skip-existing', action='store_true',
                       help='Skip an input whose output already exists instead of overwriting it')
    batch.add_argument('-j', '--jobs', type=int, default=1, metavar='N',
                       help='Process N files at once (separate processes); default 1')
    batch.add_argument('--stop-on-error', action='store_true',
                       help='Stop at the first failure (default: report it and carry on)')
    batch.add_argument('--input-list', default=None, metavar='FILE',
                       help='Also read inputs from FILE, one path per line (# comments allowed)')
    batch.add_argument('--report', default=None, metavar='FILE',
                       help='Write a JSON report: per input its status, outputs, warnings, error, '
                            'and each output\'s metadata and lyrics')
    batch.add_argument('--dry-run', action='store_true',
                       help='Show what a batch would process and write, then stop')
    batch.add_argument('-v', '--verbose', action='store_true',
                       help='Batch: print every warning under its file')
    args = ap.parse_args()

    if args.build_satb2gs:
        from importers.humdrum_filters import build_satb2gs_binary
        try:
            binary = build_satb2gs_binary()
        except RuntimeError as e:
            print(f"FAILED  building satb2gs:\n{e}", file=sys.stderr)
            return 1
        print(f"OK  satb2gs built: {binary}")
        return 0
    inputs = list(args.inputs)
    if args.input_list:
        try:
            with open(args.input_list, encoding='utf-8') as f:
                inputs += [l.strip() for l in f if l.strip() and not l.lstrip().startswith('#')]
        except OSError as e:
            ap.error(f'cannot read --input-list: {e}')
    if not inputs:
        ap.error('the following arguments are required: INPUT')

    importer_options = {}
    if args.satb2gs_bin:
        importer_options['satb2gs_binary'] = args.satb2gs_bin
    if args.no_filters:
        importer_options['apply_filters'] = False
    if args.lilypond_bin:
        importer_options['lilypond_bin'] = args.lilypond_bin
    if args.musescore_bin:
        importer_options['musescore_bin'] = args.musescore_bin

    if _wants_batch(args, inputs):
        if args.output:
            ap.error('-o/--output names ONE output file; for several inputs use --output-dir')
        if args.metadata_json:
            ap.error('--metadata-json is for a single input; for a batch use --report')
        if args.list_staves:
            ap.error('--list-staves is for a single input')
        return _run_batch_cli(args, inputs, importer_options)

    args.input = inputs[0]

    if args.list_staves:
        from core.import_pipeline import _resolve
        from core.snippets import list_staves
        spec = JobSpec(input_path=args.input, format=args.format, importer_options=importer_options)
        input_path, format_name, importer = _resolve(spec)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            score = importer.import_score(input_path, **importer_options)
        print(f"-- staves in {args.input} --")
        for number, name in list_staves(score):
            print(f"  {number}: {name or '(unnamed)'}")
        return 0

    if args.snippet_mode == 'ranges' and not args.snippet_range:
        ap.error("--snippet-mode ranges needs at least one --snippet-range")
    if args.snippet_mode == 'division' and not args.snippet_size:
        ap.error("--snippet-mode division needs --snippet-size")

    spec = JobSpec(
        input_path=args.input,
        format=args.format,
        output_path=args.output,
        importer_options=importer_options,
        multi='first' if args.first_only else 'all',
        split_snippets=not args.no_snippets,
        snippet_mode=args.snippet_mode,
        snippet_ranges=_parse_snippet_ranges(args.snippet_range, ap),
        snippet_division_size=args.snippet_size,
        snippet_division_stride=args.snippet_stride,
        snippet_staves=_parse_staff_list(args.staves, ap),
    )

    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            results = run_job_all(spec)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    # LilyCrossStaffManualFixWarning (see importers/lilypond_importer.py's
    # module docstring, CROSS-STAFF NOTATION section) marks a real,
    # disclosed architectural limitation -- a measure that couldn't be
    # reliably transcribed was replaced with a rest and a bold on-page
    # warning rather than silently mis-notated. Called out separately
    # and distinctly here (not just left to Python's default warning
    # printing) because it means the file needs a follow-up by hand,
    # not just a heads-up.
    manual_fix_warnings = [w for w in caught if w.category.__name__ == 'LilyCrossStaffManualFixWarning']
    other_warnings = [w for w in caught if w not in manual_fix_warnings]

    if len(results) > 1:
        print(f"{args.input} -> {len(results)} scores")
    for result in results:
        n_parts = len(result.score.parts)
        snip = result.metadata.get('snippet')
        label = f"  [snippet {snip['index']}/{snip['count']}: {snip['title'] or '(untitled)'}]" if snip else ''
        print(f"OK  [{result.format}]  {args.input} -> {result.output_path}  ({n_parts} part(s)){label}")
        if result.beams_repaired:
            print(f"    (tuplet beaming repaired in {result.beams_repaired} measure(s))")
        if args.show_metadata:
            _print_metadata(result.metadata)
        if args.show_lyrics:
            _print_lyrics(result.score)
    if args.metadata_json:
        payload = (results[0].metadata if len(results) == 1
                   else [r.metadata for r in results])
        with open(args.metadata_json, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
        print(f"metadata -> {args.metadata_json}"
              + (" (a JSON list, one entry per score)" if len(results) > 1 else ""))

    for w in other_warnings:
        print(f"Note: {w.message}", file=sys.stderr)
    for w in manual_fix_warnings:
        print(f"\n*** MANUAL FIX NEEDED: {w.message} ***\n", file=sys.stderr)

    return 0


if __name__ == '__main__':
    raise SystemExit(main())
