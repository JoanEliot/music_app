"""
tests/midi_compare.py

Independent check of the LilyPond exporter: the .midi LilyPond writes from
our .ly must contain the same notes as the MIDI music21 writes from the
same Score -- same pitches at the same times for the same lengths. Any
pitch, duration, tie, or transposition bug in the exporter shows up here
without any human reading the notation. (Velocity and instrument are not
compared; the exporter writes neither yet.)
"""
import sys, tempfile, warnings
from collections import Counter
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from music21 import converter, chord, note
from exporters import lilypond as ly


def midi_notes(path):
    """Multiset of (onset, length, midi pitch), in quarters, rounded."""
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        s = converter.parse(str(path))
    out = Counter()
    for el in s.flatten().notes:
        ps = [n.pitch.midi for n in el.notes] if isinstance(el, chord.Chord) else [el.pitch.midi]
        for p in ps:
            out[(round(float(el.offset), 2), round(float(el.quarterLength), 2), p)] += 1
    return out


def _relay_measures(score):
    """WORKAROUND, remove when the LilyPond importer is fixed: it places the
    first full bar after a pickup at offset = a full bar's length, leaving a
    phantom gap that music21's MIDI writer (unlike MusicXML output) plays
    as silence. Lay every part's measures end to end by their real length."""
    from music21 import stream
    for part in score.parts:
        pos = 0
        for m in part.getElementsByClass(stream.Measure):
            part.setElementOffset(m, pos)
            pos += float(m.highestTime) if m.highestTime else float(m.duration.quarterLength)


def _split_partial_chord_ties(score):
    """WORKAROUND for a music21 MIDI-writer limitation -- not a bug in this
    project's own importers or exporters/lilypond.py, both of which handle
    a tie on ONE pitch of a chord (`<c e~ g>`) correctly. music21's own
    `.write('midi', ...)`, used here only as this test's independent
    reference signal, does not: confirmed directly (a minimal Score with
    only the middle pitch of a chord tied) that it merges the WHOLE chord
    into one sustained note the moment ANY one pitch carries a tie,
    dropping the other pitches' genuine re-onset. LilyPond's own MIDI --
    what this project actually ships, via ly.compile_lilypond -- gets this
    right; only music21's writer needs help.

    The fix has to keep each tied chord's own Part/Voice completely
    undisturbed: confirmed empirically that music21's tie-merge logic
    breaks (even for a WHOLLY tied chord) as soon as any second
    simultaneous note/chord sits at the same offset in the same stream --
    it does not matter whether that second element even shares a pitch.
    So the untied pitches are pulled out into their own separate,
    measures-shaped Part purely for this comparison's MIDI rendering
    (channel/track is irrelevant to compare_midi, which only checks
    onset+pitch+length), leaving the original tied pitch(es) alone in
    their original Part where music21 already ties them correctly.

    REVISIT if this project ever writes MIDI output some way other than
    by compiling our own exported .ly with real LilyPond -- at that
    point the actual shipped output would need this same fix, not just
    this test's reference signal.
    """
    from music21 import chord as m21chord, note as m21note, stream as m21stream

    extra_flat = m21stream.Stream()
    found_any = False
    for part in score.parts:
        for c in list(part.recurse().getElementsByClass(m21chord.Chord)):
            tied = [n for n in c.notes if n.tie is not None]
            untied = [n for n in c.notes if n.tie is None]
            if not tied or not untied:
                continue   # wholly tied or wholly untied -- nothing to split
            offset = c.getOffsetInHierarchy(score)
            ql = c.duration.quarterLength
            for n in untied:
                c.remove(n)
            extra = (m21chord.Chord(untied, quarterLength=ql) if len(untied) > 1
                     else m21note.Note(untied[0].pitch, quarterLength=ql))
            extra_flat.insert(offset, extra)
            found_any = True
    if found_any:
        extra_part = extra_flat.makeMeasures()
        extra_part.id = '__partial_chord_tie_workaround__'
        score.insert(0, extra_part)


def compare_midi(score, workdir, name='m'):
    # The pipeline marks pickups / short bars before any export
    # (import_pipeline.prepare_score); without it music21's MIDI writer pads
    # a short bar to full length. Idempotent, so safe on prepared scores.
    from core.measures import mark_short_measures
    import copy
    mark_short_measures(score)
    # Grace notes sit outside bar time and LilyPond plays them BEFORE the
    # beat, stealing time from the note before, while music21 places them
    # differently; the two MIDI files cannot be compared on them. Both sides
    # are compared without grace notes (the notation round trip and the
    # rendered page are what check them).
    score = copy.deepcopy(score)
    for n in list(score.recurse().notes):
        if n.duration.isGrace:
            n.activeSite.remove(n)
    workdir = Path(workdir); workdir.mkdir(parents=True, exist_ok=True)
    ly_path = workdir / f'{name}.ly'
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        ly.write_lilypond(score, ly_path, midi=True)
    rc, err = ly.compile_lilypond(ly_path, workdir, formats=())
    ly_mid = workdir / f'{name}.midi'
    m21_mid = workdir / f'{name}_m21.mid'
    # LilyPond's MIDI plays every repeat pass (\\unfoldRepeats), so the
    # music21 side must be unfolded the same way before writing.
    from transforms.unfold_repeats import unfold_repeats
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        unfolded = unfold_repeats(score)
        _relay_measures(unfolded)
        _split_partial_chord_ties(unfolded)
        unfolded.write('midi', fp=str(m21_mid))
    a, b = midi_notes(m21_mid), midi_notes(ly_mid)
    # Onset + pitch must match exactly. LilyPond's MIDI shortens articulated
    # notes (staccato etc.) where music21 does not, so a SHORTER LilyPond note
    # is not a finding; a note that is LONGER in LilyPond's MIDI is.
    ka = Counter((o, p) for (o, _, p), n in a.items() for _ in range(n))
    kb = Counter((o, p) for (o, _, p), n in b.items() for _ in range(n))
    only_m21, only_ly = ka - kb, kb - ka
    da, db = {}, {}
    for (o, l, p), n in a.items():
        da.setdefault((o, p), []).append(l)
    for (o, l, p), n in b.items():
        db.setdefault((o, p), []).append(l)
    longer = sorted((k, max(db[k]), max(da[k])) for k in db
                    if k in da and max(db[k]) > max(da[k]) + 0.011)
    return {'m21_notes': sum(a.values()), 'ly_notes': sum(b.values()),
            'onset_pitch_only_music21': sorted(only_m21.elements())[:5],
            'onset_pitch_only_lilypond': sorted(only_ly.elements())[:5],
            'n_onset_pitch_diff': sum(only_m21.values()) + sum(only_ly.values()),
            'n_longer_in_lilypond': len(longer), 'longer_examples': longer[:3]}


if __name__ == '__main__':
    from music21 import corpus
    from importers import musicxml_importer as mx, lilypond_importer as li
    for n in sys.argv[1:]:
        if n.endswith('.ly'):
            with warnings.catch_warnings():
                warnings.simplefilter('ignore'); s = li.import_score(n)
        else:
            w = corpus.getWork(n); ws = w if isinstance(w, list) else [w]
            p = [x for x in ws if str(x).endswith(('.mxl', '.xml', '.musicxml'))][0]
            with warnings.catch_warnings():
                warnings.simplefilter('ignore'); s = mx.import_score(str(p))
        r = compare_midi(s, tempfile.mkdtemp(), Path(n).stem)
        print(n, r)
