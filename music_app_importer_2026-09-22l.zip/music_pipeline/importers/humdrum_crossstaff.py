"""
importers/humdrum_crossstaff.py

Applies a **kern spine's own per-note RDF "above"/"below" orientation
marker (e.g. a file defining `!!!RDF**kern: < = below`, with individual
notes carrying a trailing `<`) to build correct multi-staff MusicXML for
the affected instrument -- the same architecture
importers/lilypond_importer.py uses for LilyPond's `\\change Staff`, and
importers/musicxml_importer.py uses to preserve MusicXML's own
already-correct multi-staff <part> encoding (see both modules'
docstrings).

This is DISTINCT from, and unrelated to, the OTHER (much rarer) Humdrum
cross-staff convention -- a spine's own `*staff` tandem VALUE changing
partway through -- which importers/humdrum_importer.py's
_detect_cross_staff_spines only detects and warns about. That mechanism
is described in Humdrum's own documentation as having exactly one real
documented instance (a Bartok passage); THIS module's convention --
individual notes in one spine carrying a marker meaning "draw me on the
adjacent staff instead" -- is the one real files actually use (confirmed
against a genuine Beethoven piano sonata score, and against Verovio/VHV's
own documentation, which describes exactly this as the way to notate a
line that dips onto the other staff for legibility).

HOW IT WORKS
--------------------------------------------------------------------
music21's own **kern parser already correctly reads every note's pitch/
duration/tie/beam/tuplet data -- it just puts EVERY note from a spine
into that spine's own Part unconditionally, ignoring the orientation
marker entirely (confirmed against music21's own source: this marker
isn't a documented/handled **kern feature there at all, so it silently
becomes part of the token music21 doesn't recognize and is dropped).
So, unlike LilyPond (which has no existing importer to lean on and has
to parse rhythm/pitch from scratch), this module does NOT re-parse
rhythm or pitch: it only needs to (1) find which raw **kern data token
corresponds to which already-parsed music21 Note/Chord/Rest object, by
matching sequential position within one measure (the Nth real data
token for a spine in a given measure is the Nth note/rest/chord object
in that spine's Part for that measure -- confirmed reliable since
music21 doesn't reorder notes within a spine), (2) for a token carrying
the marker, MOVE that object into the target staff's own Measure at the
same offset -- staff assignment, unlike LilyPond's stem-direction-only
editorial tagging, is purely a matter of which Part/Measure an object
physically sits in (see importers/multi_staff_emitter.py's
_collect_measure_events, which derives "staff number" from position in
the `parts` list it's given) -- and (3) hand the resulting parts to
multi_staff_emitter.merge_parts_to_xml, exactly as the other two
importers do, via the shared score._manual_multistaff_parts mechanism.

SCOPE -- confirmed safe, not confirmed exhaustive
--------------------------------------------------------------------
- Only concerns **kern spines sharing the same `*I...` instrument
  tandem value (a piano's two hands, an organ's several staves, etc).
  **dynam/**text/other auxiliary spines are untouched, left to
  music21's own (already-correct) handling of those.
- A marker found in a measure where that spine is actively split
  (`*^`, i.e. temporarily divided into more than one voice-column) is
  intentionally NOT resolved and reported instead: ordinary parsing of
  that measure is completely unaffected (music21 handles the split
  itself correctly, independent of this module), but sequential-
  position alignment through a split's interleaved sub-voices hasn't
  been built or validated, so this module only ever moves a note in a
  measure with no active split for that spine.
- Grouping columns correctly through a spine split/merge is handled
  (needed just to track which raw column is which spine at all, once
  any split has occurred anywhere earlier in the piece) but a file
  whose exclusive interpretations (`**kern` etc) are (re)declared more
  than once -- a late `*+` spine addition -- is not: column tracking
  simply stops (rather than guessing) if a row's field count doesn't
  match what tracking predicted, and no further markers are resolved
  past that point (a warning names where).
- One **kern spine crossing to a THIRD, non-adjacent staff, or a
  passage where markers send notes in overlapping directions at the
  same time, aren't specifically tested against; the mechanism should
  behave reasonably (each marked note moves independently to its own
  computed target) but hasn't been verified against a real file
  exhibiting either.
"""

import re
import warnings
from fractions import Fraction

_RDF_RE = re.compile(r'^!!!RDF\*\*kern:\s*(\S+)\s*=\s*(.+?)\s*$')


class HumdrumCrossStaffAppliedWarning(UserWarning):
    """Informational: a per-note orientation marker (see module
    docstring) was found and resolved -- names how many notes moved
    and where, so the result can be spot-checked against the original."""


class HumdrumCrossStaffSkippedWarning(UserWarning):
    """A per-note orientation marker was found but could NOT be
    resolved -- e.g. its spine was actively split at that point, no
    sibling spine declares the target staff, or column tracking had
    already broken down earlier in the file. The note stays on its
    original staff, same as if this module didn't run at all."""


def _find_orientation_markers(text: str) -> dict:
    """{marker_string: 'above'|'below'} from this file's own
    `!!!RDF**kern: X = above` / `= below` definitions. Only entries
    whose meaning is literally "above" or "below" (case-insensitive)
    are treated as cross-staff orientation markers -- any other
    **kern RDF definition (editorial marks, cue-sized notes, etc) is
    left alone."""
    markers = {}
    for line in text.splitlines():
        m = _RDF_RE.match(line.strip())
        if not m:
            continue
        marker, meaning = m.group(1), m.group(2).strip().lower()
        if meaning in ('above', 'below'):
            markers[marker] = meaning
    return markers


def _analyze_spines(text: str, markers: dict):
    """Walks the raw text once, tracking column identity through any
    `*^`/`*v` splits/merges (needed just to know which raw column is
    which spine at all -- see module scope note), and returns:

      measures_by_origin: {origin_index: {measure_number: MeasureInfo}}
        MeasureInfo is {'tokens': [(token, orientation_or_None), ...],
        'was_split': bool} -- 'tokens' in row order, one entry per
        actual data token (null '.' tokens excluded) for that spine in
        that measure; 'was_split' is True if that spine had more than
        one active column at any point during the measure.
      staff_of_origin: {origin_index: most recently declared *staffN}
      instrument_of_origin: {origin_index: most recently declared *I...}
      is_kern_origin: {origin_index: bool}
      broke_down_at: the 1-based line number tracking was abandoned at
        (a row's field count stopped matching what was expected), or
        None if it held for the whole file.
    """
    column_origin = None
    next_origin_id = 0
    is_kern_origin = {}
    staff_of_origin = {}
    instrument_of_origin = {}
    measures_by_origin = {}
    broke_down_at = None

    current_measure = 0
    lines = text.splitlines()

    def token_orientation(tok):
        for marker, meaning in markers.items():
            if marker in tok:
                return meaning
        return None

    def measure_slot(origin):
        per_origin = measures_by_origin.setdefault(origin, {})
        return per_origin.setdefault(current_measure, {'tokens': [], 'was_split': False})

    for line_no, line in enumerate(lines, start=1):
        if not line or line[0] == '!':
            continue
        fields = line.split('\t')

        if line.startswith('**'):
            if column_origin is None:
                column_origin = list(range(len(fields)))
                for f in fields:
                    is_kern_origin[next_origin_id] = (f.strip() == '**kern')
                    next_origin_id += 1
            continue

        if column_origin is None:
            continue

        if line[0] == '=':
            m = re.search(r'\d+', fields[0])
            if m:
                current_measure = int(m.group(0))
            else:
                current_measure += 1
            continue

        if broke_down_at is not None:
            continue

        if len(fields) != len(column_origin):
            broke_down_at = line_no
            continue

        if line[0] == '*':
            new_origin = []
            i = 0
            while i < len(fields):
                f = fields[i].strip()
                origin = column_origin[i]
                if f == '*^':
                    new_origin.append(origin)
                    new_origin.append(origin)
                    i += 1
                elif f == '*v':
                    new_origin.append(origin)
                    i += 1
                    while i < len(fields) and fields[i].strip() == '*v':
                        i += 1
                else:
                    if f.startswith('*staff') and f[6:].isdigit():
                        staff_of_origin[origin] = int(f[6:])
                    elif f.startswith('*I') and len(f) > 2:
                        instrument_of_origin[origin] = f
                    new_origin.append(origin)
                    i += 1
            column_origin = new_origin
            continue

        # A data row.
        for i, tok in enumerate(fields):
            origin = column_origin[i]
            if not is_kern_origin.get(origin):
                continue
            tok = tok.strip()
            if tok == '.':
                continue
            slot = measure_slot(origin)
            slot['tokens'].append((tok, token_orientation(tok)))
            if column_origin.count(origin) > 1:
                slot['was_split'] = True

    return measures_by_origin, staff_of_origin, instrument_of_origin, is_kern_origin, broke_down_at


def apply_cross_staff_markers(score, text: str, input_path) -> None:
    """Entry point, called from humdrum_importer.import_score() right
    after music21 builds `score`. Mutates `score` in place: moves any
    marked note into its target staff's Measure, tags every note in
    both spines for multi_staff_emitter's beaming/stem logic, and, if
    anything was actually moved, attaches score._manual_multistaff_parts
    (see core/import_pipeline.py's run_job()) so the merged instrument
    gets spliced into the written MusicXML. Does nothing at all -- not
    even a warning -- if the file defines no above/below RDF marker,
    which is the common case."""
    markers = _find_orientation_markers(text)
    if not markers:
        return

    (measures_by_origin, staff_of_origin, instrument_of_origin,
     is_kern_origin, broke_down_at) = _analyze_spines(text, markers)
    if broke_down_at is not None:
        warnings.warn(
            f"{input_path}: couldn't reliably track spine columns past "
            f"line {broke_down_at} (a row's column count didn't match "
            f"what earlier splits/merges predicted) -- any cross-staff "
            f"orientation marker after that point was not resolved.",
            HumdrumCrossStaffSkippedWarning,
        )

    kern_origins = [o for o in is_kern_origin if is_kern_origin[o]]
    if not kern_origins:
        return

    from music21 import stream as m21stream

    # Map origin index -> that spine's own music21 Part, via the
    # "spine_{origin}" id music21's own **kern importer assigns
    # (confirmed reliable against a real multi-spine file: the
    # numeric suffix is the raw column index a spine STARTED at, one
    # per **kern-type exclusive interpretation, regardless of later
    # splits/merges, which stay within that one Part as Voices).
    part_of_origin = {}
    for p in score.parts:
        pid = str(p.id)
        if pid.startswith('spine_') and pid[6:].isdigit():
            origin = int(pid[6:])
            if origin in kern_origins:
                part_of_origin[origin] = p
    if not part_of_origin:
        return

    moved = 0
    skipped = 0
    touched_origins = set()

    for origin, measures in measures_by_origin.items():
        if origin not in part_of_origin:
            continue
        own_part = part_of_origin[origin]
        own_measures = {m.number: m for m in own_part.getElementsByClass(m21stream.Measure)}
        own_staff = staff_of_origin.get(origin)
        own_instrument = instrument_of_origin.get(origin)

        for measure_number, info in measures.items():
            if not any(o is not None for _tok, o in info['tokens']):
                continue   # nothing marked in this measure for this spine
            if info['was_split']:
                skipped += sum(1 for _tok, o in info['tokens'] if o is not None)
                continue
            own_measure = own_measures.get(measure_number)
            if own_measure is None:
                skipped += sum(1 for _tok, o in info['tokens'] if o is not None)
                continue
            real_objects = list(own_measure.notesAndRests)
            if len(real_objects) != len(info['tokens']):
                # Sequential alignment isn't trustworthy if the counts
                # don't even match (a music21 quirk this module hasn't
                # seen, or a file convention it doesn't understand) --
                # skip this measure for this spine rather than guess.
                skipped += sum(1 for _tok, o in info['tokens'] if o is not None)
                continue

            touched_origins.add(origin)
            for obj, (_tok, orientation) in zip(real_objects, info['tokens']):
                lane_id = f'humdrum:{origin}'
                obj.editorial.lily_lane_id = lane_id
                if orientation is None or own_staff is None:
                    continue
                target_staff = own_staff + (1 if orientation == 'below' else -1)
                target_origin = None
                for other, other_staff in staff_of_origin.items():
                    if other == origin or other not in is_kern_origin or not is_kern_origin[other]:
                        continue
                    if other_staff != target_staff:
                        continue
                    if own_instrument is not None and instrument_of_origin.get(other) != own_instrument:
                        continue
                    target_origin = other
                    break
                if target_origin is None or target_origin not in part_of_origin:
                    skipped += 1
                    continue
                target_part = part_of_origin[target_origin]
                target_measures = {m.number: m for m in target_part.getElementsByClass(m21stream.Measure)}
                target_measure = target_measures.get(measure_number)
                if target_measure is None:
                    skipped += 1
                    continue
                local_offset = obj.getOffsetInHierarchy(own_measure)
                own_measure.remove(obj)
                target_measure.insert(local_offset, obj)
                obj.editorial.lily_lane_id = lane_id
                obj.editorial.lily_redirected = True
                touched_origins.add(target_origin)
                moved += 1

    if not moved:
        if skipped:
            warnings.warn(
                f"{input_path}: found {skipped} cross-staff orientation "
                f"marker(s) but couldn't resolve any of them (see "
                f"HumdrumCrossStaffSkippedWarning above for why) -- "
                f"affected notes stay on their original staff.",
                HumdrumCrossStaffSkippedWarning,
            )
        return

    # Tag every OTHER (unmarked) note in the touched spines too, so
    # multi_staff_emitter sees one consistent logical-voice id across
    # the whole spine, not just the notes that happened to move --
    # exactly as importers/lilypond_importer.py's _append() tags every
    # note unconditionally, not only ones that cross.
    #
    # EXCEPT a note sitting inside a genuine Voice sub-container (this
    # spine has its own, unrelated internal divisi somewhere in the
    # piece via a `*^` spine split -- common in real keyboard writing,
    # confirmed against a real Beethoven sonata) -- tagging THOSE with
    # the same blanket lane id would collide two genuinely simultaneous
    # voices into one shared identity. multi_staff_emitter's own
    # per-Voice fallback naming (_collect_measure_events) already keeps
    # a split's sub-voices correctly distinct; overriding it here for
    # every note in the spine broke exactly that, for exactly this
    # piece: confirmed the hard way as one voice's total duration
    # coming out double the other's in every affected measure, from
    # two simultaneous voices being incorrectly treated as one
    # sequential stream.
    from music21 import stream as m21stream
    for origin in touched_origins:
        lane_id = f'humdrum:{origin}'
        for obj in part_of_origin[origin].recurse().notesAndRests:
            if hasattr(obj.editorial, 'lily_lane_id'):
                continue
            if isinstance(obj.activeSite, m21stream.Voice):
                continue
            obj.editorial.lily_lane_id = lane_id

    warnings.warn(
        f"{input_path}: resolved {moved} cross-staff orientation marker(s) "
        f"by rebuilding the affected instrument's MusicXML directly "
        f"(see HumdrumCrossStaffAppliedWarning); spot-check the result "
        f"against the original."
        + (f" {skipped} marker(s) could not be resolved (see "
           f"HumdrumCrossStaffSkippedWarning above)." if skipped else ""),
        HumdrumCrossStaffAppliedWarning,
    )

    from . import multi_staff_emitter

    ordered_origins = sorted(touched_origins, key=lambda o: staff_of_origin.get(o, 0))
    parts_in_order = [part_of_origin[o] for o in ordered_origins]
    cross_staff_lane_ids = {f'humdrum:{o}' for o in touched_origins}
    part_indices = [score.parts.index(p) for p in parts_in_order]

    score_part_xml, part_xml = multi_staff_emitter.merge_parts_to_xml(
        parts_in_order, part_id='PLACEHOLDER_PART_ID',
        part_name=part_of_origin[ordered_origins[0]].partName,
        cross_staff_lane_ids=cross_staff_lane_ids,
    )
    existing = getattr(score, '_manual_multistaff_parts', None) or []
    existing.append({
        'original_part_indices': part_indices,
        'score_part_xml': score_part_xml,
        'part_xml': part_xml,
    })
    score._manual_multistaff_parts = existing
