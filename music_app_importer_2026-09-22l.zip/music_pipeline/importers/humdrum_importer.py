"""
importers/humdrum_importer.py

Humdrum (**kern) -> music21.stream.Score, extracted from the standalone
humdrum_to_musicxml.py script so the pipeline can call it the same way
it calls every other format's importer (see import_score() below and
importers/__init__.py). The embedded-'!!!filter:' handling (satb2gs,
shed substitutions -- see importers/humdrum_filters.py and
importers/satb2gs_python.py, colocated here since they exist only to
support this importer) and the content-sniffing for extensionless
files are unchanged from that script; only the final
`score.write('musicxml', ...)` step has moved out, into
core.import_pipeline.run_job().

STRUCTURAL DIFFERENCE FROM MuseData (unchanged from the standalone
script's docstring)
--------------------------------------------------------------------
A single Humdrum file already holds every part for one movement, as
parallel spines within that one file -- unlike MuseData, which splits
a multi-part work across several files. So, unlike
musedata_importer.import_score(), this importer only ever takes a
single file; a folder of Humdrum files (one per movement) is a batch
of separate jobs, not a single combined Score -- see
humdrum_to_musicxml.py's directory-batch mode for that walking logic
if a CLI/GUI front end wants to offer it.

CROSS-STAFF NOTATION -- DETECTED, NOT (YET) PRESERVED
--------------------------------------------------------------------
Unlike LilyPond's `\\change Staff` (a common, everyday construct in
real keyboard writing -- see importers/lilypond_importer.py and
importers/multi_staff_emitter.py, which fully preserve it), genuine
cross-staff notation in **kern is a rare, exceptional encoding choice:
Humdrum's own documentation describes exactly one such real case (a
Bela Bartok passage), encoded via a `*staff` tandem interpretation
changing value PARTWAY THROUGH a single spine, rather than splitting
the line across two spines outright. Confirmed directly against
music21's own source (music21/humdrum/spineParser.py): its **kern
importer does not act on `*staff` for shaping Part structure at all --
handling it is a disclosed, commented-out TODO there ("make staff
numbers relevant; not in hum2xml") -- so a spine like this imports
with its later notes staying on whichever staff/Part the spine started
on, silently NOT reproducing the crossing.

Given how rare this pattern is against how much new infrastructure a
real fix would need (a custom **kern spine tokenizer feeding
importers/multi_staff_emitter.py, mirroring the scale of importers/
lilypond_sexp.py + lilypond_importer.py's own custom walker -- there is
no existing per-format parser here to extend, unlike LilyPond), this
importer detects the pattern (_detect_cross_staff_spines) and raises
HumdrumCrossStaffNotPreservedWarning naming exactly where it occurs,
rather than silently mis-transcribing it OR investing in full
preservation machinery before knowing whether real files actually need
it. Revisit if it turns out to matter in practice.
"""

import warnings
from pathlib import Path

from core.score_metadata import attach_metadata, new_metadata
from . import humdrum_filters
from .humdrum_lyrics import install as install_lyric_support
from .humdrum_metadata import extract_metadata

HUMDRUM_EXTENSIONS = {".krn", ".hum"}


class HumdrumCrossStaffNotPreservedWarning(UserWarning):
    """Raised when a **kern spine's own `*staff` tandem interpretation
    changes value partway through -- the documented (if rare) **kern
    convention for a single melodic line notated across two staves
    (see module docstring). music21's own Humdrum importer does not
    act on this at all (confirmed in its source: a disclosed,
    commented-out TODO), so the affected spine's later notes silently
    stay on whichever staff/Part it started on instead of crossing as
    encoded. Check the named spine/staff-numbers against the original
    file by hand."""


class HumdrumFilterNoteWarning(UserWarning):
    """An embedded '!!!filter:' record wasn't (fully) applied as written --
    e.g. the built-in Python SATB merger stood in for the compiled
    satb2gs tool, or an unsupported filter was skipped. Informational."""


class HumdrumMetadataWarning(UserWarning):
    """Raised when a file's reference records couldn't be read; the
    notes still import, with an empty metadata dict."""


def looks_like_humdrum(path: Path) -> bool:
    if path.suffix.lower() in HUMDRUM_EXTENSIONS:
        return True
    # Extension missing or unrecognized: sniff content. Real Humdrum
    # files commonly start with one or more '!!!' global reference
    # comments before the '**' exclusive interpretation line (e.g.
    # '**kern') that actually starts the data, so scan a bounded
    # number of leading lines rather than just the first non-blank one.
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for _, line in zip(range(200), f):
                if line.strip().startswith("**"):
                    return True
    except OSError:
        return False
    return False


def _detect_cross_staff_spines(text: str) -> list:
    """[(column_index, [staff_values_seen_in_order])] for every **kern
    spine column whose own `*staff` tandem interpretation value changes
    at some point in the file -- see module docstring for what this
    means and why it's only detected, not yet preserved.

    Column tracking here is deliberately NOT split/merge (`*^`/`*v`)
    aware -- a reasonable simplification given how rare this pattern
    is even without that added complication. This catches the
    documented real-world form (one uninterrupted spine's own `*staff`
    value changing) reliably; it can miss a case that also involves a
    spine split or merge at the very same point.
    """
    is_kern_column = {}
    staff_history = {}
    flagged = {}

    for line in text.splitlines():
        if not line or line[0] in '!=':
            continue
        fields = line.split('\t')
        if line.startswith('**'):
            for i, f in enumerate(fields):
                is_kern_column[i] = (f.strip() == '**kern')
            continue
        if line[0] != '*':
            continue
        for i, f in enumerate(fields):
            f = f.strip()
            if not (is_kern_column.get(i) and f.startswith('*staff')):
                continue
            digits = f[6:]
            if not digits.isdigit():
                continue  # e.g. a compound '*staff1/2' -- not this spine's own single value
            val = int(digits)
            history = staff_history.setdefault(i, [])
            if not history or history[-1] != val:
                history.append(val)
                if len(set(history)) > 1:
                    flagged[i] = list(history)

    return sorted(flagged.items())


def import_score(input_path, apply_filters: bool = True, satb2gs_binary=None, **options):
    """Parse a single Humdrum file into one music21 Score.

    If apply_filters is True (the default), any embedded '!!!filter:'
    records in the file (e.g. 'satb2gs') are applied first -- see
    importers/humdrum_filters.py and the module docstring above. If a
    'satb2gs' filter is present but no compiled satb2gs binary is
    available or buildable, falls back automatically to the
    pure-Python SATB merger in importers/satb2gs_python.py (4-voice
    SATB only).

    Returns just the Score, unlike the standalone script's convert_one()
    (which also wrote the file and printed a summary) -- printing/
    reporting the filter_notes is left to the caller, e.g. via a
    JobResult from core.import_pipeline, since a library function
    shouldn't print to stdout on the pipeline's behalf.
    """
    install_lyric_support()   # lyrics: importers/humdrum_lyrics.py
    from music21 import converter

    input_path = Path(input_path)
    with open(input_path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()

    # Work-level metadata comes from the file's own reference records
    # and comments, read from the text as first loaded (before any
    # '!!!filter:' rewriting) -- see importers/humdrum_metadata.py.
    try:
        work_metadata = extract_metadata(text, input_path)
    except Exception as e:      # metadata must never block the notes
        warnings.warn(f"{input_path}: could not read metadata ({e}); "
                      f"continuing with none.", HumdrumMetadataWarning)
        work_metadata = new_metadata('humdrum', input_path)

    needs_python_satb2gs = False
    if apply_filters and humdrum_filters.extract_filter_commands(text):
        text, filter_notes, needs_python_satb2gs = humdrum_filters.apply_embedded_filters(
            text, satb2gs_binary=satb2gs_binary)
        for note in filter_notes:
            if not note.startswith('Applied'):
                warnings.warn(f"{input_path}: {note}", HumdrumFilterNoteWarning)

    cross_staff_spines = _detect_cross_staff_spines(text)
    if cross_staff_spines:
        details = '; '.join(f'column {i} (staff {" -> ".join(map(str, values))})'
                             for i, values in cross_staff_spines)
        warnings.warn(
            f"{input_path}: {details} -- a **kern spine's own `*staff` "
            f"value changes partway through, the documented (if rare) "
            f"convention for a single line notated across two staves. "
            f"music21's own Humdrum importer does not act on this, so "
            f"the affected spine's later notes will silently stay on "
            f"whichever staff/Part it started on. Check this passage "
            f"against the original by hand.",
            HumdrumCrossStaffNotPreservedWarning,
        )

    score = converter.parse(text, format="humdrum", forceSource=True)

    if needs_python_satb2gs:
        from . import satb2gs_python
        score = satb2gs_python.merge_satb_to_grand_staff(score)

    from . import humdrum_crossstaff
    humdrum_crossstaff.apply_cross_staff_markers(score, text, input_path)

    attach_metadata(score, work_metadata)
    return score
